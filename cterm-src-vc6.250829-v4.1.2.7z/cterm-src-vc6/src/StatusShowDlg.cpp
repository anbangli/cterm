// StatusShowDlg.cpp : implementation file
//
#include "stdafx.h"
#include "viewstatus.h"

#ifdef _DEBUG_STATUS

#include "StatusShowDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStatusShowDlg dialog


CStatusShowDlg::CStatusShowDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CStatusShowDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStatusShowDlg)
	m_info = _T("");
	m_sContent = _T("");
	//}}AFX_DATA_INIT
}

void CStatusShowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStatusShowDlg)
	DDX_Text(pDX, IDC_INFO, m_info);
	DDX_Text(pDX, IDC_CONTENT, m_sContent);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStatusShowDlg, CDialog)
	//{{AFX_MSG_MAP(CStatusShowDlg)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStatusShowDlg message handlers

CString GetStatusString(const int n, const int sub);
void CStatusShowDlg::SetStatus(int n, int sub)
{
	m_info = GetStatusString(n, sub);
	UpdateData(FALSE);
}

BOOL CStatusShowDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


	SetStatus(0, 0);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

class CCTermView;
void CStatusShowDlg::OnOK()
{
}

void CStatusShowDlg::OnSend()
{
	UpdateData();

	if (m_pView) {
		TCHAR buf[100], *p = buf;
		int len = m_sContent.GetLength();

		for (int i = 0; i < len; i++) {
			TCHAR ch = m_sContent.GetAt(i);

			if (ch == '\\') {
				switch (m_sContent.GetAt(++i)) {

				case 'n':

				case 'N':
					*p++ = '\n';

				case 'r':

				case 'R':
					*p++ = '\r';
				}
			} else
				*p++ = ch;
		}

		*p = 0;

		m_pView->Send(buf, _tcslen(buf));
	}
}

BOOL CStatusShowDlg::Create(UINT nID, CWnd* pParentWnd)
{
	m_pView = (CCTermView*) pParentWnd;
	return CDialog::Create(IDD, pParentWnd);
}

void CStatusShowDlg::OnCancel()
{
	CDialog::OnCancel();
}

#endif //_DEBUG_STATUS





