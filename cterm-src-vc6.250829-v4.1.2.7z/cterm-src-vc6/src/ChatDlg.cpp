// ChatDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ChatDlg.h"
#include "getstrdlg.h"
#include "ctermview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChatDlg dialog
CChatDlg::CChatDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CChatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChatDlg)
	m_command = _T("");
	m_user = _T("");
	//}}AFX_DATA_INIT
	m_bRepload = FALSE;
}


void CChatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChatDlg)
	DDX_Control(pDX, IDC_COMMANDLIST, m_comlist);
	DDX_Control(pDX, IDC_LIST, m_list);
	DDX_LBString(pDX, IDC_COMMANDLIST, m_command);
	DDX_LBString(pDX, IDC_LIST, m_user);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChatDlg, CDialog)
	//{{AFX_MSG_MAP(CChatDlg)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_RELOAD, OnReload)
	ON_LBN_DBLCLK(IDC_COMMANDLIST, OnDblclkCommandlist)
	ON_BN_CLICKED(IDC_CHANGECSF, OnChangecsf)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChatDlg message handlers

void CChatDlg::OnOK()
{
	CDialog::OnOK();
}

void CChatDlg::OnCancel()
{
	CDialog::OnCancel();
}

void CChatDlg::OnSize(UINT nType, int cx, int cy)
{
	CRect  rect, rectWindow;
	CDialog::OnSize(nType, cx, cy);

	if (GetDlgItem(IDC_LIST)) {
		GetClientRect(&rectWindow);
		rect.top = 0;
		rect.bottom = rectWindow.Height() - 22;
		rect.left = 0;
		rect.right = rectWindow.Width() / 2 - 1;
		m_list.MoveWindow(&rect);
		rect.top = rectWindow.Height() - 21;
		rect.bottom = rectWindow.Height();
		rect.right = rectWindow.Width() / 2;
		GetDlgItem(IDC_RELOAD)->MoveWindow(&rect);
		rect.top = 0;
		rect.bottom = rectWindow.Height() - 22;
		rect.left = rectWindow.Width() / 2 - 1;
		rect.right = rectWindow.Width();
		GetDlgItem(IDC_COMMANDLIST)->MoveWindow(&rect);
		rect.top = rectWindow.Height() - 21;
		rect.bottom = rectWindow.Height();
		rect.left = rectWindow.Width() / 2 + 1;
		rect.right = rectWindow.Width();
		GetDlgItem(IDC_CHANGECSF)->MoveWindow(&rect);

	}
}

CChatDlg g_wndChat;

void static GetLine(TCHAR *buf, int &at, TCHAR *Line)
{
	int i = 0;

	while (buf[at] && buf[at] != '\r' && buf[at] != '\n' && i < 256) {
		Line[i] = buf[at];
		at++;
		i++;
	}

	Line[i] = 0;
}

void CChatDlg::AddToList(BYTE *buf, int nLen)
{
	TCHAR Line[256];
	int at = 0;
	nLen = _tcslen((TCHAR *) buf);

	if (!m_bRepload) return;

	do {
		GetLine((TCHAR *) buf, at, Line);
		AddLine(Line);

		while (buf[at] == '\r' || buf[at] == '\n')
			at++;
	} while (at < nLen && buf[at]);
}


void CChatDlg::AddLine(TCHAR *Line)
{
	int nESC = 0, nLen, i, n = 0;
	BOOL bIn = FALSE;
	TCHAR ts[256];
	nLen = _tcslen(Line);
	int nWord = 0, nStart;
	TCHAR szWord[256];
	//����ԺϷ��Եļ��,����*,�����ַ���

	if (nLen < 100) {
		return;
	}

	for (i = 0; i < nLen; i++)
		if (Line[i] == 27) nESC++;

	if (nESC < 8) {
		return;
	}

	for (i = 0; i < nLen; i++) {
		if (Line[i] == 27)
			bIn = TRUE;
		else
			if (bIn) {
				if ((Line[i] >= 'A' && Line[i] <= 'Z') || (Line[i] >= 'a' && Line[i] <= 'z')) {
					bIn = FALSE;
				}
			} else {
				ts[n] = Line[i];
				n++;
			}
	}

	ts[n] = 0;

	nLen = n;
	n = i = 0;

	while (ts[i] == ' ') i++;

	nStart = i;

	while (i < nLen) {
		while (ts[i] == ' ') i++;

		while (ts[i] != ' ') i++;

		nWord++;

		if (nWord == 1) {
			_tcsncpy(szWord, ts + nStart, i - nStart);
			szWord[i-nStart] = 0;
		}
	}

	if (nWord < 4) {
		m_bRepload = FALSE;
		return;
	}

	szWord[8] = 0;

	if (m_list.FindString(0, szWord) == -1 && _tcslen(szWord) && _tcsnicmp(_T("����"), szWord, 4))
		m_list.AddString(szWord);
}

void CChatDlg::OnReload()
{
	m_list.ResetContent();
	m_pView->Send(_T("\n/l\n"), 4);
	m_bRepload = TRUE;
}

static int GetCommand(const TCHAR *szLine, TCHAR *szCommand, TCHAR *szOp)
{
	const TCHAR *p = szLine;
	int  n = 0;
	BOOL bID = FALSE, bMSG = FALSE;

	while (*p && *p != 13 && *p != 10 && *p != '=') {
		szCommand[n] = *p;
		p++;
		n++;
	}

	szCommand[n] = 0;

	if (*p == '=')
		p++;
	else
		return -1;

	n = 0;

	while (*p && *p != 13 && *p != 10 && *p != ',') {
		szOp[n] = *p;
		p++;
		n++;
	}

	szOp[n] = 0;

	if (*p == ',')
		p++;
	else
		return CC_COMMON;

	if (!_tcsnicmp(_T("id"), p, 2)) {
		bID = TRUE;

		if (!_tcsnicmp(_T("msg"), p + 3, 3))
			bMSG = TRUE;
	} else
		if (!_tcsnicmp(_T("msg"), p, 2)) {
			bMSG = TRUE;

			if (!_tcsnicmp(_T("id"), p + 4, 2))
				bID = TRUE;
		}

	if (!bMSG && !bID)
		return CC_COMMON;

	if (bMSG && !bID)
		return CC_MSGONLY;

	if (bID && !bMSG)
		return CC_IDONLY;

	return CC_BOTH;
}

BOOL CChatDlg::OnInitDialog()
{
	FILE *fp;
	TCHAR Line[256], szCommand[100], szOp[100];
	int nType, at, nCommand = 0;
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	CString szChatFile = g_szWorkDir + _T("cterm.csf");
	m_comlist.ResetContent();
	fp = _tfopen(szChatFile, _T("rt"));

	if (!fp)
		return TRUE;

	while (_fgetts(Line, 256, fp)) {
		nType = GetCommand(Line, szCommand, szOp);

		if (nType != -1 && m_comlist.FindString(0, szCommand) == -1 && nCommand < 200) {
			at = m_comlist.AddString(szCommand);
			_tcscpy(m_Command[nCommand].szOp, szOp);
			m_Command[nCommand].nType = nType;
			m_comlist.SetItemData(at, (DWORD) &m_Command[nCommand]);
			nCommand++;
		}
	}


	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CChatDlg::OnDblclkCommandlist()
{
	int n;
	SChatCommand *pCommand;
	TCHAR ts[256];
	CGetStrDlg Dlg;
	UpdateData();
	n = m_comlist.GetCurSel();

	if (n == -1) return;

	pCommand = (SChatCommand *) m_comlist.GetItemData(n);

	_tcscpy(ts, _T(""));

	switch (pCommand->nType) {

	case CC_COMMON:
		_stprintf(ts, _T("%s\n"), pCommand->szOp);
		break;

	case CC_IDONLY:
		_stprintf(ts, _T("%s %s\n"), pCommand->szOp, m_user);
		break;

	case CC_BOTH:

		if (Dlg.DoModal() == IDOK) {
			_stprintf(ts, _T("%s %s %s\n"), pCommand->szOp, m_user, Dlg.m_input);
		} else
			return;

		break;

	case CC_MSGONLY:
		if (Dlg.DoModal() == IDOK) {
			_stprintf(ts, _T("%s %s\n"), pCommand->szOp, Dlg.m_input);
		} else
			return;

		break;
	}

	if (m_pView->IsStarted() && _tcslen(ts))
		m_pView->Send(ts, _tcslen(ts));
}

void CChatDlg::OnChangecsf()
{
	CFileDialogEx fd(TRUE, _T("csf"), _T("*.csf"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("CTerm ���춯�������ļ�(*.csf)|*.csf||"));
	FILE *fp;
	TCHAR Line[256], szCommand[32], szOp[32];
	int  nCommand = 0, nType, at;

	if (fd.DoModal() == IDOK) {
		m_comlist.ResetContent();
		fp = _tfopen(fd.GetPathName(), _T("rt"));

		if (!fp)
			return;

		while (_fgetts(Line, 256, fp)) {
			nType = GetCommand(Line, szCommand, szOp);

			if (nType != -1 && m_comlist.FindString(0, szCommand) == -1 && nCommand < 200) {
				at = m_comlist.AddString(szCommand);
				_tcscpy(m_Command[nCommand].szOp, szOp);
				m_Command[nCommand].nType = nType;
				m_comlist.SetItemData(at, (DWORD) &m_Command[nCommand]);
				nCommand++;
			}
		}

	}
}
