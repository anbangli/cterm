// Base64.cpp: implementation of the CBase64 class.
// Author: Wes Clyburn (clyburnw@enmu.edu)
//
// This code was practically stolen from:
// Dr. Dobb's Journal, September 1995,
// _T("Mime and Internet Mail"), by Tim Kientzle
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#if ENABLE_BASE64

#include "Base64.h"

#include <stdlib.h>
#include <memory.h>

// The 7-bit alphabet used to encode binary information
const TCHAR *szBase64Alphabet = _T("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
const int nMask[] = {0, 1, 3, 7, 15, 31, 63, 127, 255};

int nInputSize;
int nBitsRemaining;
unsigned long lBitStorage;
const TCHAR *szInput;

unsigned long ReadBits(int nNumBits, int *pBitsRead, int& lp)
{
	unsigned long lScratch;

	while ((nBitsRemaining < nNumBits) && (lp < nInputSize)) {
		int c = szInput[ lp++ ];

		lBitStorage <<= 8;
		lBitStorage |= (c & 0xff);
		nBitsRemaining += 8;
	}

	if (nBitsRemaining < nNumBits) {
		lScratch = lBitStorage << (nNumBits - nBitsRemaining);
		*pBitsRead = nBitsRemaining;
		nBitsRemaining = 0;
	} else {
		lScratch = lBitStorage >> (nBitsRemaining - nNumBits);
		*pBitsRead = nNumBits;
		nBitsRemaining -= nNumBits;
	}

	return lScratch &nMask[nNumBits];
}

void WriteBits(unsigned int nBits, int nNumBits, TCHAR *szOutput, int& i)
{
	unsigned int nScratch;

	lBitStorage = (lBitStorage << nNumBits) | nBits;
	nBitsRemaining += nNumBits;

	while (nBitsRemaining > 7) {
		nScratch = lBitStorage >> (nBitsRemaining - 8);
		szOutput[ i++ ] = nScratch & 0xFF;
		nBitsRemaining -= 8;
	}
}

TCHAR *Base64Encode(const TCHAR *szEncoding, int nSize)
{
	if (!szEncoding || !nSize)
		return NULL;

	TCHAR *szOutput = (TCHAR *) malloc(nSize * 2);

	int nIndex = 0;

	int nNumBits = 6;

	unsigned int nDigit;

	int lp = 0;

	szInput = szEncoding;

	nInputSize = nSize;

	nBitsRemaining = 0;

	lBitStorage    = 0;

	nDigit = ReadBits(nNumBits, &nNumBits, lp);

	while (nNumBits > 0) {
		szOutput[nIndex++] = szBase64Alphabet[(int) nDigit];
		nDigit = ReadBits(nNumBits, &nNumBits, lp);
	}

	// Pad with '=' as per RFC 1521
	while (nIndex % 4)
		szOutput[nIndex++] = '=';

	szOutput[nIndex] = NULL;

	return szOutput;
}

// The size of the output buffer must not be less than
// 3/4 the size of the input buffer. For simplicity,
// make them the same size.
TCHAR *Base64Decode(const TCHAR *szDecoding, int nSize)
{
	if (!szDecoding || !nSize)
		return NULL;

	int c, lp = 0, nDigit, nDecode[256];

	TCHAR *szOutput = (TCHAR *) malloc(nSize);

	szInput = szDecoding;


	// Build Decode Table
	//
	int i;

	for (i = 0; i < 256; i++)
		nDecode[i] = -2; // Illegal digit

	for (i = 0; i < 64; i++) {
		nDecode[szBase64Alphabet[i]] = i;
		nDecode[szBase64Alphabet[i] | 0x80] = i; // Ignore 8th bit
		nDecode['='] = -1;
		nDecode['=' | 0x80] = -1; // Ignore MIME padding TCHAR
	}

	// Clear the output buffer
	memset(szOutput, 0, nSize + 1);

	// Decode the Input
	//
	for (lp = 0, i = 0; lp < nSize; lp++) {
		c = szInput[lp];
		nDigit = nDecode[c & 0x7F];

		if (nDigit < -1) {
			return 0;
		} else if (nDigit >= 0) {
			// i (index into output) is incremented by WriteBits()
			WriteBits(nDigit & 0x3F, 6, szOutput, i);
		}
	}

	return szOutput;
}

int IsBase64Char(TCHAR c)
{
	TCHAR *base64 = _T("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");
	int i;

	for (i = 0; i < 64; i++)
		if (c == base64[i])
			return i + 1;

	if (c == '=') return -1;

	return 0;
}

int IsBase64(TCHAR *s)
{
	BYTE mask[1000];
	int len = _tcslen(s);
	int i, n = 0, m = 0, start = 0, t, w = 0;

	if (len > 1000) len = 1000;

	for (i = 0; i < len; i++)
		mask[i] = IsBase64Char(s[i]);

	i = 0;

	while (i < len) {
		while (!mask[i] && i < len) i++;

		if (i >= len) break;

		m = 0;

		t = i;

		while (mask[i] && i < len) {
			i++;
			m++;
		}

		if (m > 25 || (m % 4 == 0 && m >= 12)) {
			n++;
			start = t;
		} else
			if (m > 2) {
				w++;

				if (w > 2)
					return 0;
			}
	}

	if (n == 1) {
		/*i=0;
		while(!mask[i]&&i<len)i++;
		if(i>=len)return 0;
		start=i;
		while(mask[i]&&i<len){
		  m++;
		  i++;
		}
		if(m>25||(m%4==0&&m>=8&&len>12))*/
		return start + 1;
	}

	return 0;
}

void DecodeBase64(TCHAR *line)
{
	TCHAR s[1000], c;
	BYTE buf[4], obuf[3];
	int start, n, bat = 0, sat = 0;
	int len = _tcslen(line);

//#pragma warning( disable : 4706 )
	//if (!(start = IsBase64(line)))
	start = IsBase64(line);
	if (!start)
		return;
//#pragma warning( default : 4706 )
	
	start--;

	n = start;

	_tcsncpy(s, line, start);

	sat = start;

	do {
		c = IsBase64Char(line[n]);

		if (!c) break;

		c--;

		if (c == -2)
			c = 0;

		buf[bat] = c;

		bat++;

		if (bat >= 4) {
			obuf[0] = (buf[0] << 2) + (buf[1] >> 4);
			obuf[1] = ((buf[1] & 0xf) << 4) + (buf[2] >> 2);
			obuf[2] = ((buf[2] & 0x3) << 6) + (buf[3]);
			s[sat] = obuf[0];
			s[sat+1] = obuf[1];
			s[sat+2] = obuf[2];
			sat += 3;
			bat = 0;
		}

		n++;
	} while (n < len);

	s[sat] = 0;

	if (n < len)
		_tcscat(s, line + n);

	_tcscpy(line, s);
}
#endif//ENABLE_BASE64