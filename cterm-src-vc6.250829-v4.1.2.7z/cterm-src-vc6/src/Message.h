// Message.h: interface for the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MESSAGE_H__1CCC30EC_432E_489C_B459_7D7316474044__INCLUDED_)
#define AFX_MESSAGE_H__1CCC30EC_432E_489C_B459_7D7316474044__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTelnetSite;

#include "const.h"

class CMessage
{

public:
	void WriteToFile(const CTelnetSite *pSite, const LPCTSTR szPath);
	TCHAR szUserName[20];
	BOOL bReply;
	TCHAR szMes[DEFAULT_TERM_WIDTH*12+1]; ///TERM_WIDTH: �˴��ݲ��ܶ�����Ӱ������ļ���ʽ
	CTime MesTime;
	CMessage();
	BYTE  reserved[10];
	virtual ~CMessage();
};

#endif // !defined(AFX_MESSAGE_H__1CCC30EC_432E_489C_B459_7D7316474044__INCLUDED_)
