#include "stdafx.h"
#include "ctermview.h"
#include "paramconfig.h"
#include "usermsg.h"
#include "debugtool.h"
#include "mainfrm.h"

extern int g_nConnectionType;

#if ENABLE_CTD
#if ENABLE_RAWCTD
// return:
// 0: RECV
// 1: SEND
// 2: FAIL(END)
int GetPacket(FILE *fp, BYTE *buf, int &nLen)
{
	if (fp) {
//		int pos = ftell(fp);
		TCHAR ch; //for \n
		TCHAR action[5] = _T("");

		if (_ftscanf(fp, _T("%c%c%c%c%c%010d%c"),
		             &ch,
		             action + 0, action + 1, action + 2, action + 3,
		             &nLen,
		             &ch
		            ) == 7) {
//			pos = ftell(fp);
			if (fread(buf, nLen, 1, fp) == 1) {
//				pos = ftell(fp);

				buf[nLen] = '\0';

				if (action[0] == 'R') {
					//RECV
					return 0;
				}
				else {
					//SEND
					//nLen = 0; // ������ȵ��ú������ã�ֻ������ʾδ�յ�����
					return 1;
				}
			}
		}
	}

	//nLen = -1;//fail

	return 2;
}

void CCTermView::GetNextPacket(FILE *fp)
{
TRACE("in GetNextPacket\n");
	ASSERT(m_nCtdFile > 0 && m_nCtdFile < 4);
	if (fp == NULL)
		return;

	long c = ftell(fp);
	if (feof(fp)) {
		m_bCtdWait = true;
		rewind(fp);

		if (m_bCtd_Loading) {
			m_bCtd_Loading = false;
			m_Core.ScreenLast();
			Refresh();
			m_Core.CopyOutCsm();
		}
		
		return;
	}
	else {
		if (c == 0) {
			// �ִ�ͷ��ʼ����
			m_Core.InitCsm(); // ���ԭ�����ļ�
			SetStatusBar(ID_SEPARATOR,  _T(""));
			m_Core.AddTxt(_T("\x1b[2J"), 4, true);// clear screen
		}
	}

	//int lastLen = m_Sock.m_nLen;
		
	if (m_Sock.buf_in == NULL) {
#if ENABLE_BUF_QUEUE
		m_Sock.buf_in = m_Sock.m_bufpool.getBuf();
#else
		m_Sock.buf_in = new BYTE[m_Sock.m_nRecvBufLen];
#endif//ENABLE_BUF_QUEUE
	}
	
	int rr = GetPacket(fp, m_Sock.buf_in, m_Sock.m_nLen);

	c = ftell(fp);

	int p = int(100 * ((double)c / m_filesize));

	CString sInfo;
	sInfo.Format(_T("%d%%. len: %d "), p, m_Sock.m_nLen);

	if (rr == 0) {
		m_Sock.OnReceive(-1);
	}
	else if (rr == 1) {
		// SEND
		sInfo += _T("send: ");
		sInfo += ESCStr(m_Sock.buf_in);
	}
	else {
		sInfo += _T("over.");
	}

	SetStatusBar(ID_SEPARATOR,  sInfo);
}

// �鿴raw ansi ctd/csm
// �� Navigator ����
void CCTermView::Navigator1(const TCHAR *file, int nType)
{
	g_pMainWnd->ShowAsciiBar();

	m_nCtdFile = nType; //3=raw ansi ctd, 4=csm

	m_Site.SetDefault(_T("127.0.0.1"));

	// for utf-8
	// ������ctd�ļ�ͷ����һ��CTelnetSite
	//m_Site.m_Decode.m_nInputCodeConvert = INPUT_B2G;
	//m_Site.m_Decode.m_nOutputCodeConvert = OUTPUT_U2G;
//
//	m_nCharHWRatio = 0;

	strncpy(m_Site.m_Login.m_szSiteName, "_ctd", 5); // Ϊ����ȷ����SetViewFont��SetScrollSizes

	LoadSiteInfo();

	m_ctd_fp = _tfopen(file, _T("rb"));
	if (m_ctd_fp == NULL) return;

	fseek(m_ctd_fp, 0, SEEK_END);
	m_filesize = ftell(m_ctd_fp);
	rewind(m_ctd_fp);

	m_Status.Init(&m_Core, NULL);
	m_bInited = true;
	m_Sock.m_nStatus = PSOCK_CONNECTED;

	if (nType == 3) {
		// todo: get size
	}
	else if (nType == 4) {
		if (!m_Core.CheckCsm(m_ctd_fp)) {
			AfxMessageBox(_T("�ļ���ʽ��Ч"));
			return;
		}
	}

	// ��ʱ��֪����Ļ����
	// Ӧ��LoadSiteInfo���жϣ���������
	if (m_nMaxHistLine < m_nTermHeight) m_nMaxHistLine = m_nTermHeight;
	m_Core.Init();

	// ��ʾ��һ��
	if (nType == 3) {
		while(m_Sock.m_nLen <= 0)
			GetNextPacket(m_ctd_fp);
	}
	else if (nType == 4) {
		m_Core.ScreenJump(0);
	}

	SetTimer(TIMER_CTD_FILE, 500, NULL);
}

void CCTermView::OnCtdplay() 
{
	if (m_bCtdWait) {
		// ��ʼ����
		m_bCtdWait = false;		
		if (m_nCtdFile == 3) {
			GetNextPacket(m_ctd_fp);
		}
	}
	else {
		m_bCtdWait = true;
	}
}

void CCTermView::OnUpdateCtdplay(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(!m_bCtdWait && !m_bCtd_Loading);
	pCmdUI->Enable(m_nCtdFile == 3 || m_nCtdFile == 4);	
}

#if ENABLE_SCREENMAP
void CCTermView::OnCtdup() 
{
	if (m_bCtdWait && !m_bCtd_Loading)
		m_Core.ScreenUp();
}

void CCTermView::OnCtddown() 
{
	if (m_bCtdWait && !m_bCtd_Loading)
		m_Core.ScreenDown();
}

void CCTermView::OnUpdateCtdup(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nCtdFile == 4
		|| ((m_nCtdFile == 0 || m_nCtdFile == 3) && m_bCtdWait && !m_bCtd_Loading
		&& m_Core.HisScreenNum() > 0 && m_Core.CurScreen() > 0));
}

void CCTermView::OnUpdateCtddown(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nCtdFile == 4
		|| ((m_nCtdFile == 0 || m_nCtdFile == 3) && m_bCtdWait && !m_bCtd_Loading
		&& m_Core.HisScreenNum() > 0 && m_Core.CurScreen() < m_Core.HisScreenNum() - 1));
}
#endif//ENABLE_SCREENMAP

void CCTermView::OnCtdload() 
{
	if (m_nCtdFile == 3) {
		if (m_bCtd_Loading) {
			KillTimer(TIMER_CTD_FILE);
			SetTimer(TIMER_CTD_FILE, 500, NULL);//restore timer
			
			m_bCtdWait = true;
			m_bCtd_Loading = false;
		}
		else {
			KillTimer(TIMER_CTD_FILE);
			SetTimer(TIMER_CTD_FILE, 0, NULL);
			
			m_bCtdWait = false;
			GetNextPacket(m_ctd_fp);
			
			m_bCtd_Loading = true;
		}
	}
	else if (m_nCtdFile == 0) {
		m_Core.CopyOutCsm();
	}
}

#endif//ENABLE_RAWCTD

// todo:
// ������һ�����⣬�ڴ򿪷Ǳ�׼size��Term�����������ļ�ʱ�ͻ������
// ���size��ϢҲ��Ҫ�������ļ���
// �ļ��˵�->�鿴�ն��ļ�: *.ctd
void CCTermView::Navigator(const TCHAR *file)
{
	FILE *fp = _tfopen(file, _T("rb"));

	if (fp == NULL) {
		AfxMessageBox(_T("���ļ�ʧ��!"));
		return;
	}

	// �򱣴�lastsite
	g_szLastSiteName = file;
	g_nConnectType = g_nConnectionType;

#if ENABLE_RAWCTD
	TCHAR flag[5] = _T("");

	fread(flag, 5, 1, fp);

	if (_tcsncmp(flag + 1, _T("RECV"), 4) == 0 || _tcsncmp(flag + 1, _T("SEND"), 4) == 0) {
		fclose(fp); // Ҫ��ǰ��رգ���ΪNavigator1Ҫ�����ļ�
		Navigator1(file);
	}
	else if(_tcsncmp(flag + 1, _T("CSM"), 3) == 0) {
		fclose(fp);
		Navigator1(file, 4);
	}
#endif//ENABLE_RAWCTD
	else {
		m_nCtdFile = 2; // Ϊ��ʲô��2?
		
		m_Site.SetDefault(_T(""));
		m_Core.Init();
		
		fseek(fp, 0, SEEK_END);
		int nSize = ftell(fp);	
		if (nSize > 64000) nSize = 64000;
		
		//buf & m_pszSource, ugly
		
		char *buf = new char[nSize + 1];
		
		fseek(fp, 0, SEEK_SET);
		fread(buf, nSize, 1, fp);  // ȷ���ռ��㹻�������Ǿ�̬����100000
		fclose(fp);
		
		m_Status.Init(&m_Core, NULL);
		buf[nSize] = 0;
		m_Site.m_Login.m_szSiteName[0] = '_'; // Ϊ����ȷ����SetViewFont��SetScrollSizes
		m_bInited = true;
		m_Core.AddTxt(buf, nSize);
		delete [] buf;
		m_nCtdFile = 1;
	}
	Refresh();
}
#endif//ENABLE_CTD
