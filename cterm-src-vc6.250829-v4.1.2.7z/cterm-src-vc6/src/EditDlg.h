#if !defined(AFX_EDITDLG_H__B346F75D_70A4_47AF_99EA_580731D4110B__INCLUDED_)
#define AFX_EDITDLG_H__B346F75D_70A4_47AF_99EA_580731D4110B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditDlg dialog

class CCTermView;

#define _UNICODE

class CEditDlg : public CDialog
{
// Construction
	DECLARE_DYNAMIC(CEditDlg)
public:
	CEditDlg(CWnd* pParent = NULL);   // standard constructor
	CCTermView *m_pView;
	void OnPost();
	
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
// Dialog Data
	//{{AFX_DATA(CEditDlg)
	enum { IDD = IDD_EDIT };
	CButton	m_bnAutoSave;
	CButton	m_bnViewHis;
	CButton	m_bnCancel;
	CButton	m_bnPost;
	CButton	m_bnSave;
	CButton	m_bnLoad;
	CButton	m_bnConfigPaste;
	CButton	m_bnCancelEdit;
	CButton	m_bnPaste;
	BOOL	m_autospace;
	BOOL	m_autowarp;
	int		m_linemax;
	CString	m_edit;
	CEdit	m_editCtrl;
	BOOL	m_bAutoSave;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditDlg)

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	CFont m_Font;

	// Generated message map functions
	//{{AFX_MSG(CEditDlg)
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnCtvLoad();
	afx_msg void OnCtvSave();
	afx_msg void OnPaste();
	afx_msg void OnConfigPaste();
	afx_msg void OnCancelEdit();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnDestroy();
	afx_msg void OnViewhis();
	afx_msg void OnAutosave();
	afx_msg void OnInsertansi();
	afx_msg void OnInscolor();
	afx_msg void OnInscursor();
	afx_msg void OnInsj();
	afx_msg void OnInsk();
	afx_msg void OnInsm();
	afx_msg void OnInsbel();
	afx_msg void OnInsfont0();
	afx_msg void OnInsfont1();
	afx_msg void OnInsfont2();
	afx_msg void OnInsfont3();
	afx_msg void OnInschar();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	inline void MoveVertDlgItem(CWnd &item, int offset, CRect &rect, CRect &rectDlg);
	void Save(CString & s); // ���浽mypost.txt
	void setFont();
};
#undef _UNICODE

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITDLG_H__B346F75D_70A4_47AF_99EA_580731D4110B__INCLUDED_)
