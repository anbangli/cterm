// AutoRun.cpp: implementation of the CAutoRun class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AutoRun.h"
#include "ctermview.h"

#include "debugtool.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int CAutoRun::m_nTimeOut = 5000;

CAutoRun::CAutoRun()
{
	m_nStatus = 0;
	m_bWait = FALSE;
	m_nPastTime = 0;
	m_nWaitViewStatus = SST_UNKNOWN;
	m_nNextStatus = 0;
}

CAutoRun::~CAutoRun()
{

}

void CAutoRun::EnterNextStage(const TCHAR *buf, int nLen, SITESTATUS nViewStatus, int nNext, int nTimeOut)
{
	ASSERT(nLen == _tcslen(buf));

	if (nLen > 0) {
		m_pView->Send(buf, nLen);
		m_pView->SetWaitReceive(true); // �ж����ŵȴ����޶������ȴ�	
		m_bWait = TRUE;
	}

	TRACE(_T("EnterNextStage %d, next:%d, buf:%10s m_bWaitReceive = TRUE\n"), nViewStatus, nNext, ESCStr(buf));

//	m_nTimeOut = 5000;
	m_nPastTime = 0;
	m_nWaitViewStatus = nViewStatus;
	m_nNextStatus = nNext;
	m_nTime = clock();
}

void CAutoRun::Create(CCTermView *pView)
{
	m_pView = pView;
}

AutoRunStatus CAutoRun::QueryStatus()
{
	if (!m_bWait)
		return AutoRun_NoWait;

	if (!m_pView) {
		return AutoRun_Unknown;
	}

	if (m_pView->WaitReceive())
		return AutoRun_Wait;//Wait

	SITESTATUS st = m_pView->GetStatus();

	TRACE(_T("CAutoRun::QueryStatus m_nWaitViewStatus:%d; st:%d; m_bWaitReceive:%d ArticleChanged:%d\n"),
	      m_nWaitViewStatus, st, m_pView->WaitReceive(), m_pView->m_Status.ArticleChanged());

	if (m_nWaitViewStatus == SST_ARTICLE &&
	        (st == SST_ARTICLE ||
	         st == SST_END ||
	         st == SST_ENTER)) {
		if (m_pView->m_Status.ArticleChanged())
			return AutoRun_OK;
		else
			return AutoRun_Wait; //������ʾδ���
	}

	if (m_nWaitViewStatus == st)
		return AutoRun_OK;

	if (m_nWaitViewStatus == SST_DIGEST_UNKNOWN) {
		if (st == SST_ARTICLE
	     || st == SST_END
		 || st == SST_ENTER) {
			return AutoRun_OK;
		}
		else if (st == SST_LIST) {
			// ��ǰ�˳���
			// ִ��һ���޶�����PopStatus("")
			return AutoRun_PreExit;
		}
	}

	if (m_nWaitViewStatus == SST_ANY)
		return AutoRun_OK;

	m_nPastTime = clock() - m_nTime;

	if (m_nPastTime > m_nTimeOut)
		return AutoRun_Timeout;//Time Out;

//	if (m_nWaitViewStatus == DDS_UNKNOWN) //��û�б�Ҫ������ProcessUnkown()�ﴦ��?
//		return AutoRun_OK;

	return AutoRun_Unknown;
}

void CAutoRun::ChangeStatus(int nNextStatus)
{
	TRACE(_T("ChangeStatus %d\n"), nNextStatus);
	m_nWaitViewStatus = m_pView->GetStatus();
	m_nNextStatus = nNextStatus;
}
