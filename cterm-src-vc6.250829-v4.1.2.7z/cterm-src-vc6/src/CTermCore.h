// CTermCore.h: interface for the CCTermCore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTERMCORE_H__A8043F10_0ADD_11D4_B1E0_000080013F30__INCLUDED_)
#define AFX_CTERMCORE_H__A8043F10_0ADD_11D4_B1E0_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if ENABLE_GRAPH
#include "Graph.h"
#endif //ENABLE_GRAPH

#include "screen.h"
#include "onechar.h"

struct SEscSeq {
	TCHAR m_szEsc[256];
	int  m_nParamNum;
	int  m_nParam[20];
	BOOL m_bExtend; //*[...?*<>
	BOOL m_bNormal; // *[ | *M False
	TCHAR m_Char;
	TCHAR m_szExtend[256];
	SEscSeq();
};

#define LT_NONE    0
#define LT_URL     1
#define LT_REPLY   2
#define LT_COMMAND 3
#define URLT_SITE  0
#define URLT_FILE  1
#define URLT_PIC   2
#define URLT_BBS   3
#define URLT_MAIL  4

//#if ENABLE_LINK
struct SOneLink {
	BYTE  m_bUse;
	BYTE  m_nType;
	TCHAR  m_szURL[100];

public:
	void Reset();
};

struct SLink {
	SOneLink Link[256];

public:
	void Reset();
	void DeleteLink(int nLink);
	int AddLink(SOneLink &aLink);
};
//#endif//ENABLE_LINK

#define GSE_ESC     0
//#define GSE_NEWLINE 1
#define GSE_BUF_FULL	6
#define GSE_ENTER   2
#define GSE_RETURN  5
//#define GSE_BS		4
#define GSE_END     3
#define GSE_TAB     9 //\t=9
#define GSE_ERROR  -1
#define DEFAULT_TAB_WIDTH 8

// �滻ʱ��һ��������¼���滻�����ݣ�λ��

#if ENABLE_REPLACEIP
struct ipNode {
	TCHAR backline[MAX_LINE_CHAR];
	//CString addr; //�ɲ���
	int y; // ��������
	//int startx;
	//int endx;
//	ipNode *next;
};
#endif//ENABLE_REPLACEIP

class CCTermView;

class AFX_CLASS_EXPORT CCTermCore
{
public:
	CCTermCore();
	~CCTermCore();

	void Init();
public:
	// accessors
	void SetView(CCTermView *pView)
	{
		m_pView = pView;
	}
	
	CCTermView *getView() const
	{
		return m_pView;
	}

#if ENABLE_MESSAGE
	bool MesIn() const
	{
		return m_bMesIn;
	}

	void SetMesIn(bool b)
	{
		m_bMesIn = b;
	}
	
	int BelSeq() const
	{
		return m_nBelSeq;
	}

	void DecBelSeq()
	{
		--m_nBelSeq;
	}
#endif//ENABLE_MESSAGE

	bool Changed() const
	{
		return m_bChanged;
	}

	int MaxStartLine() const
	{
		return m_nMaxStartLine;
	}

	int MaxLine() const
	{
		return m_nMaxLine;
	}

	const CPoint &cursor() const
	{
		return m_cursor;
	}

	int cursorX() const
	{
		return m_cursor.x;
	}

	int cursorY() const
	{
		return m_cursor.y;
	}

	BYTE LinkUse(int nLink) const
	{
		return m_Link.Link[nLink].m_bUse;
	}

	const TCHAR *LinkURL(int nLink) const
	{
		return m_Link.Link[nLink].m_szURL;
	}

	BYTE LinkType(int nLink) const
	{
		return m_Link.Link[nLink].m_nType;
	}

	void SetSleepEnd()
	{
		m_bSleepEnd = true;
	}

	int TermType() const
	{
		return m_nTermType;
	}

	void SetTermType(int t)
	{
		m_nTermType = t;
	}

	bool FinishPacket() const
	{
		return m_bFinishPacket;
	}
	
	const SOneChar *line(int y) const
	{
		return m_Screen.line(y);
	}
	
	SOneChar *lineW(int y) const
	{
		return m_Screen[y];
	}

	bool ScreenInited() const
	{
		return m_Screen.IsInited();
	}
	
	bool Changed(int i) const
	{
		return m_Screen.Changed(i);
	}

	void SetChange(int i, bool b)
	{
		m_Screen.SetChange(i, b);
	}

#if ENABLE_SCREENMAP
	int HisScreenNum() const
	{
		return m_nScreen;
	}
	
	int CurScreen() const
	{
		return m_nCurScrn;
	}
#endif//ENABLE_SCREENMAP
	
#if ENABLE_REPLACEIP
	int IPRecSize() const
	{
		return m_IPRec.size();
	}

	ipNode *IPRec(const int i) const
	{
		return m_IPRec[i];
	}
	
	void IPRecClear()
	{
		m_IPRec.clear();
	}

	void IPRecAdd(ipNode *pNode)
	{
		m_IPRec.push_back(pNode);
	}

private:
	void CCTermCore::bakIP();
#endif//ENABLE_REPLACEIP

public:
#if ENABLE_RAWCTD
	void SetCtdWaiting(bool b)
	{
		m_bCtdWaiting = b;
	}
#endif//ENABLE_RAWCTD

#if ENABLE_SCREENMAP
public:
	void ScreenUp();
	void ScreenDown();
	void ScreenFirst()
	{
		ScreenJump(0);
	}

	void ScreenLast()
	{
		ScreenJump(m_nScreen - 1);
	}

	void CopyOutCsm();
	void InitCsm();
	bool CheckCsm(FILE * fp);
	void ScreenJump(int pos);
#endif//ENABLE_SCREENMAP

public:
	inline void SetChange(int s, int e)
	{
		ASSERT(0 <= s && s <= m_nMaxLine);
		ASSERT(0 <= e && e <= m_nMaxLine);
		if (s > e) swap(s, e);

		for (int i = s; i <= e; ++i) {
			m_Screen.SetChange(i, true);
		}
	}

	//�Ƿ�ĩ����y��������
	inline bool IsLastScreen(int y) const
	{
		return (y >= m_nMaxStartLine && y <= m_nMaxLine);
	}

	BYTE GetScreenLine(TCHAR* buf, int nStart, int nEnd = -1, int nScrn = 0) const;
	int GetLineStr(TCHAR *szLine, int nLine, int len = 0, int start = 0, int nScrn = 0) const;
	int GetLongLine(TCHAR *szLine, int nLine, bool bStrip = true, int nScrn = 0) const;
	bool IsBlankLine(int nLine) const;
	int ChangeToTxt(char *buf, const CRect &rect, BOOL bRect = FALSE, bool bAnsi = false) const;
	void PutLine(const TCHAR *szLine, int nLine) const;

	void AddTxt(char *buf, int nLen, bool bConst = false);
	void AddTxt(void);
	
	BYTE GetCharType(int x, int y) const;// �ж��Ƿ�˫�ֽ��ַ����Ƿ����ַ�
	int GetWordHeadTailPos(const int x, const int y, bool bBackward = false, bool bTail = true) const;
	CString GetArticleTitle() const;
	BOOL IsDigestListEnd(void) const;
	BOOL IsDigestListHead(void) const;

	bool CaretAtBottom() const
	{
		// �Ƿ���Ҫִ�й�����
		// �����������ĩ�� && ״̬���������ݲ����ǣ�
		return m_cursor.y == m_nMaxLine;
	}
private:
	void ResetAll();

	BYTE GetCharType(TCHAR c) const;

	int GetURLType(const TCHAR *szURL) const
	{
		if (!_tcsnicmp(szURL, _T("mailto:"), 7))
			return URLT_MAIL;
		else
			return URLT_SITE;
	}

	void addString(const TCHAR *s, const int len = -1);
	void ProcessSeq(const SEscSeq &Seq);
	int GetEscSeq(SEscSeq &Seq, int &nAt) const;
	inline void UpdateRedrawY(int y, int endy = -1);
	bool IgnoreZModemCode();
	void OptimizeScreen() const;
		
private:
	void AddEscBak(TCHAR *buf, int &nLen);

//#if ENABLE_LINK
	BOOL GetOnePhase(const TCHAR *sText, TCHAR* sHead, TCHAR *sValue) const;
	BOOL GetOneLink(const TCHAR *sLink, TCHAR *sText, int &fc, SOneLink &Link) const;
	void ProcessLink(const SEscSeq &Seq);
//#endif//ENABLE_LINK

	void ClearLine(int nLine = -1, int startx = -1, int endx = -1);
	void deleteStr(int n);
	void MoveTo(const SEscSeq &Seq);
	void ClearScreen(int nMode);
	void InsertLines(int n);
	void newLine(void);
	void moveCursor(int x, int y);

	void ProcessColor(const SEscSeq &Seq);
	void GetParam(SEscSeq &Seq, const TCHAR *szParam) const;

	inline void SetYPos(int y);
	inline void UpdateY(int y);
	int GetStringFromBuf(const TCHAR *buf, TCHAR *ts, int &m_nAt, int &len) const;

	inline void RedrawIt(bool bHistoryBack = false);

	void UpdateStatus() const;


#if ENABLE_GRAPH
public:
	CGraph m_Graph;
private:
	void ProcessGraph(const SEscSeq &Seq);
#endif//ENABLE_GRAPH

private:
	CCTermView *m_pView;
	int m_nBelSeq; // ��������
#if ENABLE_MESSAGE
	bool m_bMesIn;
#endif//ENABLE_MESSAGE

	bool m_bSleepEnd; //��*[M ��ʱ����
	bool m_bFinishPacket; // ��ǰ���������
	bool m_bCtdWaiting; // �Ƿ�ctd�ļ��ȴ����� *[k, ��view��m_bCtd_Waiting��;��ͬ

	CPoint m_cursor;

//	int m_nPlaneNum;
	int m_nPlane;
	int m_nTermType;

	bool m_bChanged; // ��Ļ���ݸı��ˣ���Ҫ��OnSetCurSor()��SetClickRect()����ʹ��

#if ENABLE_REPLACEIP
	std::vector<ipNode*> m_IPRec;
#endif//ENABLE_REPLACEIP

	SOneChar m_CF;
	TCHAR *m_pszSource;
	bool m_bConstBuf;
	int m_nAt;

//#if ENABLE_LINK
	SLink   m_Link;
//#endif//ENABLE_LINK

	//SOneChar  (*m_Screen)[MAX_LINE_CHAR*sizeof(TCHAR)];
	CScreen m_Screen;
	int m_nMaxLine;// ָ��ǰ�����һ��
	int m_nMaxStartLine; // ���һ���ĵ�һ�У�m_nMaxLine-nTermHeight
	
	int  m_nScrollY0, m_nScrollY1;

	TCHAR m_szEscBak[MAX_LINE_CHAR*sizeof(TCHAR)];
	BOOL m_bEscBak;

	SEscSeq m_Seq;
	CPoint m_CursorBak;
#if ENABLE_LAYER
	SOneChar m_AttrBak[11];
#endif//ENABLE_LAYER

	int m_nLen;
	int m_nRedrawMinY, m_nRedrawMaxY;
#if ENABLE_REPLACEIP
	int m_nReplaceIPMin, m_nReplaceIPMax;
#endif

	bool m_bNeedRedraw;

	CRect m_lastClickRect;

#if ENABLE_SCREENMAP
public:
	void SetScrollSize();
private:
	FILE *m_scrn_fp; // �����Ļӳ�����ʱ�ļ�
	int m_nScreen; // ��ʷ����
	int m_nCurScrn; // ��ǰ����
	bool m_bCached; // ��ǰ���Ѽ�¼����ʷ�ļ�
	CString m_csmfile; // ��ʱ�ļ���
	void CacheScreen();
#endif//ENABLE_SCREENMAP
};

#endif // !defined(AFX_CTERMCORE_H__A8043F10_0ADD_11D4_B1E0_000080013F30__INCLUDED_)
