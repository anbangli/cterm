// BatDlg.cpp : implementation file
//

#include "stdafx.h"
#include "BatDlg.h"
#include "ctermview.h"
#include "usermsg.h"
#include "global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBatDlg dialog

CBatDlg::CBatDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CBatDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBatDlg)
	m_nAdd = 0;
	m_nEnd = 0;
	m_nFlag = -1;
	m_nMul = 0;
	m_sSend = _T("");
	m_nStart = 0;
	m_nTime = 0;
	//}}AFX_DATA_INIT
	m_WaitCount = 0;
}


void CBatDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBatDlg)
	DDX_Control(pDX, IDC_FLAG_LIST, m_cbFlag);
	DDX_Control(pDX, IDC_EXE_PROGRESS, m_prog);
	DDX_Control(pDX, IDC_VAR_LIST, m_varlist);
	DDX_Text(pDX, IDC_ADD, m_nAdd);
	DDX_Text(pDX, IDC_END, m_nEnd);
	DDX_CBIndex(pDX, IDC_FLAG_LIST, m_nFlag);
	DDX_Text(pDX, IDC_MUL, m_nMul);
	DDX_Text(pDX, IDC_SENDSTR, m_sSend);
	DDV_MaxChars(pDX, m_sSend, 98);
	DDX_Text(pDX, IDC_START, m_nStart);
	DDX_Text(pDX, IDC_TIME_BAT, m_nTime);
	DDV_MinMaxUInt(pDX, m_nTime, 10, 50000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBatDlg, CDialog)
	//{{AFX_MSG_MAP(CBatDlg)
	ON_BN_CLICKED(IDC_REPLAYMODE, OnReplaymode)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_LOAD, OnLoad)
	ON_BN_CLICKED(IDC_ADDVAR, OnAddvar)
	ON_BN_CLICKED(IDC_DELVAR, OnDelvar)
	ON_BN_CLICKED(IDC_UPDATEVAR, OnUpdatevar)
	ON_NOTIFY(NM_CLICK, IDC_VAR_LIST, OnClickVarList)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBatDlg message handlers

BOOL CBatDlg::OnInitDialog()
{
	m_nFlag = 0;
	m_Bat.Reset();
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	m_varlist.InsertColumn(0, _T("������"), LVCFMT_LEFT, 50);
	m_varlist.InsertColumn(1, _T("��������ʽ"), LVCFMT_LEFT, 130);
	UpdateMe(0);
	SetMode();
	SetIcon(AfxGetApp()->LoadIcon(IDI_ICON1), TRUE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CBatDlg::OnReplaymode()
{
	UpdateData();
	SetMode();
}

void CBatDlg::SetMode()
{
}

void SBat::Reset()
{
	bReplyMode = FALSE;
	//Reply Mode
	szList[0] = 0;
	szArticle[0] = 0;
	szEnd[0] = 0;
	szMenu[0] = 0;
#if ENABLE_FILTER
	Filter.Disable();
#endif//ENABLE_FILTER
	//Normal Mode
	nVar = 0;
	nStart = 1;
	nEnd = 10;
	nMilliSecond = 100;
	szSend[0] = 0;
	//Dynamic
	nCount = 0;
	nSendAt = 0;
}

void SBat::Save(TCHAR *szFile)
{
	FILE *fp;
	fp = _tfopen(szFile, _T("wb"));

	if (fp) {
		fwrite(this, sizeof(SBat), 1, fp);
		fclose(fp);
	}
}

void SBat::Load(TCHAR *szFile)
{
	FILE *fp;
	fp = _tfopen(szFile, _T("rb"));

	if (fp) {
		fread(this, sizeof(SBat), 1, fp);
		fclose(fp);
	}
}

void CBatDlg::UpdateMe(BOOL bLoad)
{
	if (bLoad) {
		UpdateData();
		m_Bat.nEnd = m_nEnd;
		m_Bat.nMilliSecond = m_nTime;
		m_Bat.nStart = m_nStart;
		_tcscpy(m_Bat.szSend, m_sSend);
		//Var and filter is seted by control
	} else {
		m_nEnd = m_Bat.nEnd;
		m_nTime = m_Bat.nMilliSecond;
		m_nStart = m_Bat.nStart;
		m_sSend = m_Bat.szSend;
		UpdateData(FALSE);
		SetMode();
	}
}

void CBatDlg::OnSave()
{
	CFileDialogEx fd(FALSE, _T("cbat"), _T("*.cbat"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("CTerm��������¼�ļ�(*.cbat)|*.cbat||"));

	if (fd.DoModal() == IDOK) {
		UpdateMe();
		m_Bat.Save(fd.GetPathName().LockBuffer());
	}
}

void CBatDlg::OnLoad()
{
	CFileDialogEx fd(TRUE, _T("cbat"), _T("*.cbat"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("CTerm��������¼�ļ�(*.cbat)|*.cbat||"));

	if (fd.DoModal() == IDOK) {
		m_Bat.Load(fd.GetPathName().LockBuffer());
		UpdateMe(0);
		UpdateList();
	}
}

void CBatDlg::UpdateList()
{
	int i;
	TCHAR ts[100];
	int  at;
	m_varlist.DeleteAllItems();

	for (i = 0; i < m_Bat.nVar; i++) {
		_stprintf(ts, _T("%%%c"), m_Bat.Var[i].nIndex);
		at = m_varlist.InsertItem(0, ts);
		_stprintf(ts, _T("= nCount * %d + %d"), m_Bat.Var[i].nMul, m_Bat.Var[i].nAdd);
		m_varlist.SetItemText(at, 1, ts);
		m_varlist.SetItemData(at, i);
	}
}

void SBat::AddVar(TCHAR c, int m, int n)
{
	int i;

	if (nVar < 26) {
		for (i = 0; i < nVar; i++) {
			if (Var[i].nIndex == c)
				break;
		}

		Var[i].nAdd = n;

		Var[i].nMul = m;

		if (i >= nVar) {
			Var[i].nIndex = c;
			nVar++;
		}
	}
}

void SBat::DeleteVar(TCHAR c)
{
	int i, j;

	if (nVar) {
		for (i = 0; i < nVar; i++) {
			if (Var[i].nIndex == c)
				break;
		}

		for (j = i;j < nVar - 1;j++) {
			Var[j].nIndex = Var[j+1].nIndex;
			Var[j].nAdd = Var[j+1].nAdd;
			Var[j].nMul = Var[j+1].nMul;
		}

		nVar--;
	}
}

void CBatDlg::OnAddvar()
{
	UpdateData();
	TCHAR buf[2];
	m_cbFlag.GetLBText(m_nFlag, buf);
	m_Bat.AddVar(buf[0], m_nMul, m_nAdd);
	UpdateList();
}

void CBatDlg::OnDelvar()
{
	int n, m;
	n = (int) m_varlist.GetFirstSelectedItemPosition() - 1;

	if (n != -1) {
		m = m_varlist.GetItemData(n);
		m_Bat.DeleteVar(m_Bat.Var[m].nIndex);
		UpdateList();
	}
}

void CBatDlg::OnUpdatevar()
{
	UpdateData();
	TCHAR buf[2];
	m_cbFlag.GetLBText(m_nFlag, buf);
	m_Bat.AddVar(buf[0], m_nMul, m_nAdd);
	UpdateList();
}

void CBatDlg::OnClickVarList(NMHDR* pNMHDR, LRESULT* pResult)
{
	int n, m;
	n = (int) m_varlist.GetFirstSelectedItemPosition() - 1;

	if (n != -1) {
		m = m_varlist.GetItemData(n);
		m_nFlag = m_Bat.Var[m].nIndex - 'A';
		m_nMul = m_Bat.Var[m].nMul;
		m_nAdd = m_Bat.Var[m].nAdd;
		UpdateData(FALSE);
	}

	*pResult = 0;
}

void CBatDlg::OnOK()
{
	UpdateMe();
//	m_Run.m_pView->m_bPopEditDlg = FALSE;//��ʱ��ֹ�����༭��
	SetTimer(TIMER_BATDLG, m_Bat.nMilliSecond, NULL);
	m_Bat.nCount = m_Bat.nStart;
	m_Bat.nSendAt = 0;

	GetDlgItem(IDOK)->EnableWindow(0);
	GetDlgItem(IDC_LOAD)->EnableWindow(0);
	GetDlgItem(IDC_SAVE)->EnableWindow(0);
}

void CBatDlg::OnTimer(UINT nIDEvent)
{
	//TIMER_BATDLG
	CDialog::OnTimer(nIDEvent);
//TRACE(_T("in CBatDlg::OnTimer\m_WaitCount %d\n"), m_WaitCount);

	if (m_WaitCount > 0) {
		m_WaitCount--; //�ȴ�
//TRACE(_T("in CBatDlg::OnTimer\tWait %d\n"), m_WaitCount);
		return;
	}

	ProcessNormal();
}

void CBatDlg::ProcessReply()
{
	int n = m_Run.QueryStatus();

	if (n == 1 || m_Bat.nCount == 0) {
		m_Bat.nCount++;

		switch (m_Run.m_pView->GetStatus()) {

		case SST_LIST:
			SendString(m_Bat.szList);
			break;

		case SST_MENU:
			SendString(m_Bat.szMenu);
			break;

		case SST_ARTICLE:
			SendString(m_Bat.szArticle);
			break;

		case SST_END:
			SendString(m_Bat.szEnd);
			break;

		default:
			SendString(_T(""));
			break;
		}
	}
}

void CBatDlg::SendString(TCHAR *str)
{
	tstring s;

	if (!isempty(str)) {
		s = TranslateString(str);
		m_Run.EnterNextStage(s.c_str(), s.size(), SST_ANY, BS_ANY);
	}
}

void CBatDlg::OnCancel()
{
	CDialog::OnCancel();
	KillTimer(TIMER_BATDLG);
//	m_Run.m_pView->m_bPopEditDlg = g_bPopEditDlg;
}

void CBatDlg::ProcessNormal()
{
//TRACE(_T("in CBatDlg::ProcessNorma\t processing ...\n"));
	TCHAR str[2];
	int  nAll;

	if (m_Bat.nSendAt == 0) {
		PrepareString(m_Bat.nCount);
	}

	if (m_szSend[m_Bat.nSendAt] == '\\' &&
	        (m_szSend[++m_Bat.nSendAt] == 'w')) {
		//\wn delay
		TCHAR buf[6];
		m_Bat.nSendAt++;
		int count;

		for (count = 0; count < 5 && _istdigit(m_szSend[m_Bat.nSendAt]); m_Bat.nSendAt++, count++) {      //���5λ����
			//����鷳��ֻ��Ϊ�˷�ֹ���������ֻ_ttoi����
			buf[count] = m_szSend[m_Bat.nSendAt];
		}

		buf[count] = '\0';

		m_WaitCount = _ttoi(buf);
//		if(n)
//		{
//			n*=m_Bat.nMilliSecond;
//			Sleep(n);
//		}
	}

	if (m_szSend[m_Bat.nSendAt] == 0) {   //Reset to Next
		m_Bat.nSendAt = 0;
		m_Bat.nCount++;
		nAll = m_Bat.nEnd - m_Bat.nStart + 1;

		if (nAll <= 0) nAll = 1;

		m_prog.SetPos((m_Bat.nCount - m_Bat.nStart) *100 / nAll);

		if (m_Bat.nCount > m_Bat.nEnd) {
			//Over
			OnCancel();
		}

		return;
	}

//TRACE(_T("\t nSendAt %d, TCHAR: %c\n"), m_Bat.nSendAt, m_szSend[m_Bat.nSendAt]);
	_stprintf(str, _T("%c"), m_szSend[m_Bat.nSendAt]);

	m_Bat.nSendAt++;

	m_Run.m_pView->Send(str, 1);
}

void CBatDlg::PrepareString(int n)
{
//	TCHAR num[10] = _T("");
	int k = 0;
	//, *q=m_szSend
	tstring s = TranslateString(m_Bat.szSend);
	tstring::iterator p = s.begin();
	//p->q
//	_tcscpy ( m_szSend, _T ( "" ) );

	while (*p) {
		if (*p == '%') {
			if ((p[1] >= 'A' && p[1] <= 'Z') || (p[1] >= 'a' && p[1] <= 'z')) {
				if (p[1] >= 'a' && p[1] <= 'z')
					p[1] -= 32;

//				_stprintf ( num, _T ( "%d" ), m_Bat.GetCount ( n, p[1] ) );
//				_tcscat ( m_szSend, num );
				k += _stprintf(m_szSend + k, _T("%d"), m_Bat.GetCount(n, p[1]));

				p += 2;
			} else if (p[1] == '%') {
				m_szSend[k++] = p[1];
				p += 2;
			} else
				p++;
		} else {
//			_stprintf ( num, _T ( "%c" ), *p );
//			_tcscat ( m_szSend, num );
			m_szSend[k++] = *p;
			p++;
		}
	}

	m_szSend[k] = '\0';

//	s.ReleaseBuffer();
}

int SBat::GetCount(int n, TCHAR c)
{
	int i;

	for (i = 0; i < nVar; i++) {
		if (Var[i].nIndex == c)
			break;
	}

	if (i < nVar)
		return n*Var[i].nMul + Var[i].nAdd;
	else
		return 0;
}

CBatDlg *g_pBat = NULL;
