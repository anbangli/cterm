// SwitchBar.cpp : implementation file
//

#include "stdafx.h"
#include "SwitchBar.h"
#include "mainfrm.h"
#include "ctermview.h"

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSwitchBar dialog


CSwitchBar::CSwitchBar(CWnd* pParent /*=NULL*/)
		: CDialogBar()
{
	//{{AFX_DATA_INIT(CSwitchBar)
	//}}AFX_DATA_INIT
}

BEGIN_MESSAGE_MAP(CSwitchBar, CDialogBar)
	//{{AFX_MSG_MAP(CSwitchBar)
	ON_WM_MOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_SETCURSOR()
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSwitchBar message handlers

void CSwitchBar::SetTabSize()
{
//TRACE(_T("\nCSwitchBar::SetTabSize()\n\n"));
	if (!::IsWindow(m_hWnd)) return;

	CWnd *pWnd = GetDlgItem(ID_SWITCH_TAB);
	CWnd *pMainFrm = AfxGetMainWnd();
	
	if (pMainFrm && pWnd) {
		CRect rectWin, rect, rectDlg;
		pMainFrm->GetWindowRect(&rectWin);
		GetWindowRect(&rectDlg);

		rect.left = 10; //for gripper
		rect.top = 8;	//3;
		rect.bottom = rectDlg.Height() - 5;	//-3;

		rectDlg.right = rectWin.right - 5;
		rect.right = rectDlg.Width();
		pWnd->MoveWindow(&rect);
	}
}

void CSwitchBar::OnMove(int x, int y)
{
	CDialogBar::OnMove(x, y);
	CRect rectWin, rect, rectDlg;
	CWnd *pMainFrm = AfxGetMainWnd();
	if (pMainFrm)
		pMainFrm->GetWindowRect(&rectWin);

	GetWindowRect(&rectDlg);

	CWnd *pWnd = GetDlgItem(ID_SWITCH_TAB);
	if (pWnd) {
		rect.left = 9;
		rect.top = 3;
		rect.bottom = rectDlg.Height() - 3;
		rect.right = rectWin.right - rectDlg.left - 5;
		pWnd->MoveWindow(&rect);
	}

}

BOOL CSwitchBar::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	//Ҫ���²����յ�����Ϊ������view
	if (zDelta != 0) {
		if (zDelta > 0)
			g_pMainWnd->SendMessage(WM_COMMAND, (1 << 16) | ID_WINDOW_NEXT);
		else if (zDelta < 0)
			g_pMainWnd->SendMessage(WM_COMMAND, (1 << 16) | ID_CTRL_SHIFT_TAB);
	}

	return CDialogBar::OnMouseWheel(nFlags, zDelta, pt);
}

BOOL CSwitchBar::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if (g_pMainWnd && g_pMainWnd->ChildCount() > 0) {
		if (message == WM_MBUTTONUP) {
			int i = HitTest();
			if (i != -1) {
				g_pMainWnd->QuickLogout(i);
			}
		}
	}

	return CDialogBar::OnSetCursor(pWnd, nHitTest, message);
}

//����ָ�����ĸ���ǩ��
//�����ڣ�����-1
int CSwitchBar::HitTest()
{
	CPoint pt;
	GetCursorPos(&pt);

	CTabCtrl *pTab = (CTabCtrl *) GetDlgItem(ID_SWITCH_TAB);
	pTab->ScreenToClient(&pt);

	TCHITTESTINFO HitTestInfo;
	HitTestInfo.pt = pt;
	return pTab->HitTest(&HitTestInfo);
}

void CSwitchBar::DrawGripper(CDC *pDC)
{
	if (!IsFloating()) {   // && m_bGripper
		// draw the gripper.
		CRect pRect(GetGripperRect());
		pDC->Draw3dRect(pRect, ::GetSysColor(COLOR_BTNHIGHLIGHT),
		                ::GetSysColor(COLOR_BTNSHADOW));
	}

}

CRect CSwitchBar::GetGripperRect()
{
	CRect rect;
	GetClientRect(&rect);
	rect.OffsetRect(-rect.left, -rect.top);

	if (true) {   //IsHorzDocked()) {
		rect.DeflateRect(4, 2);
		//rect.left		+= -2;
		rect.right		 = rect.left + 3;
		rect.bottom	-= 1;
		rect.top		+= 1; //m_bButtons?30:1;
	} else {
		rect.DeflateRect(4, 4);
		rect.left		= 2;
		rect.top		+= 2;
		rect.bottom	 = rect.top + 3;
		rect.right		-= 2; //m_bButtons?30:2;
	}

	return rect;
}

void CSwitchBar::OnPaint()
{
	CPaintDC dc(this);    // device context for painting

	// ���߿�
	CRect rectDlg;
	GetClientRect(&rectDlg);
	//dc.Draw3dRect(rectDlg, ::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW) );
	//rectDlg.bottom--;
	dc.DrawEdge(rectDlg, EDGE_ETCHED, BF_RECT);	//::GetSysColor(COLOR_BTNHIGHLIGHT),::GetSysColor(COLOR_BTNSHADOW) );
	//dc.DrawEdge(rectDlg, EDGE_ETCHED, BF_BOTTOM);
	//if(g_pMainWnd->m_Child.nChild>0)
	DrawGripper(&dc);

	// Do not call CDialogBar::OnPaint() for painting messages
}



void CSwitchBar::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (point.x == -1 && point.y == -1) {
		//keystroke invocation
		CRect rect;
		GetClientRect(rect);
		ClientToScreen(rect);
		
		point = rect.TopLeft();
		point.Offset(5, 5);
	}
	
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_BAR_MENU));
	
#if ENABLE_MULTILANG
	if (g_currLangID != ID_LANG1) {
		g_OutMenuStrings(&menu, _T(""));  //����Ĭ��
		g_SetMenuStrings(&menu, _T(""));
	}
#endif// ENABLE_MULTILANG
	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);
	CWnd* pWndPopupOwner = AfxGetMainWnd();
	while (pWndPopupOwner->GetStyle() & WS_CHILD)
		pWndPopupOwner = pWndPopupOwner->GetParent();
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
		pWndPopupOwner);
}

CTabCtrl *CSwitchBar::tab() const
{
	 return (CTabCtrl *)GetDlgItem(ID_SWITCH_TAB);
}
