#if !defined(AFX_CONTROLSOCK_H__066249E0_03D0_11D4_B1CD_000080013F30__INCLUDED_)
#define AFX_CONTROLSOCK_H__066249E0_03D0_11D4_B1CD_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ControlSock.h : header file
//
#define MAX_ALLOW_INSTANCE 20

#define CS_COMMAND			'C' // ����
#define CS_RESTOREWINDOW	0 //_T("RestoreWin")
#define CS_BOSSKEY			1 //_T("BossKey")
#define CS_REREG_BOSSKEY	2 //_T("ReRegHotKey")
#define CS_CHANGE_BOSSKEY	3 //_T("ChangeHotKey")
#define CS_HOTKEY			4 // ����
/////////////////////////////////////////////////////////////////////////////
// CControlSock command target

class CControlSock : public CAsyncSocket
{
// Attributes

public:

// Operations

public:
	CControlSock();
	virtual ~CControlSock();
	UINT m_nPort;

// Overrides

public:
	bool Init(BOOL bAllowMulti);
	void BroadCast(int nMessage, bool bToSelf = false);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CControlSock)

public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CControlSock)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation

protected:

private:
	void ProcessCommand(TCHAR *, int);
};

extern CControlSock ControlSock;
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTROLSOCK_H__066249E0_03D0_11D4_B1CD_000080013F30__INCLUDED_)
