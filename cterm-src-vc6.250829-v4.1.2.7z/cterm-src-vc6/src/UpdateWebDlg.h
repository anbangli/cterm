#if !defined(AFX_UPDATEWEBDLG_H__0EE2FEEA_5F80_487B_8BDE_86291D3993F1__INCLUDED_)
#define AFX_UPDATEWEBDLG_H__0EE2FEEA_5F80_487B_8BDE_86291D3993F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UpdateWebDlg.h : header file
//

#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

/////////////////////////////////////////////////////////////////////////////
// CUpdateWebDlg dialog

class CUpdateWebDlg : public CDialog
{
// Construction
public:
	CUpdateWebDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUpdateWebDlg)
	enum { IDD = IDD_UPDATE_WEB };
	//CButtonST	m_gitcode;  //CButtonST ��ƽ�Ͱ�ť
	//CButtonST	m_gitee;
	//CButtonST	m_github;
	CButton	m_gitcode;
	CButton	m_gitee;
	CButton	m_github;
	CString	m_ver;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUpdateWebDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUpdateWebDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnGitee();
	afx_msg void OnGitcode();
	afx_msg void OnGithub();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:

	CString	m_wd;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPDATEWEBDLG_H__0EE2FEEA_5F80_487B_8BDE_86291D3993F1__INCLUDED_)
