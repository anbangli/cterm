#if !defined(AFX_SITEDECODEPAGE_H__21A54107_A74A_403A_AD39_D9B6BB148B56__INCLUDED_)
#define AFX_SITEDECODEPAGE_H__21A54107_A74A_403A_AD39_D9B6BB148B56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteDecodePage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteDecodePage dialog

struct SLoginSet;

struct SDecodeSet;

class CSiteDecodePage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteDecodePage)

// Construction

public:
	BOOL m_bDouble;
//	SLoginSet  * m_pLogin;
	SDecodeSet *m_pDecode;
	CSiteDecodePage();
	~CSiteDecodePage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(CSiteDecodePage)
	enum { IDD = IDD_SITE_DECODE };
	CComboBox	m_nEscChar_ctrl;
	CComboBox	m_nDecode_ctrl;
	int		m_nDecode;
	BOOL	m_bEnter;
	int     m_nEscChar;
	BOOL	m_bBsIsDel;
	BOOL	m_bDelAsStop;
	BOOL	m_bDoubleCode;
	int		m_nInputCodeInvert;
	int		m_nOutputCodeInvert;

	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteDecodePage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CSiteDecodePage)
	virtual BOOL OnInitDialog();
	afx_msg void OnDoublecodeYes();
	afx_msg void OnDoublecodeNo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITEDECODEPAGE_H__21A54107_A74A_403A_AD39_D9B6BB148B56__INCLUDED_)
