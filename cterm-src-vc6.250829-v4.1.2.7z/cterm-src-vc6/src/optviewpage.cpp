// OptViewPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptViewPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptViewPage property page

IMPLEMENT_DYNCREATE(COptViewPage, CMyPropertyPage)

COptViewPage::COptViewPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptViewPage)
	m_bTabUser = FALSE;
	m_bReadFlag = FALSE;
	m_bHilight = FALSE;
	m_nTabWid = 0;
	m_bTabFullName = -1;
	m_nMouseMenu = 0;
	m_nTermHeight = 0;
	m_nTermWidth = 0;
	m_bShowCenter = FALSE;
	m_bMaxFullScreen = FALSE;
	m_bMenuFavTop = FALSE;
	m_bShowUserMenu = TRUE;
	m_nCharHWRatio = 0;
	m_bTransparent = FALSE;
	m_nAlpha = 0;
	//}}AFX_DATA_INIT
#if ENABLE_CLEARTYPE
	m_nFontQuality = 0;
#endif//ENABLE_CLEARTYPE
}

COptViewPage::~COptViewPage()
{
}

void COptViewPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptViewPage)
	DDX_Control(pDX, IDC_CBCLICK, m_cbClick);
	DDX_Check(pDX, IDC_CHECK_TABUSER, m_bTabUser);
	DDX_Check(pDX, IDC_CHECK_READFLAG, m_bReadFlag);
	DDX_Check(pDX, IDC_CHECK_HILIGHT, m_bHilight);
	DDX_Text(pDX, IDC_EDIT_TABWIDTH, m_nTabWid);
	DDV_MinMaxInt(pDX, m_nTabWid, 20, 500);
	DDX_Radio(pDX, IDC_TAB_MODE_0, m_bTabFullName);
	DDX_CBIndex(pDX, IDC_CBCLICK, m_nMouseMenu);
	DDX_Text(pDX, IDC_EDIT_TERM_HEIGHT, m_nTermHeight);
	DDV_MinMaxInt(pDX, m_nTermHeight, 12, 48);
	DDX_Text(pDX, IDC_EDIT_TERM_WIDTH, m_nTermWidth);
	DDV_MinMaxInt(pDX, m_nTermWidth, 40, 254);
	DDX_Check(pDX, IDC_CHK_SHOWCENTER, m_bShowCenter);
	DDX_Check(pDX, IDC_CHK_MAX_FULLSCREEN, m_bMaxFullScreen);
	DDX_Check(pDX, IDC_CHK_MENUFAVTOP, m_bMenuFavTop);
//	DDX_Check(pDX, IDC_CHK_SHOWUSERMENU, m_bShowUserMenu);
//	DDX_Text(pDX, IDC_EDIT_HWRATIO, m_nCharHWRatio);
	DDX_Check(pDX, IDC_TRANSPARENT, m_bTransparent);
	DDX_Text(pDX, IDC_ALPHA, m_nAlpha);
	DDV_MinMaxUInt(pDX, m_nAlpha, 0, 255);
	//}}AFX_DATA_MAP
#if ENABLE_CLEARTYPE
	DDX_Text(pDX, IDC_EDIT_QUALITY, m_nFontQuality);
	DDV_MinMaxInt(pDX, m_nFontQuality, 0, 6);
#endif//ENABLE_CLEARTYPE
}


BEGIN_MESSAGE_MAP(COptViewPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptViewPage)
	ON_BN_CLICKED(IDC_TRANSPARENT, OnTransparent)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptViewPage message handlers

BOOL COptViewPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

UINT COptViewPage::GetIDD()
{
	return IDD;
}

void COptViewPage::OnTransparent() 
{
	UpdateData();
	if (m_bTransparent && m_nAlpha == 0)  {
		m_nAlpha = 120;
		UpdateData(FALSE);
	}
}
