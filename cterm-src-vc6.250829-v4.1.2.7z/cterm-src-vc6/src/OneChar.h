// OneChar.h: interface for the SOneChar class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ONECHAR_H__F01C9CF9_79C4_405B_8D81_5274B30877B1__INCLUDED_)
#define AFX_ONECHAR_H__F01C9CF9_79C4_405B_8D81_5274B30877B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "const.h"

struct SOneChar {  //һ���ַ�����������
public:
	enum COLOR {BLACK = 0};

public:
	SOneChar();
	void _ResetLow();
	void SetChar(SOneChar &CF, TCHAR c, int nPlane);
	BOOL IsSameAttr(const SOneChar &Char) const;
	void Reset();
	void GetColor(int &fc, int &bc, bool bSelect = false, bool bClick = false) const;
	void SetNeverChar();
	
public:
	// accessors
	void SetChar(TCHAR c, int nPlane = 0)
	{
		Char[nPlane] = c;
	}
	
	TCHAR GetChar(int nPlane = 0) const
	{
		return Char[nPlane];
	}
	
	bool GetUnderline() const
	{
		return Attr[0] & ATTR_UNDERLINE;
	}

	void SetUnderline(bool b)
	{
		if (b) {
			Attr[0] |= ATTR_UNDERLINE;
		}
		else {
			Attr[0] &= ~ATTR_UNDERLINE;
		}
	}

	void SetReverse(bool b)
	{
		if (b) {
			Attr[0] |= ATTR_REVERSE;
		}
		else {
			Attr[0] &= ~ATTR_REVERSE;
		}
	}

	TCHAR GetBlinkChar(int nBlink) const
	{
		return Char[nBlink];
	}

	BYTE GetColor() const
	{
		return Color[0];
	}
	
	void SetColor(BYTE c, int nPlane = 0)
	{
		Color[nPlane] = c;
	}

	// c: 0 - 7
	void SetFC(BYTE c)
	{
		Color[0] = (Color[0] & ~COLOR_FC) | c;
	}
	
	// c: 0 - 7
	void SetBC(BYTE c)
	{
		Color[0] = (Color[0] & ~COLOR_BC) | (c << 4);
	}
	
	int GetFC() const
	{
		return Color[0] & COLOR_FC;
	}

	int GetBC() const
	{
		return (Color[0] & COLOR_BC) >> 4;
	}

	BYTE GetAttr() const
	{
		return Attr[0];
	}

	void SetAttr(BYTE c, int nPlane = 0)
	{
		Attr[nPlane] = c;
	}

	BYTE HasAttr(BYTE mask) const
	{
		return Attr[0] & mask;
	}

	BYTE GetAdvAttr() const
	{
		return Adv_Attr;
	}
	
	int GetFont() const
	{
		return (Adv_Attr & ADVATTR_FONT) >> 4;
	}
	
	int GetBlink() const
	{
		return Adv_Attr & ADVATTR_BLINK;
	}

	void SetAdvAttr(BYTE c)
	{
		Adv_Attr = c;
	}

	void SetFont(BYTE c)
	{
		Adv_Attr = (Adv_Attr & ~ADVATTR_FONT) | (c << 4);
	}

	// c: 1-4
	void SetBlink(BYTE c)
	{
		Adv_Attr = (Adv_Attr & ~ADVATTR_BLINK) | c;
	}

	void SetHilight(BOOL b)
	{
		if (b) {
			Attr[0] |= ATTR_HIGHLIGHT;
		}
		else {
			Attr[0] &= ~ATTR_HIGHLIGHT;
		}
	}

//	void RemoveAdvAttr(unsigned mask)
//	{
//		Adv_Attr &= ~mask;
//	}
//
//	void AddAdvAttr(unsigned mask)
//	{
//		Adv_Attr |= mask;
//	}

	void RemoveAttr(unsigned mask)
	{
		Attr[0] &= ~mask;
	}

	void AddAttr(unsigned mask)
	{
		Attr[0] |= mask;
	}

	void SetLink(BYTE c)
	{
		Link = c;
	}
	
	BYTE GetLink() const
	{
		return Link;
	}

private:
	TCHAR Char[LAYER_SPACE_NUM];   // �ַ�����
	BYTE Attr[LAYER_SPACE_NUM];   // ����ֵ����Ϊ ATTR_HIGHLIGHT ��
	BYTE Color[LAYER_SPACE_NUM];  // ��ɫ�룺��4λ��������4λǰ����0-7����-��
	BYTE Link;
	//int m_nPlaneNum;

	BYTE Adv_Attr;
	//����1: ��4λ=nBlink>1��ʾ��˸; nBlinkΪѭ����ʾ���棬nBlinkȡֵΪ0-7
	//����2: �߼����Ը�4λ��ʾ����
	// Adv_Attr = 1111 0000 (b) = 0xF0 = 15 0 = NEVER_ATTR ���������Զ������ֵ����ԣ�Ŀ����Ϊ�˱Ƚ�ʱʹIsSameAttr���ؼ�
};

#endif // !defined(AFX_ONECHAR_H__F01C9CF9_79C4_405B_8D81_5274B30877B1__INCLUDED_)
