// SiteBlackListPage.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "SiteBlackListPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteBlackListPage dialog

IMPLEMENT_DYNCREATE(CSiteBlackListPage, CMyPropertyPage)

CSiteBlackListPage::CSiteBlackListPage() : CMyPropertyPage(CSiteBlackListPage::IDD)
{
	//{{AFX_DATA_INIT(CSiteBlackListPage)
	m_bBlackList = FALSE;
	m_szBlackList = _T("");
	//}}AFX_DATA_INIT
}

CSiteBlackListPage::~CSiteBlackListPage()
{
}

void CSiteBlackListPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteBlackListPage)
	DDX_Control(pDX, IDC_EDIT_BLACKLIST, m_EditBlackList);
	DDX_Check(pDX, IDC_CHECK_BLACKLIST, m_bBlackList);
	DDX_Text(pDX, IDC_EDIT_BLACKLIST, m_szBlackList);
	DDV_MaxChars(pDX, m_szBlackList, 1024);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteBlackListPage, CDialog)
	//{{AFX_MSG_MAP(CSiteBlackListPage)
	ON_BN_CLICKED(IDC_CHECK_BLACKLIST, OnCheckBlacklist)
	ON_BN_CLICKED(IDC_OPENINI, OnOpenini)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteBlackListPage message handlers

void CSiteBlackListPage::OnCheckBlacklist() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	//m_EditBlackList.EnableWindow(m_bBlackList);
}

//extern CString g_sAddrInfoFile;
//void CSiteBlackListPage::OnOpenini() 
//{
//	ShellExecute(NULL, _T("open"), g_sAddrInfoFile, NULL, NULL, SW_SHOW);
//}