// MessageDlg.cpp : implementation file
//

#include "stdafx.h"

#include "MessageDlg.h"
#include "Ctermview.h"
#include "historydlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMessageDlg dialog

#if ENABLE_MESSAGE
CMessageDlg::CMessageDlg(CWnd* pParent /*=NULL*/, bool bSend)
		: CDialog(CMessageDlg::IDD, pParent),
		m_pView((CCTermView *)pParent),
		m_bSend(bSend)
{
	//{{AFX_DATA_INIT(CMessageDlg)
	m_inmes = _T("");
	m_sender = _T("");
	m_time = _T("");
	m_replystr = _T("");
	//}}AFX_DATA_INIT
}


void CMessageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMessageDlg)
	DDX_Control(pDX, IDC_SENDER, m_ctrlSender);
	DDX_Control(pDX, IDC_REPLY, m_reply);
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Control(pDX, IDCANCEL, m_cancel);
	DDX_Control(pDX, IDC_HIS, m_his);
	DDX_Text(pDX, IDC_INMES, m_inmes);
	DDX_Text(pDX, IDC_SENDER, m_sender);
	DDX_Text(pDX, IDC_TIME, m_time);
	DDX_Text(pDX, IDC_REPLY, m_replystr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMessageDlg, CDialog)
	//{{AFX_MSG_MAP(CMessageDlg)
	ON_BN_CLICKED(IDC_HIS, OnHis)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMessageDlg message handlers

BOOL CMessageDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	if (m_bMultiLine)
		m_reply.LimitText(m_pView->TermW() * 12);	// ������Ϣ
	else
		m_reply.LimitText(53);		// ������Ϣ�������FB�����������Ƶ�53

	if (m_bSend)
		m_ctrlSender.EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CMessageDlg::OnHis()
{
	CHistoryDlg Dlg;
	TCHAR ts[100];
	Dlg.m_pView = m_pView;
	_tcscpy(ts, m_sender);
	Dlg.m_pszUserName = ts;

	if (Dlg.DoModal() == IDOK) {
	}
}

void CMessageDlg::OnOK()
{
	UpdateData();

//	TCHAR ch;
//	int i;

//	for ( i = 0; i < _tcslen ( m_replystr ); i++ )
//		ch = m_replystr[i];

	m_replystr.Replace('\r', ' ');
	m_replystr.Replace('\n', 17);    //^Q

//	for ( i = 0; i < len; i++ )
//		ch = m_replystr[i];

	if (m_pView) {
		if (!m_replystr.IsEmpty()) {
			m_pView->DealMsgDlg(true);
			CDialog::OnOK();
		} else {
			if (MessageBox(_T("��Ĳ��ش�������Ϣ��?"), _T("ȷ��"), MB_YESNO | MB_ICONQUESTION) == IDYES)
				OnCancel();
		}
	}
}

void CMessageDlg::OnCancel()
{
	//	if(MessageBox(_T("��Ĳ��ش�������Ϣ��?"),_T("ȷ��"),MB_YESNO|MB_ICONQUESTION)==IDYES)
	if (m_pView)
		m_pView->DealMsgDlg(false);

	CDialog::OnCancel();
}


void CMessageDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	//����������һ�㣬������༭���ص�
	//�޷�ͨ�����༭�����ʾ����������Ƿ���λ��ֻ��ͳͳ��λ�ˡ�
	//CRect rect;
	//GetWindowRect(&rect);
	//MoveWindow(rect.left,rect.top/2,rect.Width(),rect.Height());

	CDialog::OnShowWindow(bShow, nStatus);
	SetForegroundWindow();
	SetFocus();
}


BOOL CMessageDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN) {
		if (!m_bMultiLine && pMsg->wParam == VK_RETURN) {	//������Ϣ
			OnOK();
			return TRUE;
		}

		if (m_bMultiLine && pMsg->wParam == VK_RETURN) {	// ������Ϣʱ����ͳ������
			int i = 0, j = 0, k = 0;
			UpdateData();
			k = m_replystr.GetLength();

			for (i = 0; i < k; i++) {
				if (m_replystr[i] == '\n')
					j++;
			}

			if (j >= 11) {
				OnOK();
				return TRUE;
			}
		}

		if (isdown(VK_CONTROL) && pMsg->lParam >= 0 && pMsg->wParam == VK_RETURN) {	// ^enter
			UINT nID = GetFocus()->GetDlgCtrlID();

			if (nID == IDC_REPLY) {
				OnOK();
				return TRUE; //was translated and should not be dispatched
			}
		}

		if (isdown(VK_CONTROL) && pMsg->lParam >= 0	&& pMsg->wParam == 'A') {	// ^A
			m_reply.SetFocus();
			m_reply.SetSel(0, -1, TRUE);
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

#endif//ENABLE_MESSAGE
