/****************************************************************************
DLArticleDlg.cpp : implementation file      ��ƪ���������Ķ�

****************************************************************************/

#include "stdafx.h"
#include "DLArticleDlg.h"
#include "ctermview.h"
#include "string.h"
#include "usermsg.h"
#include "paramconfig.h"
#include "global.h"
#include "forcode.h"

#if ENABLE_HTMLDOWN
#include "HTMLConvert.h"	// HTMLת��
#endif//ENABLE_HTMLDOWN

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDLArticleDlg dialog

#define TIMEOUT_TIME 8000 //8��

#define _UNICODE

CDLArticleDlg::CDLArticleDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CDLArticleDlg::IDD, pParent)
{
#if ENABLE_HTMLDOWN
	m_pConvert = NULL;
#endif//ENABLE_HTMLDOWN

	m_bFirstScr = true;
	//{{AFX_DATA_INIT(CDLArticleDlg)
	m_article = _T("");
	m_bShowEdit = TRUE;
	m_read = 0;
	m_bDLByLine = FALSE;
	m_npos = 0;
	m_keyword = _T("");
	//}}AFX_DATA_INIT
}

CDLArticleDlg::~CDLArticleDlg()
{
#if ENABLE_HTMLDOWN
	if (m_pConvert)
		delete m_pConvert;
#endif//ENABLE_HTMLDOWN

	AfxGetApp()->WriteProfileInt(_T("Setup"), _T("ShowEditWhenDownloadArticle"), m_bShowEdit);
}

void CDLArticleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDLArticleDlg)
	DDX_Control(pDX, IDC_KEYWORD, m_ctrl_keyword);
	DDX_Control(pDX, IDC_ARTICLE, m_edit);
	DDX_Control(pDX, IDC_PROGRESS1, m_prog);
	DDX_Text(pDX, IDC_ARTICLE, m_article);
	DDX_Check(pDX, IDC_CHECK_TOGGLEEDIT, m_bShowEdit);
	DDX_Radio(pDX, IDC_READ_TEXT, m_read);
	DDX_Check(pDX, IDC_CHECK_DLBYLINE, m_bDLByLine);
	DDX_Text(pDX, IDC_KEYWORD, m_keyword);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDLArticleDlg, CDialog)
	//{{AFX_MSG_MAP(CDLArticleDlg)
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_DLNEXT, OnDlnext)
	ON_BN_CLICKED(IDC_DLPREV, OnDlprev)
	ON_BN_CLICKED(IDC_CHECK_TOGGLEEDIT, OnCheckToggleedit)
	ON_BN_CLICKED(IDC_READ_TEXT, OnReadText)
	ON_BN_CLICKED(IDC_READ_ANSI, OnReadAnsi)
	ON_BN_CLICKED(IDC_CHECK_DLBYLINE, OnCheckDlbyline)
	ON_EN_CHANGE(IDC_KEYWORD, OnChangeKeyword)
	ON_EN_KILLFOCUS(IDC_KEYWORD, OnKillfocusKeyword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLArticleDlg message handlers

BOOL CDLArticleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


	bInMes = FALSE;

	if (m_pView) {
#if ENABLE_HTMLDOWN
		m_pConvert = new CHTMLConvert(&m_pView->m_Core);
#endif//ENABLE_HTMLDOWN
	} 
	else {
		CDialog::OnCancel();
	}

	m_read = 0;

	//m_filename = g_szWorkDir + _T("temp.txt");
	//DeleteFile(m_filename);

	// ����
	m_Font.CreateFont(16, 0, 0, 0, 100, FALSE, FALSE, 0, ANSI_CHARSET,
	                  OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_SWISS, _T("SimSun"));

	CEdit *m_Edit = (CEdit *) GetDlgItem(IDC_ARTICLE);

	if (m_Edit)
		m_Edit->SetFont(&m_Font, FALSE);

	//m_bDLByLine=((CMainFrame*)AfxGetMainWnd())->m_bDLByLine;

	m_bShowEdit = AfxGetApp()->GetProfileInt(_T("Setup"), _T("ShowEditWhenDownloadArticle"), 1);

	g_bDownloadWithHTML = AfxGetApp()->GetProfileInt(_T("Setup"), _T("DownloadWithHTML"), 1);

	UpdateData(FALSE);

	Toggleedit();

	CRect rect;
	if (g_nDLDlgHeight == 0 || g_nDLDlgWidth == 0) {
		GetWindowRect(&rect);
		g_nDLDlgWidth = rect.Width();
		g_nDLDlgHeight = rect.Height();
	}

	rect.bottom = 60 + g_nDLDlgHeight;
	rect.right = 60 + g_nDLDlgWidth;
	rect.top = 60;
	rect.left = 60;

	MoveWindow(&rect);

	InitDL();

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDLArticleDlg::InitDL()
{
#if ENABLE_HTMLDOWN
	if (m_pConvert) {
		m_pConvert->Create(g_szWorkDir, m_pView->m_Site.m_Login.m_szAddr, m_pView->m_Site.m_Login.m_szSiteName, _T(""));
		//_stprintf(ts,_T("file://%s"),m_pConvert->m_szFile);
		//	m_info.Navigate(ts,FALSE,NULL,NULL,NULL);
	}
#endif//ENABLE_HTMLDOWN

	TRACE(_T("Start download ...\n"));

	SetTimer(TIMER_DLARTICLEDLG, g_nDownTimeout, NULL);
	m_nLastTime = clock();
	m_bOK = FALSE;
	m_bNew = TRUE;
	m_bFirstScr = true;
	m_article = _T("");
	m_article_txt = _T("");
	m_article_ansi = _T("");
	UpdateData(FALSE);

	SITESTATUS nStatus = m_pView->GetStatus();

	if (nStatus == SST_LIST)		//�����б���
		m_pView->Send("r", 1);	// r: �Ķ����¡�

	m_title.Empty();

	// ��ʱ����⵽���ڶ�����״̬�ͻ��Զ�����

	GetDlgItem(IDOK)->EnableWindow(FALSE);

	GetDlgItem(IDC_DLPREV)->EnableWindow(FALSE);

	GetDlgItem(IDC_DLNEXT)->EnableWindow(FALSE);

	GetDlgItem(IDC_CHECK_DLBYLINE)->EnableWindow(FALSE);
}


void CDLArticleDlg::OnTimer(UINT nIDEvent)
{
	//TIMER_DLARTICLEDLG
	if (m_bOK) {
		KillTimer(TIMER_DLARTICLEDLG);
		return;
	}

	if (!m_pView->IsStable()) return;

	if (m_bDLByLine) {
		DLByLine();
	} else {
		DLByScreen();
	}

	CDialog::OnTimer(nIDEvent);
}

void CDLArticleDlg::DLByScreen()		// ��������
{
	if (!m_pView) return;

	SITESTATUS nStatus = m_pView->GetStatus();

//	int start=0;

	if (nStatus == SST_LIST) return;

	if (!m_pView->m_Status.ArticleChanged()) return;

	int nPos = m_pView->m_Status.GetArticlePercent();

	if (nPos < 0 || nPos > 100) {
		//wrong: unkown status or bad status line, may not stable yet
		return;
	}

	//m_npos=nPos;

	static int lastReceiveSize = 0;

	if (m_pView->ReceiveSize() == lastReceiveSize && clock() - m_nLastTime < TIMEOUT_TIME)
		return;

	lastReceiveSize = m_pView->ReceiveSize();

	if (nPos)
		m_prog.SetPos(nPos);	// ������

	if (m_bNew) {	//��ʱ��ˢ����Ļ�����Ա�������������ʱ��ʱ�俴��������
		m_article = _T("");
		m_article_txt = _T("");
		m_article_ansi = _T("");
		UpdateData(FALSE);
		m_bNew = FALSE;
	}

	//FILE *fp = _tfopen(m_filename, _T("at"));		// ׷�ӷ�ʽ���ı��ļ�
	TRACE(_T("nStatus:%d ,m_bOK:%d \n"), nStatus, m_bOK);

	switch (nStatus) {

	case SST_ARTICLE:	//Copy all
		//643�����ģ�80*8��80������8�Ǽ���ANSI���ÿ���ַ����ÿռ䣿
		//m_pView->m_Core.ChangeToTxt(m_ts.GetBuffer(24*643), CRect(0,0,256,21), TRUE); //���ƴ�0�е�21��(ĩ���´θ���), false��ʾ��ѡȡ����
		m_pView->m_Core.ChangeToTxt(m_ts.GetBuffer(m_pView->TermH()*(m_pView->TermW()*8 + 3)),         //8��ansi��Ŀռ䣬3���ַ�����β��־?
		                            CRect(0, 0,
		                                  256, (m_pView->TermH() - 3)));     //0-23, 24�����ڣ�23Ϊ״̬�У�22��һ�����ƣ���Ϊ21=24-3

//		{
//		m_ts.ReleaseBuffer();
//		CString tstr=m_ts.Right( 80 );
//		m_ts.GetBuffer(m_ts.GetLength());
//		}

#if ENABLE_HTMLDOWN
		if (g_bDownloadWithHTML) {
			m_pConvert->AddScreen();//ͬʱ����html(temp)
		}
#endif//ENABLE_HTMLDOWN

		if (nPos == 100) {
			m_pView->Send("q", 1);
			m_bOK = TRUE;
			GetDlgItem(IDOK)->EnableWindow(TRUE);
			GetDlgItem(IDC_DLPREV)->EnableWindow(TRUE);
			GetDlgItem(IDC_DLNEXT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_DLBYLINE)->EnableWindow(TRUE);
		}
		else {
			m_pView->Send(" ", 1);
		}

		m_nLastTime = clock();
		m_bFirstScr = false;
		break;

	case SST_END:	// check &Copy, quit

	case SST_ENTER:
		//643=80*8+3
		m_pView->m_Core.ChangeToTxt(m_ts.GetBuffer(m_pView->TermH() * (m_pView->TermW() * 8 + 3)),
		                            CRect(0, m_bFirstScr ? 0 : m_pView->m_Status.DupLineNum(),
		                                  256, (m_pView->TermH() - 2)));    //0-23, 24�����ڣ�23Ϊ״̬�У���Ϊ22=24-2��ע�⣬û����һ���ˣ�����22��(����ĩ��)ҲҪ����

#if ENABLE_HTMLDOWN
		if (g_bDownloadWithHTML) {
			m_pConvert->AddScreen(!m_bFirstScr);   //ͬʱ����html(temp)
		}
#endif//ENABLE_HTMLDOWN

		m_pView->Send("q", 1);

		m_bOK = TRUE;
		GetDlgItem(IDC_CHECK_DLBYLINE)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		GetDlgItem(IDC_DLPREV)->EnableWindow(TRUE);
		GetDlgItem(IDC_DLNEXT)->EnableWindow(TRUE);
		GetDlgItem(IDC_DLNEXT)->SetFocus();

		break;

	default:
		TRACE(_T("nStatus:%d ,m_bOK:%d clock(), m_nLastTime:%Ld - %Ld = %Ld\n"), nStatus, m_bOK, clock(), m_nLastTime, clock() - m_nLastTime);

		if (clock() - m_nLastTime > TIMEOUT_TIME && !m_bOK) {
			//Warring
			m_nLastTime = clock();

			if (!bInMes) {
				bInMes = TRUE;

				if (MessageBox(_T("����ͣ�ˣ�Ҫֹͣ������(ֹͣ����Գ����ð��п����������ظ�����)"), _T("��������"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
					//�Ƿ����ð��п����������ظ�����
					//Copy
					m_pView->Send("q", 1);
					m_bOK = TRUE;
					GetDlgItem(IDOK)->EnableWindow(TRUE);
					GetDlgItem(IDC_DLPREV)->EnableWindow(TRUE);
					GetDlgItem(IDC_DLNEXT)->EnableWindow(TRUE);
					GetDlgItem(IDC_CHECK_DLBYLINE)->EnableWindow(TRUE);
				} else {
					m_nLastTime = clock();
				}

				bInMes = FALSE;
			}

			//TRACE(_T("3\n"));
		}

		//TRACE(_T("4\n"));
		return;
	}

	if (m_title.IsEmpty())
		m_title = m_pView->m_Core.GetArticleTitle();

	m_ts.ReleaseBuffer();

	CString plaintext = AnsiToTxt(m_ts);

	m_article_txt += plaintext + _T("\r\n");

	m_article_ansi += m_ts + _T("\r\n");	// ANSI

//	TRACE ( _T ( "screen: %d\n\n" ), plaintext.GetLength() );
//	TRACE ( _T ( "article: %d\n\n" ), m_article_txt.GetLength() );
//	TRACE ( _T ( "plaintext: %d\n\n" ), plaintext.GetLength() );

	if (m_read == 0) {
		m_article = m_article_txt;
		//LPTSTR b = m_article.GetBuffer(m_article_txt.GetLength() * 2 + 2);
		//m_article = GB2Unicode((LPCSTR)m_article_txt, (WCHAR *)b);	// ���ı���ʽ
		//m_article.ReleaseBuffer();
	}
	else {
		m_article = m_article_ansi;
	}

	UpdateData(FALSE);

	m_nLastTime = clock();
}

void CDLArticleDlg::DLByLine()	// �������� new
{
	SITESTATUS nStatus = m_pView->GetStatus();
//	int start=0;

	if (nStatus == SST_LIST) return;

	//static int nLineCount=0;

	static int lastReceiveSize = 0;

	if (m_pView->ReceiveSize() == lastReceiveSize && clock() - m_nLastTime < TIMEOUT_TIME)
		return;

	lastReceiveSize = m_pView->ReceiveSize();

	TRACE(_T("in CDLArticleDlg::DLByLine() \t nStatus:%d\n"), nStatus);

	if (nStatus == SST_ARTICLE || nStatus == SST_END || nStatus == SST_ENTER) {
		int nPos = m_pView->m_Status.GetArticlePercent();
		//m_npos=nPos;
		//if(nLineCount>=(m_pView->TermH()-1) || nPos==100)
		//{
		//	nLineCount=0;
		//}

		if (nPos)
			m_prog.SetPos(nPos);

		UpdateData();

		if (m_bFirstScr) {
			m_pView->m_Core.ChangeToTxt(m_ts.GetBuffer(m_pView->TermH()*(m_pView->TermW()*8 + 3)),
			                            CRect(0, 0,
			                                  256, (m_pView->TermH() - 2)));
			//���ƴ�0�е�21��(ĩ���´θ���)

#if ENABLE_HTMLDOWN
			m_pConvert->AddLines(0, (m_pView->TermH() - 2));
#endif//ENABLE_HTMLDOWN
			//nLineCount=(m_pView->TermH()-1);
		} else {
			m_pView->m_Core.ChangeToTxt(m_ts.GetBuffer(m_pView->TermH()*(m_pView->TermW()*8 + 3)),
			                            CRect(0, (m_pView->TermH() - 2),
			                                  256, (m_pView->TermH() - 2)));
#if ENABLE_HTMLDOWN
			m_pConvert->AddLines((m_pView->TermH() - 2));
#endif//ENABLE_HTMLDOWN
			//nLineCount++;
		}

		if (m_bFirstScr) m_bFirstScr = false;

		if (nStatus == SST_ARTICLE) {
			m_pView->Send("\x1b[B", 3);   // �¹�һ��
		}
		else {
			m_pView->Send("q", 1);
			m_bOK = TRUE;
			GetDlgItem(IDOK)->EnableWindow(TRUE);
			GetDlgItem(IDC_DLPREV)->EnableWindow(TRUE);
			GetDlgItem(IDC_DLNEXT)->EnableWindow(TRUE);
			GetDlgItem(IDC_CHECK_DLBYLINE)->EnableWindow(TRUE);
			m_bDLByLine = false;
		}
	}
	else if (clock() - m_nLastTime > TIMEOUT_TIME && !m_bOK) {
		m_pView->Send("\x1b[B", 3);   // �¹�һ��,��ֹ���̬QMD�����״̬�в���ȷ
		m_nLastTime = clock();
		return;
	}
	else {
		m_nLastTime = clock();
		return;
	}

	if (m_title.IsEmpty())
		m_title = m_pView->m_Core.GetArticleTitle();

	m_ts.ReleaseBuffer();

	m_article_txt += AnsiToTxt(m_ts) + _T("\r\n");

	m_article_ansi += m_ts + _T("\r\n");	// ANSI

	if (m_read == 0)
		m_article = m_article_txt;	// ���ı���ʽ
	else
		m_article = m_article_ansi;

	UpdateData(FALSE);

	m_nLastTime = clock();
}

// ����
void CDLArticleDlg::OnOK()
{
	if (m_edit.GetModify()) {
		UpdateData(); // ���ܱ��༭��

		if (m_read == 0)
			m_article_txt = m_article;
		else if (m_read == 1)
			m_article_ansi = m_article; // html�޷����޷��༭
	}

	if (m_title.IsEmpty())
		m_title = _T("�ޱ���");

	int len = m_title.GetLength();

	for (int i = 0; i < len ; i++) {
		if (_tcschr(_T("<>|:*?/\\\""), m_title[i])) {
			m_title.SetAt(i, '-');
		}
	}

	CString sFilter[3] = {
		_T("�ı��ļ� (*.txt)|*.txt|"),
		_T("��ANSI���ɫ�ı� (*.ctd)|*.ctd|")
	}, sFilters, htmlfilter = _T("���ı��ļ�(*.htm)|*.htm|");

	if (!g_bDownloadWithHTML) {
		htmlfilter = _T("");
	}

	if (g_sArticleSaveExt == _T("txt"))
		sFilters = sFilter[0] + sFilter[1] + htmlfilter + _T("|");
	else if (g_sArticleSaveExt == _T("ctd"))
		sFilters = sFilter[1] + sFilter[0] + htmlfilter + _T("|");
	else if (g_sArticleSaveExt == _T("htm"))
		sFilters = htmlfilter + sFilter[0] + sFilter[1] + _T("|");

	CFileDialogEx fd(FALSE, g_sArticleSaveExt, m_title, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               sFilters);

	//fd.m_ofn.lpstrDefExt=g_sArticleSaveExt;
	if (fd.DoModal() == IDOK) {
		CString s = fd.GetFileExt();

		if (!s.CompareNoCase(_T("ctd"))) {
			CStdioFile f;
			
			if (!f.Open(fd.GetFileName(), CFile::modeWrite | CFile::modeCreate | CFile::typeBinary | CFile::shareExclusive)) {
				AfxMessageBox(_T("�����ļ�ʧ��!"));
				return;
			}
			g_sArticleSaveExt = _T("ctd");   //remember it
			f.Write(m_article_ansi, m_article_ansi.GetLength());
			f.Close();
		}
		else if (!s.CompareNoCase(_T("htm")) || !s.CompareNoCase(_T("html"))) {
#if ENABLE_HTMLDOWN
			g_sArticleSaveExt = _T("htm");
			//CString sHTML=AnsiToHTML(m_article);
			//f.Write(sHTML, sHTML.GetLength());
			//html(temp):

			if (!g_bDownloadWithHTML) {
				AfxMessageBox(_T("�Բ���htmlû�б����ء��޷�����:("));
			}
			else {
				CopyFile(m_pConvert->m_szFile, fd.GetPathName(), TRUE);
			}

#endif//ENABLE_HTMLDOWN
		}
		else { //text
			CStdioFile f;
			
			if (!f.Open(fd.GetFileName(), CFile::modeWrite | CFile::modeCreate | CFile::typeBinary | CFile::shareExclusive)) {
				AfxMessageBox(_T("�����ļ�ʧ��!"));
				return;
			}
			
			g_sArticleSaveExt = _T("txt");
			//CString sTxt=AnsiToTxt(m_article_txt);
			f.Write(m_article_txt, m_article_txt.GetLength());
			f.Close();
		}
	}
}

void CDLArticleDlg::OnClose()
{
	OnCancel();	
}

void CDLArticleDlg::OnCancel()
{
// ɾ����ʱ�ļ� temp.htm �� temp.txt
//	CString ts = g_szWorkDir + _T("temp.htm");
//	DeleteFile(ts);
//	ts = g_szWorkDir + _T("temp.txt");
//	DeleteFile(ts);
//	if(m_pConvert)
//		delete m_pConvert;
	CRect rect;
	GetWindowRect(&rect);
	g_nDLDlgWidth = rect.Width();
	g_nDLDlgHeight = rect.Height();

	KillTimer(TIMER_DLARTICLEDLG);
	CDialog::OnCancel();
}

void CDLArticleDlg::OnDlprev()
{
	if (!m_pView->IsStable())
		return;

	SITESTATUS nStatus = m_pView->GetStatus();

	if (nStatus != SST_ARTICLE && nStatus != SST_END && nStatus != SST_ENTER) {
		m_pView->Send("k", 1);	// k:����һƪ
		InitDL();
	}
}

void CDLArticleDlg::OnDlnext()
{
	if (!m_pView->IsStable())
		return;

	SITESTATUS nStatus = m_pView->GetStatus();

	if (nStatus != SST_ARTICLE && nStatus != SST_END && nStatus != SST_ENTER) {
		m_pView->Send("j", 1);	// j:����һƪ
		InitDL();
	}
}

void CDLArticleDlg::OnCheckToggleedit()
{
	UpdateData();
	Toggleedit();
}

void CDLArticleDlg::Toggleedit()
{
	if (!m_bShowEdit) {
		m_edit.ShowWindow(SW_HIDE);
		CRect rect, rect1;
		GetWindowRect(&rect);
		//m_edit.GetWindowRect(&rect1);
		rect.bottom = rect.top + m_pView->TermW();
		MoveWindow(rect);
	} else {
		CRect rect, rect1;
		GetWindowRect(&rect);
		rect.bottom = rect.top + 486;
		MoveWindow(rect);
		//m_edit.GetWindowRect(&rect1);
		//rect1.top=35;	//rect.top+0;
		//rect1.bottom =rect.bottom -30;
		//rect1.left =10;
		//rect1.right =rect.right -10;

		m_edit.ShowWindow(SW_SHOW);
		//m_edit.MoveWindow(rect1);
	}
}

void CDLArticleDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);

	if (GetDlgItem(IDC_ARTICLE)) {	//�˾���뱣������������ʾ�˶Ի���ʱ�������
		CRect rect;
		rect = CRect(0, 0, cx, cy);
		rect.left += 2;
		rect.right -= 2;
		rect.top += 35;
		rect.bottom -= 20;
		GetDlgItem(IDC_ARTICLE)->MoveWindow(&rect);

		rect.top = cy - 15;
		rect.bottom = cy - 5;
		GetDlgItem(IDC_PROGRESS1)->MoveWindow(&rect);

		/*	��ǰ����Щ��ť�����ڵײ�����Ҫ��Ӧ���ƶ����ַ����ڶ���������Ҫ�ƶ���
			  rect.top=5;
			  rect.bottom=rect.top+22;

			  rect.left=cx-420;
			  rect.right=rect.left+90;
			  GetDlgItem(IDC_DLPREV)->MoveWindow(&rect);

			  rect.left=cx-300;
			  rect.right=rect.left+90;
			  GetDlgItem(IDC_DLNEXT)->MoveWindow(&rect);

			  rect.left=cx-200;
			  rect.right=rect.left+90;
			  GetDlgItem(IDOK)->MoveWindow(&rect);
			  rect.left=cx-100;
			  rect.right=rect.left+90;
			  GetDlgItem(IDCANCEL)->MoveWindow(&rect);
		*/
	}
}


BOOL CDLArticleDlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN) {
		if (isdown(VK_CONTROL)
		        && pMsg->lParam >= 0
		   ) {
			if (pMsg->wParam == 'A') {
				// ^A ȫѡ
				m_edit.SetFocus();
				m_edit.SetSel(0, -1, TRUE);
				return TRUE;
			}
			else if (pMsg->wParam == 'C') {
				// || pMsg->wParam == 'X'

				int maxlen = m_article.GetLength() * 2 + 2;
				//char *buf = new char[maxlen];
				
				HGLOBAL hmem;
				TCHAR * p = startcopy(maxlen, hmem);
				if (p) {
					memcpy(p, (LPCSTR)m_article, m_article.GetLength() + 1);
					GB2Unicode(p);
					//memcpy(p, buf, ?);
				}
				endcopy(hmem);
		
				//delete [] buf;

//				if (pMsg->wParam == 'X') {
//					m_article.Empty();
//					UpdateData(FALSE);
//				}
				return TRUE;
			}
			else if (pMsg->wParam == 'F') {
				// ^F ����
				if (GetFocus() != &m_ctrl_keyword) {
					m_ctrl_keyword.ShowWindow(SW_SHOW);
					m_ctrl_keyword.SetFocus();
				} else {
					m_ctrl_keyword.ShowWindow(SW_HIDE);
				}
				return TRUE;
			}
		}
		else if (pMsg->wParam == VK_RETURN) {
			if (GetFocus() == &m_ctrl_keyword) {
				// ִ������
				UpdateData();
				if (!m_keyword.IsEmpty()) {
					int nStartChar = 0,  nEndChar = 0;

					if (m_keyword != m_lastKeyword) {
						m_edit.SetSel(0, 0);
					}
					else {
						m_edit.GetSel(nStartChar, nEndChar);
					}

					int pos = m_article.Find(m_keyword, nEndChar);
					if (pos != -1) {
						m_edit.SetSel(pos, pos + m_keyword.GetLength());
						// ����ý����ʱ��Ż����ѡ��
						//			m_edit.RedrawWindow();
					} 
					else {
						m_edit.SetSel(nEndChar, nEndChar);
					}
				}
				m_edit.SetFocus();
				m_lastKeyword = m_keyword;
				return TRUE;
			}
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CDLArticleDlg::OnReadText()
{
	m_read = 0;
	m_article = m_article_txt;
	UpdateData(FALSE);
}

void CDLArticleDlg::OnReadAnsi()
{
	m_read = 1;
	m_article = m_article_ansi;
	UpdateData(FALSE);
}

void CDLArticleDlg::OnCheckDlbyline()
{
	UpdateData();

	if (!m_pView->IsStable())
		return;

	ASSERT(m_pView->GetStatus() == SST_LIST);

	InitDL();
}

void CDLArticleDlg::OnChangeKeyword() 
{
}

void CDLArticleDlg::OnKillfocusKeyword() 
{
	m_ctrl_keyword.ShowWindow(SW_HIDE);
	m_edit.SetFocus();
}
#define _UNICODE
