#define ICONV_SET_DISCARD_ILSEQ   4  /* const int *argument */

typedef void* libiconv_t;
extern "C" {
typedef __declspec(dllimport) libiconv_t (*fn_libiconv_open) (const char* tocode, const char* fromcode);
typedef __declspec(dllimport) size_t (*fn_libiconv) (libiconv_t cd, const char* * inbuf, size_t *inbytesleft, char* * outbuf, size_t *outbytesleft);
typedef __declspec(dllimport) int (*fn_libiconv_close) (libiconv_t cd);
typedef __declspec(dllimport) int (*fn_libiconvctl) (libiconv_t cd, int request, void* argument);

typedef libiconv_t iconv_t;

fn_libiconv_open iconv_open;
fn_libiconv iconv;
fn_libiconv_close iconv_close;
fn_libiconvctl iconvctl;
}

void init_iconv()
{
	static bool inited = false;
	if (!inited) {
		HMODULE iconv_handle = LoadLibrary(_T("iconv.dll"));
		
		if (iconv_handle) {
			iconv_open = (fn_libiconv_open) GetProcAddress(iconv_handle, "libiconv_open");
			iconv = (fn_libiconv) GetProcAddress(iconv_handle, "libiconv");
			iconv_close = (fn_libiconv_close) GetProcAddress(iconv_handle, "libiconv_close");
			iconvctl = (fn_libiconvctl) GetProcAddress(iconv_handle, "libiconvctl");

			if (iconv_open && iconv && iconv_close && iconvctl) inited = true;
		}
	}
}
