// OptBossPage.cpp : implementation file
//

#include "stdafx.h"

#if ENABLE_HOTKEY
#include "OptBossPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptBossPage property page

IMPLEMENT_DYNCREATE(COptBossPage, CMyPropertyPage)

COptBossPage::COptBossPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptBossPage)
	m_bOldEffect = FALSE;
	m_bBossMouse = FALSE;
	m_bExecute = FALSE;
	m_programe = _T("");
	m_bBossKey = TRUE;
	m_bBosskeyFtermStyle = FALSE;
	//}}AFX_DATA_INIT
}

COptBossPage::~COptBossPage()
{
}

void COptBossPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptBossPage)
	DDX_Control(pDX, IDC_BOSSKEYSHOW, m_chkBossKeyShow);
	DDX_Control(pDX, IDC_BOSSHOTKEYSHOW, m_editBossHotkeyShow);
	DDX_Control(pDX, IDC_BOSSMOUSE, m_chkBossMouse);
	DDX_Control(pDX, IDC_BOSSHOTKEY, m_editBossHotKey);
	DDX_Check(pDX, IDC_OLDBOSSKEY, m_bOldEffect);
	DDX_Check(pDX, IDC_BOSSMOUSE, m_bBossMouse);
	DDX_Check(pDX, IDC_EXECUTE, m_bExecute);
	DDX_Text(pDX, IDC_PROGRAM, m_programe);
	DDX_Check(pDX, IDC_BOSSKEY, m_bBossKey);
	DDX_Check(pDX, IDC_BOSSKEYSTYLE, m_bBosskeyFtermStyle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptBossPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptBossPage)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_EXECUTE, OnExecute)
	ON_BN_CLICKED(IDC_BOSSKEY, Onbosskey)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptBossPage message handlers

void COptBossPage::OnBrowse()		// �����ϰ��ʱִ�еĳ�����ļ�
{
	CFileDialogEx fd(TRUE, _T(""), m_programe, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("�����ļ�(*.*)|*.*||"));

	if (fd.DoModal() == IDOK) {
		UpdateData();
		m_programe = fd.GetPathName();
		//GetDlgItem(IDC_BROWSE)->SetWindowText(m_programe);
		UpdateData(FALSE);
	}
}

void COptBossPage::OnExecute()
{
	UpdateData();
	GetDlgItem(IDC_BROWSE)->EnableWindow(m_bExecute);
}

BOOL COptBossPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	GetDlgItem(IDC_BROWSE)->EnableWindow(m_bExecute);
	//GetDlgItem(IDC_BROWSE)->SetWindowText(m_programe);

	m_bBossKey = !(m_BossHotkey.IsEqual(CHotKey()));
	UpdateData(FALSE);
	m_editBossHotKey.EnableWindow(m_bBossKey);

	ShowOldKey();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

// ��ini��ȡ����ʾ��edit
void COptBossPage::ShowOldKey()
{
	CString sKey;
	m_BossHotkey.GetString(sKey);
	m_editBossHotKey.SetWindowText(sKey);   //m_editBossHotKey.DisplayKeyboardString();
	m_BossHotkeyShow.GetString(sKey);
	m_editBossHotkeyShow.SetWindowText(sKey);
}

UINT COptBossPage::GetIDD()
{
	return IDD;
}

void COptBossPage::Onbosskey() 
{
	UpdateData();
	m_editBossHotKey.EnableWindow(m_bBossKey);
	m_chkBossMouse.EnableWindow(m_bBossKey);
	m_chkBossKeyShow.EnableWindow(m_bBossKey);
	m_editBossHotkeyShow.EnableWindow(m_bBossKey);
	if (m_bBossKey) {
		m_BossHotkey = CHotKey();	//_T("");
		m_editBossHotKey.SetFocus();
	}
}

void COptBossPage::OnOK() 
{
	UpdateData();
	if (m_bBossKey)
		m_editBossHotKey.SetKey(m_BossHotkey);
	
	CMyPropertyPage::OnOK();
}

#endif//ENABLE_HOTKEY

