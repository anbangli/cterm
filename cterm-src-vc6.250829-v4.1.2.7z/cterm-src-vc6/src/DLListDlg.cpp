// DLListDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DLListDlg.h"
#include "askdlg.h"
#include "ctermview.h"
#include "global.h"
#include "usermsg.h"
#include "paramconfig.h"

#if ENABLE_HTMLDOWN
#include "HTMLConvert.h"	// HTMLת��
#endif//ENABLE_HTMLDOWN

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDLListDlg dialog

#if ENABLE_HTMLDOWN

CDLListDlg::CDLListDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CDLListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDLListDlg)
	m_cond = _T("");
	m_destfile = _T("");
	m_nNowDL = _T("");
	m_bAdd = FALSE;
	m_author = _T("");
	m_EndDate = -1;
	m_EndMonth = -1;
	m_EndNum = 0;
	m_Flag = _T("");
	m_bOr = -1;
	m_StartDate = -1;
	m_StartMonth = -1;
	m_StartNum = 0;
	m_Title1 = _T("");
	m_Title2 = _T("");
	//}}AFX_DATA_INIT
	m_pPage = NULL;
	m_pBak = NULL;
	m_pIndexPage = NULL;
	m_szLast[0] = 0;
}

CDLListDlg::~CDLListDlg()
{
}


void CDLListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDLListDlg)
	DDX_Control(pDX, IDC_ONE_PROG, m_oneprog);
	DDX_Control(pDX, IDC_ALLPROG, m_allprog);
	//DDX_Text(pDX, IDC_DL_COND, m_cond);
	DDX_Text(pDX, IDC_DESTFILE, m_destfile);
	DDX_Text(pDX, IDC_DL_NUM, m_nNowDL);
	DDX_Check(pDX, IDC_ADD, m_bAdd);
	DDX_Text(pDX, IDC_AUTHOR, m_author);
	DDX_CBIndex(pDX, IDC_END_DATE, m_EndDate);
	DDX_CBIndex(pDX, IDC_END_MONTH, m_EndMonth);
	DDX_Text(pDX, IDC_END_NUM, m_EndNum);
	DDX_Text(pDX, IDC_FLAG_SET, m_Flag);
	DDX_CBIndex(pDX, IDC_OR_AND, m_bOr);
	DDX_CBIndex(pDX, IDC_START_DATE, m_StartDate);
	DDX_CBIndex(pDX, IDC_START_MONTH, m_StartMonth);
	DDX_Text(pDX, IDC_START_NUM, m_StartNum);
	DDX_Text(pDX, IDC_TITLE_1, m_Title1);
	DDX_Text(pDX, IDC_TITLE_2, m_Title2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDLListDlg, CDialog)
	//{{AFX_MSG_MAP(CDLListDlg)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLListDlg message handlers

BOOL CDLListDlg::OnInitDialog()
{
	m_Condition.cFlag = ' ';
	m_Condition.m_bOr = -1;
	m_Condition.nStart = 0;
	m_Condition.nEnd = 0;
	m_Condition.nStartDate = 0;
	m_Condition.nEndDate = 30;
	m_Condition.nStartMonth = 0;
	m_Condition.nEndMonth = 11;
	m_Condition.szAuthor[0] = 0;
	m_Condition.szTitle[0][0] = m_Condition.szTitle[1][0] = 0;

	m_StartNum = m_Condition.nStart;
	m_EndNum = m_Condition.nEnd;
	m_StartDate = m_Condition.nStartDate;
	m_StartMonth = m_Condition.nStartMonth;
	m_EndMonth = m_Condition.nEndMonth;
	m_EndDate = m_Condition.nEndDate;
	m_StartNum = m_Condition.nStart;
	m_Flag = m_Condition.cFlag;

	if (m_Flag == _T(" "))
		m_Flag = _T("");

	m_author = m_Condition.szAuthor;

	m_Title1 = m_Condition.szTitle[0];

	m_Title2 = m_Condition.szTitle[1];

	m_bOr = m_Condition.m_bOr;

//	UpdateData();
	CDialog::OnInitDialog();

#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);

#endif// ENABLE_MULTILANG

	m_bAdd = FALSE;

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDLListDlg::OnTimer(UINT nIDEvent)
{
	static BOOL bBusy = FALSE;

	if (bBusy) return;

	AutoRunStatus n = m_Run.QueryStatus();

	if (n) {
		if (n == AutoRun_OK) {   //Ok
			m_Run.m_nStatus = m_Run.m_nNextStatus;
		} else {
			if (n == AutoRun_Timeout) {
				switch (m_Run.m_nStatus) {

				case DLS_SEARCH_NEXT://�ֹ���Ԥ

				case DLS_COPY: {
					static int retType = 0;

					if (g_iAskDlg == -1) {
						CAskDlg Dlg;

						if (retType >= 0 && retType <= 3) {
							Dlg.m_nType = retType;
						}

						bBusy = TRUE;

						Dlg.m_nType = 0;

						if (Dlg.DoModal() == IDOK) {
							retType = Dlg.m_nType;
						} else
							retType = -1;

						bBusy = FALSE;
					} else {
						retType = g_iAskDlg;
					}

					switch (retType) {

					case 0:
						m_Run.EnterNextStage(_T("\x1b[D"), 3, SST_LIST, DLS_SEARCH_NEXT);
						break;

					case 1:
						m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DLS_COPY);
						break;

					case 2:
						m_Run.EnterNextStage(_T("\x0c"), 3, SST_LIST, DLS_SEARCH_NEXT); //^L
						break;

					case 3:
						// �Զ��ж�

						if (m_Run.m_pView) {
							SITESTATUS st = m_Run.m_pView->GetStatus();

							switch (st) {

							case SST_END:
								m_Run.EnterNextStage(_T("\x1b[D"), 3, SST_LIST, DLS_SEARCH_NEXT);
								break;

							case SST_ARTICLE:
								m_Run.ChangeStatus(DLS_COPY); //m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DLS_COPY);
								break;

							case SST_LIST:
								m_Run.EnterNextStage(_T("\x0c"), 1, SST_LIST, DLS_SEARCH_NEXT);
								break;

							default:
								m_Run.EnterNextStage(_T("j"), 1, SST_UNKNOWN, DLS_SET);
							}
						}

						break;

					default: //-1:cancel, other:invalid
						m_Run.m_nTime = clock();
					}
				}

				break;
				}
			}

			return;
		}

		switch (m_Run.m_nStatus) {
			case DLS_SEARCH_NEXT:
				SearchNext();
				break;

			case DLS_COPY:
				CopyArticle();
				break;
		}
	}

	CDialog::OnTimer(nIDEvent);
}

// ��ʼ����, ������ͷ��ʼ�ʹӶϵ㿪ʼ
void CDLListDlg::OnOK()
{
	UpdateData();

	m_Condition.nStart = m_StartNum;
	m_Condition.nEnd = m_EndNum;
	_tcscpy(m_Condition.szAuthor, m_author);

	if (!m_Flag.IsEmpty()) {
		m_Condition.cFlag = *m_Flag.LockBuffer();
		m_Flag.UnlockBuffer();
	} else
		m_Condition.cFlag = ' ';

	m_Condition.nStartMonth = m_StartMonth;

	m_Condition.nEndMonth = m_EndMonth;

	m_Condition.nStartDate = m_StartDate;

	m_Condition.nEndDate = m_EndDate;

	_tcscpy(m_Condition.szTitle[0], m_Title1);

	_tcscpy(m_Condition.szTitle[1], m_Title2);

	m_Condition.m_bOr = m_bOr;

	if (!CreateIndexFile()) {
		MessageBox(_T("���ܴ�Ŀ���ļ���"), _T("��������"), MB_OK | MB_ICONERROR);
		return ;
	}

	GetDlgItem(IDOK)->EnableWindow(FALSE);

	GetDlgItem(IDC_ADD)->EnableWindow(FALSE);

	TCHAR ts[100];
	//First Start :Goto First Article
	m_Condition.nAllPage = m_Condition.nStart;

	if (m_Condition.nAllPage <= 0) m_Condition.nAllPage = 1;

	if (m_Condition.nStart)
		_stprintf(ts, _T("%d\n"), m_Condition.nStart);
	else {
		_tcscpy(ts, _T("1\n"));
		m_Condition.nStart = 1;
	}

//	CopyPicture();
	m_Run.EnterNextStage(ts, _tcslen(ts), SST_LIST, DLS_SEARCH_NEXT);

	SetTimer(TIMER_DLLISTDLG, g_nDownTimeout, NULL);
}

void CDLListDlg::SearchNext()		// ������һƪ
{
	if (!m_Run.m_pView)	return;

	CCTermCore *pCore = &m_Run.m_pView->m_Core;

	SArticleList Article;

	TCHAR szLine[256] = _T("");

	BOOL bResult;

	int i, nStart;

	for (i = 3; i < (m_Run.m_pView->TermH() - 1); i++) {
		if (pCore->line(i + pCore->MaxStartLine())[0].GetChar() != ' ')
			break;
	}

	if (i >= (m_Run.m_pView->TermH() - 1))
		return;

	nStart = i;

	for (i = nStart; i < (m_Run.m_pView->TermH() - 1); i++) {
		pCore->GetLineStr(szLine, i);

		if (rStrip(szLine) < 5) {      //Empty line
			//Ending DownLoad
			WriteLink(TRUE);
			DLEnd();
			return;
		}

		if (m_Run.m_pView->SiteType() == ST_MAPLE)
			bResult = Article.GetArticle_Maple(szLine);
		else
			bResult = Article.GetArticle(szLine);

		if (bResult) {
			if (Article.m_nIndex > (int) m_Condition.nEnd && m_Condition.nEnd) {
				//End
				WriteLink(TRUE);
				DLEnd();
				return;
			}

			if (Article.m_nIndex < (int) m_Condition.nStart && m_Condition.nStart)
				continue;

			if (m_Condition.nStartMonth != -1 && Article.m_nMonth - 1 < m_Condition.nStartMonth)
				continue;

			if (m_Condition.nStartDate != -1 && m_Condition.nStartMonth != -1
			        && Article.m_nDate - 1 < m_Condition.nStartDate && Article.m_nMonth - 1 == m_Condition.nStartMonth)
				continue;

			if (m_Condition.nEndMonth && Article.m_nMonth - 1 > m_Condition.nEndMonth)
				continue;

			if (m_Condition.nEndDate != -1 && m_Condition.nEndMonth != -1
			        && Article.m_nDate - 1 > m_Condition.nEndDate && Article.m_nMonth - 1 == m_Condition.nEndMonth)
				continue;

			if (m_Condition.cFlag != ' ' && Article.m_cFlag != m_Condition.cFlag && abs(Article.m_cFlag - m_Condition.cFlag) != 32)
				continue;

			if (!isempty(m_Condition.szAuthor) && _tcsicmp(m_Condition.szAuthor, Article.m_szAuthor))
				continue;

			if (!isempty(m_Condition.szTitle[0]) && !InString(m_Condition.szTitle[0], Article.m_szName)) {
				if (!m_Condition.m_bOr)
					continue;

				if (!InString(m_Condition.szTitle[1], Article.m_szName) || isempty(m_Condition.szTitle[1]))
					continue;
			} else {
				if (!m_Condition.m_bOr &&
				        _tcslen(m_Condition.szTitle[1]) &&
				        !InString(m_Condition.szTitle[1], Article.m_szName))
					continue;
			}

			//Ok
			m_Condition.nStart = Article.m_nIndex + 1;

			//before new pBak is stored last page
			if (m_pPage) {
				delete m_pPage;
				m_pPage = NULL;
			}

			m_pPage = new CHTMLConvert(&m_Run.m_pView->m_Core);

			_stprintf(m_szNextFile, _T("%s%d.htm"), m_szPath, Article.m_nIndex);
			AddList(Article);

			if (!m_pPage->Create(m_szNextFile, m_Run.m_pView->m_Site.m_Login.m_szAddr,
			                     m_Run.m_pView->m_Site.m_Login.m_szSiteName, Article.m_szName, FALSE, FALSE)) {
				delete m_pPage;
				m_pPage = NULL;
				continue;
			}

			//when create successful ,Deal with Last File
			WriteLink();

			_stprintf(szLine, _T("%d\n\n"), Article.m_nIndex);

			m_Run.EnterNextStage(szLine, _tcslen(szLine), SST_ARTICLE, DLS_COPY);

			SetAllProg(Article.m_nIndex);

			//Add to List
			return;
		} else //Error
			continue;
	}

	if (i >= (m_Run.m_pView->TermH() - 1))     //PgDown
		m_Run.EnterNextStage(_T(" "), 1, SST_LIST, DLS_SEARCH_NEXT);
}

void CDLListDlg::CopyArticle()
{
	if (m_Run.m_pView->GetStatus() == SST_END) {
		m_Run.EnterNextStage(_T("\x1b[D"), 3, SST_LIST, DLS_SEARCH_NEXT);

		if (m_pPage) {
			m_pPage->AddScreen(TRUE);

			if (m_pBak) {
				_tcscpy(m_szLast, (LPCSTR)m_pBak->m_szFile.Right(m_pBak->m_szFile.GetLength() - _tcslen(m_szPath)));
				delete m_pBak;
			}

			m_pBak = m_pPage;

			m_pPage = NULL;
			m_oneprog.SetPos(0);
		}
	} else {
		int nPos = m_Run.m_pView->m_Status.GetArticlePercent();

		if (m_pPage) {
			m_pPage->AddScreen(FALSE);
			m_oneprog.SetPos(nPos);
		}

		if (nPos >= 0 && nPos <= 100) {
			m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DLS_COPY);
		}
	}
}

void CDLListDlg::OnBrowse()
{
	CFileDialogEx fd(FALSE, _T("htm"), _T("index.htm"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("HTML�ļ�(*.htm)|*.htm||"));
	UpdateData();

	if (fd.DoModal() == IDOK) {
		m_destfile = fd.GetPathName();
		UpdateData(FALSE);
	}
}

BOOL CDLListDlg::CreateIndexFile()
{
	TCHAR szFile[300], *p;
	_stprintf(szFile, m_destfile);

	if (m_pIndexPage) {
		delete m_pIndexPage;
		m_pIndexPage = NULL;
	}

	m_pIndexPage = new CHTMLConvert(&m_Run.m_pView->m_Core);

	if (!m_pIndexPage->Create(szFile, m_Run.m_pView->m_Site.m_Login.m_szAddr,
	                          m_Run.m_pView->m_Site.m_Login.m_szSiteName,
	                          _T("�����������б�"), FALSE, TRUE)) {
		delete m_pIndexPage;
		m_pIndexPage = NULL;
		return FALSE;
	}

	_tcscpy(m_szPath, szFile);

	p = m_szPath + _tcslen(m_szPath);

	while (*p != '\\' && *p != ':' && p > m_szPath)
		p--;

	if (p > m_szPath)
		p[1] = 0;
	else
		return FALSE;

	m_pIndexPage->AddLine(_T("<p ALIGN=\"center\">\n"));

	return TRUE;
}

void CDLListDlg::DLEnd()
{
	if (m_pIndexPage)
		m_pIndexPage->AddLine(_T("</p>"));

	if (m_pPage) {
		delete m_pPage;
		m_pPage = NULL;
	}

	if (m_pBak) {
		delete m_pBak;
		m_pBak = NULL;
	}

	if (m_pIndexPage) {
		delete m_pIndexPage;
		m_pIndexPage = NULL;
	}

	if (m_pPage) {
		delete m_pPage;
		m_pPage = NULL;
	}

		
	KillTimer(TIMER_DLLISTDLG);
	CDialog::OnOK();

	CString msg;
	msg.Format(_T("���������ļ�������������ҳ�ļ�Ϊ��\n  %s\n\n�Ƿ�򿪲鿴��"), m_destfile);
	//if (MessageBox(_T("���������ļ��������Ƿ��������ҳ�ļ���"), _T("���������ļ�"), MB_YESNO | MB_ICONQUESTION) == IDYES) 
	if (MessageBox(msg, _T("���������ļ�"), MB_YESNO | MB_ICONQUESTION) == IDYES) 
		ShellExecute ( NULL, _T ( "open" ), _T ( m_destfile ), NULL, NULL, NULL );
}

void CDLListDlg::SetAllProg(int nNow)
{
	int nAll;
	TCHAR ts[20];
	nAll = m_Condition.nEnd - m_Condition.nAllPage + 1;

	if (nAll <= 0) nAll = 1;

	if (m_Condition.nEnd > 0)
		m_allprog.SetPos((nNow - m_Condition.nAllPage) *100 / nAll);

	UpdateData();

	_stprintf(ts, _T("%d"), nNow);

	m_nNowDL = ts;

	UpdateData(FALSE);
}

void CDLListDlg::OnCancel()
{
	KillTimer(TIMER_DLLISTDLG);

	if (m_Run.m_nStatus == 0) {
		CDialog::OnCancel();
	} else if (MessageBox(_T("����δ���,��¼�ϵ��ļ��Ա����´ν���������?"), _T("�����ж�"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
		CFileDialogEx fd(FALSE, _T("dlc"), _T("*.dlc"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		               _T("����Ŀ¼�ϵ��¼�ļ�(*.dlc)|*.dlc||"));

		if (fd.DoModal() == IDOK) {
			SListContinue SLC;
			SLC.nIndexFileAt = m_pIndexPage->GetFileAt();
			memcpy(&SLC.Cond, &m_Condition, sizeof(m_Condition));
			_tcscpy(SLC.szFile, m_destfile);
			FILE *fp = _tfopen(fd.GetPathName(), _T("wb"));

			if (fp) {
				fwrite(&SLC, sizeof(SLC), 1, fp);
				fclose(fp);
			}
		}
	}

	DLEnd();

	//	CDialog::OnCancel();
}

void CDLListDlg::OnAdd()		// �ָ��ϵ�����
{
	CFileDialogEx fd(TRUE, _T("dlc"), _T("*.dlc"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("����Ŀ¼�ϵ��¼�ļ�(*.dlc)|*.dlc||"));

	if (fd.DoModal() == IDOK) {
		SListContinue SLC;
		FILE *fp;
		TCHAR *p, ts[10];

		fp = _tfopen(fd.GetPathName(), _T("rb"));

		if (!fp)
			return;

		fread(&SLC, sizeof(SLC), 1, fp);

		fclose(fp);

		memcpy(&m_Condition, &SLC.Cond, sizeof(m_Condition));

		if (m_pIndexPage == NULL) {
			m_pIndexPage = new CHTMLConvert(&m_Run.m_pView->m_Core);
		}

		if (!m_pIndexPage->Create(SLC.szFile, SLC.nIndexFileAt, &m_Run.m_pView->m_Core)) {
			return;
		}

		_tcscpy(m_szPath, SLC.szFile);

		m_destfile = m_szPath;
		p = m_szPath + _tcslen(m_szPath);

		while (*p != '\\' && *p != ':' && p > m_szPath)
			p--;

		if (p > m_szPath)
			p[1] = 0;
		else
			return;

		m_StartNum = m_Condition.nStart;

		m_EndNum = m_Condition.nEnd;

		m_StartDate = m_Condition.nStartDate;

		m_StartMonth = m_Condition.nStartMonth;

		m_EndMonth = m_Condition.nEndMonth;

		m_EndDate = m_Condition.nEndDate;

		m_StartNum = m_Condition.nStart;

		m_Flag = m_Condition.cFlag;

		if (m_Flag == _T(" "))
			m_Flag = _T("");

		m_author = m_Condition.szAuthor;

		m_Title1 = m_Condition.szTitle[0];

		m_Title2 = m_Condition.szTitle[1];

		m_bOr = m_Condition.m_bOr;

		UpdateData(FALSE);

		GetDlgItem(IDOK)->EnableWindow(TRUE);

		GetDlgItem(IDC_ADD)->EnableWindow(TRUE);

		//First Start :Goto First Article
		//m_Condition.nAllPage=m_Condition.nStart;
		if (m_Condition.nAllPage <= 0) m_Condition.nAllPage = 1;

		if (m_Condition.nStart)
			_stprintf(ts, _T("%d\n"), m_Condition.nStart);
		else {
			_tcscpy(ts, _T("1\n"));
			m_Condition.nStart = 1;
		}

		m_Run.EnterNextStage(ts, _tcslen(ts), SST_LIST, DLS_SEARCH_NEXT);
	}
}

void CDLListDlg::AddList(SArticleList Article)
{

	TCHAR ts[300], szLink[300];

	if (Article.m_nIndex % 2)
		m_pIndexPage->AddLine(_T("<table border=\"0\" width=\"80%%\" align=\"center\" bgcolor=\"#302010\">\n"));
	else
		m_pIndexPage->AddLine(_T("<table border=\"0\" width=\"80%%\" align=\"center\" bgcolor=\"#103010\">\n"));

	_stprintf(szLink, _T("<a href=\"%d.htm\"><font color=\"#FFFFFF\">%s</font></a>"),
	          Article.m_nIndex,
	          Article.m_szName);

	_stprintf(ts, _T("<tr>\n<td width=\"15%%\"><font color=\"#FFFFFF\">%d</font></td>\n<td width=\"30%%\"><font color=\"#FFFFFF\">%s</font></td>\n<td width=\"55%%\">%s</td>\n</tr>\n"),
	          Article.m_nIndex,
	          Article.m_szAuthor,
	          szLink);

	m_pIndexPage->AddLine(ts);

	m_pIndexPage->AddLine(_T("</table>\n"));

}

/*
void CDLListDlg::CopyPicture()
{
    //Task :Copy Jpg Pic to dest Path
//	CString ts = g_szWorkDir + _T("adv.gif");
//	CString dest = g_szWorkDir + _T("adv.gif");
//	CopyFile(ts,dest,0);

	ts = g_szWorkDir + _T("logo.gif");
	_stprintf(dest,_T("%slogo.gif"),m_szPath);
	CopyFile(ts,dest,0);
}
*/

void CDLListDlg::WriteLink(BOOL bLast)
{
	//DealWith pBak
	/*
	    X X X X X X x
		^         T ^
	*/
	TCHAR ts[300], szLink[100];
	_tcscpy(ts,
	        _T("<P ALIGN=\"center\"><font size=\"2\" color=\"#FFFFFF\">\n"));

	if (!m_pBak)   //First File
		return;

	//_stprintf(szLink, _T("<a href=\"%s\">����ҳ��</a>"), (LPCSTR)m_pBak->m_szFile.Right(m_pBak->m_szFile.GetLength() - _tcslen(m_szPath)));	//����
		_stprintf(szLink, _T("<a href=\"%s\">����ҳ��</a>"), (LPCSTR)m_destfile.Right(m_destfile.GetLength() - _tcslen(m_szPath)));

	_tcscat(ts, szLink);

	if (!isempty(m_szLast)) {
		_stprintf(szLink, _T(" | <a href=\"%s\">��һƪ</a>"), m_szLast);
		_tcscat(ts, szLink);
	}

	if (!bLast) {
		//_stprintf(szLink, _T(" | <a href=\"%s\">��һƪ</a>"), (LPCSTR)m_pBak->m_szFile.Right(m_pBak->m_szFile.GetLength() - _tcslen(m_szPath))); //����
		CString m_nextfile = _T(m_szNextFile);
		

		_stprintf(szLink, _T(" | <a href=\"%s\">��һƪ</a>"), (LPCSTR)m_nextfile.Right(m_nextfile.GetLength() - _tcslen(m_szPath)));
		_tcscat(ts, szLink);
	}

	_tcscat(ts, _T("\n</font></P>"));

	m_pBak->AddLine(ts);
}

#endif//ENABLE_HTMLDOWN
