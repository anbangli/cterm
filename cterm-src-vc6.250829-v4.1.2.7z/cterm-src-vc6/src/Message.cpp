// Message.cpp: implementation of the CMessage class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "Message.h"
#include "TelnetSite.h"
#include "global.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMessage::CMessage()
{
	bReply = FALSE;
}

CMessage::~CMessage()
{

}

void CMessage::WriteToFile(const CTelnetSite *pSite, const LPCTSTR szPath)
{
	TCHAR szFile[300];
	TCHAR ts[MAX_TERM_WIDTH*12+1];
	LPCTSTR p;
	FILE *fp = NULL;

	do { //for once
		if (_tcslen(szPath) < 4) break;

		_stprintf(szFile, _T("%s%s-%s.msg"), szPath, pSite->m_Login.m_szSiteName, szUserName);

		fp = _tfopen(szFile, _T("rb"));

		if (fp) {
			//Exist
			fclose(fp);
			fp = _tfopen(szFile, _T("ab"));
		} else {
			//First Write
			p = szPath + _tcslen(szPath);

			while (p > szPath && *p != '\\') p--;

			if (*p != '\\') break;

			p--;

			while (p > szPath && *p != '\\') p--;

			if (*p != '\\') break;

			_tcscpy(ts, p);

			EncodePsw(ts);

			fp = _tfopen(szFile, _T("wb"));

			if (fp) fwrite(ts, 200, 1, fp);
			else break;
		}

		_tcscpy(ts, szMes);

		EncodePsw(szMes);
		fwrite(this, sizeof(CMessage), 1, fp);
		_tcscpy(szMes, ts);
		fclose(fp);
	} while (0);
}
