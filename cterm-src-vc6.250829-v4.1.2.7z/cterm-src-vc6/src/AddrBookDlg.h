#if !defined(AFX_ADDRBOOKDLG_H__B3EAD670_0570_11D4_B1D2_000080013F30__INCLUDED_)
#define AFX_ADDRBOOKDLG_H__B3EAD670_0570_11D4_B1D2_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddrBookDlg.h : header file
//
#include "resource.h"

#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

#include "TelnetSite.h"	// Added by ClassView
/////////////////////////////////////////////////////////////////////////////
// CAddrBookDlg dialog

//typedef TCHAR ProfileName[40];

#include <vector>
#include "tooltipwnd.h"

class CAddrBookDlg : public CDialog
{
public:
// Construction
	CAddrBookDlg(CWnd* pParent = NULL, const TCHAR * file = NULL);

public:
	BOOL SaveSiteList();	//����վ������վ������
	BOOL SaveSite(CTelnetSite * pSite);  //����һ��վ�����ϸ��Ϣ

	CTelnetSite *FindSite(const TCHAR *szUserName, const TCHAR *szFile, const TCHAR *szName);

	const CTelnetSite &GetSite() const
	{
		return m_Site;
	}

	void UnInit() const;

private:
	TCHAR m_szUserName[MAX_USER_NAME + 1];
	CTelnetSite m_Site;  //վ�����
	CString m_pszFile;   //��ַ���ļ�

	int m_bInited;

	TCHAR   m_szFavorite[MAX_FAVORITE_NUM][40];	// ���վ�㣨���5����
	int		m_nFavorite;			// ����

// Dialog Data
	//{{AFX_DATA(CAddrBookDlg)
	enum { IDD = IDD_ADDRBOOK };
	CButton	m_chkAutoLogin;
	CListBox	m_list2;
	CComboBox	m_sitetype_ctrl;
	CEdit	m_sitename_ctrl;
	CEdit	m_port_ctrl;
	CEdit	m_addr_ctrl;
	CButton	m_del;
	CButton	m_save;
	CButton	m_set;
	CListBox	m_list;
	CString	m_addr;
	CString	m_sitename;
	int		m_port;
	int		m_sitetype;
	BOOL	m_bAutologin;
	CString	m_szStartSite;
	int		m_ssh;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddrBookDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation

private:

	// Generated message map functions
	//{{AFX_MSG(CAddrBookDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetSite();
	afx_msg void OnSelchangeList1();
	afx_msg void OnDblclkList1();
	virtual void OnOK();
	afx_msg void OnChangeCtvAddr();
	afx_msg void OnChangeCtvPort();
	afx_msg void OnChangeCtvSitename();
	afx_msg void OnSelchangeSitetype();
	afx_msg void OnSiteUp();
	afx_msg void OnSiteDown();
	afx_msg void OnDelSite();
	afx_msg void OnFavotiteAdd();
	afx_msg void OnFavotiteDel();
	afx_msg void OnSelchangeList2();
	afx_msg void OnDblclkList2();
	afx_msg void OnFavotiteUp();
	afx_msg void OnFavotiteDown();
	afx_msg void OnCheckAutologin();
	afx_msg void OnStartsiteSet();
	afx_msg void OnChangeStartsite();
	afx_msg void OnOpenbok();
	afx_msg void OnChangeKeyword();
	afx_msg void OnNewSite();
	afx_msg void OnSetfocusKeyword();
	afx_msg void OnSaveSite();
	afx_msg void OnProtoTelnet();
	afx_msg void OnProtoSSH();
	afx_msg void OnStartsite();
	afx_msg void OnFavorsite();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
//	ProfileName *m_szSiteName;
	std::vector <CString> m_szSiteNameList;  //վ������ ��������
	vector <CString> m_StartSites;

	int  m_nSiteNum;
//	BOOL m_bChanged; // ��δ��
//	BOOL m_bBusyTimer; // δ��
	int addrbookver;
	BOOL m_bNameModified;  //վ�������޸�
	BOOL m_bSiteChanged;   //վ��������޸�

//	CToolTipCtrl m_tooltip;    //��ť��ʾ��Ϣ�ؼ�. ����
//	CToolTipWnd m_BalloonToolWnd;

	void UpdateList();
	void UpdateList2();
	bool InitList(BOOL bInitCtrls = TRUE); //bInitCtrls, �Ƿ���½���

	bool GetSite(int nIndex, CString filename = _T(""), bool bReportError = true);
	void SetSite(int nIndex, CTelnetSite &Site);

	bool ReadSite(int nIndex, CString filename = _T(""), bool bReportError = true);  //�ӵ�ַ���ж�ȡվ����Ϣ�� 2025

	bool AddrBookHeader(FILE *fp); //д��ַ��ͷ���������û������汾����Ϣ
	bool CheckHeader(CString file);
	bool CheckHeader(FILE *fp); //����ַ��ͷ��
	bool ImportSites();  //����ɸ�ʽ��ַ���е�վ�� (2025)

	bool AddSiteTail(CTelnetSite &site);
	int InsertSite(int index, CTelnetSite &site);
//	inline void WriteSite(FILE *fp);
//	inline void WriteSite(FILE *fp, CTelnetSite &site);

//	void exitSearch(bool bEmptyed = false); //�˳�����ģʽ

	void Init(const TCHAR * file = NULL);
	void CAddrBookDlg::UpdateUI();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDRBOOKDLG_H__B3EAD670_0570_11D4_B1D2_000080013F30__INCLUDED_)
