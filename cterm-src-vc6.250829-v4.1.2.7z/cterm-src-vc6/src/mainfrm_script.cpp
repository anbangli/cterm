///////////////////////////////////////////////////////////
//		vbs, js �ű�֧��
//		ActiveX Scripting ������Ҫ�ο�:
//		Andrew Garbuzov ������ActiveX script hosting (codeguru.com)
//		����������axhost.exe�е�step1

#include "stdafx.h"
#include "MainFrm.h"
#include "ctermview.h"
#include "childfrm.h"
#include "paramconfig.h"
#include "debugtool.h"

#if ENABLE_VBS

// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
#include <AFXPRIV.H>
//#include <fstream.h>

const IID LIBID_VBSCRIPT = {0xF3B1C684, 0x05C7, 0x8BF7, {0xEE, 0x51, 0x3E, 0x5A, 0xB5, 0x21}};
const IID CLSID_VBScript = {0xb54f3741, 0x5b07, 0x11cf, {0xa4, 0xb0, 0x0, 0xaa, 0x0, 0x4a, 0x55, 0xe8 } };

const TCHAR* szItemName = _T("Document");

BEGIN_INTERFACE_MAP(CMainFrame, CFrameWnd)
INTERFACE_PART(CMainFrame, IID_IActiveScriptSite, ScriptSite)
INTERFACE_PART(CMainFrame, IID_IActiveScriptSiteWindow, ScriptSiteWindow)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
//BEGIN COM interface implementation
ULONG FAR EXPORT CMainFrame::XScriptSite::AddRef()
{
	METHOD_PROLOGUE(CMainFrame, ScriptSite)
	return pThis->ExternalAddRef();
}

ULONG FAR EXPORT CMainFrame::XScriptSite::Release()
{
	METHOD_PROLOGUE(CMainFrame, ScriptSite)
	return pThis->ExternalRelease();
}

HRESULT FAR EXPORT CMainFrame::XScriptSite::QueryInterface(
    REFIID iid, void FAR* FAR* ppvObj)
{
	METHOD_PROLOGUE(CMainFrame, ScriptSite)
	return (HRESULT) pThis->ExternalQueryInterface(&iid, ppvObj);
}




ULONG FAR EXPORT CMainFrame::XScriptSiteWindow::AddRef()
{
	METHOD_PROLOGUE(CMainFrame, ScriptSiteWindow)
	return pThis->ExternalAddRef();
}

ULONG FAR EXPORT CMainFrame::XScriptSiteWindow::Release()
{
	METHOD_PROLOGUE(CMainFrame, ScriptSiteWindow)
	return pThis->ExternalRelease();
}

HRESULT FAR EXPORT CMainFrame::XScriptSiteWindow::QueryInterface(
    REFIID iid, void FAR* FAR* ppvObj)
{
	METHOD_PROLOGUE(CMainFrame, ScriptSiteWindow)
	return (HRESULT) pThis->ExternalQueryInterface(&iid, ppvObj);
}

//END COM interface implementation
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//BEGIN ActiveScript hosting

//***************************************************************************
// IActiveScriptSite Interface
//***************************************************************************

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::GetLCID(LCID *plcid)
{
	return E_NOTIMPL;     // Use system settings
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::GetItemInfo
(
    LPCOLESTR   pstrName,
    DWORD       dwReturnMask,
    IUnknown**  ppunkItemOut,
    ITypeInfo** pptinfoOut
)
{
	return TYPE_E_ELEMENTNOTFOUND;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::GetDocVersionString(BSTR *pbstrVersion)
{
	return E_NOTIMPL;   // UNDONE: Implement this method
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::RequestItems(void)
{
	return E_NOTIMPL;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::RequestTypeLibs(void)
{
	METHOD_PROLOGUE(CMainFrame, ScriptSite);
	return E_NOTIMPL;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::OnScriptTerminate(const VARIANT   *pvarResult, const EXCEPINFO *pexcepinfo)
{
	// UNDONE: Put up error dlg here
	return S_OK;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::OnStateChange(SCRIPTSTATE ssScriptState)
{
	// Don't care about notification
	return S_OK;
}


//---------------------------------------------------------------------------
// Display the error
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::OnScriptError(IActiveScriptError *pse)
{
	METHOD_PROLOGUE(CMainFrame, ScriptSite);

	CString   strError;
	CString	  strArrow;
	CString	  strDesc;
	CString	  strLine;

	EXCEPINFO ei;
	DWORD     dwSrcContext;
	ULONG     ulLine;
	LONG      ichError;
	BSTR      bstrLine = NULL;

	HRESULT   hr;

	pse->GetExceptionInfo(&ei);
	pse->GetSourcePosition(&dwSrcContext, &ulLine, &ichError);
	hr = pse->GetSourceLineText(&bstrLine);

	if (hr)
		hr = S_OK;  // Ignore this error, there may not be source available

	if (!hr) {
		strError = ei.bstrSource;

		strDesc = ei.bstrDescription;
		strLine = bstrLine;

		if (ichError > 0 && ichError < 255) {
			strArrow = CString(_T('-'), ichError);
			strArrow.SetAt(ichError - 1, _T('v'));

		}

		CString strErrorCopy = strError;

		strError.Format(_T("Source:'%s'\nFile:'%s'  Line:%d  Char:%ld\nError:%d  '%s'\n%s\n%s"),
		                LPCTSTR(strErrorCopy),
		                _T("File"),
		                ulLine,
		                ichError,
		                (int) ei.wCode,
		                LPCTSTR(strDesc),
		                LPCTSTR(strArrow),
		                LPCTSTR(strLine));

		AfxMessageBox(strError);
	}

	if (bstrLine)
		SysFreeString(bstrLine);

	return hr;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::OnEnterScript(void)
{
	// No need to do anything
	return S_OK;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSite::OnLeaveScript(void)
{
	// No need to do anything
	return S_OK;
}



//***************************************************************************
// IActiveScriptSiteWindow Interface
//***************************************************************************

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSiteWindow::GetWindow(HWND *phwndOut)
{
	if (!phwndOut)
		return E_INVALIDARG;

	METHOD_PROLOGUE(CMainFrame, ScriptSiteWindow);

	*phwndOut = pThis->GetSafeHwnd();

	return S_OK;
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
STDMETHODIMP CMainFrame::XScriptSiteWindow::EnableModeless(BOOL fEnable)
{
	return S_OK;
}

//END ActiveScript hosting
////////////////////////////////////////////////////////////////////////////////

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
HRESULT CMainFrame::CreateScriptEngine(LPCOLESTR pstrItemName)
{
	HRESULT hr;

	if (m_pIActiveScript)
		return S_FALSE;   // Already created it

	// Create the ActiveX Scripting Engine
	// �ӿ�й¶����֪����ô�죬OnClose��ر�Ҳ���У�Ҳ����BoundChecker����
	hr = CoCreateInstance(CLSID_VBScript, NULL, CLSCTX_INPROC_SERVER, IID_IActiveScript, (void **) & m_pIActiveScript);

	if (hr) {
		return E_FAIL;
	}

	// Script Engine must support IActiveScriptParse for us to use it
	hr = m_pIActiveScript->QueryInterface(IID_IActiveScriptParse, (void **) & m_pIActiveScriptParse);

	if (hr) {
		return hr;
	}

	hr = m_pIActiveScript->SetScriptSite(&m_xScriptSite);

	if (hr)
		return hr;

	// InitNew the object:
	hr = m_pIActiveScriptParse->InitNew();

	return hr;
}

BOOL CMainFrame::RunMSScript(BYTE nType)
{
	if (g_bVBSInited) {
		// todo: js
		//compile
		USES_CONVERSION;
		EXCEPINFO   ei;
		LPCOLESTR	lpszCode = T2COLE(LPCTSTR(m_strCode));

		HRESULT hr = m_pIActiveScriptParse->ParseScriptText(lpszCode, NULL, NULL, NULL, 0, 0, 0L, NULL, &ei);

		if (hr) {
			AfxMessageBox(_T("Can't compile the program."));
			return FALSE;
		}

		//run
		if (m_pIActiveScript->SetScriptState(SCRIPTSTATE_CONNECTED)) {
			AfxMessageBox(_T("Can't run the program."));
			return FALSE;
		}

		return TRUE;
	} else
		return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers for scripting
//
bool CMainFrame::LoadScriptText(CString &rFilename)
{
	m_strCode.Empty();

//	TCHAR szBuffer[256];
	CStdioFile f;

	if (!f.Open(rFilename, CFile::modeRead)) {
		CString s;
		s.Format(_T("���ļ�%s����!"), rFilename);
		AfxMessageBox(s);
		return false;
	}

	CString line;

	while (f.ReadString(line)) {
		m_strCode += line + _T("\n");    // ����\r\n, python�Ͳ�������ִ��
	}

	return true;
}

// #####  END  ACTIVEX SCRIPTING SUPPORT #####

void CMainFrame::OnUpdateStopScript(CCmdUI* pCmdUI)
{
	if (!g_bVBSInited)
		pCmdUI->Enable(FALSE);
	else {
		SCRIPTSTATE ss;

		/*for debug
		CString s;
		s.Format(_T("m_pIActiveScript=%p"),m_pIActiveScript);
		AfxMessageBox(s);
		*/

		pCmdUI->Enable(m_pIActiveScript->GetScriptState(&ss) == S_OK && ss == SCRIPTSTATE_CONNECTED);
	}

	// todo: for python js
}

void CMainFrame::OnStopScript()
{
	if (g_bVBSInited) {
		//Reset script
		m_pIActiveScript->SetScriptState(SCRIPTSTATE_DISCONNECTED);
	}

	// todo: python js
}

// ����flashget�Ľӿڴ�flashget������URL
// �ú����ı�д�ο���flashgetĿ¼�µ�jc_link.htm�еĴ���
void CMainFrame::OnDownloadTool()
{
//	AfxMessageBox ( "���ع���" );
//TRACEF( "OnDownloadTool\n" );
	if (g_bVBSInited) {
		CChildFrame *pFrame = (CChildFrame *) MDIGetActive();

		if (!(pFrame && pFrame->m_pView)) return;

		CCTermView *pView = pFrame->m_pView;

		m_strCode.Empty();

//	AfxMessageBox ( "���ع���1" );
//TRACEF( "OnDownloadTool 1 \n" );
		////////// load
		CString s = g_sScriptDir + _T("\\jc_link.vbs");

		if (!LoadScriptText(s))
			return;

//TRACEF( "OnDownloadTool 2 \n" );
		////////// custom code
		CString sCmd;

		sCmd.Format(_T("\nuse=%d\nCall AddLink(\""), g_nDownTool);

		CString sURL;

		if (pView->IsCopySelected()/* && pView->MouseInSelection()*/) {
			TCHAR szBuf[MAX_TERM_HEIGHT * MAX_TERM_WIDTH * 9 * sizeof(TCHAR)] = _T("");

			if (pView->SelectToUrl(szBuf))
				sURL = szBuf;
			else
				return;
		} else// ASSERT( ( m_rectClick.Width() && m_bClickRectURL ) )
			sURL = pView->GetClickStr() + 2; //URL

		// ���ع�����Ҫ��Э��ͷ������˵���Ϸ�(Ѹ��)
		if (sURL.Find(_T("://")) == -1)
			sCmd += _T("http://");

		const TCHAR info[] = _T("added by cterm from BBS ");

		sCmd += sURL + _T("\", \"") + info + pView->m_Site.m_Login.m_szSiteName + _T(": ") + pView->m_Site.m_Login.m_szAddr
		        + _T("\", \"bbs://") + pView->m_Site.m_Login.m_szAddr + _T("\")");

		m_strCode += sCmd;

//#if defined(_DEBUG) || defined(_DEBUG_RELEASE)
//		extern void dumpBuf ( const TCHAR *buf, const int nLen, TCHAR *filename );
//		dumpBuf ( m_strCode, m_strCode.GetLength(), "debug.txt" );
//#endif

		RunVBScript();
	}
}

void CMainFrame::RunViewPicVBS(CString url)
{
	if (g_bVBSInited) {
		CString s = g_sScriptDir + _T("\\viewpic.vbs");

		if (!LoadScriptText(s))
			return;

		s.Format(_T("download=\"%s\"\n")
		         _T("url=\"%s\"\n"), g_sScriptDir, url);

		m_strCode = s + m_strCode;

		RunVBScript();
	}
}

#endif// ENABLE_VBS
