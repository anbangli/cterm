#if !defined(AFX_PROXYSOCK_H__3215F438_788E_458C_8D63_B316EA936FA3__INCLUDED_)
#define AFX_PROXYSOCK_H__3215F438_788E_458C_8D63_B316EA936FA3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProxySock.h : header file
#include "TelnetSite.h"

#if ENABLE_IPV6
#define _WIN32_WINNT 0x0502
#include "ws2tcpip.h"
#endif

//
#define PSOCK_NOT_CONNECT		0
#define PSOCK_CONNECTING        1
#define PSOCK_CONNECTED_PROXY   2
#define PSOCK_CONNECTING_PROXY  4
#define PSOCK_CONNECTED         5

#include <deque>
#include <algorithm>

/////////////////////////////////////////////////////////////////////////////
// CProxySock command target

#if ENABLE_ZMODEM
class QTermZmodem;
#endif//ENABLE_ZMODEM

#if ENABLE_BUF_QUEUE
// ��sockʹ��
struct SBuf
{
	BYTE *m_buf;
	int m_len; // ��m_buf_pool��ʾ�����len; ��queue�б�ʾ���ݵ�len, ��queue�еķ���len�̶�Ϊm_len + 1
};

class CBufPool
{
public:
	std::deque<SBuf> m_buf_pool;
	int m_len;

	CBufPool(void) 
		:m_len(0)
	{
	}

	CBufPool(int len)
		:m_len(len)
	{
	}

	~CBufPool(void) {
		if (!m_buf_pool.empty()) {
			//TRACE("CBufPool size = %d\n", m_buf_pool.size());

			for (std::deque<SBuf>::iterator it = m_buf_pool.begin();
				it != m_buf_pool.end();
				++it) {
					if (find_if(m_buf_pool.begin(), it, buf_compare(it->m_buf)) != it) {
						// �����ظ���
						ASSERT(FALSE);
						continue;
					}
					
					if (it->m_buf) {
						//TRACE("buf %p deleting in ~CBufPool\n", it->m_buf);
						delete [] it->m_buf;
						//TRACE("buf %p deleted in ~CBufPool\n", it->m_buf);
					}
			}
		}
	}

	BYTE *getBuf(int *len = NULL) {
		BYTE *buf = NULL;
		if (!m_buf_pool.empty()) {
			SBuf &b = m_buf_pool.back();
			buf = b.m_buf;
			ASSERT(buf);
			if (len) *len = b.m_len;
			m_buf_pool.pop_back();
			//TRACE("buf %p got in getBuf size = %d\n", buf, m_buf_pool.size());
		}
		else {
			int L = len ? *len : m_len + 1;
			buf = new BYTE[L];
			//TRACE("buf %p newed in getBuf size = %d\n", buf, m_buf_pool.size());
		}
		return buf;
	}

	class buf_compare
	{
	public:
		buf_compare(BYTE *buf): mybuf(buf) {}
		
		bool operator()(const SBuf &b) {
			return mybuf == b.m_buf;
		}

	private:
		BYTE *mybuf;
	};

	// �黹
	void freeBuf(BYTE *&buf, int len = 0) {
		if (buf == NULL) return;
		
#ifdef _DEBUG
		// �����û�б�Ҫ��
		if (find_if(m_buf_pool.begin(), m_buf_pool.end(), buf_compare(buf)) != m_buf_pool.end()) {
			ASSERT(FALSE);
			return;
		}
#endif//_DEBUG

		if (len == 0) len = m_len + 1;
		SBuf b = {buf, len};
		m_buf_pool.push_back(b);
		//TRACE("buf %p freed size = %d\n", buf, m_buf_pool.size());
		buf = NULL;
	}
};
#endif//ENABLE_BUF_QUEUE

class CProxySock : public CAsyncSocket
{
// Attributes

public:
	BOOL m_bProxy;
#if ENABLE_PROXY
	ProxyType m_ProxyType;
	int m_nProxyPort;
	TCHAR m_ProxyAddr[100];
	TCHAR m_szProxyUserPass[256];
	TCHAR m_szProxyUserName[256];
	STelnetProxy TProxy;
#endif//ENABLE_PROXY

#if ENABLE_ZMODEM
	QTermZmodem *m_pZmodem;
#endif // ENABLE_ZMODEM

// Operations

public:
	CProxySock();
	virtual ~CProxySock();

	virtual int SendFilter(const void *lpBuf, int nBuffLen, const TCHAR * trigger) = 0;
	virtual void AnsiLog(const void * buf /*NULL for create*/, int len, bool bSend = false, const TCHAR * trigger = NULL) = 0;

	bool DisConnected() const
	{
		return m_bDisconnected;
	}

public:
	int m_nLen;
	int m_nRecvBufLen;
	// �����Ժ�����ݣ�ֱ��������ʾ
	BYTE *m_pBuf;
	// ����buf�����ã�
	// �����ݴ���ѡ���0ֵʱ����buf_in������buf_out, ��pBufָ��buf_out
	// ���򲻿�����ֱ����pBufָ��buf_in
	BYTE *buf_in; //[(RECV_BUF_LEN+1) * sizeof(BYTE)];
	BYTE *buf_out;//[(RECV_BUF_LEN+1) * sizeof(BYTE)];

#if ENABLE_BUF_QUEUE
	CBufPool m_bufpool;
#endif//ENABLE_BUF_QUEUE

	CString m_strHostAddress; //ԭ����ָ�룬ȷʵ���������ַ����
	UINT m_nHostPort;

	HWND m_hWnd; //sock�����ĸ����ھ��

	short m_nTermWidth; //Э��ʱҪ��
	short m_nTermHeight;
	CString m_sTermType;

	int m_nSockVer;
	int m_nStatus;

public:
	bool m_bDNSResolved;
	BOOL m_bStarted;

	BOOL StartConnect2(); // ���Ƚ������������ӵķ�ʽ
	static unsigned __stdcall DNSThreadFunc(void *arg); // ����DNS�̺߳���
	BOOL ConnectNow2();

	void Reset();

#if ENABLE_PROXY
	void SetProxyUser(TCHAR *user, TCHAR *pass);
	int ConnectTo();  //ͨ����������
	void SetProxy(ProxyType type, TCHAR *, int, TCHAR *, int);

	void SetSock4();
#endif//ENABLE_PROXY

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProxySock)

public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CProxySock)
	// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

#if ENABLE_IPV6
	inline BOOL CreateEx(ADDRINFOT* pAI, long lEvent = FD_READ | FD_WRITE | FD_OOB | FD_ACCEPT | FD_CONNECT | FD_CLOSE);
	BOOL CreateV6(LPCTSTR lpszSocketAddress = NULL, UINT nSocketPort = 0, int nSocketType = SOCK_STREAM, long lEvent = FD_READ | FD_WRITE | FD_OOB | FD_ACCEPT | FD_CONNECT | FD_CLOSE);
	BOOL ConnectEx(ADDRINFOT* pAI);
	ADDRINFOT* m_pAI; // todo: should be protected?
#endif

// Implementation

protected:
	virtual void OnConnectError(int errcode, TCHAR *errinfo = NULL);

private:
	SOCKADDR m_Addr;
	HANDLE m_hThread;
	unsigned m_ThreadID;

	void TelnetNegotiate(int nLen);
	void RespondToOptions(CStringList &sListOptions);
	void ArrangeReply(BYTE *& sReply, CString &strOption);

	int IsIpAddr(TCHAR *, BYTE *);

	bool m_bDisconnected;
#if ENABLE_PROXY
	int m_nSock5Status;
	void ProcessProxy(int);

	void SendSock4ConnectRequest();
	void SendSock5ConnectRequest();
	void Sock5Negotiate(int nLen);

	void connectCTermProxy();
#endif//ENABLE_PROXY
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROXYSOCK_H__3215F438_788E_458C_8D63_B316EA936FA3__INCLUDED_)
