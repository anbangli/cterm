// ProxySock.cpp : implementation file
//

#include "stdafx.h"

#include <process.h>

#include "ProxySock.h"

#if ENABLE_BASE64
#include "base64.h"
#endif//ENABLE_BASE64

#include "mainfrm.h" // for SetStatusBar
#include "usermsg.h"
#include "global.h"
#include "debugtool.h"

#include "ParamConfig.h"

#if ENABLE_ZMODEM
#include "zmodem\qtermzmodem.h"
#endif

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
	DWORD g_datalasttick = 0;
#endif //_DEBUG

static int parse_http_status_line(const TCHAR *line, const TCHAR **reason_phrase_ptr);

/////////////////////////////////////////////////////////////////////////////
// CProxySock
static TCHAR g_szNowAddr[40]; // ���õ��÷�������ֻ��proxy, socks��ʹ��
static int  g_nNowPort;
CProxySock::CProxySock() :
		m_nLen(0),
		m_sTermType(_T("vt100")),
		m_nRecvBufLen(g_nRecvBufLen),
#if ENABLE_BUF_QUEUE
		m_bufpool(m_nRecvBufLen),
#endif//ENABLE_BUF_QUEUE
		buf_in(NULL),
		buf_out(NULL),
		m_bDisconnected(false)
{
	m_nHostPort = 0;
	m_hThread = NULL;
	m_ThreadID = 0;
	m_hWnd = NULL;
	m_bDNSResolved = false;
	m_bStarted = FALSE;

	m_nStatus = PSOCK_NOT_CONNECT;
#ifdef _DEBUG
	//memset(buf_out, NULL, m_nRecvBufLen * sizeof(BYTE));
	//memset(buf_in, NULL, m_nRecvBufLen * sizeof(BYTE));
#endif//_DEBUG
	m_pBuf = buf_out;


	m_nTermWidth = DEFAULT_TERM_WIDTH;
	m_nTermHeight = DEFAULT_TERM_HEIGHT;

#if ENABLE_PROXY
	m_bProxy = FALSE;
	m_nSock5Status = 0;
	m_nSockVer = 5;

#ifdef _DEBUG
	memset(m_szProxyUserName, '\0', 256);
	memset(m_szProxyUserPass, '\0', 256);
#endif//_DEBUG
#endif//ENABLE_PROXY

#if ENABLE_ZMODEM
	m_pZmodem = new QTermZmodem(this, 0);   //non-ssh
#endif // ENABLE_ZMODEM

#if ENABLE_IPV6
	m_pAI = NULL;
#endif //ENABLE_IPV6
}

CProxySock::~CProxySock()
{
	if (m_hThread) {
		WaitForSingleObject(m_hThread, INFINITE);
	}

//	if ( m_hThread )
//	{
//		TerminateThread ( m_hThread, -1 );
//		CloseHandle( m_hThread );
//		m_hThread = NULL;
//	}

	if (buf_in) {
		delete [] buf_in;
		//TRACE("deleted buf %p in ~CProxySock\n", buf_in);
		buf_in = NULL;
	}

	if (buf_out) {
		delete [] buf_out;
		//TRACE("deleted buf %p in ~CProxySock\n", buf_out);
		buf_out = NULL;
	}

#if ENABLE_ZMODEM
	delete m_pZmodem;

	m_pZmodem = NULL;

#endif // ENABLE_ZMODEM
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CProxySock, CAsyncSocket)
	//{{AFX_MSG_MAP(CProxySock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CProxySock member functions
void CProxySock::connectCTermProxy()
{
	CString s;
	s.Format(_T("kcuf %5d %s"), m_nHostPort, m_strHostAddress);
	Send((LPCTSTR)s, s.GetLength());
	m_nStatus = PSOCK_CONNECTED;
	SetStatusBar(ID_INDICATOR_TERM, _T("connected"));
}

void CProxySock::OnConnect(int nErrorCode)
{
	m_bDisconnected = false;

	if (nErrorCode) {
		OnConnectError(nErrorCode
#if ENABLE_PROXY
		               , m_bProxy ? _T("���Ӵ���������ʧ��") : NULL
#endif//ENABLE_PROXY
		              );
	}
	else {
		//TRACEF(_T("connected!\r\n"));     //, m_pView->m_nSessionID);

		//TRACE(_T("connected!\r\n"));

		if (m_bProxy) {
#if ENABLE_PROXY
#ifdef _DEBUG_RELEASE
//			TRACEF ( _T ( "sending request to proxy ...\r\n" ) );
#endif

			m_nStatus = PSOCK_CONNECTED_PROXY;

			switch (m_ProxyType) {

			case PT_SOCK4:

			case PT_SOCK5:
				Sock5Negotiate(0);
				break;

			case PT_HTTP: {
				TCHAR *proxyauth = NULL;

				if (!isempty(m_szProxyUserName)) { //not empty
					//��Ҫ��֤
					//proxyauth = basic_authentication_encode
					//(proxy_usr, proxy_pwd, _T("Proxy-Authorization"));
					TCHAR header[] = _T("Proxy-Authorization");

					{
						TCHAR *t1 = NULL, *t2 = NULL;//, *res;
						int len1 = _tcslen(m_szProxyUserName) + 1 + _tcslen(m_szProxyUserPass);
						int len2 = (4 * (((len1) + 2) / 3));         //BASE64_LENGTH

						t1 = (TCHAR *) malloc(len1 + 1);
						_stprintf(t1, _T("%s:%s"), m_szProxyUserName, m_szProxyUserPass);
#if ENABLE_BASE64
						t2 = Base64Encode(t1, len1);
#endif//ENABLE_BASE64
						proxyauth = (TCHAR *) malloc(len2 + 11 + _tcslen(header));
						_stprintf(proxyauth, _T("%s: Basic %s\r\n"), header, t2);
						free(t1);
						free(t2);
					}
				}

				int len = proxyauth != NULL ? _tcslen(proxyauth) : 0;

				TCHAR *request = new TCHAR[ m_strHostAddress.GetLength() + len + 81 ];//81=45+(�˿ڳ���, 2-4)+

				_stprintf(request,
				          _T("CONNECT %s:%u HTTP/1.0\r\n")
				          _T("%s\r\n"),
				          //_T("User-Agent: CTerm/3.2\r\n"),
				          m_strHostAddress, m_nHostPort,
				          proxyauth != NULL ? proxyauth : _T(""));

				Send(request, _tcslen(request));
				delete [] request;

				if (proxyauth)
					free(proxyauth);

				//proxy_state=1;
				m_nStatus = PSOCK_CONNECTED_PROXY;

				TRACE(_T("connected to proxy\n"));

				return;
			}

			break;
			case PT_CTERM:
				connectCTermProxy();
			}

#endif//ENABLE_PROXY
		} 
		else {
			m_nStatus = PSOCK_CONNECTED;

			SetStatusBar(ID_INDICATOR_TERM, _T("connected"));
		}
	}

	CAsyncSocket::OnConnect(nErrorCode);
}

BOOL CProxySock::StartConnect2()
{
	//TRACEF(_T("start connecting ...\r\n"));     //, m_pView->m_nSessionID);

	//TRACE(_T("start connecting ...\r\n"));

	BOOL ret = FALSE;

	if (!IsIP(m_strHostAddress.LockBuffer())) {
		if (!m_bDNSResolved) {
			// ����DNS
			SetStatusBar(ID_INDICATOR_TERM, _T("resolving hostname..."));

			m_hThread = (HANDLE) _beginthreadex(NULL,
			                                    0,
			                                    CProxySock::DNSThreadFunc,
			                                    (LPVOID) this,
			                                    0,
			                                    &m_ThreadID);

			if (m_hThread)
				ret = TRUE; //���ڽ���DNS����Ҫ�ȴ� ... ֻ����������ſ��ܷ���WM_DNSRESOLVED�����Ϣ
			else
				ret = FALSE; //����DNS�߳�ʧ��
		} else { //�ѽ���
			SetStatusBar(ID_INDICATOR_TERM, _T("connecting..."));

			ret = ConnectNow2();
		}
	} else { //connect directly
		SetStatusBar(ID_INDICATOR_TERM, _T("connecting..."));

		ret = CAsyncSocket::Connect(m_strHostAddress, m_nHostPort);
	}

	m_strHostAddress.UnlockBuffer();

	return ret;
}

unsigned __stdcall CProxySock::DNSThreadFunc(void *arg)
{
	//TRACEF(_T("resolving DNS ...\r\n"));     //, m_pView->m_nSessionID);

	//TRACE(_T("resolving DNS ...\r\n"));

	CProxySock *pto = (CProxySock *) arg;
	DWORD ret = 0;

#if defined(_UNICODE) || defined(UNICODE)
	char *str = NULL;
	char *s = GetANSIStr(pto->m_strHostAddress, str);
	TRACE(_T("%s\r\n"), str);
	hostent* pHostEnt = gethostbyname(str);
	safe_delete(s);
#else
	hostent* pHostEnt = gethostbyname(pto->m_strHostAddress);
#endif

	//TRACE(_T("resolved DNS ...\r\n"));

	if (pHostEnt != NULL) {
		ULONG* pulAddr = (ULONG*) pHostEnt->h_addr_list[0];
		SOCKADDR_IN* pAddrTemp = (SOCKADDR_IN*)(&pto->m_Addr);
		pAddrTemp->sin_family = AF_INET;
		pAddrTemp->sin_port = htons(pto->m_nHostPort);
		pAddrTemp->sin_addr.s_addr = *pulAddr; // address is already in network byte order

		//TRACE(_T("sending WM_DNSRESOLVED...\r\n"));
		//�������, ��sock�����ĸ����ڷ���Ϣ
		PostMessage(pto->m_hWnd, WM_DNSRESOLVED, (WPARAM) 0, (LPARAM) 0);
		pto->m_bDNSResolved = true;

		ret = 1;
	} else {
		PostMessage(pto->m_hWnd, WM_DNSRESOLVED, (WPARAM) 1, (LPARAM) 0);
		TRACE(_T("resolving DNS fail...\r\n"));
	}

	CloseHandle(pto->m_hThread);

	pto->m_hThread = NULL;
	return ret;
}

BOOL CProxySock::ConnectNow2() // ��SOCKADDR����
{
	//TRACEF(_T("connecting the address ...\r\n"));     //, m_pView->m_nSessionID);
	//TRACE(_T("connecting the address ...\r\n"));

	SetStatusBar(ID_INDICATOR_TERM, _T("connecting..."));

	return CAsyncSocket::Connect(&m_Addr, sizeof(m_Addr));
};

#ifdef _DEBUG
#include "ctermview.h"
extern CCTermView *g_pView;
#endif

#ifndef ENABLE_ZMODEM
void CProxySock::OnReceive(int nErrorCode)
{
	//	TRACE ( _T ( "in CProxySock::OnReceive\n" ) );
	if (nErrorCode != -1) { // -1: is file
		if (buf_in == NULL) {
#if ENABLE_BUF_QUEUE
			buf_in = m_bufpool.getBuf();
#else
			buf_in = new BYTE[m_nRecvBufLen];
#endif//ENABLE_BUF_QUEUE
		}


		ASSERT(buf_in);
		if (buf_in == NULL) return;
		
		m_nLen = Receive(buf_in, m_nRecvBufLen - 1);
		buf_in[m_nLen] = '\0';
		
#ifdef _DEBUG
		//TRACE(_T("in CProxySock::OnReceive\n"));
		g_datalasttick = GetTickCount();
#endif //_DEBUG
		
		//ASSERT(!m_nCtdfile);
		
		AnsiLog(buf_in, m_nLen);
		
		//	TRACE ( _T ( "in CProxySock::OnReceive, received%d\n" ), m_nLen );
	}
	
	if (m_nLen > 0) {
		switch (m_nStatus) {
#if ENABLE_PROXY
		case PSOCK_CONNECTED_PROXY:
			ProcessProxy(m_nLen);
			m_pBuf = buf_in;
			break;
			
		case PSOCK_CONNECTING_PROXY:
			m_nStatus = PSOCK_CONNECTED;
			TelnetNegotiate(m_nLen);
			break;
#endif//ENABLE_PROXY
			
		case PSOCK_CONNECTED:
			TelnetNegotiate(m_nLen);
			
			{
//#ifdef _DEBUG
//				DWORD tick = GetTickCount();
//				TRACE(_T("in CProxySock::OnReceive after TelnetNegotiate "));
//				TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick - g_datalasttick);
//				g_datalasttick = GetTickCount();
//#endif //_DEBUG
			}

			break;
		}
	}
	else {
		m_nLen = 0;
	}
	
	CAsyncSocket::OnReceive(nErrorCode);
}

#else //have ENABLE_ZMODEM
void CProxySock::OnReceive(int nErrorCode)
{
	m_nLen = Receive(buf_in, m_nRecvBufLen - 1);    //raw data
	buf_in[m_nLen] = NULL;

	char *raw_str = new char[m_nLen];
	memcpy(raw_str, buf_in, m_nLen);
	m_pZmodem->ZmodemRcv((BYTE*) raw_str, m_nLen, & (m_pZmodem->info));

	if (m_pZmodem->transferstate == notransfer) {
		if (m_nLen > 0) {
			switch (m_nStatus) {

			case PSOCK_CONNECTED_PROXY:
				ProcessProxy(m_nLen);
				m_pBuf = buf_in;
				break;

			case PSOCK_CONNECTING_PROXY:
				m_nStatus = PSOCK_CONNECTED;
				TelnetNegotiate(m_nLen);
				break;

			case PSOCK_CONNECTED:
				TelnetNegotiate(m_nLen);
				break;
			}
		} else
			m_nLen = 0;

		CAsyncSocket::OnReceive(nErrorCode);
	} else
		m_nLen = 0;//������ʾ

	//delete the buf
	delete []raw_str;

	if (m_pZmodem->transferstate == transferstop)
		m_pZmodem->transferstate = notransfer;
}

#endif // ENABLE_ZMODEM

#if ENABLE_PROXY
// ��CCTermSock::SetProxy����
void CProxySock::SetProxy(ProxyType type, TCHAR *pAddr, int pPort, TCHAR *szAddr, int nPort)
{
	m_bProxy = TRUE;
	m_ProxyType = type;
	_tcscpy(m_ProxyAddr, pAddr);
	m_nProxyPort = pPort;
	_tcscpy(g_szNowAddr, szAddr);
	g_nNowPort = nPort;
}

void CProxySock::ProcessProxy(int nLen)
{
	if (!m_bProxy) return;

	switch (m_ProxyType) {

	case PT_TELNET: {
		TelnetNegotiate(nLen);
#if ENABLE_FILTER

		if (TProxy.DoFilter(m_pBuf, nLen, this)) {
			m_nStatus = PSOCK_CONNECTING_PROXY;
			TProxy.Filter.Disable();
			return;
		}

#endif//ENABLE_FILTER
		break;
	}

	case PT_SOCK5: {
		Sock5Negotiate(nLen);
		break;
	}

	case PT_HTTP: {
		TCHAR *error = NULL;
		int statcode = parse_http_status_line((const TCHAR *) buf_in, (const TCHAR **) & error);

		if (statcode >= 200 && statcode < 300) {
			TelnetNegotiate(nLen);
			m_nStatus = PSOCK_CONNECTING_PROXY;
		}
		else {
			//			logerr ( error );
			switch (statcode) {
				//case 404:
				//	error=_T("not found");
				//	break;

			case 407:
				error = _T("Http������֤ʧ��");
				break;

			default:
				error = _T("Http��������������");
			}

			OnConnectError(statcode, error);    //1 HTTP error
		}

		break;
	}
	}
}

int CProxySock::ConnectTo()
{
	if (m_nStatus == PSOCK_NOT_CONNECT) {
		if (m_bProxy) {
//TRACEF( _T ( "connectint proxy ...\r\n" ) );
			return Connect(m_ProxyAddr, m_nProxyPort);
		} else
			return 0;
	} else
		return 0;
}

void CProxySock::SetSock4()
{
	m_nSockVer = 4;
}

void CProxySock::SendSock4ConnectRequest()
{
	TCHAR reply[100];
	BYTE bAddr[8];
	int  nLen, flag;
	nLen = _tcslen(g_szNowAddr);

	if (nLen < 4) {
		Reset();
		return;
	}

	reply[0] = m_nSockVer;

	reply[1] = 1;// connect
	reply[2] = g_nNowPort / 256;
	reply[3] = g_nNowPort % 256;
	flag = IsIpAddr(g_szNowAddr, bAddr);

	if (!flag) {
		HOSTENT *pAddr;
#if defined(_UNICODE) || defined(UNICODE)
		char *str = NULL;
		char *s = GetANSIStr(g_szNowAddr, str);
		pAddr = gethostbyname(str);
		safe_delete(s);
#else
		pAddr = gethostbyname(g_szNowAddr);
#endif
		memcpy(reply + 4, *pAddr->h_addr_list, pAddr->h_length);
	} else {
		memcpy(reply + 4, bAddr, 4);
	}

	_tcscpy(reply + 8, m_szProxyUserName);

	Send(reply, 9 + _tcslen(m_szProxyUserName));
	m_nSock5Status = 4;//Wait for reply
	m_nStatus = PSOCK_CONNECTED;
}

void CProxySock::SendSock5ConnectRequest()
{
	TCHAR reply[100];
	BYTE bAddr[8];
	int  nLen, flag;
	nLen = _tcslen(g_szNowAddr);

	if (nLen < 4) {
		Reset();
		return;
	}

	reply[0] = m_nSockVer;

	reply[1] = 1;//connect
	reply[2] = 0;
	flag = IsIpAddr(g_szNowAddr, bAddr);

	switch (flag) {

	case 0:
		reply[3] = 3;//Domain name
		reply[4] = nLen;
		_tcscpy(reply + 5, g_szNowAddr);
		reply[5+nLen] = g_nNowPort / 256;
		reply[6+nLen] = g_nNowPort % 256;
		Send(reply, 7 + nLen);
		break;

	case 4:
		reply[3] = 1;//Ip v4
		memcpy(reply + 4, bAddr, 4);
		reply[8] = g_nNowPort / 256;
		reply[9] = g_nNowPort % 256;
		Send(reply, 10);
		break;

	case 6:
		reply[3] = 4;//Ip v6
		memcpy(reply + 4, bAddr, 6);
		reply[10] = g_nNowPort / 256;
		reply[11] = g_nNowPort % 256;
		Send(reply, 12);
		break;

	default:
		Reset();
		AfxGetMainWnd()->MessageBox(_T("Ŀ�ĵ�ַ����"), _T("����"), MB_OK | MB_ICONERROR);
		break;
	}

	m_nSock5Status = 4;//Wait for reply
}

void CProxySock::Sock5Negotiate(int nLen)
{
	BYTE reply[600];
	int  Len;

	if (nLen == 0) {
		if (m_nSockVer == 4) {
			SendSock4ConnectRequest();
		}
		else {
			if (isempty(m_szProxyUserName)) {
				reply[0] = m_nSockVer;
				reply[1] = 1;
				reply[2] = 0x00;
				Send(reply, 3);
			}
			else {
				reply[0] = m_nSockVer;
				reply[1] = 2;
				reply[2] = 0x02;//U/P  //no GSS_API support?
				reply[3] = 0x00;//No Password
				Send(reply, 4);
			}
			m_nSock5Status = 1;
		}
		
		return;
	}

	switch (m_nSock5Status) {

	case 1://ver method

		switch (buf_in[1]) {

		case 0x00://no pas
			//Sendrequest
			SendSock5ConnectRequest();
			break;

		case 0x02:
			reply[0] = m_nSockVer;//Send Password
			reply[1] = Len = _tcslen(m_szProxyUserName);
			_tcsncpy((TCHAR *) reply + 2, m_szProxyUserName, Len);
			reply[2+Len] = _tcslen(m_szProxyUserPass);
			_tcscpy((TCHAR *) reply + 3 + Len, m_szProxyUserPass);
			Send(reply, 3 + Len + _tcslen(m_szProxyUserPass));
			m_nSock5Status = 2;
			break;

		case 0xff:
			// ����Ҳ����ʵ�ֶ�̬...��Ϊ��ͨ��thisָ����õ�
			OnConnectError(-1, _T("Socks ������������֧�ֵĵ�½��ʽ"));
			//Reset();
			//AfxGetMainWnd()->MessageBox(_T("Socks ������������֧�ֵĵ�½��ʽ"), _T("��������"), MB_OK | MB_ICONERROR);
			m_nLen = 0;//��ֹ��ʾ
			break;
		}

		break;

	case 2://U/P reply

		if (buf_in[1]) {
			//Reset();
			OnConnectError(-2, _T("Socks ��������������"));
			//AfxGetMainWnd()->MessageBox(_T("Socks ��������������"), _T("�������ô���"), MB_OK | MB_ICONERROR);
			m_nLen = 0;//��ֹ��ʾ
		}
		else {
			//Sendrequest
			SendSock5ConnectRequest();
		}

		break;

	case 4:
		if (buf_in[1] && m_nSockVer == 5) {
			OnConnectError(-3, _T("Socks ��������������"));
			//Reset();
			//AfxGetMainWnd()->MessageBox(_T("Socks ��������������"), _T("�������ô���"), MB_OK | MB_ICONERROR);
			m_nLen = 0;//��ֹ��ʾ
			return;
		} else { //success
			m_nSock5Status = 0;
			m_nStatus = PSOCK_CONNECTED;
		}

		break;
	}

	if (m_nLen > 0 &&
		(m_nSock5Status == 1 || m_nSock5Status == 2 || m_nSock5Status == 4)) {
		m_nLen -= 2;
	}
}

void CProxySock::SetProxyUser(TCHAR *user, TCHAR *pass)
{
	if (_tcslen(user) > 255) user[255] = 0;

	if (_tcslen(pass) > 255) pass[255] = 0;

	_tcscpy(m_szProxyUserName, user);

	_tcscpy(m_szProxyUserPass, pass);
}

#endif//ENABLE_PROXY

/*
#define DO (253)
#define WILL (251)
#define WONT (252)
#define DONT (254)
#define SB   (250)
*/
const	unsigned char IAC		= 255; //FF
const	unsigned char DO		= 253; //FD
const	unsigned char DONT		= 254; //FE
const	unsigned char WILL		= 251; //FB
const	unsigned char WONT		= 252; //FC
const	unsigned char SB 		= 250; //FA
const	unsigned char SE		= 240; //F0
const	unsigned char IS		= '\0'; //00
const	unsigned char SEND		= '\1'; //01
const	unsigned char INFO		= '2'; //?
const	unsigned char VAR		= '0';
const	unsigned char VALUE		= '1';
const	unsigned char ESC		= '2';
const	unsigned char USERVAR	= '3';

const	unsigned char	TXBINARY	= 0; 	/* TRANSMIT-BINARY option	*/
const	unsigned char	ECHO		= 1;	/* ECHO Option			*/
const	unsigned char	NOGA		= 3;	/* Suppress Go-Ahead Option	*/
const	unsigned char	TERMTYPE	= 24; //18	/* Terminal-Type Option		*/
const	unsigned char	NAWS		= 31; //1F	/* Window Size */

///////////////////// telnet start ////////////////////////////////////////////////////////
// ��д
void CProxySock::TelnetNegotiate(int nLen)
{
	// �����ʡû���壺���������ַ�������0�أ�
//	if (m_nLen < 3) {
//		m_pBuf = buf_in;
//		return; // �����ǰreturn�ܲ��ã�������������ǰӦ��������
//	}

	//CString sNormalText = _T ( "" );
	//unsigned char *pNormal = sNormalText.GetBuffer( m_nLen );
	if (buf_out == NULL) {
#if ENABLE_BUF_QUEUE
			buf_out = m_bufpool.getBuf();
#else
			buf_out = new BYTE[m_nRecvBufLen];
#endif//ENABLE_BUF_QUEUE
	}

	if (buf_out == NULL) return;
	
	unsigned char *pNormalStr = buf_out; //new unsigned char[m_nLen + 1];

#ifdef _DEBUG
	*pNormalStr = '\0';

#endif
	unsigned char *pNormal = pNormalStr;

	// p0ָ��ǰһ�������ַ��Ŀ�ʼ��pָ��ǰ�ַ�
	unsigned char *p0 = buf_in, * p = buf_in;
	// qָ������2���ַ���q1ָ���ַ���������
	unsigned char *q = buf_in + m_nLen - 2, * q1 = buf_in + m_nLen;

	unsigned char ch;

	CStringList sListOptions;

	CString sOption;

	bool bGotZero = false;

	while (p < q) {
		if (*p == IAC) {
			if (p > p0) {
				strncpy((char *)pNormal, (char *)p0, p - p0);
				pNormal += p - p0;
			}
			ch = *(p + 1);

			switch (ch) {

			case 0:
				//����0���ַ�
				*(pNormal++) = IAC;
				p++;
				break;

			case DO:

			case DONT:

			case WILL:

			case WONT:
				sOption += (TCHAR) IAC;
				sOption += (TCHAR) ch;
				sOption += (TCHAR) * (p + 2);

				p += 3;

				sListOptions.AddTail(sOption);
				sOption.Empty();
				break;

			case IAC:
				*(pNormal++) = IAC;
				p++;
				break;

			case SB: {
				unsigned char *pSE = p + 2;

				for (; *pSE != SE && pSE < q1 && pSE < p + 6 ; pSE++);

				if (*pSE == SE) {
					//RFC884:
					//IAC SB TERMINAL-TYPE SEND IAC SE
					//IAC SB TERMINAL-TYPE IS _T("vt100") IAC SE
					ASSERT(pSE < q1 && pSE < p + 6);
//						char *pOption = new char[ pSE - p + 1 + 1 ];
//						strncpy ( pOption, (char *)p, pSE - p + 1 );
//						pOption[pSE - p + 1] = '\0';
//
//						GetSafeStr( sOption.GetBuffer( pSE - p + 1 + 1 ), pOption, pSE - p + 1 );
//						sOption.ReleaseBuffer();
//
//						delete [] pOption;

					int oplen = pSE - p + 1;
					TCHAR *pOption = sOption.GetBuffer(pSE - p + 1 + 1);
					int i = 0;

					for (; i < oplen; i++) {
						pOption[i] = (TCHAR) * p;
						p++;
					}

					pOption[i] = '\0';

					sOption.ReleaseBuffer();

					sListOptions.AddTail(sOption);
					sOption.Empty();

					p = pSE + 1;
				} else {
					//�Ƿ�ѡ��IAC SB SE || IAC SB ... without SE
					//��IAC SB��Ϊ�����ַ�
					*(pNormal++) = IAC;
					*(pNormal++) = SB;
					p += 2;
				}

				//CString info;
				//info.Format(_T("len:%d\t"), sOption.GetLength());
				//info+=sOption;
				//MessageBox(NULL, info, _T("Telnet Option"), MB_OK);
			}

			break;

			default: { //Unkown command, ��������������ѭ��
				//δ֪ѡ�����ԭ�����
				*(pNormal++) = IAC;
				*(pNormal++) = ch;
				p += 2;
				//sTemp = sTemp.Mid ( ndx + 2 );
			}
			}//switch ( ch )

			p0 = p;
		}//if ( *p == IAC )
		else if (*p == 0) {
			bGotZero = true;
			if (p > p0) {
				strncpy((char *)pNormal, (char *)p0, p - p0);
				pNormal += p - p0;
			}
			p++;
			p0 = p;
		} else
			p++;
	}

	// ��ĩ�����ַ��Ĵ���
	{
		bool b1 = false, b2 = false;
		if (m_nLen > 2) {
			if (*(q - 1) == IAC) {
				switch(*q) {
				case 0:
				case IAC:
					b1 = true; // ������2���ַ���������
					break;
				case DO:
				case DONT:
				case WILL:
				case WONT:
				case SB:
					b1 = b2 = true; // ĩ��������������
					break;
				}
			}
		}

		if (!b1 && *q == 0) {
			bGotZero = true;
			if (p > p0) {
				strncpy((char *)pNormal, (char *)p0, p - p0);
				pNormal += p - p0;
			}
			p0 = q + 1;
		}
		
		if (!b2 && *(++q) == 0) {
			bGotZero = true;
			q1--;
		}
	}
	
	if (!sListOptions.IsEmpty()) {
		bGotZero = true;
		RespondToOptions(sListOptions);
	}

	if (bGotZero) {
		if (q1 > p0) {
			// q1 < p0ʱ��q1 - p0��һ���ܴ�������������Ǹ���...���
			memcpy((char *)pNormal, (char *)p0, q1 - p0);
			pNormal += (q1 - p0);
		}
		*pNormal = '\0';

		m_nLen = pNormal - pNormalStr;
		m_pBuf = buf_out;
		//memcpy((char *) buf, (char *)pNormalStr, m_nLen);
		//buf[ m_nLen ] = '\0';
	} else {
		m_pBuf = buf_in;
	}

	//delete [] pNormalStr;

#ifdef _DEBUG
	//	ASSERT( sNormalText.Find(IAC)==-1 );
#endif
}

void CProxySock::RespondToOptions(CStringList &sListOptions)
{
	CString strOption;
	BYTE *sReply = new BYTE[sListOptions.GetCount() * 6 + m_sTermType.GetLength() + 1];
	sReply[0] = '\0';
	BYTE *psReply = sReply;

	//TRACE(_T("RespondToOptions 1\n"));

	while (!sListOptions.IsEmpty()) {
		strOption = sListOptions.RemoveHead();
		ArrangeReply(psReply, strOption);
	}

	*psReply = '\0';

	if (sReply[0] != '\0') {
//#if defined(_UNICODE) || defined(UNICODE)
//		char *str = NULL;
//		char *s = GetANSIStr ( sReply, str ); // �����ַ�FF FAʲô�ģ����������ְ취
//		Send ( str, sReply.GetLength() );
//		safe_delete ( s );
//#else
		Send(sReply, psReply - sReply);
//#endif
	}

	delete [] sReply;

	//TCHAR *p=sReply.GetBuffer(0);
	//for(;*p;p++)
	//{
	//TCHAR c=*p;
	//}

//	sReply[0] = '\0';
}

void CProxySock::ArrangeReply(BYTE *& sReply, CString &strOption)
{
	unsigned char Verb;
	unsigned char Option;
	unsigned char Modifier;
	BOOL bDefined = FALSE;

	//	if(strOption.GetLength() < 3) return;

	Verb = (unsigned char) strOption.GetAt(1);
	Option = (unsigned char) strOption.GetAt(2);

	//ͬ����Щѡ��
	//��������ͬ��

	switch (Option) {

	case ECHO:	// Echo

	case NOGA: // Suppress Go-Ahead

	case TERMTYPE: // TERMINAL-TYPE

	case NAWS:	// Negotiate About Window Size

	case TXBINARY:
		bDefined = TRUE;
		break;
	}

	*(sReply++) = IAC;

	if (bDefined == TRUE) {
		switch (Verb) {

		case DO: {
			bool bNAWS = false;

			if (Option == NAWS) {
				if (m_nTermWidth != DEFAULT_TERM_WIDTH || m_nTermHeight != DEFAULT_TERM_HEIGHT) {
					bNAWS = true;
					*(sReply++) = WILL;
				}
				else {
					*(sReply++) = WONT;
				}
			} else
				*(sReply++) = WILL;

			*(sReply++) = Option;

			if (bNAWS) { //Window Size
				//IAC SB NAWS <16-bit value> <16-bit value> IAC SE
				*(sReply++) = IAC;
				*(sReply++) = SB;
				*(sReply++) = NAWS;

				unsigned char* p = (unsigned char *) & m_nTermWidth;  //short, 2 bytes
				*(sReply++) = (* (p + 1));
				*(sReply++) = (*p);
				p = (unsigned char *) & m_nTermHeight;
				*(sReply++) = (* (p + 1));
				*(sReply++) = (*p);

				*(sReply++) = IAC;
				*(sReply++) = SE;
			}
		}

		break;

		case DONT:
			*(sReply++) = WONT;
			*(sReply++) = Option;
			break;

		case WILL:
			*(sReply++) = DO;
			*(sReply++) = Option;
			break;

		case WONT:
			*(sReply++) = DONT;
			*(sReply++) = Option;
			break;

		case SB:
			Modifier = strOption.GetAt(3);

			if (Modifier == SEND) {
				*(sReply++) = SB;
				*(sReply++) = Option;
				*(sReply++) = '\0';//IS

				if (Option == TERMTYPE) {
					int typelen = m_sTermType.GetLength();
					strncpy((char*)sReply, (char*)m_sTermType.LockBuffer(),  typelen);   //_T("vt100");
					sReply += typelen;
				}

				*(sReply++) = IAC;

				*(sReply++) = SE;
			}

			break;
		}
	} else {
		switch (Verb) {

		case DO:
			*(sReply++) = WONT;
			*(sReply++) = Option;
			break;

		case DONT:
			*(sReply++) = WONT;
			*(sReply++) = Option;
			break;

		case WILL:
			*(sReply++) = DONT;
			*(sReply++) = Option;
			break;

		case WONT:
			*(sReply++) = DONT;
			*(sReply++) = Option;
			break;
		}
	}
}

//////////////////////////////////////      telnet end /////////////////////////////////

void CProxySock::Reset()
{
	if (m_hSocket != INVALID_SOCKET) {
//		TRACE( "in CProxySock::Reset()\n" );
//		TRACE( "m_hSocket=%p\n", this->m_hSocket);
//		TRACEF( "in CProxySock::Reset()" );
//		TRACEFHEXS( "m_hSocket=", this->m_hSocket);
		m_bStarted = FALSE;

		ShutDown(CAsyncSocket::both);

		//��ִ�� AsyncSelect(0)���ɹ��� KillSocket ��ΪINVALID_SOCKET
		//���� AsyncSelect(0) �Ժ��ܷ��յ�������Ϣ
		Detach(); //��䲻Ҫִ�У�����������m_hSocketΪINVALID_SOCKET
		//���������Close()��closesocket��ִ�У�boundchecker�ᱨ��Դй©
		//��ִ���ֿ��ܻ�crash, ���Ի���ִ��
		//bc̫������

//		TRACEF( "Shutdowned" );
//		TRACE( "Shutdowned, closing\n" );

		Close(); //����INVALID_SOCKET��closesocket��Ȼ��KillSocket

//		TRACE( "closed" );
//		TRACEF( "Closed" );


		// todo: �Ƿ���Ҫ�ȴ���
		//while (pSocket->Receive(Buffer,50) > 0);?
		//�����ȵȴ���close
		//�����ж��Ƿ����ϣ��������ϣ���shutdown���ȴ�û������close
		//��δ����(������)���򷢳�reset�źţ������ϣ�������ʧ�ܣ���reset?
	}

	m_bDisconnected = true;
	m_nStatus = PSOCK_NOT_CONNECT;

#if ENABLE_PROXY
	m_bProxy = FALSE;
	m_nSock5Status = 0;
#endif//ENABLE_PROXY

#if ENABLE_FILTER
	TProxy.Filter.Disable();
#endif//ENABLE_FILTER

//		SetStatusBar( ID_INDICATOR_TERM, _T ( "disconnected" ) );

	if (m_hThread) {
		TerminateThread(m_hThread, -1);
		CloseHandle(m_hThread);
		m_hThread = NULL;
	}
	
	SetStatusBar(ID_INDICATOR_TERM, _T("�����ѶϿ�"));	//"disconnected"
//	SetStatusBar(ID_INDICATOR_TERM, g_LoadString(ID_DISCONNECTED));
}

int CProxySock::IsIpAddr(TCHAR *addr, BYTE *Dest)
{
	int nLen, i;
	TCHAR *p, ts[4], tsat, dat = 0;
	nLen = _tcslen(addr);

	for (i = 0; i < nLen; i++) {
		if ((addr[i] > '9' || addr[i] < '0') && addr[i] != '.')
			return 0;
	}

	p = addr;

	do {
		tsat = 0;

		while (*p != '.' && tsat < 3 && *p) {
			ts[tsat] = *p;
			p++;
			tsat++;
		}

		if (tsat > 3)   //error
			return 0;

		ts[tsat] = 0;

		Dest[dat] = _ttoi(ts);

		dat++;

		if (*p == '.') p++;
	} while (*p && dat < 6);

	return dat;
}

void CProxySock::OnConnectError(int errcode, TCHAR *errinfo)
{
	//never here, but never delete it
}

// from qterm
/* Parse the HTTP status line, which is of format:

  HTTP-Version SP Status-Code SP Reason-Phrase

	The function returns the status-code, or -1 if the status line is
malformed.  The pointer to reason-phrase is returned in RP.  */
static int
parse_http_status_line(const TCHAR *line, const TCHAR **reason_phrase_ptr)
{
	/* (the variables must not be named `major' and `minor', because
		that breaks compilation with SunOS4 cc.)  */
	int mjr, mnr, statcode;
	const TCHAR *p;

	*reason_phrase_ptr = NULL;

	/* The standard format of HTTP-Version is: `HTTP/X.Y', where X is
	major version, and Y is minor version.  */

	if (_tcsncmp(line, _T("HTTP/"), 5) != 0)
		return -1;

	line += 5;

	/* Calculate major HTTP version.  */
	p = line;

	for (mjr = 0; _istdigit(*line); line++)
		mjr = 10 * mjr + (*line - '0');

	if (*line != '.' || p == line)
		return -1;

	++line;

	/* Calculate minor HTTP version.  */
	p = line;

	for (mnr = 0; _istdigit(*line); line++)
		mnr = 10 * mnr + (*line - '0');

	if (*line != ' ' || p == line)
		return -1;

	/* Wget will accept only 1.0 and higher HTTP-versions.  The value of
	minor version can be safely ignored.  */
	if (mjr < 1)
		return -1;

	++line;

	/* Calculate status code.  */
	if (!(_istdigit(*line) && _istdigit(line[1]) && _istdigit(line[2])))
		return -1;

	statcode = 100 * (*line - '0') + 10 * (line[1] - '0') + (line[2] - '0');

	/* Set up the reason phrase pointer.  */
	line += 3;

	/* RFC2068 requires SPC here, but we allow the string to finish
	here, in case no reason-phrase is present.  */
	if (*line != ' ') {
		if (!*line)
			*reason_phrase_ptr = line;
		else
			return -1;
	}
	else {
		*reason_phrase_ptr = line + 1;
	}

	return statcode;
}

#if ENABLE_IPV6

inline BOOL CProxySock::CreateEx(ADDRINFOT* pAI, long lEvent)
{
	if (pAI == NULL) {
		WSASetLastError(WSAEINVAL);
		return FALSE;
	}

	return Socket(pAI->ai_socktype, lEvent, pAI->ai_protocol, pAI->ai_family);
}

BOOL CProxySock::ConnectEx(ADDRINFOT* pAI)
{
	if (pAI == NULL) {
		WSASetLastError(WSAEINVAL);
		return FALSE;
	}

	return Connect((SOCKADDR*) pAI->ai_addr, (int) pAI->ai_addrlen);
}

//getaddrinfoFunc getaddrinfo = NULL;


typedef
int
(__stdcall *getaddrinfo_ptr_t)(
    IN const char FAR *nodename,
    IN const char FAR *servname,
    IN const struct addrinfo FAR *hints,
    OUT struct addrinfo FAR *FAR *res
);

/* static pointers to the native Windows IPv6 routines, so we only do the lookup once. */

static getaddrinfo_ptr_t getaddrinfo_ptr = NULL;

static
bool haveNativeWindowsIPv6routines(void)
{
	HMODULE h  = NULL;
	HINSTANCE h1 = NULL;
	static bool  alreadyLookedForIpv6routines = FALSE;

	if (alreadyLookedForIpv6routines)
		return (getaddrinfo_ptr != NULL);

	/*
	* For Windows XP and Windows 2003 (and longhorn/vista), the IPv6
	* routines are present the WinSock 2 library (ws2_32.dll).  Try that first
	*/
	h = GetModuleHandle(_T("WS2_32.DLL"));       //LoadLibraryA("ws2_32");

	if (h != NULL) {
		getaddrinfo_ptr = (getaddrinfo_ptr_t) GetProcAddress(h, "getaddrinfo");
	}

	if (getaddrinfo_ptr == NULL) {
		/* Well, ws2_32 doesn't exist, or more likely doesn't have getaddrinfo. */
		//if (hLibrary != NULL)
		//     FreeLibrary(hLibrary);

		/* In Windows 2000, there was only the IPv6 Technology Preview
		* look in the IPv6 WinSock library (wship6.dll).
		*/
		h1 = LoadLibraryA("wship6");
	}

	/* If hLibrary is null, we couldn't find a dll that supports the functions */
	if (h1 != NULL) {
		/* We found a dll, so now get the addresses of the routines */
		getaddrinfo_ptr = (getaddrinfo_ptr_t) GetProcAddress(h1, "getaddrinfo");
		//freeaddrinfo_ptr = GetProcAddress(hLibrary, "freeaddrinfo");
		//getnameinfo_ptr = GetProcAddress(hLibrary, "getnameinfo");

		/* If any one of the routines is missing, let's play it safe and ignore them all */

		if (getaddrinfo_ptr == NULL) { //|| freeaddrinfo_ptr == NULL || getnameinfo_ptr == NULL)
			FreeLibrary(h1);
			h = NULL;
			h1 = NULL;
			//getaddrinfo_ptr = NULL;
			//           freeaddrinfo_ptr = NULL;
			//           getnameinfo_ptr = NULL;
		}
	}

	alreadyLookedForIpv6routines = TRUE;

	return (getaddrinfo_ptr != NULL);
}

BOOL CProxySock::CreateV6(LPCTSTR lpszSocketAddress, UINT nSocketPort, int nSocketType,	long lEvent)
{
//	HMODULE h = GetModuleHandle ( _T ( "WS2_32.DLL" ) );
//	if ( !h || ! ( getaddrinfo = ( getaddrinfoFunc ) GetProcAddress ( h, "getaddrinfo" ) ) )
//		return FALSE;

	if (!haveNativeWindowsIPv6routines())
		return FALSE;

	ADDRINFOT Hints, *AddrInfo, *AI;

	int RetVal;

	TCHAR port[10] = _T("");

	_stprintf(port, _T("%d"), nSocketPort);

	memset(&Hints, 0, sizeof(Hints));

	Hints.ai_family = PF_INET6;

	Hints.ai_socktype = SOCK_STREAM;

	RetVal = GetAddrInfo(lpszSocketAddress, port, &Hints, &AddrInfo);

	if (RetVal != 0) {
		fprintf(stderr,
		        "Cannot resolve address [%s] and port [%s], error %d: %s\n",
		        lpszSocketAddress, port, RetVal, gai_strerror(RetVal));
		WSACleanup();
		return FALSE;
	}

	//
	// Try each address getaddrinfo returned, until we find one to which
	// we can successfully connect.
	//
	for (AI = AddrInfo; AI != NULL; AI = AI->ai_next) {
		if (CreateEx(AI)) {
			//printf("socket created with family: %d socktype: %d, protocol: %d\n",
			//AI->ai_family, AI->ai_socktype, AI->ai_protocol);

			m_pAI = AI;
			break;
		} else {
			//fprintf(stderr, "Error Opening socket, error %d: %s\n",
			//      WSAGetLastError(), PrintError(WSAGetLastError()));
			return FALSE;
		}
	}

	return TRUE;
}
#endif//ENABLE_IPV6
