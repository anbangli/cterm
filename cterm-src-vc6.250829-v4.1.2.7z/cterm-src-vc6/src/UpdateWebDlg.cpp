// UpdateWebDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "UpdateWebDlg.h"
#include "global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUpdateWebDlg dialog


CUpdateWebDlg::CUpdateWebDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpdateWebDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpdateWebDlg)
	m_ver = _T("");
	//}}AFX_DATA_INIT
}


void CUpdateWebDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpdateWebDlg)
	DDX_Control(pDX, IDC_GITCODE, m_gitcode);
	DDX_Control(pDX, IDC_GITEE, m_gitee);
	DDX_Control(pDX, IDC_GITHUB, m_github);
	DDX_Text(pDX, IDC_INTER_VER, m_ver);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUpdateWebDlg, CDialog)
	//{{AFX_MSG_MAP(CUpdateWebDlg)
	ON_BN_CLICKED(IDC_GITEE, OnGitee)
	ON_BN_CLICKED(IDC_GITCODE, OnGitcode)
	ON_BN_CLICKED(IDC_GITHUB, OnGithub)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpdateWebDlg message handlers

BOOL CUpdateWebDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG
	
	m_ver.Format(_T("%d.%d.%d"), g_Ver[0], g_Ver[1], g_Ver[2]);
	
	//m_ver += _T(" (");
	//m_ver += GetBuildTime();
	//m_ver += _T(")");
	
	UpdateData(FALSE);

	//�� .h �ļ��У�����Ѱ�ť������Ϊ CbuttonST������ ��ƽ�Ͱ�ť��

	CFont m_font;	//�����������
    //m_font.CreateFont(24, 0, 0, 0, 1, FALSE, FALSE, 0, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, FF_SWISS, _T("tahoma"));
	//GetDlgItem(IDC_INTER_VER)->SetFont(&m_font);

	//m_font.CreatePointFont(200, _T("Arial")); // 100��ʾ10���С
    // ��ȡ�ؼ�ָ�벢��������
    //CWnd* pControl = GetDlgItem(IDC_INTER_VER);
    //if (pControl != NULL) {
    //    pControl->SetFont(&m_font);
    //}
	

	::GetModuleFileName(NULL, m_wd.GetBuffer(_MAX_PATH + 1), _MAX_PATH + 1);
	m_wd.ReleaseBuffer();
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUpdateWebDlg::OnGitee() 
{
	ShellExecute(NULL, _T("open"), _T("https://gitee.com/devcpp/cterm"), NULL, NULL, NULL);	
}

void CUpdateWebDlg::OnGitcode() 
{
	ShellExecute(NULL, _T("open"), _T("https://gitcode.com/devcpp/cterm"), NULL, NULL, NULL);	
}

void CUpdateWebDlg::OnGithub() 
{
	ShellExecute(NULL, _T("open"), _T("https://anbangli.github.io/cterm/"), NULL, NULL, NULL);	
}
