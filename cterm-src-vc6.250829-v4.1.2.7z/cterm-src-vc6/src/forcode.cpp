// code.cpp:	����ʶ����ת��������GB<->BIG5��

#include "stdafx.h"
#include "forcode.h"

#if ENABLE_BASE64
#include "base64.h"
#endif//ENABLE_BASE64

#define MAXLINE 100
static TCHAR sLine[MAXLINE];
static int *g_pFrec = NULL;
static int CodeType[18];
static TCHAR LastEnter[2];

TCHAR *GetLine(TCHAR *buf, int &len)
{
	int at = 0;

	while (buf[at] != 10 && buf[at] != 13 && buf[at] && at < MAXLINE - 1) {
		sLine[at] = buf[at];
		at++;
	}

	sLine[at] = 0;

	if (at < MAXLINE - 1) {
		LastEnter[0] = buf[at];
		LastEnter[1] = 0;
	} else
		LastEnter[0] = 0;

	len = at + (buf[at] != 0);

	if (!isempty(sLine))
		return sLine;
	else
		return NULL;
}

bool InitCode()
{
	g_pFrec = (int *) malloc(65536 * 2 + 10);
	
	if (g_pFrec == NULL) {
		return false;
	}
	
	CString path = g_szWorkDir + _T("codech.frc");
	FILE *fp = _tfopen(path, _T("rb"));
	
	if (fp == NULL) {
		free(g_pFrec);
		return false;
	}
	
	fread((BYTE *) g_pFrec, 32768, 4, fp);
	
	g_pFrec[(0xa1-0x80) *256+0xa1] = 10;
	fclose(fp);

	return true;
}

void DeInitCode()
{
	if (g_pFrec)
		free(g_pFrec);
}

int IsHexChar(TCHAR c)
{
	if (c >= '0' && c <= '9') return c -'0' + 1;

	if (c >= 'A' && c <= 'F') return c -'A' + 11;

	if (c >= 'a' && c <= 'f') return c -'a' + 11;

	return 0;
}

int GetCodeType(TCHAR *line)
{
	int len = _tcslen(line);
	int i, num;

	for (i = 0; i < len; i++)
		if (line[i] < 0) return CODE_BINARY;

	i = 0;

	num = 0;

	while (i < len) {
		switch (line[i]) {

		case ' ':
			i++;
			break;

		case '=':

			if (i < len - 2) {
				if ((10 < IsHexChar(line[i+1])) && IsHexChar(line[i+2])) {
					num++;
					i += 3;
				} else
					i++;

				break;
			} else {
				i = len + 20;
				break;
			}

		default:

			if (line[i] > 0) i++;
			else
				i = len + 20;

			break;
		}
	}//while

	if (num > 1)
		return CODE_HEX;

	num = 0;

	for (i = 0; i < len; i++) {
		if (line[i] == '~'
		        && (line[i+1] == '{' || line[i+1] == '}'))
			num++;
	}

	if (num > 1)
		return CODE_OFFHEAD;

#if ENABLE_BASE64
	if (IsBase64(line))
		return CODE_BASE64;

#endif//ENABLE_BASE64

	return CODE_NORMAL;
}

BOOL IsTableChar(TCHAR *s)
{
	TCHAR *tab = _T("�T�U�V�W�X�Y�Z�[�\�]�^�_�`�a�b�c�d�e�f�g�h�i�j�k�l�m�n�o�p\
	                �q�r�s�t�u�v�w�x�y�z�{�|�}�~����������������������������������������������\
	                �����������������������������©éĩũƩǩȩɩʩ˩̩ͩΩϩЩѩҩөԩթ֩ש�\
	                �٩ک۩ܩݩީߩ����������������輻������������������");
	int i, l;
	l = _tcslen(tab);

	for (i = 0; i < l; i += 2) {
		if (s[0] == tab[i] && s[1] == tab[i+1])
			return TRUE;
	}

	return FALSE;
}


double GetFrec(BYTE *line, int len)
{
	ASSERT(g_pFrec != NULL);

	if (!g_pFrec)
		return 0.0;

	int i = 0, j, off;

	BYTE buf[20], *p = (BYTE *) line;

	int bat = 0;

	double frc = 0.0, t;

	while (i < len) {
		if (*p > 128) {
			buf[bat] = *p;
			buf[bat+1] = p[1];
			bat += 2;

			if (bat >= 10) {
				//count frc
				t = 1;

				for (j = 0;j < 5;j++) {
					if (IsTableChar((TCHAR *) buf + j*2)) {
						t *= 10.0;
					} else {
						off = (buf[j*2] - 128) * 256 + buf[j*2+1];
						t *= (double) g_pFrec[off] / 100.0;
					}
				}

				if (t > frc) frc = t;

				bat = 0;
			}

			i += 2;

			p += 2;
		} else {
			i++;
			p++;
		}
	}

	if (bat >= 4) {
		t = 1;

		for (j = 0;j < bat / 2;j++) {
			off = (buf[j*2] - 128) * 256 + buf[j*2+1];
			t *= (double) g_pFrec[off] / 100.0;
		}

		if (t > frc) frc = t;

		bat = 0;
	}

	return frc;
}

// Big5 => GBK��
// ���ؤH���@�M�� --> ���A���񹲺͇�
void BIG52GBK(char *szBuf)
{
#ifndef _UNICODE
	int nStrLen = strlen(szBuf);

	if (nStrLen == 0)
		return;

	wchar_t *pws = new wchar_t[nStrLen + 1];

	__try {
		int nReturn = MultiByteToWideChar(950, 0, szBuf, nStrLen, pws, nStrLen + 1);
		nReturn = WideCharToMultiByte(936, 0, pws, nReturn, szBuf, nStrLen + 1, NULL, NULL);
		szBuf[nReturn] = 0;
	}
	__finally {

		delete[] pws;
	}
#endif
}

#pragma warning(disable : 4305 4309)
// GB2312 => GBK
// �л����񹲺͹� --> ���A���񹲺͇�
void GB2GBK(char *szBuf)
{
#ifndef _UNICODE

	if (!strcmp(szBuf, ""))
		return;

	int nStrLen = strlen(szBuf);

	WORD wLCID = MAKELCID(MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED), SORT_CHINESE_PRC);

	int nReturn = LCMapString(wLCID, LCMAP_TRADITIONAL_CHINESE, szBuf, nStrLen, NULL, 0);

	if (!nReturn)
		return;

	char *pcBuf = new char[nReturn + 1];

	__try {
		wLCID = MAKELCID(MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED), SORT_CHINESE_PRC);
		LCMapString(wLCID, LCMAP_TRADITIONAL_CHINESE, szBuf, nReturn, pcBuf, nReturn + 1);
		strncpy(szBuf, pcBuf, nReturn);
	}
	__finally {

		delete[] pcBuf;
	}
#endif
}

#pragma warning(default : 4305 4309)

// GBK => Big5
// ���A���񹲺͇� --> ���ؤH���@�M��
void GBK2BIG5(char *szBuf)
{
#ifndef _UNICODE
	int nStrLen = strlen(szBuf);

	if (nStrLen == 0)
		return;

	wchar_t *pws = new wchar_t[nStrLen + 1];

	__try {
		MultiByteToWideChar(936, 0, szBuf, nStrLen, pws, nStrLen + 1);
		WideCharToMultiByte(950, 0, pws, nStrLen, szBuf, nStrLen + 1, NULL, NULL);
		szBuf[nStrLen] = 0;
	}
	__finally {

		delete[] pws;
	}
#endif
}

void GB2BIG5(BYTE *line)
{
	GB2GBK((char *) line);
	GBK2BIG5((char *) line);
}

// GBK =��GB2312
// ���A���񹲺͇� --> �л����񹲺͹�
void GBK2GB(char *szBuf)
{
#ifndef _UNICODE

	if (!strcmp(szBuf, ""))
		return;

	int nStrLen = strlen(szBuf);

	WORD wLCID = MAKELCID(MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED), SORT_CHINESE_BIG5);

	int nReturn = LCMapString(wLCID, LCMAP_SIMPLIFIED_CHINESE, szBuf, nStrLen, NULL, 0);

	if (!nReturn)
		return;

	char *pcBuf = new char[nReturn + 1];

	__try {
		wLCID = MAKELCID(MAKELANGID(LANG_CHINESE, SUBLANG_CHINESE_SIMPLIFIED), SORT_CHINESE_BIG5);
		LCMapString(wLCID, LCMAP_SIMPLIFIED_CHINESE, szBuf, nReturn, pcBuf, nReturn + 1);
		strncpy(szBuf, pcBuf, nReturn);
	}
	__finally {

		delete []pcBuf;
	}
#endif
}

void BIG52GB(BYTE *line)
{
	char *szBuf = (char *) line;
	BIG52GBK(szBuf);
	GBK2GB(szBuf);
}

//-------------- big5-hkscs ---------------
#include <iconv_1.h>

// http://www.monster.com.tw/archives/1075
int fnConvert(const char *from, const char *to, char* save, int savelen, char *src, int srclen)
{
	if (!(iconv_open && iconv && iconv_close && iconvctl)) return -1;

    iconv_t cd;
    char   *inbuf = src;
    char *outbuf = save;
    size_t outbufsize = savelen;
    int status = 0;
    size_t  savesize = 0;
    size_t inbufsize = srclen+1;
    const char* inptr = inbuf;
    size_t      insize = inbufsize;
    char* outptr = outbuf;
    size_t outsize = outbufsize;

    if ( ( cd = iconv_open(to, from) ) == (iconv_t)-1 )
    {
        status = -1;
        goto done;
    }

    iconv(cd,NULL,NULL,NULL,NULL);
    if (inbufsize == 0)
    {
        status = -1;
        goto done;
    }
    while (insize > 0)
    {
        size_t res = iconv(cd, &inptr,&insize,&outptr,&outsize);
        if (outptr != outbuf)
        {
            int saved_errno = errno;
            int outsize = outptr - outbuf;
            strncpy(save+savesize, outbuf, outsize);
            errno = saved_errno;
        }
        if (res == (size_t)(-1))
        {
            if (errno == EILSEQ)
            {
                int one = 1;
                iconvctl(cd,ICONV_SET_DISCARD_ILSEQ,&one);
                status = -3;
            }
            else if (errno == EINVAL)
            {
                if (inbufsize == 0)
                {
                    status = -4;
                    goto done;
                }
                else
                {
                    break;
                }
            }
            else if (errno == E2BIG)
            {
                status = -5;
                goto done;
            }
            else
            {
                status = -6;
                goto done;
            }
        }
    }
    status = strlen(save);
done:
    iconv_close(cd);
    return status;
}

int H2G(char *str)
{
	int status = 0;
	if (!(iconv_open && iconv && iconv_close && iconvctl)) {
		BIG52GB((BYTE *)str);
		GBK2GB(str);
	}
	else {
		int srclen, destlen;
		
		status = -1;
		if ( ( srclen = strlen( str ) ) == 0 )
			return status;
		destlen  = sizeof( unsigned char ) * ( srclen * 2 ) + 1;
		char *tmp = new char[destlen];
		tmp[0] = '\0';
		status = fnConvert ( "big5-hkscs", "GBK", tmp, destlen, str, srclen);
		if (status > 0) {
			GBK2GB(tmp);
			strcpy(str, tmp);
		}
		delete [] tmp;
	}

    return status;
}

//-------------- end big5-hkscs -----------

void RightCode(unsigned char *s)
{
	int  mask[1010], bak[1010];//1010��ô���ģ�
	int i, off, n, len;
	BYTE t, sbak[1010];
	len = _tcslen((TCHAR*) s);
	//����
	//��ȡ�ֲ�ͼ
	i = 0;

	while (i < len) {
		if (s[i] > 128) {
			if (i == (79))
				mask[i] = 1;
			else {
				off = (s[i] - 128) * 256 + s[i+1];
				mask[i] = mask[i+1] = g_pFrec[off] < 30 ? 0 : 1;
			}

			i += 2;
		} else {
			mask[i] = 1;
			i++;
		}
	}//while

//��ֵ�˲�
	for (i = 0; i < len; i++) bak[i] = mask[i];

	i = 0;

	while (i < len - 2) {
		if (s[i] > 128) {
			if (i > 1) {
				n = 0;

				if (bak[i-2]) n++;

				if (bak[i]) n++;

				if (bak[i+2]) n++;

				if (n > 1)
					mask[i] = mask[i+1] = 1;
				else
					mask[i] = mask[i+1] = 0;
			}

			i += 2;
		} else {
			i++;
		}
	}//while

//�ٴ�ɨ�����4�ġ���϶��
	for (i = 0; i < len - 4; i++) {
		if (!mask[i]) {
			n = 0;

			while (!mask[n+i]) n++;

			if (n >= 6) {
				if (s[i+1] < 128 && s[i+3] > 128) {
					t = s[i+1];
					s[i+1] = s[i+2];
					s[i+2] = t;
				} else {
					_tcsncpy((TCHAR *) sbak, (TCHAR *) s, len);
					sbak[len] = 0;
					sbak[i] = 32;

					if (GetFrec(sbak + i, n) > GetFrec(s + i, n))
						s[i] = 32;//����ո�
				}

				i += n;
			}
		}
	}
}

void GetOffWrongEnd(TCHAR *line)
{
	TCHAR temp[1002], *p = temp;
	int l;
	_tcscpy(temp, line);
	l = _tcslen(line);

	if (l < 2) return;

	temp[_tcslen(temp) +1] = 0;

	while (*p) {
		if (*p < 0) {
			p += 2;
		} else
			p++;
	}

	p--;

	if (*p == 0) {
		p--;
		*p = 32;
	}

	_tcscpy(line, temp);
}

int ConvertLine(TCHAR *line)
{
	int len = _tcslen(line);
	TCHAR pBak[1000], pBig5[1000];
	double frec, dbig5;
	int resault[2] = {CODE_GB, CODE_BIG5};
	//��������,pline�ٶ���GB��pBig5�ٶ���BIG5��ת��֮
	_tcscpy(pBak, line);
	_tcscpy(pBig5, line);
	BIG52GB((BYTE *) pBig5);
	//��GB��WGB�ĸ�ǿ���ͷ��Ǹ���pline��
	RightCode((BYTE *) pBak);
	RightCode((BYTE *) pBak);
	RightCode((BYTE *) pBak);
	frec = GetFrec((BYTE *) pBak, len);

	if (_tcscmp(pBak, line)) {
		resault[0] = CODE_WGB;
		_tcscpy(line, pBak);
	}

	//��BIG5��WBIG5
	_tcscpy(pBak, pBig5);

	RightCode((BYTE *) pBak);

	RightCode((BYTE *) pBak);

	RightCode((BYTE *) pBak);

	dbig5 = GetFrec((BYTE *) pBak, len);

	if (_tcscmp(pBak, pBig5)) {
		resault[1] = CODE_WBIG5;
		_tcscpy(pBig5, pBak);
	}

	//�ۺϱȽ�
	if (dbig5 > frec) {
		frec = dbig5;
		resault[0] = resault[1];
		_tcscpy(line, pBig5);
	}

	GetOffWrongEnd(line);

	return resault[0];
}

void DecodeHex(TCHAR *line)
{
	TCHAR ts[1000], *pt, *pl = line;
	BYTE c;
	pt = ts;

	while (*pl) {
		if (*pl == '=' && pl[1] && pl[2]) {
			c = (IsHexChar(pl[1]) - 1) * 16 + (IsHexChar(pl[2]) - 1);
			*pt = (TCHAR) c;
			pl += 3;
			pt++;
		} else {
			*pt = *pl;
			pt++;
			pl++;
		}
	}

	*pt = 0;

	_tcscpy(line, ts);
}

void DecodeHeadOff(TCHAR *line)
{
	TCHAR ts[1000], *pt, *pl = line;
	int flag = 0;
	BYTE c;
	pt = ts;

	while (*pl) {
		if (!flag) {
			if (*pl == '~' && pl[1] == '{') {
				flag = 1;
				pl += 2;
			} else {
				*pt = *pl;
				pt++;
				pl++;
			}
		} else {
			if (*pl == '~' && pl[1] == '}') {
				flag = 0;
				pl += 2;
			} else {
				c = *pl;
				c += 128;
				*pt = (TCHAR) c;
				pt++;
				pl++;
			}
		}
	}

	*pt = 0;

	_tcscpy(line, ts);
}

//CMainFrame::OnRightcode()->CleverCodeConvert()->ConvertLine()->RightCode()->GetFrec()->g_pFrec
int CleverCodeConvert(TCHAR *buf, int len)
{
	int n, codetype, NewLen = 0;
	TCHAR *pBak, *p, *pLine, *pbuf = buf;

	if ((pBak = (TCHAR *) malloc(len + 1)) == NULL) {
		return len;
	}

	memcpy(pBak, buf, len);

	pBak[len] = 0;
	*pbuf = 0;
	p = pBak;

	do {
		pLine = GetLine(p, n);
		//if pLine==NULL,write a Enter
		len -= n;
		p += n;

		if (pLine) {
			codetype = GetCodeType(pLine);
			CodeType[codetype]++;

			switch (codetype) {   //��BINARY�ȴ���

			case CODE_OFFHEAD:
				DecodeHeadOff(pLine);
				//Write Back to  buffer;
				break;

			case CODE_HEX:
				DecodeHex(pLine);
				break;
#if ENABLE_BASE64

			case CODE_BASE64:
				DecodeBase64(pLine);
				break;
#endif//ENABLE_BASE64

			default:
				break;
			}

			//�ۺϴ���
			if (codetype != CODE_NORMAL)
				CodeType[ConvertLine(pLine)]++;

			_tcscat(pbuf, pLine);

			_tcscat(pbuf, LastEnter);

			NewLen += _tcslen(pLine) + _tcslen(LastEnter);
		} else {
			//Write Enter to buffer
			_tcscat(pbuf, LastEnter);
			NewLen += _tcslen(LastEnter);
		}

	} while (len > 0 && *p);

	return NewLen;
}

bool UTF8ToGB(CString &str)
{
	WCHAR *strSrc;
	TCHAR *szRes;
	int i = MultiByteToWideChar(CP_UTF8, 0, str, -1, NULL, 0);
	strSrc = new WCHAR[i + 1];
	MultiByteToWideChar(CP_UTF8, 0, str, -1, strSrc, i);
	i = WideCharToMultiByte(CP_ACP, 0, strSrc, -1, NULL, 0, NULL, NULL);
	szRes = new TCHAR[i + 1];
	WideCharToMultiByte(CP_ACP, 0, strSrc, -1, szRes, i, NULL, NULL);
	str = szRes;
	delete []strSrc;
	delete []szRes;
	return true;
}

bool GBKToUtf8(CString& strGBK)
{
	int len = MultiByteToWideChar(CP_ACP, 0, (LPCTSTR)strGBK, -1, NULL, 0);
	LPWSTR wszUtf8 = new WCHAR[len + 1];
	memset(wszUtf8, 0, len * 2 + 2);
	MultiByteToWideChar(CP_ACP, 0, (LPCTSTR)strGBK, -1, wszUtf8, len);

	len = WideCharToMultiByte(CP_UTF8, 0, wszUtf8, -1, NULL, 0, NULL, NULL);
	char *szUtf8 = new char[len + 1];
	memset(szUtf8, 0, len + 1);
	WideCharToMultiByte(CP_UTF8, 0, wszUtf8, -1, szUtf8, len, NULL, NULL);

	strGBK = szUtf8;
	delete[] szUtf8;
	delete[] wszUtf8;
	return true;
}

// gb to unicode(utf-16)
bool GB2Unicode(char *s)
{
	// ��ascii/gbתΪunicode(utf-16)
	// ������2*(len+1)�ֽ�
	// len�ֽ�ascii�룬�����len��WCHAR����Ϊascii�ַ�����ռ2*len�ֽ�
	// ������len/2��WCHAR����Ϊ���֣���ռlen�ֽ�
	int len = strlen(s);
	WCHAR *buf = new WCHAR[len + 1];
	len = MultiByteToWideChar(CP_ACP, MB_COMPOSITE, s, len, buf, len);   // for CF_UNICODETEXT
	buf[len] = '\0';
	memcpy(s, buf, (len + 1) * 2);
	delete [] buf;

	return true;
}

bool GB2Unicode(const char *s, WCHAR *dest)
{
	int len = strlen(s);
	len = MultiByteToWideChar(CP_ACP, MB_COMPOSITE, s, len, dest, len);
	return true;
}