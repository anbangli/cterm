// SiteColorPage.cpp : implementation file
//

#include "stdafx.h"
#include "TelnetSite.h"
#include "SiteColorPage.h"
#include "usermsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteColorPage property page

IMPLEMENT_DYNCREATE(CSiteColorPage, CMyPropertyPage)

CSiteColorPage::CSiteColorPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(CSiteColorPage)
	m_colorfile = _T("");
	m_nColorSet = -1;
	//}}AFX_DATA_INIT
}

CSiteColorPage::~CSiteColorPage()
{
}

void CSiteColorPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteColorPage)
	DDX_Text(pDX, IDC_COLORFILE, m_colorfile);
	DDX_Radio(pDX, IDC_SET_A, m_nColorSet);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteColorPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteColorPage)
	ON_BN_CLICKED(IDC_SET_A, OnSetA)
	ON_BN_CLICKED(IDC_SET_B, OnSetB)
	ON_BN_CLICKED(IDC_SET_C, OnSetC)
	ON_BN_CLICKED(IDC_SET_D, OnSetD)
	ON_BN_CLICKED(IDC_SET_E, OnSetE)
	ON_BN_CLICKED(IDC_SET_F, OnSetF)
	ON_BN_CLICKED(IDC_SET_G, OnSetG)
	ON_BN_CLICKED(IDC_SET_H, OnSetH)
	ON_BN_CLICKED(IDC_SET_ZZ, OnSetZz)
	ON_BN_CLICKED(IDC_SET_I, OnSetI)
	ON_BN_CLICKED(IDC_C0, OnC0)
	ON_BN_CLICKED(IDC_C1, OnC1)
	ON_BN_CLICKED(IDC_C2, OnC2)
	ON_BN_CLICKED(IDC_C3, OnC3)
	ON_BN_CLICKED(IDC_C4, OnC4)
	ON_BN_CLICKED(IDC_C5, OnC5)
	ON_BN_CLICKED(IDC_C6, OnC6)
	ON_BN_CLICKED(IDC_C7, OnC7)
	ON_BN_CLICKED(IDC_C8, OnC8)
	ON_BN_CLICKED(IDC_C9, OnC9)
	ON_BN_CLICKED(IDC_C10, OnC10)
	ON_BN_CLICKED(IDC_C11, OnC11)
	ON_BN_CLICKED(IDC_C12, OnC12)
	ON_BN_CLICKED(IDC_C13, OnC13)
	ON_BN_CLICKED(IDC_C14, OnC14)
	ON_BN_CLICKED(IDC_C15, OnC15)
	ON_BN_CLICKED(IDC_COLOROPEN, OnColoropen)
	ON_BN_CLICKED(IDC_COLORSAVE, OnColorsave)
	ON_WM_TIMER()
	ON_WM_MOVE()
	ON_WM_SHOWWINDOW()
	ON_WM_CLOSE()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteColorPage message handlers

BOOL CSiteColorPage::OnInitDialog()
{

//	CButton *pBut;
//??m_nColorSet
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



	SetTimer(TIMER_SITECOLORPAGE, 500, NULL);
	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CSiteColorPage::OnC0()
{
	SetCustColor(0);
	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];
}

void CSiteColorPage::OnC1()
{
	SetCustColor(1);
}

void CSiteColorPage::OnC2()
{
	SetCustColor(2);
}

void CSiteColorPage::OnC3()
{
	SetCustColor(3);
}

void CSiteColorPage::OnC4()
{
	SetCustColor(4);
}

void CSiteColorPage::OnC5()
{
	SetCustColor(5);
}

void CSiteColorPage::OnC6()
{
	SetCustColor(6);
}

void CSiteColorPage::OnC7()
{
	SetCustColor(7);
}

void CSiteColorPage::OnC8()
{
	SetCustColor(8);
}

void CSiteColorPage::OnC9()
{
	SetCustColor(9);
}

void CSiteColorPage::OnC10()
{
	SetCustColor(10);
}

void CSiteColorPage::OnC11()
{
	SetCustColor(11);
}

void CSiteColorPage::OnC12()
{
	SetCustColor(12);
}

void CSiteColorPage::OnC13()
{
	SetCustColor(13);
}

void CSiteColorPage::OnC14()
{
	SetCustColor(14);
}

void CSiteColorPage::OnC15()
{
	SetCustColor(15);
}

// ����һ����ɫ
void CSiteColorPage::SetCustColor(int index)
{
	UpdateData();
	CColorDialog dlg(m_pDecode->m_ColorSet[index]);

	if (dlg.DoModal() == IDOK && m_pDecode->m_ColorSet[index] != dlg.GetColor()) {
		m_pDecode->m_ColorSet[index] = dlg.GetColor();

		for (int i = 0; i < 16; i++)
			m_CustColor[i] = m_pDecode->m_ColorSet[i];

		m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

		// ��ɫ�ı䣬��������custom
		m_pDecode->m_nColorSetNum = 9;

		m_nColorSet = 9; // ID_SET_ZZ

		UpdateData(FALSE);
	}

	m_bNeedRedrawColor = true;		// ������ʱ���������ɫ
}

void CSiteColorPage::DrawColors()		// ����������ɫ
{
	CRect rect;
	CDC *pDC;
	CWnd *pWndCtrl;

	for (int i = 0; i < 16; i++) {
		pWndCtrl = GetDlgItem(IDC_C0 + i);    // ��ЩIDҪ˳���ţ����߿�һ�����飬�����Ƿŵ�������
		pDC = pWndCtrl->GetDC();
		pWndCtrl->GetClientRect(&rect);
		pDC->FillSolidRect(&rect, m_pDecode->m_ColorSet[i]);
		pWndCtrl->ReleaseDC(pDC);
	}

	m_bNeedRedrawColor = false;
}

// ������ʱ���������ɫ��
void CSiteColorPage::OnTimer(UINT nIDEvent)
{
	if (m_bNeedRedrawColor) {
		DrawColors();
		m_bNeedRedrawColor = false;
	}

	CDialog::OnTimer(nIDEvent);
}

void CSiteColorPage::OnColorsave()
{
	int i;
	CString str1, str2;

	CFileDialogEx fd(FALSE, _T("ctc"), m_colorfile, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("CTerm ��ɫ�����ļ� (*.ctc)|*.ctc||"));

	if (fd.DoModal() == IDOK) {
		m_colorfile = fd.GetPathName();
		UpdateData(FALSE);
		TCHAR fl[100];
		_tcscpy(fl, fd.GetPathName());
		::WritePrivateProfileString(_T("Version"), _T("Version"), _T("CTerm 3.2"), fl);
		::WritePrivateProfileString(_T("Version"), _T("Description"), _T("CTerm Color Theme File"), fl);

		for (i = 0; i <= 15; i++) {
			str1.Format(_T("Color%d"), i);
			str2.Format(_T("%u"), m_pDecode->m_ColorSet[i]);
			::WritePrivateProfileString(_T("Color Set"), str1, str2, fl);		// д��
		}
	}

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnColoropen()
{
	CFileDialogEx fd(TRUE, _T("ctc"), m_colorfile, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("CTerm ��ɫ�����ļ� (*.ctc)|*.ctc||"));

	if (fd.DoModal() == IDOK) {
		m_colorfile = fd.GetPathName();
		UpdateData(FALSE);

		GetColorFromFile(m_colorfile);

		OnSetZz();

		UpdateData();
		m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
	}
}

// ���뵽m_CustColor, �Զ��巽��
void CSiteColorPage::GetColorFromFile(CString filename)
{
	CString  str1;

	for (int i = 0; i <= 15; i++) {
		str1.Format(_T("Color%d"), i);
		m_CustColor[i] = GetPrivateProfileInt(_T("Color Set"), str1, 10, filename);
	}
}

void CSiteColorPage::OnMove(int x, int y)
{
	CDialog::OnMove(x, y);
	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

//*********************************************************************
void CSiteColorPage::OnSetA()			// ��׼
{
//	int i;
//	CTelnetSite TempSite;
//	TempSite.SetDefault(_T(""));
//	m_pDecode->m_BackColor = TempSite.m_Decode.m_BackColor; //?
//
//	for (i = 0; i < 16; i++)
//		m_pDecode->m_ColorSet[i] = TempSite.m_Decode.m_ColorSet[i];
//
//	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0]; //?

	COLORREF  MyColor[16] = {
		RGB(0, 0, 0),
		RGB(128, 0, 0),
		RGB(0, 128, 0),
		RGB(128, 128, 0),
		RGB(0, 0, 128),
		RGB(128, 0, 128),
		RGB(0, 128, 128),
		RGB(192, 192, 192),
		RGB(128, 128, 128),
		RGB(255, 0, 0),
		RGB(0, 255, 0),
		RGB(255, 255, 0),
		RGB(0, 0, 255),
		RGB(255, 0, 255),
		RGB(0, 255, 255),
		RGB(255, 255, 255)
	};
	
	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 0;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetB()			// ���
{
	COLORREF MyColor[16] = { RGB(20, 20, 20),
	                         RGB(128, 60, 60),
	                         RGB(60, 128, 60),
	                         RGB(128, 128, 50),
	                         RGB(60, 60, 128),
	                         RGB(128, 60, 128),
	                         RGB(60, 128, 128),
	                         RGB(192, 192, 192),
	                         RGB(128, 128, 128),
	                         RGB(200, 100, 100),
	                         RGB(100, 200, 100),
	                         RGB(200, 200, 100),
	                         RGB(100, 100, 200),
	                         RGB(200, 100, 200),
	                         RGB(100, 200, 200),
	                         RGB(200, 200, 200)
	                       };

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 1;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetC()			// �ڿ�
{
	COLORREF MyColor[16] = {
		0,
		128,
		11371788,
		32896,
		8388608,
		8388736,
		8421376,
		45824,
		5395026,
		255,
		16761928,
		8454143, //ǳ�� //65535, //��
		16711680,
		16711935,
		16776960,
		65280
	};

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 2;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetD()			// FTERM
{
	// FTERM ���ڱ�׼��ɫ�����Ļ����ϸĻ��˱���ɫ
	COLORREF MyColor[16] = { 8404992,
	                         128,
	                         32768,
	                         32896,
	                         8388608,
	                         8388736,
	                         8421376,
	                         12632256,
	                         8421504,
	                         255,
	                         65280,
	                         65535,
	                         16711680,
	                         16711935,
	                         16776960,
	                         16777215
	                       };

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 3;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetE()			// BAIYUN
{
	COLORREF MyColor[16] = {  15717331,
	                          4227200,
	                          32768,
	                          12615680,
	                          16763283,
	                          16752639,
	                          10329344,
	                          8388608,
	                          13226148,
	                          16512,
	                          47872,
	                          8421376,
	                          16744448,
	                          16711935,
	                          7302912,
	                          16711680
	                       };

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 4;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}


void CSiteColorPage::OnSetF()			// Blue
{
	COLORREF MyColor[16] = {
		8388608 ,
		6596098 ,
		55769   ,
		12632256,
		7884545 ,
		8388736 ,
		50176   ,
		15526912,
		12016384,
		10877955,
		65535   ,
		16777215,
		16744448,
		16711935,
		4259584 ,
		16777088
	};

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 5;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetG()			// Green
{
	COLORREF MyColor[16] = { 	4227072,
	                          4210816,
	                          16754342,
	                          32896,
	                          12615680,
	                          8388736,
	                          8421376,
	                          15461355,
	                          8404992,
	                          33023,
	                          65535,
	                          65280,
	                          4227327,
	                          16744703,
	                          16777088,
	                          16777215
	                       };

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 6;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetH()			// Win98
{
	COLORREF MyColor[16] = { 	8421376,
	                          128,
	                          5329407,
	                          32896,
	                          12615680,
	                          8388736,
	                          2434341,
	                          12632256,
	                          12615680,
	                          33023,
	                          65280,
	                          9830399,
	                          13238272,
	                          5855743,
	                          16776960,
	                          16777215
	                       };

	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 7;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}


void CSiteColorPage::OnSetI()		// �ڰ׻ң��ϰ�ɫ��//��ǰԱ�������������Ľ����Ϊ�ڰ׻ң��Ա����ϰ���Ϊ�Լ�����Ŭ�������������˲����⡰�ϰ塱�������˼
{
	CTelnetSite TempSite;
	int gray;
	int R, G, B;
	BYTE *pColor;
	TempSite.SetDefault(_T(""));
	m_pDecode->m_BackColor = RGB(255, 255, 255);
	COLORREF MyColor[16];

	int i;
	for (i = 0; i <= 15; i++) {
		pColor = (BYTE *) & TempSite.m_Decode.m_ColorSet[i];
		R = pColor[0];
		G = pColor[1];
		B = pColor[2];
		gray = 255 - (R * 3 + G * 6 + B) / 10;

		if (gray < 0) gray = 0;

		if (gray > 255) gray = 255;

		MyColor[i] = RGB(gray, gray, gray);
	}

	for (i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = MyColor[i];

	m_pDecode->m_BackColor = m_pDecode->m_ColorSet[0];

	m_pDecode->m_nColorSetNum = 8;

	UpdateData();

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnSetZz()	// �Զ���
{
	for (int i = 0; i <= 15; i++)
		m_pDecode->m_ColorSet[i] = m_CustColor[i];

	m_pDecode->m_BackColor = m_CustColor[0];

	m_pDecode->m_nColorSetNum = m_nColorSet = 9;

	UpdateData(FALSE);

	m_bNeedRedrawColor = true;		//  ������ʱ���������ɫ
}

void CSiteColorPage::OnClose()
{
	KillTimer(TIMER_SITECOLORPAGE);
	CMyPropertyPage::OnClose();
}

void CSiteColorPage::OnPaint()
{
	CPaintDC dc(this);    // device context for painting

	m_bNeedRedrawColor = true;

	// Do not call CMyPropertyPage::OnPaint() for painting messages
}

UINT CSiteColorPage::GetIDD()
{
	return IDD;
}