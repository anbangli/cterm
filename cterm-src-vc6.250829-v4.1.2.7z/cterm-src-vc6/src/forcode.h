#ifndef CODE_CORRECT
#define CODE_CORRECT 0

#define CODE_NORMAL		0
#define CODE_BINARY		1
#define CODE_HEX		2
#define CODE_OFFHEAD	3
#define CODE_GB			4
#define CODE_BIG5		5
#define CODE_WGB		6
#define CODE_WBIG5		7

int CleverCodeConvert(TCHAR *buf, int len);
bool InitCode();
void DeInitCode();
void BIG52GB(BYTE *line);
void GB2BIG5(BYTE *line);
bool UTF8ToGB(CString &str);
bool GBKToUtf8(CString &strGBK);
int H2G(char *str);
bool GB2Unicode(char *s);
bool GB2Unicode(const char *s, WCHAR *dest);
void init_iconv();
#endif
