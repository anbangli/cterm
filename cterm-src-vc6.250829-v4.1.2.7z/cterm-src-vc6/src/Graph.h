// Graph.h: interface for the CGraph class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPH_H__FB2369C0_151B_11D4_B205_000080013F30__INCLUDED_)
#define AFX_GRAPH_H__FB2369C0_151B_11D4_B205_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define GCT_LINE	0
#define GCT_POINT	1
#define GCT_ROUND	2
#define GCT_ARC		3
#define GCT_F_ARC	4
#define GCT_RECT	5
#define GCT_F_RECT	6
#define GCT_F_ROUND	7
#define GCT_TEXT	8
#define GCT_SFC  	110
#define GCT_SBC  	111
#define GCT_SLW 	112
#define GCT_ST  	113
#define GCT_SM      114
#define GCT_RESET   115

#if ENABLE_GRAPH

struct SGCommand {
	BYTE  nType;
	BYTE  nParam;
	short snParam[6];
	TCHAR  szText[80];//��term width�й�? ��DEFAULT_TERM_WIDTH��
};

class CTelnetSite;

struct SGraphSeq {
	BYTE  x, y; //ͼ�����꣬ms���ַ�Ϊ��λ...
	BYTE  nCommand;
	SGCommand Command[30];
};

class CCTermView;

struct SGraphSet {
	COLORREF fc, bc;		// ǰ��ɫ,����ɫ
	CFont    Font;
	CPen     Pen;
	CBrush   Brush;
	int      nWidth;
	BOOL     bTextTrans;
	BOOL     bXOR;
	CString m_font;

	const CCTermView *m_pView;

public:
	void Init(const CTelnetSite *pSite, int nFontSize, const CCTermView *pView);		// ��ʼ��
	~SGraphSet();
	void SetFColor(const SGCommand *, CDC *);		// ����ǰ��ɫ
	void SetBkColor(const SGCommand *, CDC *);		// ���ñ���ɫ
	void SetFont(const SGCommand *, CDC *, int);	// ��������
	void Reset(CDC *pDC, const CTelnetSite *pSite, int nSize);	// Reset
};

class AFX_CLASS_EXPORT CGraph
{

public:
	void Scroll(int);
	void DeleteSeq(int x0, int y0, int x1, int y1);
	void AddSeq(const TCHAR *szSeq, int x, int y);
	void Reset();
	SGraphSeq Seq[10];
	BYTE      m_nNum;
	CGraph();
	virtual ~CGraph();

private:
	BOOL GetParam(TCHAR *szCom, SGCommand &Com);
	BOOL GetCommand(const TCHAR *szSeq, int &nAt, SGCommand &Command);
};

#endif//ENABLE_GRAPH

#endif // !defined(AFX_GRAPH_H__FB2369C0_151B_11D4_B205_000080013F30__INCLUDED_)
