// OptAutoPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptAutoPage.h"
#include "global.h"
#include "paramconfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptAutoPage property page

IMPLEMENT_DYNCREATE(COptAutoPage, CMyPropertyPage)

COptAutoPage::COptAutoPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptAutoPage)
	m_bAntiIdle = FALSE;
	m_nAutoLeave = 0;
	m_IdleTime = 0;
	m_ReplyMsg = _T("");
	m_bMsgRec = FALSE;
	m_bPlayWav = FALSE;
	m_bPopup = FALSE;
	m_sAntiIdleStr = _T("");
	m_bPopupOnMsg = FALSE;
	m_bAutoLockBBS = FALSE;
	m_bBeepWhenMsg = FALSE;
	m_bBeepWhenMail = FALSE;
	m_bMinWhenLeave = FALSE;
	m_mailsnd = _T("");
	m_bAutoReply = TRUE;
	m_bAutoReply = FALSE;
	m_bBeepWhenMail = FALSE;
	//}}AFX_DATA_INIT
}

COptAutoPage::~COptAutoPage()
{
}

void COptAutoPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptAutoPage)
	DDX_Control(pDX, IDC_REPLYMSG, m_editReplyMSG);
	DDX_Check(pDX, IDC_ANTIIDLE, m_bAntiIdle);
	DDX_CBIndex(pDX, IDC_AUTOLEAVE, m_nAutoLeave);
	DDX_Text(pDX, IDC_IDLETIME, m_IdleTime);
	DDX_Text(pDX, IDC_REPLYMSG, m_ReplyMsg);
	DDV_MaxChars(pDX, m_ReplyMsg, 72);
	DDX_Check(pDX, IDC_MSGREC, m_bMsgRec);
	DDX_Check(pDX, IDC_POPUP, m_bPopup);
	DDX_Text(pDX, IDC_IDLESTR, m_sAntiIdleStr);
	DDX_Check(pDX, IDC_CHK_POPUPONMSG, m_bPopupOnMsg);
	DDX_Check(pDX, IDC_CHECK_AUTOLOCKBBS, m_bAutoLockBBS);
	DDX_Check(pDX, IDC_CHECK_BEEP, m_bBeepWhenMsg);
	DDX_Check(pDX, IDC_CHECK_LEAVE_MIN, m_bMinWhenLeave);
	//DDX_Text(pDX, IDC_EDITMAILSND, m_mailsnd);
	DDX_Check(pDX, IDC_AUTOREPLY, m_bAutoReply);
	DDX_Check(pDX, IDC_CHK_BEEPMAIL, m_bBeepWhenMail);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptAutoPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptAutoPage)
	ON_BN_CLICKED(IDC_ANTIIDLE, OnAntiidle)
	ON_BN_CLICKED(IDC_CHECK_AUTOLOCKBBS, OnCheckAutolockbbs)
	ON_BN_CLICKED(IDC_AUTOREPLY, OnAutoreply)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptAutoPage message handlers

void COptAutoPage::OnAntiidle()
{
	UpdateData();
	GetDlgItem(IDC_IDLETIME)->EnableWindow(m_bAntiIdle);
	GetDlgItem(IDC_IDLESTR)->EnableWindow(m_bAntiIdle);
}

/*
void COptAutoPage::OnBrowseWav() // ���������ļ�
{
	PrependWorkDir(m_wavefile);
	CFileDialogEx fd(TRUE, _T("wav"), m_wavefile, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("�����ļ�(*.wav)|*.wav||"));

	if (fd.DoModal() == IDOK) {
		UpdateData();
		m_wavefile = StripWorkDir(fd.GetPathName());
		GetDlgItem(IDC_BROWSEWAV)->SetWindowText(m_wavefile);
	}
	else {
		m_wavefile = StripWorkDir(m_wavefile);
	}

	UpdateData(FALSE);
}
*/

// ����ʱ�����շ���Ϣ���Ӷ�����ʹ���Զ��ظ�
void COptAutoPage::OnCheckAutolockbbs()
{

//��������ֻ����1����Ļ���޷��շ���Ϣ�������ܻ���û����������ϵĻ���
//	UpdateData();
//	GetDlgItem(IDC_STATIC_AUTOREPLY)->EnableWindow(!m_bAutoLockBBS);
//	GetDlgItem(IDC_REPLYMSG)->EnableWindow(!m_bAutoLockBBS);
}

BOOL COptAutoPage::OnInitDialog()
{
	Init();
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	//GetDlgItem(IDC_BROWSEWAV)->SetWindowText(m_wavefile);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

static int TimeSet[6] = {0, 300, 900, 1800, 3600, 7200};	// �Ӳ�/5/15/30/1Сʱ/2Сʱ

void COptAutoPage::Init()
{
#if ENABLE_MESSAGE
	m_bPopup = g_bMsgPopup;
	//m_bPlayWav = g_bPlayWav;	// �����ļ��ڴ�������ʱ���ã���øĵ���������
	m_bMsgRec = g_bMsgRec;
	m_bPopupOnMsg = g_bPopupOnMsg;
	m_bBeepWhenMsg = g_bBeepWhenMsg;
	m_bBeepWhenMail = g_bBeepWhenMail;
	//m_wavefile = StripWorkDir(g_szWavFile);
#endif// ENABLE_MESSAGE

#if ENABLE_LOCK
	m_bAutoLockBBS = g_bAutoLockBBS;
	m_bMinWhenLeave = g_bMinWhenLeave;
	int i;

	for (i = 0; i < 6; i++) {
		if (g_nAutoProtectTime <= TimeSet[i]) {
			m_nAutoLeave = i;
			break;
		}
	}

	if (i >= 6)
		m_nAutoLeave = 5;

#endif// ENABLE_LOCK

	m_bAntiIdle = g_bAntiIdle;

	m_IdleTime = g_nIdleTime;

	m_bAutoReply= g_bIsAutoReply;
	m_ReplyMsg = g_szInitReply;

	m_sAntiIdleStr = g_sAntiIdleStr;

	m_mailsnd = g_szMailWavFile;
}

void COptAutoPage::UnInit()
{
#if ENABLE_MESSAGE
		// ��ֹ�������Զ��ظ�		// ��Ϣ
		g_bMsgPopup = m_bPopup;
		g_bMsgRec  = m_bMsgRec;
		//g_bPlayWav = m_bPlayWav;
		g_bPopupOnMsg = m_bPopupOnMsg;
		g_bBeepWhenMsg = m_bBeepWhenMsg;
		g_bBeepWhenMail = m_bBeepWhenMail;
		//g_szWavFile = m_wavefile;
		PrependWorkDir(g_szWavFile);
#endif// ENABLE_MESSAGE

#if ENABLE_LOCK
		g_bAutoLockBBS = m_bAutoLockBBS;
		g_bMinWhenLeave = m_bMinWhenLeave;
		if (m_nAutoLeave >= 0 && m_nAutoLeave <= 5)
			g_nAutoProtectTime = TimeSet[m_nAutoLeave];
#endif// ENABLE_LOCK

		g_bAntiIdle = m_bAntiIdle;

		g_nIdleTime = m_IdleTime;
		
		g_bIsAutoReply = m_bAutoReply;

		g_szInitReply = m_ReplyMsg;
		g_szReply = g_szInitReply;

		g_sAntiIdleStr = m_sAntiIdleStr;

		g_szMailWavFile = m_mailsnd;
}

UINT COptAutoPage::GetIDD()
{
	return IDD;
}

void COptAutoPage::OnOK() 
{
	UnInit();	
	CMyPropertyPage::OnOK();
}

void COptAutoPage::OnAutoreply() 
{
	UpdateData();
	m_editReplyMSG.EnableWindow(m_bAutoReply);
}
