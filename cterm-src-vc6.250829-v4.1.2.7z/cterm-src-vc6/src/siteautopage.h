#if !defined(AFX_AUTOLOGINPAGE_H__16964DE3_7FFD_426F_879E_BF14F4E3712F__INCLUDED_)
#define AFX_AUTOLOGINPAGE_H__16964DE3_7FFD_426F_879E_BF14F4E3712F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AutoLoginPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteAutoPage dialog

struct SLoginSet;

class CSiteAutoPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteAutoPage)

	int m_nType;
// Construction

public:
	SLoginSet  * m_pLogin;
	//CString	m_psw;

	CSiteAutoPage();
	~CSiteAutoPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(CSiteAutoPage)
	enum { IDD = IDD_SITE_AUTOLOGIN };
	CEdit	m_editPSW;
	CEdit	m_editName;
	CString	m_name;
	CString	m_psw;
	BOOL	m_bAutoLogin;
	BOOL	m_bSSHbbsLogin;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteAutoPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CSiteAutoPage)
	afx_msg void OnScript();
	afx_msg void OnCheckAutologin();
	virtual BOOL OnInitDialog();
	afx_msg void OnSetfocusPsw();
	afx_msg void OnChangePsw();
	afx_msg void OnFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool m_bPWChanged;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOLOGINPAGE_H__16964DE3_7FFD_426F_879E_BF14F4E3712F__INCLUDED_)
