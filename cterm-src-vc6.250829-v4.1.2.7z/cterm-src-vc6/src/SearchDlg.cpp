// SearchDlg.cpp : implementation file
// ������������

#include "stdafx.h"
#include "SearchDlg.h"
#include "ctermview.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSearchDlg dialog


CSearchDlg::CSearchDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CSearchDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSearchDlg)
	m_author = _T("");
	m_Title1 = _T("");
	//}}AFX_DATA_INIT

}


void CSearchDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSearchDlg)
	DDX_Text(pDX, IDC_AUTHOR, m_author);
	DDX_Text(pDX, IDC_TITLE_1, m_Title1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSearchDlg, CDialog)
	//{{AFX_MSG_MAP(CSearchDlg)
	ON_BN_CLICKED(IDC_SEARCHNEXT, OnSearchnext)
	ON_BN_CLICKED(IDC_SEARCHPREV, OnSearchprev)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSearchDlg message handlers

BOOL CSearchDlg::OnInitDialog()
{
	// m_pview ��MainFrm ����ʱ���ã����Բ����ڴ˴���ʼ��

	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	return TRUE;
}


void CSearchDlg::OnSearchprev()		// ��һ��
{
	Search(0);
}

void CSearchDlg::OnSearchnext()		// ��һ��
{
	Search(1);
}

// ������ii=0 Ϊ���ϣ�ii=1 Ϊ����
void CSearchDlg::Search(int ii)
{
	CCTermView *pView;

	pView = g_pMainWnd->GetView(-1); // get active view
	if (!pView) {
		return;
	}

	CCTermCore *pCore = &pView->m_Core;
	if (!pCore) {
		return;
	}

	if (!pView->IsStable()) {
		return;
	}

	SITESTATUS nStatus = pView->GetStatus();
	if (nStatus != SST_LIST) {
		return;
	}

	TCHAR ts[100];
	UpdateData();

	if (m_author.IsEmpty() && m_Title1.IsEmpty()) {
		return;
	}

	SITESTATUS nSub = pView->m_Status.SubStatus();
	if (nSub == SST_LIST_ARTICLE && !m_author.IsEmpty()) {
		// ��������  A���ϣ�a����
		if (ii == 0)
			_stprintf(ts, _T("A%s\n"), m_author);
		else
			_stprintf(ts, _T("a%s\n"), m_author);

		pView->Send(ts, _tcslen(ts));

		// todo: �ҵ�����֮���ٷ����Ƿ��������
	}
	else if (!m_Title1.IsEmpty()) {
		// ����Ϊ��ʱ��ֻ���������⡣?���ϣ�/����
		if (ii == 0)
			_stprintf(ts, _T("?%s\n"), m_Title1);
		else
			_stprintf(ts, _T("/%s\n"), m_Title1);

		//AfxGetMainWnd()->MessageBox(ts);
		pView->Send(ts, _tcslen(ts));
	}
}

void CSearchDlg::OnClose()
{
	CDialog::OnClose();
	CDialog::OnDestroy();
}

void CSearchDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	delete this;
}
