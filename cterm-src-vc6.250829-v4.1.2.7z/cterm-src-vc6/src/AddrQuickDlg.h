#if !defined(AFX_ADDRQUICKDLG_H__08F35EFC_0F08_41E6_9858_44F13FD68201__INCLUDED_)
#define AFX_ADDRQUICKDLG_H__08F35EFC_0F08_41E6_9858_44F13FD68201__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddrQuickDlg.h : header file
//
#include "resource.h"
#include "TelnetSite.h"
/////////////////////////////////////////////////////////////////////////////
// CAddrQuickDlg dialog

class AFX_CLASS_EXPORT CAddrQuickDlg : public CDialog
{
// Construction

public:
	CAddrQuickDlg(CWnd* pParent = NULL);   // standard constructor
	CTelnetSite m_Site;
// Dialog Data
	//{{AFX_DATA(CAddrQuickDlg)
	enum { IDD = IDD_ADDRQUICK };
	CString	m_addr;
	int		m_port;
	BOOL	m_bIPv6;
	BOOL	m_ssh;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddrQuickDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CAddrQuickDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSsh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDRQUICKDLG_H__08F35EFC_0F08_41E6_9858_44F13FD68201__INCLUDED_)
