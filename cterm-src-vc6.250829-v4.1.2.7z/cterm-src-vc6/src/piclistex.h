// HscPreList.h: interface for the CTypedPtrListEx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HSCPRELIST_H__478EA218_73F3_41D6_BABF_D75F3B97D06D__INCLUDED_)
#define AFX_HSCPRELIST_H__478EA218_73F3_41D6_BABF_D75F3B97D06D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CTypedPtrListEx<TYPE, ARG_TYPE>
template<class TYPE, class ARG_TYPE>

class CTypedPtrListEx
{

protected:

	struct CNode {
		CNode* pNext;
		CNode* pPrev;
		TYPE data;
	};

	//��ͷ
	CNode* m_pNodeHead;
	//��β
	CNode* m_pNodeTail;
	//�ڵ�����
	int m_nCount;

public:
// Construction
	CTypedPtrListEx() {
		m_pNodeHead = NULL;
		m_pNodeTail = NULL;
		m_nCount = 0;
	}

public:
	~CTypedPtrListEx() {
		RemoveAll();
	}

	//��ȡ��Ԫ����
	int GetCount() const {
		return m_nCount;
	}

	//�Ƿ�Ϊ��
	BOOL IsEmpty() const {
		return m_nCount == 0;
	}

	//����ͷԪ��
	TYPE& GetHead() {
		ASSERT(m_pNodeHead != NULL);
		return m_pNodeHead->data;
	}

	//����ͷԪ��
	TYPE GetHead() const {
		ASSERT(m_pNodeHead != NULL);
		return m_pNodeHead->data;
	}

	//����βԪ��
	TYPE& GetTail() {
		ASSERT(m_pNodeTail != NULL);
		return m_pNodeTail->data;
	}

	//����βԪ��
	TYPE GetTail() const {
		ASSERT(m_pNodeTail != NULL);
		return m_pNodeTail->data;
	}

	//����ͷ
	POSITION GetHeadPosition() const {
		return (POSITION) m_pNodeHead;
	}

	//����β
	POSITION GetTailPosition() const {
		return (POSITION) m_pNodeTail;
	}

	//��һԪ��
	TYPE& GetNext(POSITION& rPosition) {
		CNode* pNode = (CNode*) rPosition;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		rPosition = (POSITION) pNode->pNext;
		return pNode->data;
	}

	//��һԪ��
	TYPE GetNext(POSITION& rPosition) const {
		CNode* pNode = (CNode*) rPosition;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		rPosition = (POSITION) pNode->pNext;
		return pNode->data;
	}

	//��һԪ��
	TYPE& GetPrev(POSITION& rPosition) {
		CNode* pNode = (CNode*) rPosition;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		rPosition = (POSITION) pNode->pPrev;
		return pNode->data;
	}

	//��һԪ��
	TYPE GetPrev(POSITION& rPosition) const {
		CNode* pNode = (CNode*) rPosition;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		rPosition = (POSITION) pNode->pPrev;
		return pNode->data;
	}

	//ȡһԪ��
	TYPE& GetAt(POSITION position) {
		CNode* pNode = (CNode*) position;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		return pNode->data;
	}

	//ȡһԪ��
	TYPE GetAt(POSITION position) const {
		CNode* pNode = (CNode*) position;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		return pNode->data;
	}

	//�滻Ԫ��
	void SetAt(POSITION pos, ARG_TYPE newElement) {
		CNode* pNode = (CNode*) pos;
		ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
		pNode->data = newElement;
	}

	//ɾ������Ԫ��
	void RemoveAll() {
		if (m_pNodeHead) {
			CNode* pNode;
			CNode* pNextNode;

			for (pNode = m_pNodeHead; pNode != NULL;) {
				pNextNode = pNode->pNext;
				delete pNode;
				pNode = pNextNode;
			}

			m_nCount = 0;

			m_pNodeHead = m_pNodeTail = NULL;
		}
	}

	//һ���½ڵ�
	CNode* NewNode(CNode* pPrev, CNode* pNext) {
		CNode* pNode = new CNode;
		pNode->pPrev = pPrev;
		pNode->pNext = pNext;
		m_nCount++;
		return pNode;
	}

	//ɾ��һ���ڵ�
	void FreeNode(CNode* pNode) {
		if (pNode->pPrev) {
			pNode->pPrev->pNext = pNode->pNext;
		} else {
			m_pNodeHead = pNode->pNext;
		}

		if (pNode->pNext) {
			pNode->pNext->pPrev = pNode->pPrev;
		} else {
			m_pNodeTail = pNode->pPrev;
		}

		delete pNode;

		m_nCount--;
		ASSERT(m_nCount >= 0);  // make sure we don't underflow

		// if no more elements, cleanup completely

		if (m_nCount == 0)
			RemoveAll();
	}

	//�ڱ�ͷ����Ԫ��
	POSITION AddHead(ARG_TYPE newElement) {


		CNode* pNewNode = NewNode(NULL, m_pNodeHead);
		pNewNode->data = newElement;

		if (m_pNodeHead)
			m_pNodeHead->pPrev = pNewNode;
		else {
			m_pNodeTail = pNewNode;
		}

		m_pNodeHead = pNewNode;

		return (POSITION) pNewNode;
	}

	//�ڱ�β����Ԫ��
	POSITION AddTail(ARG_TYPE newElement) {

		CNode* pNewNode = NewNode(m_pNodeTail, NULL);
		pNewNode->data = newElement;

		if (m_pNodeTail != NULL)
			m_pNodeTail->pNext = pNewNode;
		else
			m_pNodeHead = pNewNode;

		m_pNodeTail = pNewNode;

		return (POSITION) pNewNode;
	}

	//�ڱ�ͷ��������
	void AddHead(CTypedPtrListEx* pNewList) {
		//�����Լ����Լ�
		ASSERT(pNewList != this);

		ASSERT(pNewList != NULL);

		// add a li of same elements to head (maintain order)
		POSITION pos = pNewList->GetTailPosition();

		while (pos != NULL)
			AddHead(pNewList->GetPrev(pos));
	}

	//�ڱ�β��������
	void AddTail(CTypedPtrListEx* pNewList) {
		//�����Լ����Լ�
		ASSERT(pNewList != this);
		ASSERT(pNewList != NULL);
		// add a li of same elements
		POSITION pos = pNewList->GetHeadPosition();

		while (pos != NULL)
			AddTail(pNewList->GetNext(pos));
	}

	//ɾ����ͷԪ��
	//freenodeֻɾ�������ݵ�ָ�룬��û��ɾ��ʵ�����ݣ����뽫���ݷ����������ͷ�
	TYPE RemoveHead() {
		ASSERT(m_pNodeHead != NULL);
		TYPE data = m_pNodeHead->data;
		FreeNode(m_pNodeHead);
		return data;
	}

	//ɾ����βԪ��
	//freenodeֻɾ�������ݵ�ָ�룬��û��ɾ��ʵ�����ݣ����뽫���ݷ����������ͷ�
	TYPE RemoveTail() {
		ASSERT(m_pNodeTail != NULL);  // don't call on empty li !!!
		TYPE data = m_pNodeTail->data;
		FreeNode(m_pNodeTail);
		return data;
	}

	//ָ��λ��֮ǰ����Ԫ��
	POSITION InsertBefore(POSITION position, ARG_TYPE newElement) {
		if (position == NULL)
			return AddHead(newElement); // insert before nothing-> head of the li

		// Insert it before position
		CNode* pOldNode = (CNode*) position;

		CNode* pNewNode = NewNode(pOldNode->pPrev, pOldNode);

		pNewNode->data = newElement;

		if (pOldNode->pPrev != NULL) {
			ASSERT(AfxIsValidAddress(pOldNode->pPrev, sizeof(CNode)));
			pOldNode->pPrev->pNext = pNewNode;
		} else {
			ASSERT(pOldNode == m_pNodeHead);
			m_pNodeHead = pNewNode;
		}

		pOldNode->pPrev = pNewNode;

		return (POSITION) pNewNode;
	}

	//ָ��λ��֮�����Ԫ��
	POSITION InsertAfter(POSITION position, ARG_TYPE newElement) {
		if (position == NULL)
			return AddTail(newElement); // insert after nothing-> tail of the li

		// Insert it before position
		CNode* pOldNode = (CNode*) position;

		ASSERT(AfxIsValidAddress(pOldNode, sizeof(CNode)));

		CNode* pNewNode = NewNode(pOldNode, pOldNode->pNext);

		pNewNode->data = newElement;

		if (pOldNode->pNext != NULL) {
			ASSERT(AfxIsValidAddress(pOldNode->pNext, sizeof(CNode)));
			pOldNode->pNext->pPrev = pNewNode;
		} else {
			ASSERT(pOldNode == m_pNodeTail);
			m_pNodeTail = pNewNode;
		}

		pOldNode->pNext = pNewNode;

		return (POSITION) pNewNode;
	}

	//ָ��λ��ɾ��Ԫ��
	//freenodeֻɾ�������ݵ�ָ�룬��û��ɾ��ʵ�����ݣ����뽫���ݷ����������ͷ�
	TYPE RemoveAt(POSITION position) {
		CNode* pOldNode = (CNode*) position;
		ASSERT(AfxIsValidAddress(pOldNode, sizeof(CNode)));
		TYPE data = pOldNode->data;
		FreeNode(pOldNode);
		return data;
	}

	//ָ����������Ԫ��
	POSITION FindIndex(int nIndex) const {
		if (nIndex >= m_nCount || nIndex < 0)
			return NULL;  // went too far

		CNode* pNode = m_pNodeHead;

		while (nIndex--) {
			ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
			pNode = pNode->pNext;
		}

		return (POSITION) pNode;
	}

	//ָ��λ�ò���Ԫ��
	POSITION Find(ARG_TYPE searchValue, POSITION startAfter = NULL) const {
		CNode* pNode = (CNode*) startAfter;

		if (pNode == NULL) {
			pNode = m_pNodeHead;  // start at head
		} else {
			ASSERT(AfxIsValidAddress(pNode, sizeof(CNode)));
			pNode = pNode->pNext;  // start after the one specified
		}

		for (; pNode != NULL; pNode = pNode->pNext) {
			if (pNode->data == searchValue) {
				return (POSITION)pNode;
			}
		}

		return NULL;
	}

	//ָ��Ԫ�ز������� - Hendy����
	int Find(ARG_TYPE searchValue) {
		int nIndex = -1;
		CNode* pNode = m_pNodeHead;

		for (; pNode != NULL; pNode = pNode->pNext) {
			nIndex ++;

			if (pNode->data == searchValue) {
				return nIndex;
			}
		}

		return -1;
	}

	//�������
	void Serialize(CArchive& ar) {
		if (ar.IsStoring()) {
			ar.WriteCount(m_nCount);

			for (CNode* pNode = m_pNodeHead; pNode != NULL; pNode = pNode->pNext) {
				ar.Write(&pNode->data, sizeof(TYPE));
			}
		} else {
			DWORD nNewCount = ar.ReadCount();

			while (nNewCount--) {
				TYPE newData;
				ar.Read(&newData, sizeof(TYPE));
				AddTail(newData);
			}
		}
	}
};

#endif // !defined(AFX_HSCPRELIST_H__478EA218_73F3_41D6_BABF_D75F3B97D06D__INCLUDED_)
