// OptWebPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptWebPage.h"
#include "global.h"

#include <io.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptWebPage property page

IMPLEMENT_DYNCREATE(COptWebPage, CMyPropertyPage)

COptWebPage::COptWebPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptWebPage)
	m_usegoogle = -1;
	m_weblong = -1;
	m_homepage = _T("");
	m_bSearchBox = FALSE;

	m_showip = FALSE;
	m_showipauto = FALSE;

//	m_nDownTool = 0;
	//}}AFX_DATA_INIT
}

COptWebPage::~COptWebPage()
{
}

void COptWebPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptWebPage)
	DDX_Radio(pDX, IDC_USEGOOGLE0, m_usegoogle);
	DDX_Radio(pDX, IDC_WEBLONG0, m_weblong);
	DDX_Text(pDX, IDC_EDIT_HOMEPAGE, m_homepage);
	DDX_Check(pDX, IDC_CHECK_SEARCHBOX, m_bSearchBox);

	DDX_Check(pDX, IDC_CHK_IP, m_showip);
	DDX_Check(pDX, IDC_CHK_IP_AUTO, m_showipauto);

//	DDX_Text(pDX, IDC_EDIT_DOWNTOOL, m_nDownTool);
//	DDV_MinMaxInt(pDX, m_nDownTool, 0, 9);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptWebPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptWebPage)
	ON_BN_CLICKED(IDC_CHK_IP, OnChkIP)
	ON_BN_CLICKED(IDC_SETIPDAT, OnSetIPdat)
	ON_BN_CLICKED(IDC_DOWNIPDAT, OnDownipdat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptWebPage message handlers

BOOL COptWebPage::OnInitDialog()
{
	CMyPropertyPage ::OnInitDialog();

#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG
	
	GetDlgItem(IDC_SETIPDAT)->SetWindowText(m_ipdat);

//	if (m_ftp != _T("")) {		//_T("0")) {	//mainfrm.cpp�г�ʼ��ʱ���û�����ã������дΪ_T("0")
//		GetDlgItem(IDC_SETFTPTOOL)->SetWindowText(m_ftp);
//	}

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

UINT COptWebPage::GetIDD()
{
	return IDD;
}

//void COptWebPage::OnSetftptool()
//{
//	CFileDialogEx fd(TRUE, _T("*.exe"), m_ftp, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
//	               _T("��ִ�г���(*.exe)|*.exe||"));
//	if (fd.DoModal() == IDOK) {
//		UpdateData();
//		m_ftp = fd.GetPathName();
//		GetDlgItem(IDC_SETFTPTOOL)->SetWindowText(m_ftp);
//		UpdateData(FALSE);
//	}
//}
void COptWebPage::OnSetIPdat()
{
	PrependWorkDir(m_ipdat);
	CFileDialogEx fd(TRUE, _T("*.dat"), m_ipdat, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("IP���ݿ��ļ�(*.dat)|*.dat||"));

	if (fd.DoModal() == IDOK) {
		UpdateData();
		m_ipdat = StripWorkDir(fd.GetPathName());
		GetDlgItem(IDC_SETIPDAT)->SetWindowText(m_ipdat);
		UpdateData(FALSE);
	}
	else {
		m_ipdat = StripWorkDir(m_ipdat);
	}
}

void COptWebPage::OnChkIP()
{
	m_showip = !m_showip;
	UpdateData(FALSE);

	PrependWorkDir(m_ipdat);
	if (m_showip && _taccess(m_ipdat, 0) != 0) {
		CString ss = _T("IP ���ݿ��ļ� ") + m_ipdat + _T(" �����ڡ�������IP���ݿ��ļ���Ȼ�������ô�ѡ�");
		MessageBox(ss);
		m_showip = 0;
		UpdateData(FALSE);
	}
	m_ipdat = StripWorkDir(m_ipdat);
}

void COptWebPage::OnDownipdat()
{
	//ShellExecute(NULL, _T("open"), _T("http://cterm.phy.ccnu.edu.cn/downipdat.htm"), NULL, NULL, NULL);
	//ShellExecute(NULL, _T("open"), _T("http://www.cz88.net/ip/"), NULL, NULL, NULL);
	ShellExecute(NULL, _T("open"), _T("https://www.cz88.net/geo-public"), NULL, NULL, NULL);

}