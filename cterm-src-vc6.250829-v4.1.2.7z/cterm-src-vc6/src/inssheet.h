#if !defined(AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_)
#define AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// inssheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInsSheet

class CMyPropertyPage;
class CEditDlg;

class CInsSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CInsSheet)

// Construction

public:
	CInsSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CInsSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes

	int *m_pLastTabIndex; // ָ��һ����̬������������������tab����
public:

// Operations

public:
	void AddPage(CMyPropertyPage* pPage);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInsSheet)

public:
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation

public:
	virtual ~CInsSheet();

	// Generated message map functions

protected:
	//{{AFX_MSG(CInsSheet)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

private:
	bool bView; // or edit
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_)
