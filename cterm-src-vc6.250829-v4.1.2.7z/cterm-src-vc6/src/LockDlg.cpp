// LockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LockDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLockDlg dialog


CLockDlg::CLockDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CLockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLockDlg)
	//}}AFX_DATA_INIT
}


void CLockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLockDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLockDlg, CDialog)
	//{{AFX_MSG_MAP(CLockDlg)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLockDlg message handlers

void CLockDlg::OnCancel()
{

//	CDialog::OnCancel();
}

void CLockDlg::OnClose()
{

//	CDialog::OnClose();
}

void CLockDlg::OnOK()
{
//	UpdateData();
//    if(!_tcscmp(m_pLockPsw[0]=='\0' ? _T("OK") : m_pLockPsw, m_psw)) //����Ϊ�գ�����OK

//	if (!_tcscmp(m_pLockPsw, m_psw)) {
		CDialog::OnOK();
//	}
}
