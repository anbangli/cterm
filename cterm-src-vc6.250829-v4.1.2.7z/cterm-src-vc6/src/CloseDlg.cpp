// CloseDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CloseDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCloseDlg dialog


CCloseDlg::CCloseDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CCloseDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCloseDlg)
	m_bQuickLogout = FALSE;
	m_bNoAskWhenClose = TRUE;
	//}}AFX_DATA_INIT
}


void CCloseDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCloseDlg)
	DDX_Control(pDX, IDOK, m_ok);
	DDX_Check(pDX, IDC_CHECK_NOASK, m_bNoAskWhenClose);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCloseDlg, CDialog)
	//{{AFX_MSG_MAP(CCloseDlg)
	ON_BN_CLICKED(IDC_CLOSEIT, OnCloseit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCloseDlg message handlers

BOOL CCloseDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


#if ENABLE_BTNST
	m_ok.SetFlat(0);
	m_ok.SetIcon(IDI_QUICKLOGOUT);
#endif//ENABLE_BTNST

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CCloseDlg::OnOK()
{
	m_bQuickLogout = TRUE;
	CDialog::OnOK();
}

void CCloseDlg::OnCloseit()
{
	CDialog::OnOK();
}

void CCloseDlg::OnCancel()
{
	UpdateData();
	CDialog::OnCancel();
}
