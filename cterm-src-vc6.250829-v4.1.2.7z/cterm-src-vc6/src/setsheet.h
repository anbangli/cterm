#if !defined(AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_)
#define AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SetSheet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSetSheet

class CMyPropertyPage;

class CSetSheet : public CPropertySheet
{
	DECLARE_DYNAMIC(CSetSheet)

// Construction

public:
	CSetSheet(UINT nIDCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);
	CSetSheet(LPCTSTR pszCaption, CWnd* pParentWnd = NULL, UINT iSelectPage = 0);

// Attributes

	int *m_pLastTabIndex; // ָ��һ����̬������������������tab����
public:

// Operations

public:
	void AddPage(CMyPropertyPage* pPage);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetSheet)
	public:
	virtual BOOL OnInitDialog();
	//}}AFX_VIRTUAL

// Implementation

public:
	virtual ~CSetSheet();

	// Generated message map functions

protected:
	//{{AFX_MSG(CSetSheet)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETSHEET_H__C8AEE050_0637_11D4_B1D3_000080013F30__INCLUDED_)
