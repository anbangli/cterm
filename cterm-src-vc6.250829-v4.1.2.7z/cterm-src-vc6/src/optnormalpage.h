#if !defined(AFX_OPTNORMALPAGE_H__162307F2_A4FB_44FA_A63E_FA9EF77F6C17__INCLUDED_)
#define AFX_OPTNORMALPAGE_H__162307F2_A4FB_44FA_A63E_FA9EF77F6C17__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptNormalPage.h : header file
//

#if defined(ENABLE_ACCELEDIT) || defined(ENABLE_HOTKEY)
#include "KeyboardEdit.h"
#endif

#if ENABLE_HOTKEY
#include "HotKey.h"
#endif//ENABLE_HOTKEY

/////////////////////////////////////////////////////////////////////////////
// COptNormalPage dialog
#include "MyPropertyPage.h"

class COptNormalPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptNormalPage)

// Construction

public:
	COptNormalPage();
	~COptNormalPage();
	virtual UINT GetIDD();

public:
	CHotKey m_BossHotkey;
// Dialog Data
	//{{AFX_DATA(COptNormalPage)
	enum { IDD = IDD_OPT_NORMAL };
	CButton	m_btnBossMouse;
	BOOL	m_bAllowMulti;
	BOOL	m_bLastSite;
	BOOL	m_bMinToTray;
	BOOL	m_bSiteReport;
	BOOL	m_bUseMouse;
	BOOL	m_bEnablePython;
	BOOL	m_bPopupOnMsg;
	BOOL	m_bAutoMailBack;
	BOOL	m_bAutoUpdate;
	BOOL	m_bDoubleClickTab;
	BOOL	m_bPythonStatus;
	BOOL	m_bAutoLast;
	BOOL	m_bBossKeyActive;
	CKeyboardEdit	m_editBossHotKey;
	BOOL	m_bBossMouse;
	BOOL	m_bSiteStatus;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptNormalPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(COptNormalPage)
	afx_msg void OnChkEnablepython();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual BOOL OnInitDialog();
	afx_msg void OnBosskeyActive();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTNORMALPAGE_H__162307F2_A4FB_44FA_A63E_FA9EF77F6C17__INCLUDED_)
