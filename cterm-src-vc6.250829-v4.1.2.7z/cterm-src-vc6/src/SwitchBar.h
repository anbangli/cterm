#if !defined(AFX_SWITCHBAR_H__159ECF40_0306_11D4_B1C9_000080013F30__INCLUDED_)
#define AFX_MYDIALOGBAR_H__159ECF40_0306_11D4_B1C9_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SwitchBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSwitchBar dialog

//#define WM_TAB_BUTTON_SWITCH	0x127 //��ֵ���Ϣ��û�ж��塣���ü����л���ťʱ����ť���£�����δѡ�У���Ҫ��һ�¿ո�

class CSwitchBar : public CDialogBar
{
// Construction

public:
	CSwitchBar(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSwitchBar)
	enum { IDD = IDR_SWITCH_BAR };
	//}}AFX_DATA

// Implementation

public:
	int HitTest();
	void SetTabSize();
	CTabCtrl *tab() const;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSwitchBar)

protected:
	//}}AFX_VIRTUAL

protected:

	// Generated message map functions
	//{{AFX_MSG(CSwitchBar)
	afx_msg void OnMove(int x, int y);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnPaint();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void DrawGripper(CDC *pDC);
	CRect GetGripperRect();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SWITCHBAR_H__159ECF40_0306_11D4_B1C9_000080013F30__INCLUDED_)
