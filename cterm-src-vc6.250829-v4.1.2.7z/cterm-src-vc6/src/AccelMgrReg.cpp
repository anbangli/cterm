////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Thierry Maurel
// All rights reserved
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc., and
// I'll try to keep a version up to date.  I can be reached as follows:
//    tmaurel@caramail.com   (or tmaurel@hol.fr)
//
////////////////////////////////////////////////////////////////////////////////
// File    : AccelMgrReg.cpp
// Project : AccelsEditor
////////////////////////////////////////////////////////////////////////////////
// Version : 1.0                       * Author : T.Maurel
// Date    : 17.08.98
//
// Remarks : implementation of the CAcceleratorManager class,
//           access to the registry.
//
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "AcceleratorManager.h"
#include "CmdAccelOb.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// In/Out to the registry
//////////////////////////////////////////////////////////////////////
//
//
/*bool CAcceleratorManager::Load(HKEY hRegKey, LPCTSTR szRegKey)
{
	ASSERT(szRegKey != NULL);

	m_hRegKey = hRegKey;
	m_szRegKey = szRegKey;

	CDWordArray AccelsDatasArray;
	CRegistry reg;
	reg.Open(m_hRegKey, m_szRegKey);
	if (reg.VerifyValue  (_T("Keyboard"))) {
		BOOL bRet = reg.Read(_T("Keyboard"), AccelsDatasArray);
		reg.Close();
		if (bRet == TRUE) {
			CCmdAccelOb* pCmdAccel;
			CAccelsOb* pAccel;
			DWORD dwHeader, dwIDAccelData, dwAccelData;
			BOOL bExistID;
			int iIndex = 0;
			dwHeader = AccelsDatasArray.GetAt(iIndex++);
			if (LOWORD(dwHeader) == 65535) {
				for (int i = 0; i < HIWORD(dwHeader); i++) {
					dwIDAccelData = AccelsDatasArray.GetAt(iIndex++);
					WORD wIDCommand = LOWORD(dwIDAccelData);
					bExistID = m_mapAccelTable.Lookup(wIDCommand, pCmdAccel);
					if (bExistID)//else?
						pCmdAccel->DeleteUserAccels();
					for (int j = 0; j < HIWORD(dwIDAccelData); j++) {
						dwAccelData = AccelsDatasArray.GetAt(iIndex++);
						if (bExistID) {
							pAccel = new CAccelsOb;
							ASSERT(pAccel != NULL);
							pAccel->SetData(dwAccelData);
							pCmdAccel->Add(pAccel);
						}
					}
				}
			}
			AccelsDatasArray.RemoveAll();
			UpdateWndTable();
			return true;
		}
		return false;
	}
	return true;
}*/

bool CAcceleratorManager::Load(CString sFileName)
{
	ASSERT(!sFileName.IsEmpty());

	CDWordArray AccelsDatasArray;

	bool bRet = true;
	CString filename = g_szWorkDir + m_sDataFileName;
	CFile f;
	CFileException ex;

	if (!f.Open(filename, CFile::modeRead | CFile::shareDenyWrite, &ex)) {
		if (ex.m_cause == CFileException::fileNotFound)
			return true; //no user accelerators to load

		return false;
	}

	try {
		CArchive ar(&f, CArchive::load);
		AccelsDatasArray.Serialize(ar);
	}

//	catch(CFileException ex)
//	{
//		AfxMessageBox(_T("file open error when read accelerator data"));
//		bRet=false;
//	}
	catch (...) {
//		AfxMessageBox(_T("error occurs when read accelerator data"));
		bRet = false;
	}

	if (bRet) {
		CCmdAccelOb* pCmdAccel;
		CAccelsOb* pAccel;
		DWORD dwHeader, dwIDAccelData, dwAccelData;
		BOOL bExistID;
		int iIndex = 0;
		dwHeader = AccelsDatasArray.GetAt(iIndex++);

		if (LOWORD(dwHeader) == 65535) {
			for (int i = 0; i < HIWORD(dwHeader); i++) {
				dwIDAccelData = AccelsDatasArray.GetAt(iIndex++);
				WORD wIDCommand = LOWORD(dwIDAccelData);
				bExistID = m_mapAccelTable.Lookup(wIDCommand, pCmdAccel);

				if (bExistID)   //else?
					pCmdAccel->DeleteUserAccels();

				for (int j = 0; j < HIWORD(dwIDAccelData); j++) {
					dwAccelData = AccelsDatasArray.GetAt(iIndex++);

					if (bExistID) {
						pAccel = new CAccelsOb;
						ASSERT(pAccel != NULL);
						pAccel->SetData(dwAccelData);
						pCmdAccel->Add(pAccel);
					}
				}
			}
		}

		AccelsDatasArray.RemoveAll();

		UpdateWndTable();
		return true;
	}

	return false;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::Load()
{
	BOOL bRet = FALSE;
//	if (!m_szRegKey.IsEmpty())
//		bRet = Load(m_hRegKey, m_szRegKey);

	if (!m_sDataFileName.IsEmpty())
		bRet = Load(m_sDataFileName);

	if (bRet == TRUE)
		return true;
	else
		return false;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::Write()
{
	CDWordArray AccelsDatasArray;
	CDWordArray CmdDatasArray;

	int iCount = 0;
	CCmdAccelOb* pCmdAccel;
	CAccelsOb* pAccel;
	DWORD dwAccelData;

	WORD wKey;
	POSITION pos = m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);

		CmdDatasArray.RemoveAll();
		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();

		while (pos != NULL) {
			pAccel = pCmdAccel->m_Accels.GetNext(pos);

			if (!pAccel->m_bLocked) {
				dwAccelData = pAccel->GetData();
				CmdDatasArray.Add(dwAccelData);
			}
		}

		if (CmdDatasArray.GetSize() > 0) {
			CmdDatasArray.InsertAt(0, MAKELONG(pCmdAccel->m_wIDCommand, CmdDatasArray.GetSize()));

			AccelsDatasArray.Append(CmdDatasArray);
			iCount++;
		}
	}

	AccelsDatasArray.InsertAt(0, MAKELONG(65535, iCount));

// ʹ��ע���
//	CRegistry reg;
//	reg.Open(m_hRegKey, m_szRegKey);
//	BOOL bRet = reg.Write(_T("Keyboard"), AccelsDatasArray);
//	reg.Close();

// ʹ��ini ... ���ð죬��400�ֽ����ݣ�д��һ�п϶����ã�д�ɶ��С�����������
// ����ֱ��д�ɶ�����.dat�ļ�
	bool bRet = true;

	CString filename = g_szWorkDir + m_sDataFileName;

	try {
		CFile f(filename, CFile::modeCreate | CFile::modeWrite | CFile::shareDenyRead | CFile::shareDenyWrite);
		CArchive ar(&f, CArchive::store);
		AccelsDatasArray.Serialize(ar);
	} catch (CFileException ex) {
//		AfxMessageBox(_T("file open error when write accelerator data"));
		bRet = false;
	} catch (...) {
//		AfxMessageBox(_T("error occurs when write accelerator data"));
		bRet = false;
	}

	AccelsDatasArray.RemoveAll();

	return bRet;
}


//////////////////////////////////////////////////////////////////////
// Defaults values management.
//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::CreateDefaultTable()
{
	if (m_bDefaultTable)
		return false;

	CCmdAccelOb* pCmdAccel;

	CCmdAccelOb* pNewCmdAccel;

	CAccelsOb* pAccel;

	CAccelsOb* pNewAccel;

	WORD wKey;

	POSITION pos = m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
		pNewCmdAccel = new CCmdAccelOb;
		ASSERT(pNewCmdAccel != NULL);

		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();

		while (pos != NULL) {
			pAccel = pCmdAccel->m_Accels.GetNext(pos);

			if (!pAccel->m_bLocked) {
				pNewAccel = new CAccelsOb;
				ASSERT(pNewAccel != NULL);

				*pNewAccel = *pAccel;
				pNewCmdAccel->m_Accels.AddTail(pNewAccel);
			}
		}

		if (pNewCmdAccel->m_Accels.GetCount() != 0) {
			pNewCmdAccel->m_wIDCommand = pCmdAccel->m_wIDCommand;
			pNewCmdAccel->m_szCommand = pCmdAccel->m_szCommand;

			m_mapAccelTableSaved.SetAt(wKey, pNewCmdAccel);
		} else
			delete pNewCmdAccel;
	}

	m_bDefaultTable = true;

	return true;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::Default()
{
	CCmdAccelOb* pCmdAccel;
	CCmdAccelOb* pSavedCmdAccel;

	CAccelsOb* pAccel;
	CAccelsOb* pSavedAccel;

	WORD wKey;
	POSITION pos = m_mapAccelTableSaved.GetStartPosition();
	// If there is NO USERS ACCELS at the beginning, we will erase all
	// of the users accels.

	if (pos == NULL) {
		pos = m_mapAccelTable.GetStartPosition();

		while (pos != NULL) {
			m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
			pCmdAccel->DeleteUserAccels();
		}
	} else {
		// Other case, there is some users accels defined by the programmer
		while (pos != NULL) {
			m_mapAccelTableSaved.GetNextAssoc(pos, wKey, pSavedCmdAccel);
			m_mapAccelTable.Lookup(wKey, pCmdAccel);

			pCmdAccel->DeleteUserAccels();
			POSITION pos = pSavedCmdAccel->m_Accels.GetHeadPosition();

			while (pos != NULL) {
				pSavedAccel = pSavedCmdAccel->m_Accels.GetNext(pos);
				pAccel = new CAccelsOb(pSavedAccel);
				ASSERT(pAccel != NULL);
				pCmdAccel->m_Accels.AddTail(pAccel);
			}
		}
	}

	return true;
}



