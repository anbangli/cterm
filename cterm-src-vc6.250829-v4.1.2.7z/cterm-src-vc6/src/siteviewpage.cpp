// SiteViewPage.cpp : implementation file
//

#include "stdafx.h"
#include "SiteViewPage.h"
#include "const.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteViewPage property page

IMPLEMENT_DYNCREATE(CSiteViewPage, CMyPropertyPage)

CSiteViewPage::CSiteViewPage() : CMyPropertyPage(CSiteViewPage::IDD)
{
	//{{AFX_DATA_INIT(CSiteViewPage)
	//m_nCharHWRatio = 2;
	
	
	m_sFont = _T("");
	m_bBold = FALSE;
	m_bNotMono = FALSE;
	m_sEFont = _T("");
	m_bFixFont = FALSE;
	//m_nFontSize = 16;
	m_nFixedSize = 16;
	m_bClearSigna= FALSE;
	m_bBlackList = FALSE;
	m_sBlackList = _T("");
	//}}AFX_DATA_INIT
}

CSiteViewPage::~CSiteViewPage()
{
}

void CSiteViewPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteViewPage)
	DDX_Check(pDX, IDC_CHECK_FIXFONT, m_bFixFont);
//	DDX_Text(pDX, IDC_EDIT_HWRATIO, m_nCharHWRatio);
	DDX_Check(pDX, IDC_CHECK_MONO, m_bNotMono);
	DDX_Check(pDX, IDC_CHECK_BOLD, m_bBold);
	DDX_Text(pDX, IDC_EDIT_EFONT, m_sEFont);
	DDX_Text(pDX, IDC_EDIT_FIXEDSIZE, m_nFixedSize);
	DDX_Text(pDX, IDC_EDIT_FONT, m_sFont);
	DDX_Check(pDX, IDC_CHECK_CLEARSIGNA, m_bClearSigna);
	DDX_Check(pDX, IDC_CHECK_BLACKLIST, m_bBlackList);
	DDX_Text(pDX, IDC_EDIT_BLACKLIST, m_sBlackList);
	DDV_MaxChars(pDX, m_sBlackList, 128);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteViewPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteViewPage)
//	ON_BN_CLICKED(IDC_SONG, OnSong)
//	ON_BN_CLICKED(IDC_HEI, OnHei)
//	ON_BN_CLICKED(IDC_KAI, OnKai)
//	ON_BN_CLICKED(IDC_WINFONT, OnWinfont)
	ON_BN_CLICKED(IDC_SELFONT, OnSelFont)
	ON_BN_CLICKED(IDC_SELFONT2, OnSelFont2)
//	ON_BN_CLICKED(IDC_FIXED, OnFixedsys)
//	ON_EN_KILLFOCUS(IDC_FONTNAME, OnKillfocusFontname)
	ON_BN_CLICKED(IDC_CHECK_MONO, OnCheckMono)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteViewPage message handlers

//CString g_sCustomFontName = _T("SimSun");    //�����ϴε�ѡ��

BOOL CSiteViewPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



	CButton *pBut = NULL;
	m_bChange = TRUE;

//	Font[0].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,m_szFont);		//վ��ṹ�ж��������
//	Font[1].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("SimSun"));
//	Font[2].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("SimHei"));
//	Font[3].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("Kaiti"));  //_T("Kaiti_GB2312");
	//	pOldFont=pDC->SelectObject(&Font[0]);	// ԭ������


//	m_sFont = g_sCustomFontName;
//	m_nFontSize=16;
//	m_bFixFont=FALSE;

	//GetDlgItem(IDC_SELFONT)->EnableWindow(0);
/*
	if (!m_font.CompareNoCase(_T("SimSun")))			// ���ʹ����SimSun
		pBut = (CButton *) GetDlgItem(IDC_SONG);
	else if (!m_font.CompareNoCase(_T("SimHei")))			// ���ʹ����SimHei
		pBut = (CButton *) GetDlgItem(IDC_HEI);
	else if (!m_font.CompareNoCase(_T("Kaiti")))			// ���ʹ����Kaiti_GB2312  //Kaiti_GB2312
		pBut = (CButton *) GetDlgItem(IDC_KAI);
	else if (!m_font.CompareNoCase(_T("Fixedsys")))
		pBut = (CButton *) GetDlgItem(IDC_FIXED);
	else {		// ������������趨�ļ�������
		m_sFontName = m_font;
		//GetDlgItem(IDC_SELFONT)->EnableWindow(TRUE);
		pBut = (CButton *) GetDlgItem(IDC_WINFONT);
	}
	if (pBut) pBut->SetCheck(1);
*/
	UpdateData(FALSE);

	GetDlgItem(IDC_EDIT_EFONT)->EnableWindow(m_bNotMono);
	GetDlgItem(IDC_SELFONT2)->EnableWindow(m_bNotMono);

	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_SELFONT), IDS_TIP_FONTDLG_1);
	}

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

/*
void CSiteViewPage::OnSong()
{
	m_sFont = _T("SimSun");
	//GetDlgItem(IDC_SELFONT)->EnableWindow(FALSE);
}

void CSiteViewPage::OnHei()
{
	m_sFont = _T("SimHei");
	//GetDlgItem(IDC_SELFONT)->EnableWindow(FALSE);
}

void CSiteViewPage::OnKai()
{
	m_sFont = _T("Kaiti");	//_T("Kaiti_GB2312");
	//GetDlgItem(IDC_SELFONT)->EnableWindow(FALSE);
}

void CSiteViewPage::OnFixedsys()
{
	m_sFont = _T("Fixedsys");
	//GetDlgItem(IDC_SELFONT)->EnableWindow(FALSE);
}
*/

/*
void CSiteViewPage::OnWinfont()
{
//	TCHAR ts[100];
	//GetDlgItem(IDC_SELFONT)->EnableWindow(1);
	//GetDlgItem(IDC_SELFONT)->GetWindowText(ts,100);

	if (m_sFontName.IsEmpty()) {
		m_sFontName = _T("SimSun");
		UpdateData(FALSE);
		//m_font=_T("SimSun");
		//GetDlgItem(IDC_SELFONT)->SetWindowText(m_szFont);
	}

	m_font = m_sFontName;
}
*/

void CSiteViewPage::OnSelFont()
{
	CFont Font;
	LOGFONT fontset;
	Font.CreatePointFont(120, m_sFont);

	if (!Font.GetLogFont(&fontset)) return;

	CFontDialog Dlg(&fontset, CF_EFFECTS | CF_SCREENFONTS | CF_NOVERTFONTS);    //|CF_TTONLY|CF_SCALABLEONLY

	if (Dlg.DoModal() == IDOK) {
		CString s = Dlg.GetFaceName();
		//BOOL isBold = fontDialog.IsBold();	//�Ƿ����
		if (s.GetLength() > MAXFONTNAME) {
			CString msg;
			msg.Format(_T("��ѡ�������������� %d ���ַ�������"), MAXFONTNAME);
			AfxMessageBox(msg);
		}
		else {
			//m_nFontSize = Dlg.GetSize() / 10; //Return Value: The font��s size, in tenths of a point.
			//m_sFontName = s;
			//m_font = m_sFontName;
			m_sFont = s;

			//CButton *pBut = (CButton *) GetDlgItem(IDC_WINFONT);
			//if (pBut) pBut->SetCheck(1);

			UpdateData(FALSE);
		}
		//GetDlgItem(IDC_SELFONT)->SetWindowText(m_szFont);
	}
}

void CSiteViewPage::OnSelFont2()
{
	CFont Font;
	LOGFONT fontset;
	Font.CreatePointFont(120, m_sFont);

	if (!Font.GetLogFont(&fontset)) return;

	CFontDialog Dlg(&fontset, CF_EFFECTS | CF_SCREENFONTS | CF_NOVERTFONTS);    //|CF_TTONLY|CF_SCALABLEONLY

	if (Dlg.DoModal() == IDOK) {
		CString s = Dlg.GetFaceName();
		if (s.GetLength() > MAXFONTNAME) {
			CString msg;
			msg.Format(_T("��ѡ�������������� %d ���ַ�������"), MAXFONTNAME);
			AfxMessageBox(msg);
		}
		else {
			m_sEFont = s;  //
			UpdateData(FALSE);
		}
		//GetDlgItem(IDC_SELFONT2)->SetWindowText(m_szFont);
	}
}

BOOL CSiteViewPage::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}

	return CMyPropertyPage::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

/*
void CSiteViewPage::OnKillfocusFontname()
{
	UpdateData(TRUE);
	m_font = m_sFontName;
}
*/

UINT CSiteViewPage::GetIDD()
{
	return IDD;
}

void CSiteViewPage::OnCheckMono() 
{
	UpdateData();
	GetDlgItem(IDC_EDIT_EFONT)->EnableWindow(m_bNotMono);	//���������Ƿ������
	GetDlgItem(IDC_SELFONT2)->EnableWindow(m_bNotMono);	//���������Ƿ������
}
