#if !defined(AFX_CToolBarEx_H__CA197756_5110_46C1_AEF9_DE5BE94336A7__INCLUDED_)
#define AFX_CToolBarEx_H__CA197756_5110_46C1_AEF9_DE5BE94336A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CToolBarEx.h : header file
//
#include "OleDropTargetEx.h"
/////////////////////////////////////////////////////////////////////////////
// CToolBarEx window
#if ENABLE_SEARCHBOX

class CToolBarEx : public CToolBar
{
// Construction

public:
	CToolBarEx();

// Attributes

public:
	CComboBox m_wndUrl;

// Operations

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolBarEx)
	//}}AFX_VIRTUAL

// Implementation

public:
	void ShowCombo();
	void SaveString();
	BOOL Init();
	BOOL CreateCombo();
	virtual ~CToolBarEx();

	// Generated message map functions

protected:
	//{{AFX_MSG(CToolBarEx)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPressEnter();
	afx_msg void OnCancel();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

protected:
	COleDropTargetEx m_dropEx;
	virtual LRESULT OnDragOver(WPARAM pDropInfoClass, LPARAM lParm);
	virtual LRESULT OnDropEx(WPARAM pDropInfoClass, LPARAM lParm);
	virtual LRESULT OnDrop(WPARAM pDropInfoClass, LPARAM lParm);

private:
	CFont m_pFont;
};

#endif//ENABLE_SEARCHBOX
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CToolBarEx_H__CA197756_5110_46C1_AEF9_DE5BE94336A7__INCLUDED_)
