#if !defined(AFX_SITELOGINPAGE_H__7D5FA484_03CF_4AF2_86DF_9630065DCD6E__INCLUDED_)
#define AFX_SITELOGINPAGE_H__7D5FA484_03CF_4AF2_86DF_9630065DCD6E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteLoginPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteLoginPage dialog

struct SLoginSet;

class CSiteLoginPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteLoginPage)

// Construction

public:
	SLoginSet  * m_pLogin;
	CSiteLoginPage();
	~CSiteLoginPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(CSiteLoginPage)
	enum { IDD = IDD_SITE_LOGIN };
	CString	m_sitename;
	UINT	m_siteport;
	CString	m_siteaddr;
	int		m_nTermHeight;
	int		m_nTermWidth;
	CString	m_sTermType;
	BOOL	m_bIPv6;
	int		m_sitetype;
	int		m_nProtocol;
	CString	m_sWebURL;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteLoginPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CSiteLoginPage)
	afx_msg void OnTypeA();
	afx_msg void OnTypeB();
	afx_msg void OnTypeC();
	afx_msg void OnTypeD();
	afx_msg void OnTypeE();
	afx_msg void OnTypeF();
	afx_msg void OnDoublecodeYes();
	afx_msg void OnDoublecodeNo();
	afx_msg void OnChkSSH();
	virtual BOOL OnInitDialog();
	afx_msg void OnKillfocusSiteaddr();
	afx_msg void OnBrowseSite();
	afx_msg void OnProtossh();
	afx_msg void OnPrototelnet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITELOGINPAGE_H__7D5FA484_03CF_4AF2_86DF_9630065DCD6E__INCLUDED_)
