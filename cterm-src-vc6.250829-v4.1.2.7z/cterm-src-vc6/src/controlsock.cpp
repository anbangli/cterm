// ControlSock.cpp : implementation file
//

#include "stdafx.h"
#include "ControlSock.h"
#include "mainfrm.h"
#include "paramconfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//bool WriteMyProfileInt(CString filename, CString VarName, int value);
//int GetMyProfileInt(CString filename, CString VarName, const int defvalue);

/////////////////////////////////////////////////////////////////////////////
// CControlSock
CControlSock ControlSock;
CControlSock::CControlSock()
{
	m_nPort = 0;
}

CControlSock::~CControlSock()
{
//	int n=GetMyProfileInt(_T("CTermMulti.ini")), _T("InstanceNum"), 0);
//	ASSERT( n>0 );
//	if(n>0)
//		WriteMyProfileInt(_T("CTermMulti.ini"),_T("InstanceNum"), --n);
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CControlSock, CAsyncSocket)
	//{{AFX_MSG_MAP(CControlSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CControlSock member functions

void CControlSock::OnReceive(int nErrorCode)
{
	TCHAR buf[3000];
	CString sAddr;
	UINT nPort;
	int nLen = ReceiveFrom(buf, 3000, sAddr, nPort);

	if (nLen != 0 && nLen != SOCKET_ERROR) {
#ifdef _DEBUG
		/*   FILE *fp;
		  fp=_tfopen(_T("contrlsock.log"),_T("a"));
		   if(fp)
		   {
			   TCHAR info[100];
			   _stprintf(info, _T("\n the addr is: %s, the port is: %d\n %d bytes recved. data is:"), sAddr, nPort, nLen);
			   fwrite((TCHAR*)info, _tcslen(info), 1, fp);
			   fwrite((TCHAR*)buf, nLen, 1, fp);
			   fwrite(_T("\n\n\n"),3,1,fp);
			   fclose(fp);
		   }*/
#endif
//		switch(buf[0])
//		{
//		case CS_COMMAND:
		ProcessCommand(buf, nLen);
//			break;
//		}
	}

	CAsyncSocket::OnReceive(nErrorCode);
}

extern int g_nInstanceNumber;
//extern UINT g_minControlPort;
//extern UINT g_maxControlPort;
bool CControlSock::Init(BOOL bAllowMulti)
{
	if (g_nInstanceNumber >= 1 && !bAllowMulti) {
		Create(0, SOCK_DGRAM);

		BroadCast(CS_RESTOREWINDOW);
		//Sleep(100); //ΪʲôҪsleep����ȥ��
		return false; //PostQuitMessage(-1);
	}

	int i;

	for (i = g_nControlPort; i < g_nControlPort + MAX_ALLOW_INSTANCE; i++) {
		if (Create(i, SOCK_DGRAM))
			break;
		else {
			DWORD err = GetLastError();

			if (err != WSAEADDRINUSE) {
				if (g_nInstanceNumber == 0) {   //ֻ�ڵ�1��ʵ���������
					ASSERT(err == WSAENETDOWN);    //�ܴ�������������ô�����ͬ����û��õȵ�
					CString s;
					s.Format(_T("�����ʼ��ʧ��! ���ܻ�����ĳЩ����ʧЧ�������룺%d"), err);
					AfxMessageBox(s);
				}

				break;//���������˳�
			}

			//WSAEADDRINUSE, continue
			//g_nInstanceNumber!=0 cotinue
		}

#ifdef _DEBUG
		//		if(err) //err == WSAEADDRINUSE
		//		{
		//			CString s;
		//			s.Format(_T("in controlsock init, err: %d"), err);
		//			AfxMessageBox(s);
		//		}
#endif
	}

	if (g_nInstanceNumber >= MAX_ALLOW_INSTANCE && i >= g_nControlPort + MAX_ALLOW_INSTANCE) {
		AfxMessageBox(_T("�������Ѿ�������20��ʵ��?!"));
		return false; //PostQuitMessage(-2);
	}

	m_nPort = i;

//	if(m_nPort<g_minControlPort)
//		g_minControlPort=m_nPort;
//	if(m_nPort>g_maxControlPort)
//		g_maxControlPort=m_nPort;
	return true;
}

void CControlSock::ProcessCommand(TCHAR *buf, int nLen)
{
	if (nLen >= sizeof(int) && g_pMainWnd) {
		int nMessage = * ((int *) buf);    //ǰ4�ֽ���Ϊ��Ϣ��

		switch (nMessage) {

		case CS_HOTKEY:

		case CS_RESTOREWINDOW:

			if (g_pMainWnd->m_bBossHided) {
#if ENABLE_HOTKEY
				g_pMainWnd->OnBossKey();
#endif //ENABLE_HOTKEY
			}
			else {
				g_pMainWnd->PopupSelf(true);    //true: ģ������������򴰿ڵ����޽���
			}

			break;

#if ENABLE_HOTKEY

		case CS_BOSSKEY:
			g_pMainWnd->OnBossKey();

			break;

		case CS_REREG_BOSSKEY:
			g_pMainWnd->ReRegisterBossHotKey();

			break;

		case CS_CHANGE_BOSSKEY:
			g_pMainWnd->ReRegisterBossHotKey(true);

#endif //ENABLE_HOTKEY

			break;
		}
	}
}

// ������ʵ���㲥��Ϣ
void CControlSock::BroadCast(int nMessage, bool bToSelf)
{
	// ΪʲôҪ�㲥�أ���Ϊ��֪���ĸ��˿�����ʵ���ڼ���
	TCHAR buf[sizeof(int)] = _T("");
	memcpy(buf, (TCHAR*)(&nMessage), sizeof(int));            //��Ϊ�����������ϣ����Բ���Ҫ�����ֽ��������

	for (int nPort = g_nControlPort; nPort < g_nControlPort + MAX_ALLOW_INSTANCE; nPort++) {
		if (nPort != m_nPort || bToSelf)
			SendTo(buf, sizeof(int) , nPort, _T("127.0.0.1"));
	}

	//SendTo(CS_RESTOREWINDOW, _tcslen(CS_RESTOREWINDOW) , i, _T("127.0.0.1"));
}