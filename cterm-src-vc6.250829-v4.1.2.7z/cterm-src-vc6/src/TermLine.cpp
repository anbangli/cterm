// TermLine.cpp: implementation of the CTermLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "screen.h"
#include "onechar.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#ifdef _DEBUG
int CScreen::CTermLine::total_line_id = 0;
#endif //_DEBUG

CScreen::CTermLine::CTermLine()
{
	NewLine(MAX_LINE_CHAR);
}

#if ENABLE_SCREENMAP
void CScreen::CTermLine::dumpLine(FILE * fp) const
{
	fwrite(m_buf, sizeof(SOneChar), m_nLineLen, fp);
#ifdef _DEBUG
	fflush(fp);
#endif//_DEBUG
}

void CScreen::CTermLine::load(FILE * fp)
{
	fread(m_buf, sizeof(SOneChar), m_nLineLen, fp);
}
#endif//ENABLE_SCREENMAP

CScreen::CTermLine::CTermLine(CString s)
{
	NewLine(MAX_LINE_CHAR);
	int len = s.GetLength();

	if (len >= MAX_LINE_CHAR) len = MAX_LINE_CHAR;

	for (int i = 0; i < len; ++i) {
		m_buf[i].SetChar(s[i]);
	}
}

inline void CScreen::CTermLine::NewLine(int len)
{
	m_nLineLen = len;
	m_buf = new SOneChar[MAX_LINE_CHAR]; // todo: Ӧ��Ϊm_nLineLen�������ǵ��޸���������Ĺ�����������

	//int n=sizeof(SOneChar);//5, 256*5=1280
	//n=sizeof(CTermLine);//20=1+4+4+4+?

	m_bChanged = true;
	// ��δ�� m_nLineNum = -1;

#ifdef _DEBUG
	new_id = CScreen::CTermLine::total_line_id++;
	//TRACE("newed termline #%03d\n", new_id);
	memset(m_buf, 0, sizeof(SOneChar) * m_nLineLen);
#endif //_DEBUG
}

CScreen::CTermLine::~CTermLine()
{
	if (m_buf) {
		delete [] m_buf;
		m_buf = NULL;

#ifdef _DEBUG
//	TRACE("termline #%03d deleted\n", new_id);
#endif //_DEBUG
	}
}

// endxΪҪ������һ���ַ��±��1
void CScreen::CTermLine::ClearLine(int startx, int endx)
{
	if (endx == -1) endx = m_nLineLen;

	for (int i = startx; i < endx; i++) {
		m_buf[i].Reset();
	}
}

#ifdef _DEBUG
void CScreen::CTermLine::getStr(char *buf) const
{
	int i;
	for (i = 0; i < m_nLineLen; ++i) {
		buf[i]  = m_buf[i].GetChar();
	}

	buf[i] = '\0';
}

#endif //_DEBUG
