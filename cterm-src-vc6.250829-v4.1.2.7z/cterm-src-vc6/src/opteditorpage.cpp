// OptEditorPage.cpp : implementation file
//

#include "stdafx.h"
#include "MyPropertyPage.h"
#include "OptEditorPage.h"
#include "paramconfig.h"

extern CString g_szLanguagePath;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptEditorPage property page

IMPLEMENT_DYNCREATE(COptEditorPage, CMyPropertyPage)

COptEditorPage::COptEditorPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptEditorPage)
	m_bAutoWarp = FALSE;
	m_nWidth = 0;
	m_bAutoPara = FALSE;
	m_bPlusSpace = FALSE;
	m_bAlwaysAsk = FALSE;
	m_bEditDlg = FALSE;
	m_bCtrlCCopy = FALSE;
	m_bCtrlVPaste = FALSE;
	m_fontsize = 0;
	//}}AFX_DATA_INIT
}

COptEditorPage::~COptEditorPage()
{
}

void COptEditorPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptEditorPage)
	DDX_Check(pDX, IDC_AUTOWARP, m_bAutoWarp);
	DDX_Text(pDX, IDC_WIDTH, m_nWidth);
	DDV_MinMaxInt(pDX, m_nWidth, 10, 255);
	DDX_Check(pDX, IDC_AUTOPARA, m_bAutoPara);
	DDX_Check(pDX, IDC_PLUSSPACE, m_bPlusSpace);
	DDX_Check(pDX, IDC_ALWAYSASK, m_bAlwaysAsk);
	DDX_Check(pDX, IDC_EDITDLG, m_bEditDlg);
	DDX_Check(pDX, IDC_CTRLCCOPY, m_bCtrlCCopy);
	DDX_Check(pDX, IDC_CTRLVPASTE, m_bCtrlVPaste);
	DDX_Text(pDX, IDC_FONTSIZE, m_fontsize);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptEditorPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptEditorPage)
	ON_BN_CLICKED(IDC_AUTOWARP, OnAutowarp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptEditorPage message handlers

void COptEditorPage::OnAutowarp()
{
	UpdateData();
	GetDlgItem(IDC_WIDTH)->EnableWindow(m_bAutoWarp);
	GetDlgItem(IDC_AUTOPARA)->EnableWindow(m_bAutoWarp);
	GetDlgItem(IDC_PLUSSPACE)->EnableWindow(m_bAutoWarp);
}

BOOL COptEditorPage::OnInitDialog()
{
	Init();

	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	OnAutowarp();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

UINT COptEditorPage::GetIDD()
{
	return IDD;
}

void COptEditorPage::OnOK() 
{
	UnInit();
	
	CMyPropertyPage::OnOK();
}

void COptEditorPage::Init()
{
#if ENABLE_EDITBOX
	m_bEditDlg = g_bPopEditDlg;
#endif//ENABLE_EDITBOX
	m_bCtrlCCopy = g_bCtrlCCopy;
	m_bCtrlVPaste = g_bCtrlVPaste;
	m_bAutoWarp = g_bAutoWarp;
	m_nWidth = g_nWarpNumber;		// 72
	m_bAutoPara = g_bWarpAutoPara;
	m_bPlusSpace = g_bWarpPlusSpace;
	m_bAlwaysAsk = g_bWarpAlwaysAsk;
	m_fontsize = g_nEditFontSize;
}

void COptEditorPage::UnInit()
{
	if (!UpdateData())
		return;

#if ENABLE_EDITBOX
	g_bPopEditDlg = m_bEditDlg;
#endif//ENABLE_EDITBOX
	g_bCtrlCCopy = m_bCtrlCCopy;
	g_bCtrlVPaste = m_bCtrlVPaste;
	g_bAutoWarp	= m_bAutoWarp;
	g_nWarpNumber = m_nWidth;
	g_bWarpAutoPara = m_bAutoPara;
	g_bWarpPlusSpace = m_bPlusSpace;
	g_bWarpAlwaysAsk = m_bAlwaysAsk;
	g_nEditFontSize = m_fontsize;
}
