// QueryIPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "QueryIPDlg.h"
#include "ReadQQWry.h"
#include "global.h"
#include "paramconfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQueryIPDlg dialog
#if ENABLE_SHOWIP

CQueryIPDlg::CQueryIPDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CQueryIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQueryIPDlg)
	m_strIP = _T("");
	m_strAddr = _T("");
	//}}AFX_DATA_INIT
}


void CQueryIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQueryIPDlg)
	DDX_Text(pDX, IDC_IP, m_strIP);
	DDV_MaxChars(pDX, m_strIP, 100);
	DDX_Text(pDX, IDC_ADDR, m_strAddr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQueryIPDlg, CDialog)
	//{{AFX_MSG_MAP(CQueryIPDlg)
	ON_BN_CLICKED(IDC_QUERY, OnQuery)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQueryIPDlg message handlers
void CQueryIPDlg::OnQuery()
{
//	ASSERT(!g_szWorkDir.IsEmpty());
	UpdateData(TRUE);
//	CString strModulePath(g_szWorkDir);
//	g_sIPWryPath += _T("qqwry.dat");
	CReadQQWry wry(g_sIPWryPath);
	m_strAddr = wry.QueryIP(m_strIP);
	UpdateData(FALSE);
}

BOOL CQueryIPDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



	//�Ӽ���������ȡ����
	::OpenClipboard(NULL);
	HANDLE hData = GetClipboardData(CF_TEXT);

	if (hData != NULL) {
		LPSTR lptstr = (LPSTR) GlobalLock(hData);

		if (lptstr != NULL) {
			m_strIP = lptstr;

			if (g_bFilterQueryIP) {
				int len = m_strIP.GetLength();

				int i = 0;

				for (; i < len && !('0' <= m_strIP[i] && m_strIP[i] <= '9'); ++i);

				m_strIP = m_strIP.Right(len - i);

				if (m_strIP.GetLength() > 100)
					m_strIP = m_strIP.Left(100);

				TCHAR cIP[17];

				int count = IsIP(m_strIP.LockBuffer(), cIP);

				m_strIP.UnlockBuffer();

				if (count == 4 || count == -2) {
					m_strIP = cIP;
				} else
					m_strIP.Empty();
			}

			GlobalUnlock(hData);
		}
	}

	::CloseClipboard();

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

#endif//ENABLE_SHOWIP