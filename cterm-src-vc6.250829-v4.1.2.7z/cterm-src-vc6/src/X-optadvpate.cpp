// OptAdvPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptAdvPage.h"
#include "usermsg.h"
#include "paramconfig.h"
#include "const.h"
#include "global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

struct SCaretStyle
{
	int h;
	int w;
	bool center;
}CaretStyles[] = {
	{2, -5, false},
	{-10, 1, true},
	{1, -5, false},
	{-8, -5, true}
};

const int g_nCaretStyleSize = sizeof(CaretStyles) / sizeof(SCaretStyle);

//inline void Index2CaretStyle(int idx, SCaretStyle &cs)
//{
//	if (0 <= idx && idx < g_nCaretStyleSize) {
//		cs = CaretStyles[idx];
//	}
//}

inline int CaretStyle2Index(const SCaretStyle &cs)
{
	int r = 4;
	for (int i = 0; i < g_nCaretStyleSize; ++i) {
		if (cs.h == CaretStyles[i].h
			&& cs.w == CaretStyles[i].w
			&& cs.center == CaretStyles[i].center) {
			r = i;
			break;
		}
	}

	return r;
}

/////////////////////////////////////////////////////////////////////////////
// COptAdvPage property page

IMPLEMENT_DYNCREATE(COptAdvPage, CMyPropertyPage)

//���� nullspace �� 2004 �����ұ�д�����ݣ���������˴�������ѡ�������
// 2025 �����á�

COptAdvPage::COptAdvPage()
	: CMyPropertyPage(COptAdvPage::IDD), 
	m_ctrlTreeOptions(), 
	m_bInitializedTreeOpts(false),
	m_bRepeatUserName(true),
	m_bURLNoMouse(false),
	m_bHideMouse(true),
	m_bSiteStatus(true),
	m_bCaptureMouse(true),
	m_bChildDefaultMax(true),
	m_bRefreshTitle(true),
	m_bAutoSize(false),
	m_bCacheHistory(true),
	//m_bIsAutoReply(true),
	m_bNoAskClose(false),
	m_bPythonLog(false),
	m_bAnsiLog(false),
	m_bReportSimple(false),
	m_bEnableVBS(true),
	m_bAltShowMenu(false),
	m_bCaptionButtons(true),
	m_bClickUser(true),
	m_nKeybarWidth(45),
	m_nKeybarHeight(24),
	m_nFixedSysSize(16),
	m_nCharScale(10),
	m_nRowSpace(0),
	//m_TA_CENTER(false),
	m_bMONOSPACE(true),
	m_bFixFont(false),
	m_nFixFontSize(16),
	//m_nBoldWeight(7),
	m_bSelectStay(false),
	m_bSelBackHi(false),
	m_bSelAntiHalf(true),
	m_bEnableM(true),
	m_bFullScreenBar(false),
	m_bCursorPos(true),
	//m_bTransparent(false),
	//m_nAlpha(255),
	//m_bCtrlVPaste(true),
	//m_bCopyUni(false),
	//m_bPasteUni(false),
	m_bCopyNoReturn(false),
	m_nWrapLen(0),
	m_bCopyRectNoReturn(false),
	m_bAutoSaveEdit(true),
	m_bEditIME(false),
//	m_nEditFontSize(0),
//	m_nCloseIME(0),
	m_bIMEChar(false),
	m_gbCharSet(3),
	m_big5CharSet(4),
	m_bPasteConfirm(true),
	m_bFilterQueryIP(true),
	//m_bAutoFromIP(false),
	m_bBakAutoIP(true),
	//m_nPicHoverTime(500),
	m_nPicLoadTimeOut(3000),
	m_bPicDrag(true),
	m_bLoadPicThread(false),
	m_sPicDlgColor(_T("0")),
	m_bGetPicInfo(true),
	m_bDelPicAsk(true),
	m_nPicTimeOut(5),
	m_bPicTip(true),
	m_bPicNoBorder(false),
	m_bPicHide(true),
	m_bAutoRetryPic(true),
	m_bPythonOpenFile(false),
	m_sPlink(_T("plink")),
	m_sLoginFlag(_T("�ϴ�����ʱ��")),
	m_sLoginFlag1(_T("Last login:")),
	m_bUrlWithConfirm(false),
	m_bURLStrip(true),
	m_bViewDrag(true),
	m_bAutoURLHeader(true),
	m_nBlinkTimeOut(600),
	m_nCaretStyle(0),
	m_nCARET_H(2),
	m_nCARET_W(-5),
	m_bCaretCenter(true),
	m_bCaretBlink(false),
	m_bUploadAttAuto(true),
	m_sKeyTableFile(_T("user\\mycmds.txt")),
	m_sScriptDir(_T("script")),
	m_sMailWavFile(_T("CONTACT2.WAV")),
	m_bAllowSameSiteName(false),
	m_bAddrFullName(true),
//	m_sArticleSaveExt(_T("txt")),
	//m_iAskDlg(4),
	//m_nDownTimeout(100),
	m_bCtdDraw(false),
//	m_bDrawByString(false),
	m_nRecvBufLen(DEFAULT_RECV_BUF_LEN),
	//m_nBossKeyStyle(0),
	m_nControlPort(ORIGIN_CONTROL_PORT),
	m_bNoFocusNoCursor(true),
//	m_bDownloadWithHTML(false),
	m_bRegBBSProto(false),
	m_nTimer(1),////////////////////////

	m_htiFontGrp(NULL),
	m_htiPicGrp(NULL),
	m_htiCaretGrp(NULL),
	m_htiTxtGrp(NULL),
	m_htiViewGrp(NULL),
	m_hTermGrp(NULL),

	m_htiRepeatUserName(NULL),
	m_htiURLNoMouse(NULL),
	m_htiHideMouse(NULL),
	m_htiSiteStatus(NULL),
	m_htiCaptureMouse(NULL),
	m_htiChildDefaultMax(NULL),
	m_htiRefreshTitle(NULL),
	m_htiAutoSize(NULL),
	m_htiIsAutoReply(NULL),
	m_htiNoAskClose(NULL),
	m_htiPythonLog(NULL),
	m_htiAnsiLog(NULL),
	m_htiReportSimple(NULL),
	m_htiEnableVBS(NULL),
	m_htiAltShowMenu(NULL),
	m_htiCaptionButtons(NULL),
	m_htiClickUser(NULL),
	m_htiKeybarWidth(NULL),
	m_htiKeybarHeight(NULL),
	m_htiFixedSysSize(NULL),
	m_htiCharScale(NULL),
	m_htiRowSpace(NULL),
	m_htiTA_CENTER(NULL),
	m_htiEFont(NULL),
	m_htiFont(NULL),
	m_htiMONOSPACE(NULL),
	m_htiFixFont(NULL),
	m_htiFixFontSize(NULL),
	//m_htiBoldWeight(NULL),
	m_htiSelectStay(NULL),
	m_htiSelBackHi(NULL),
	m_htiSelAntiHalf(NULL),
	m_htiEnableM(NULL),
	m_htiFullScreenBar(NULL),
	m_htiCursorPos(NULL),
	//m_htiTransparent(NULL),
	//m_htiAlpha(NULL),
	m_htiCtrlVPaste(NULL),
	//m_htiCopyUni(NULL),
	//m_htiPasteUni(NULL),
	m_htiCopyNoReturn(NULL),
	m_htiWrapLen(NULL),
	m_htiCopyRectNoReturn(NULL),
	m_htiAutoSaveEdit(NULL),
	m_htiEditIME(NULL),
//	m_htiCloseIME(NULL),
	m_htiIMEChar(NULL),
	m_htigbCharSet(NULL),
	m_htibig5CharSet(NULL),
	m_htiPasteConfirm(NULL),
	m_htiFilterQueryIP(NULL),
	m_htiAutoFromIP(NULL),
	m_htiBakAutoIP(NULL),
	m_htiPicHoverTime(NULL),
	m_htiPicLoadTimeOut(NULL),
	m_htiPicDrag(NULL),
	m_htiLoadPicThread(NULL),
	m_htiPicDlgColor(NULL),
	m_htiPicPath(NULL),
	m_htiGetPicInfo(NULL),
	m_htiDelPicAsk(NULL),
	m_htiPicTimeOut(NULL),
	m_htiPicTip(NULL),
	m_htiPicNoBorder(NULL),
	m_htiPicHide(NULL),
	m_htiAutoRetryPic(NULL),
	m_htiUrlProg(NULL),
	m_htiFtpProg(NULL),
	m_htiDownProg(NULL),
	m_htiPythonOpenFile(NULL),
	m_htiPlink(NULL),
	m_htiLoginFlag(NULL),
	m_htiLoginFlag1(NULL),
	m_htiUrlWithConfirm(NULL),
	m_htiURLStrip(NULL),
	m_htiViewDrag(NULL),
	m_htiAutoURLHeader(NULL),
	m_htiBlinkTimeOut(NULL),
	m_htiCaretStyle(NULL),
	m_htiCARET_H(NULL),
	m_htiCARET_W(NULL),
	m_htiCaretCenter(NULL),
	m_htiCaretBlink(NULL),
	m_htiHttpUploadDlg(NULL),
	m_htiKeyTableFile(NULL),
	m_htiScriptDir(NULL),
	//m_htiMailWavFile(NULL),
	m_htiAllowSameSiteName(NULL),
	m_htiAddrFullName(NULL),
	//m_htiArticleSaveExt(NULL),
	//m_htiAskDlg(NULL),
	//m_htiDownTimeout(NULL),
	m_htiCtdDraw(NULL),
	m_htiDrawByString(NULL),
	m_htiRecvBufLen(NULL),
	//m_htiBossKeyStyle(NULL),
	m_htiControlPort(NULL),
	m_htiNoFocusNoCursor(NULL),
	//m_htiDownloadWithHTML(NULL),
	m_htiRegBBSProto(NULL),
	m_htiTimer(NULL),
	//m_htiHotKey(NULL),
	m_htiPicDlgInfo(NULL)
{
	//{{AFX_DATA_INIT(COptAdvPage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

COptAdvPage::~COptAdvPage()
{
}

void COptAdvPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptAdvPage)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_EXT_OPTS, m_ctrlTreeOptions);
	//}}AFX_DATA_MAP

	if (!m_bInitializedTreeOpts)
	{
		{
			int iImgGrp = 8;
			CImageList* piml = m_ctrlTreeOptions.GetImageList(TVSIL_NORMAL);
			if (piml){
				iImgGrp = piml->Add(AfxGetApp()->LoadIcon(IDI_FOLDER));
			}
			
			// groups
			//m_htiFontGrp = m_ctrlTreeOptions.InsertGroup(_T("ȫ����������"), iImgGrp, TVI_ROOT);
			m_htiViewGrp = m_ctrlTreeOptions.InsertGroup(_T("��ʾ/��������"), iImgGrp, TVI_ROOT);
			m_htiCaretGrp = m_ctrlTreeOptions.InsertGroup(_T("��꣨����㣩����"), iImgGrp, m_htiViewGrp);
			m_htiTxtGrp = m_ctrlTreeOptions.InsertGroup(_T("����/�༭/��������"), iImgGrp, TVI_ROOT);
			m_htiPicGrp = m_ctrlTreeOptions.InsertGroup(_T("ͼƬ����"), iImgGrp, TVI_ROOT);
			m_htiUrlGrp = m_ctrlTreeOptions.InsertGroup(_T("URL/IP�������"), iImgGrp, TVI_ROOT);
			m_hTermGrp = m_ctrlTreeOptions.InsertGroup(_T("�ն�/��������"), iImgGrp, TVI_ROOT);
			
			// terminal
			m_htiRepeatUserName = m_ctrlTreeOptions.InsertCheckBox(_T("�ظ������û�����YTHT�ڳ�������24��ʱ���γ��֡������û���������ʱ��Ӧ��η��ͣ�������������ʱ��Ҫ��η���"), m_hTermGrp, m_bRepeatUserName);
//			m_htiSiteStatus = m_ctrlTreeOptions.InsertCheckBox(_T("ʶ��վ��״̬"), m_hTermGrp, m_bSiteStatus);
//			m_htiClickUser = m_ctrlTreeOptions.InsertCheckBox(_T("��������鿴�û���"), m_hTermGrp, m_bClickUser);
			m_htiEnableM = m_ctrlTreeOptions.InsertCheckBox(_T("������ʱ��������������*[M��"), m_hTermGrp, m_bEnableM);
			m_htiReportSimple = m_ctrlTreeOptions.InsertCheckBox(_T("ʹ�ü�վ�㱨���ʽ"), m_hTermGrp, m_bReportSimple);
			m_htiRecvBufLen = m_ctrlTreeOptions.InsertItem(_T("������ջ�������С"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_hTermGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiRecvBufLen, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiPlink = m_ctrlTreeOptions.InsertItem(_T("plink.exe��λ��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_hTermGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiPlink, RUNTIME_CLASS(CTreeOptionsEditEx));
			m_htiLoginFlag = m_ctrlTreeOptions.InsertItem(_T("��¼�ɹ��ı�־����ֻ����ssh"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_hTermGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiLoginFlag, RUNTIME_CLASS(CTreeOptionsEditEx));
			m_htiLoginFlag1 = m_ctrlTreeOptions.InsertItem(_T("����*nix����ssh�ĵ�¼�ɹ���־"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_hTermGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiLoginFlag1, RUNTIME_CLASS(CTreeOptionsEditEx));

			// view/ui
			m_htiRefreshTitle = m_ctrlTreeOptions.InsertCheckBox(_T("��ʱˢ�±�����"), m_htiViewGrp, m_bRefreshTitle);
			m_htiChildDefaultMax = m_ctrlTreeOptions.InsertCheckBox(_T("���Ӵ����Զ����"), m_htiViewGrp, m_bChildDefaultMax);
			m_htiAutoSize = m_ctrlTreeOptions.InsertCheckBox(_T("�Զ��������ڴ�С���̶��ֺ�ʱ�����⣩"), m_htiViewGrp, m_bAutoSize);
			m_htiNoAskClose = m_ctrlTreeOptions.InsertCheckBox(_T("�ر�������ʱ����ʾ���������ж�ֱ�ӹر�"), m_htiViewGrp, m_bNoAskClose);
			m_htiKeybarWidth = m_ctrlTreeOptions.InsertItem(_T("�Զ��尴ť�����ȣ���λ�����أ�"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiViewGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiKeybarWidth, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiKeybarHeight = m_ctrlTreeOptions.InsertItem(_T("�߶ȣ���λ��������ť�߶ȣ�"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiViewGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiKeybarHeight, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiDrawByString = m_ctrlTreeOptions.InsertCheckBox(_T("��ʾ���ƹ���"), TVI_ROOT, m_bDrawByString);
			//m_htiFullScreenBar = m_ctrlTreeOptions.InsertCheckBox(_T("ȫ��ʱ��ʾ���߰�ť"), m_htiViewGrp, m_bFullScreenBar);
			//m_htiCursorPos = m_ctrlTreeOptions.InsertCheckBox(_T("��״̬����ʾ���ָ����ָ������"), m_htiViewGrp, m_bCursorPos);
			//m_htiTransparent = m_ctrlTreeOptions.InsertCheckBox(_T("����͸��Ч����XP����ϵͳ֧�֣�"), m_htiViewGrp, m_htiViewGrp);
			//m_htiAlpha = m_ctrlTreeOptions.InsertItem(_T("͸���ȣ�0-255����ֵԽ��Խ��͸����"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiViewGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiAlpha, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiAltShowMenu = m_ctrlTreeOptions.InsertCheckBox(_T("���ز˵���������ALT-F�ȼ���ʾ�˵�"), m_htiViewGrp, m_bAltShowMenu);
			//m_htiCaptionButtons = m_ctrlTreeOptions.InsertCheckBox(_T("���ز˵����ڱ�������ʾ���ư�ť"), m_htiViewGrp, m_bCaptionButtons);
			m_htiCtdDraw = m_ctrlTreeOptions.InsertCheckBox(_T("CTD�ļ���ʾ���ƹ���"), m_htiViewGrp, m_bCtdDraw);
			//m_htiNoFocusNoCursor = m_ctrlTreeOptions.InsertCheckBox(_T("�����޽���ʱ���ı���"), m_htiViewGrp, m_bNoFocusNoCursor);

			// caret
			m_htiCaretStyle = m_ctrlTreeOptions.InsertGroup(_T("�����"), iImgGrp, m_htiCaretGrp);
			m_htiCaretStyle0 = m_ctrlTreeOptions.InsertRadioButton(_T("��ƽС���飨CTermĬ�Ϸ��"), m_htiCaretStyle, m_nCaretStyle == 0);
			m_htiCaretStyle1 = m_ctrlTreeOptions.InsertRadioButton(_T("����"), m_htiCaretStyle, m_nCaretStyle == 1);
			m_htiCaretStyle2 = m_ctrlTreeOptions.InsertRadioButton(_T("�»���"), m_htiCaretStyle, m_nCaretStyle == 2);
			m_htiCaretStyle3 = m_ctrlTreeOptions.InsertRadioButton(_T("��ֱ�󷽿�(FTERM���)"), m_htiCaretStyle, m_nCaretStyle == 3);
			m_htiCaretStyle4 = m_ctrlTreeOptions.InsertRadioButton(_T("�Զ���"), m_htiCaretStyle, m_nCaretStyle == 4);
			
			m_htiCARET_H = m_ctrlTreeOptions.InsertItem(_T("���߶ȣ�����ʱ������Ϊ��λ��0=����ʾ,-10=���ָ߶ȣ�-9=���ָ߶�*9/10..."), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiCaretGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiCARET_H, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiCARET_W = m_ctrlTreeOptions.InsertItem(_T("�����ȣ�ȡֵ����ͬ�ϣ�Ĭ��-5=����ַ�����"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiCaretGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiCARET_W, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiCaretCenter = m_ctrlTreeOptions.InsertCheckBox(_T("��괹ֱ����"), m_htiCaretGrp, m_bCaretCenter);
			m_htiCaretBlink = m_ctrlTreeOptions.InsertCheckBox(_T("�����˸"), m_htiCaretGrp, m_bCaretBlink);
			m_htiBlinkTimeOut = m_ctrlTreeOptions.InsertItem(_T("��꼰�ַ���˸��ʱ��������λ�����룩"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiCaretGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiBlinkTimeOut, RUNTIME_CLASS(CNumTreeOptionsEdit));

			// font
			//m_htiFixedSysSize = m_ctrlTreeOptions.InsertItem(_T("Fixedsys����Ĵ�С����Ϊ20ʱ�������ּ�ࣩ"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiFixedSysSize, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiCharScale = m_ctrlTreeOptions.InsertItem(_T("�ַ����ű����������ּ���ã���ֵԽ���ֿ�Խ�󣬼��ԽС"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiCharScale, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiRowSpace= m_ctrlTreeOptions.InsertItem(_T("�м�࣬��λ���أ�0=Ĭ��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiRowSpace, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiTA_CENTER = m_ctrlTreeOptions.InsertCheckBox(_T("�ַ����ж��루ѡ�зǵȿ�����ѡ��ʱ��Ч��"), m_htiFontGrp, m_TA_CENTER);
			//m_htiFont = m_ctrlTreeOptions.InsertItem(_T("���壬��siteinfo.ini��δ���ã����øò���"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiFont, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiEFont = m_ctrlTreeOptions.InsertItem(_T("Ӣ�����壬վ��δ����ʱʹ�ã����߶�Ϊ����ͬ��������"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiEFont, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiMONOSPACE = m_ctrlTreeOptions.InsertCheckBox(_T("�ȿ����壨��Ҫ������һͬ���ã�"), m_htiFontGrp, m_bMONOSPACE);
			//m_htiFixFont = m_ctrlTreeOptions.InsertCheckBox(_T("�̶��ֺ�"), m_htiFontGrp, m_bFixFont);
			//m_htiFixFontSize = m_ctrlTreeOptions.InsertItem(_T("�̶��ֺŴ�С"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiFontGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiFixFontSize, RUNTIME_CLASS(CNumTreeOptionsEdit));

			//m_htiBoldWeight = m_ctrlTreeOptions.InsertGroup(_T("������ʾʱ��weight"), iImgGrp, m_htiFontGrp);
			//m_htiBoldWeight0 = m_ctrlTreeOptions.InsertRadioButton(_T("����ν"), m_htiBoldWeight, m_nBoldWeight == 0);
			//m_htiBoldWeight1 = m_ctrlTreeOptions.InsertRadioButton(_T("THIN"), m_htiBoldWeight, m_nBoldWeight == 1);
			//m_htiBoldWeight2 = m_ctrlTreeOptions.InsertRadioButton(_T("EXTRALIGHT"), m_htiBoldWeight, m_nBoldWeight == 2);
			//m_htiBoldWeight3 = m_ctrlTreeOptions.InsertRadioButton(_T("LIGHT"), m_htiBoldWeight, m_nBoldWeight == 3);
			//m_htiBoldWeight4 = m_ctrlTreeOptions.InsertRadioButton(_T("NORMAL"), m_htiBoldWeight, m_nBoldWeight == 4);
			//m_htiBoldWeight5 = m_ctrlTreeOptions.InsertRadioButton(_T("MEDIUM"), m_htiBoldWeight, m_nBoldWeight == 5);
			//m_htiBoldWeight6 = m_ctrlTreeOptions.InsertRadioButton(_T("SEMIBOLD"), m_htiBoldWeight, m_nBoldWeight == 6);
			//m_htiBoldWeight7 = m_ctrlTreeOptions.InsertRadioButton(_T("BOLD"), m_htiBoldWeight, m_nBoldWeight == 7);
			//m_htiBoldWeight8 = m_ctrlTreeOptions.InsertRadioButton(_T("EXTRABOLD"), m_htiBoldWeight, m_nBoldWeight == 8);
			//m_htiBoldWeight9 = m_ctrlTreeOptions.InsertRadioButton(_T("HEAVY"), m_htiBoldWeight, m_nBoldWeight == 9);

			//m_htigbCharSet = m_ctrlTreeOptions.InsertGroup(_T("����վ������������"), iImgGrp, m_htiFontGrp);
			//m_htigbCharSet0 = m_ctrlTreeOptions.InsertRadioButton(_T("ANSI"), m_htigbCharSet, m_gbCharSet == 0);
			//m_htigbCharSet1 = m_ctrlTreeOptions.InsertRadioButton(_T("DEFAULT"), m_htigbCharSet, m_gbCharSet == 1);
			//m_htigbCharSet2 = m_ctrlTreeOptions.InsertRadioButton(_T("SYMBOL"), m_htigbCharSet, m_gbCharSet == 2);
			//m_htigbCharSet6 = m_ctrlTreeOptions.InsertRadioButton(_T("GB2312"), m_htigbCharSet, m_gbCharSet == 3);
			//m_htigbCharSet7 = m_ctrlTreeOptions.InsertRadioButton(_T("CHINESEBIG5"), m_htigbCharSet, m_gbCharSet == 4);

			//m_htibig5CharSet = m_ctrlTreeOptions.InsertGroup(_T("����վ������������"), iImgGrp, m_htiFontGrp);
			//m_htibig5CharSet0 = m_ctrlTreeOptions.InsertRadioButton(_T("ANSI"), m_htibig5CharSet, m_big5CharSet == 0);
			//m_htibig5CharSet1 = m_ctrlTreeOptions.InsertRadioButton(_T("DEFAULT"), m_htibig5CharSet, m_big5CharSet == 1);
			//m_htibig5CharSet2 = m_ctrlTreeOptions.InsertRadioButton(_T("SYMBOL"), m_htibig5CharSet, m_big5CharSet == 2);
			//m_htibig5CharSet6 = m_ctrlTreeOptions.InsertRadioButton(_T("GB2312"), m_htibig5CharSet, m_big5CharSet == 3);
			//m_htibig5CharSet7 = m_ctrlTreeOptions.InsertRadioButton(_T("CHINESEBIG5"), m_htibig5CharSet, m_big5CharSet == 4);

			// txt
			m_htiSelectStay = m_ctrlTreeOptions.InsertCheckBox(_T("�������ݱ仯ʱѡ�����䣨���򴰿����ݱ仯��ȡ��ѡ����"), m_htiTxtGrp, m_bSelectStay);
			m_htiSelBackHi = m_ctrlTreeOptions.InsertCheckBox(_T("ѡ�����ֱ���������ǰ���ߵ�������"), m_htiTxtGrp, m_bSelBackHi);
			m_htiSelAntiHalf = m_ctrlTreeOptions.InsertCheckBox(_T("����ѡȡʱ��ֹ���룬���ı�ѡ���Ծ����������룬������ѡ��ʱ���ܳ��׷�ֹ����"), m_htiTxtGrp, m_bSelAntiHalf);
			m_htiAutoSaveEdit = m_ctrlTreeOptions.InsertCheckBox(_T("�ر�ʱ�Զ�����༭���е����ݵ� user\\mypost.txt"), m_htiTxtGrp, m_bAutoSaveEdit);
			m_htiEditIME = m_ctrlTreeOptions.InsertCheckBox(_T("�ػ�༭������뷨��Ϣ��ѡ�н���༭���������벻�������⣩"), m_htiTxtGrp, m_bEditIME);
//			m_htiEditFontSize = m_ctrlTreeOptions.InsertItem(_T("*�༭���ֺţ�0��ʾ��ָ�����Ƽ�14��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiTxtGrp);
//			m_ctrlTreeOptions.AddEditBox(m_htiEditFontSize, RUNTIME_CLASS(CNumTreeOptionsEdit));
//			m_htiCloseIME = m_ctrlTreeOptions.InsertCheckBox(_T("�Ǳ༭״̬�Զ��ر����뷨"), m_htiTxtGrp, m_nCloseIME);
			m_htiIMEChar = m_ctrlTreeOptions.InsertCheckBox(_T("�������뷨��Ϣ����ȡ��ƴ��ʱ����ƴ������һ��ƴ���д˹��ܣ������û�У�"), m_htiTxtGrp, m_bIMEChar);
//			m_htiCtrlVPaste = m_ctrlTreeOptions.InsertCheckBox(_T("������Ctrl+V����Ϊճ����SMTH����վ����Ч��"), m_htiTxtGrp, m_bCtrlVPaste);
			//m_htiCopyUni = m_ctrlTreeOptions.InsertCheckBox(_T("��������ʱ����Unicode����"), m_htiTxtGrp, m_bCopyUni);
			//m_htiPasteUni = m_ctrlTreeOptions.InsertCheckBox(_T("ճ������ʱ����Unicode����"), m_htiTxtGrp, m_bPasteUni);
			m_htiCopyNoReturn = m_ctrlTreeOptions.InsertCheckBox(_T("����/�������£��������У���ĩ�ǿո񣩲��Զ����С�Ҫ��ԭ����������ѡ��Ҫ������Ű���鷳��ѡ�и�ѡ��"), m_htiTxtGrp, m_bCopyNoReturn);
			m_htiWrapLen = m_ctrlTreeOptions.InsertItem(_T("���������Զ�����ʱ��ÿ���ַ�����Ĭ��Ϊ0����ʾ������ʾ����"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiTxtGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiWrapLen, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiCopyRectNoReturn = m_ctrlTreeOptions.InsertCheckBox(_T("���ο���, ���У���ĩ�ǿո񣩲��Զ�����"), m_htiTxtGrp, m_bCopyRectNoReturn);
			m_htiPasteConfirm = m_ctrlTreeOptions.InsertCheckBox(_T("���������ڲ��Ƿ�������״̬��ǿ��ճ�������Σ�ա�����ʾ"), m_htiTxtGrp, m_bPasteConfirm);
			//m_htiArticleSaveExt = m_ctrlTreeOptions.InsertItem(_T("�������±���ʱ��Ĭ������"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiTxtGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiArticleSaveExt, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiDownloadWithHTML = m_ctrlTreeOptions.InsertCheckBox(_T("��ƪ��������ʱת��ΪHTML����Ҫ����ΪHTMLʱѡ����"), m_htiTxtGrp, m_bDownloadWithHTML);

			//m_htiAskDlg = m_ctrlTreeOptions.InsertGroup(_T("����������ʱ���֡�����������ĩβ��ǿ�з��ء�֮�����ʾ��"), iImgGrp, m_htiTxtGrp);
			//m_htiAskDlg0 = m_ctrlTreeOptions.InsertRadioButton(_T("����"), m_htiAskDlg, m_iAskDlg == -1);
			//m_htiAskDlg1 = m_ctrlTreeOptions.InsertRadioButton(_T("�����ʣ�Ĭ�ϴ�Ϊ0"), m_htiAskDlg, m_iAskDlg == 0);
			//m_htiAskDlg2 = m_ctrlTreeOptions.InsertRadioButton(_T("�����ʣ�Ĭ�ϴ�Ϊ1"), m_htiAskDlg, m_iAskDlg == 1);
			//m_htiAskDlg3 = m_ctrlTreeOptions.InsertRadioButton(_T("�����ʣ�Ĭ�ϴ�Ϊ2"), m_htiAskDlg, m_iAskDlg == 2);
			//m_htiAskDlg4 = m_ctrlTreeOptions.InsertRadioButton(_T("�����ʣ��Զ��ж�"), m_htiAskDlg, m_iAskDlg == 3);
			//m_htiAskDlg5 = m_ctrlTreeOptions.InsertRadioButton(_T("�����ʣ��ȴ�"), m_htiAskDlg, m_iAskDlg == 4);

			//m_htiDownTimeout = m_ctrlTreeOptions.InsertItem(_T("�������µĳ�ʱֵ��������ʱ���ز��������Ե��󣨵�λ�����룩"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiTxtGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiDownTimeout, RUNTIME_CLASS(CNumTreeOptionsEdit));

			// pic
			//m_htiPicHoverTime = m_ctrlTreeOptions.InsertItem(_T("��ͼ����ͣʱ�䣨��λ�����룩����ֵ��ʾ��ֹ��ͣ��ͼ"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiPicGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiPicHoverTime, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiPicLoadTimeOut = m_ctrlTreeOptions.InsertItem(_T("����ͼƬ�ĳ�ʱʱ��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiPicGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiPicLoadTimeOut, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiPicDrag = m_ctrlTreeOptions.InsertCheckBox(_T("ѡ�У�����ƶ�ʱ�ƶ�ͼƬ��δѡ������ɿ�ʱ���ƶ�"), m_htiPicGrp, m_bPicDrag);
			m_htiLoadPicThread = m_ctrlTreeOptions.InsertCheckBox(_T("�߳�����ͼƬ������ͼƬ�������"), m_htiPicGrp, m_bLoadPicThread);
			m_htiPicDlgColor = m_ctrlTreeOptions.InsertItem(_T("ͼƬ����ɫ��RRGGBB����0Ϊ��ɫ����������Ч��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiPicGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiPicDlgColor, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiPicPath = m_ctrlTreeOptions.InsertItem(_T("ͼƬ���ر���·��"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiPicGrp);
			//m_ctrlTreeOptions.AddEditBox(m_htiPicPath, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiDelPicAsk = m_ctrlTreeOptions.InsertCheckBox(_T("���ͼƬĿ¼ǰ����ȷ�϶Ի���"), m_htiPicGrp, m_bDelPicAsk);
			//m_htiGetPicInfo = m_ctrlTreeOptions.InsertCheckBox(_T("��ͼʱȡ���±��⣨��ʾ��I��ť��tip�ϣ�"), m_htiPicGrp, m_bGetPicInfo);
			//m_htiPicDlgInfo = m_ctrlTreeOptions.InsertCheckBox(_T("����ͼƬʱ����ͼƬ����ʾ������ֻ��״̬����ʾ��"), m_htiPicGrp, m_bPicDlgInfo);
			m_htiPicTimeOut = m_ctrlTreeOptions.InsertItem(_T("ͼƬ���س�ʱʱ�䣨��λ���룩"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiPicGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiPicTimeOut, RUNTIME_CLASS(CNumTreeOptionsEdit));
			m_htiAutoRetryPic = m_ctrlTreeOptions.InsertCheckBox(_T("ͼƬ��ʱ��������"), m_htiPicGrp, m_bAutoRetryPic);
			//m_htiPicTip = m_ctrlTreeOptions.InsertCheckBox(_T("��ͼ��ʾtip(�ļ���)"), m_htiPicGrp, m_bPicTip);
			//m_htiPicNoBorder = m_ctrlTreeOptions.InsertCheckBox(_T("ͼƬ����ʾ�߿�"), m_htiPicGrp, m_bPicNoBorder);
			m_htiPicHide = m_ctrlTreeOptions.InsertCheckBox(_T("����뿪ͼƬ������, �������ָ������url��ѡ��ʱ����"), m_htiPicGrp, m_bPicHide);
			

			// url
			m_htiUrlProg = m_ctrlTreeOptions.InsertItem(_T("http��url���Զ������"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiUrlGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiUrlProg, RUNTIME_CLASS(CTreeOptionsEditEx));
			m_htiFtpProg = m_ctrlTreeOptions.InsertItem(_T("�򿪺���FTP://����URL���Զ������"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiUrlGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiFtpProg, RUNTIME_CLASS(CTreeOptionsEditEx));
			m_htiDownProg = m_ctrlTreeOptions.InsertItem(_T("���ع���(0-��, 1-Ѹ�ף�2-�쳵, 3-Ӱ�����ʹ�)"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, m_htiUrlGrp);
			m_ctrlTreeOptions.AddEditBox(m_htiDownProg, RUNTIME_CLASS(CTreeOptionsEditEx));

			m_htiPythonOpenFile = m_ctrlTreeOptions.InsertCheckBox(_T("��Python�ű���URL"), m_htiUrlGrp, m_bPythonOpenFile);
			m_htiUrlWithConfirm = m_ctrlTreeOptions.InsertCheckBox(_T("��url��Ҫ�����Ի��򣨷���ֱ�Ӵ򿪣�"), m_htiUrlGrp, m_bUrlWithConfirm);
			m_htiURLStrip = m_ctrlTreeOptions.InsertCheckBox(_T("ѡ��������Ϊurl��ʱ���˿հ�"), m_htiUrlGrp, m_bURLStrip);
			m_htiViewDrag = m_ctrlTreeOptions.InsertCheckBox(_T("�����϶�����"), m_htiUrlGrp, m_bViewDrag);
			m_htiAutoURLHeader = m_ctrlTreeOptions.InsertCheckBox(_T("url�Զ���Э��ͷѡ��"), m_htiUrlGrp, m_bAutoURLHeader);
			m_htiFilterQueryIP = m_ctrlTreeOptions.InsertCheckBox(_T("�ֶ���ѯIP��ȡ���а�����ʱ���й���"), m_htiUrlGrp, m_bFilterQueryIP);
			//m_htiAutoFromIP = m_ctrlTreeOptions.InsertCheckBox(_T("ȫ�Զ��滻IPʱֻ�滻FROM����ģ���ѡ��ȫ���滻��"), m_htiUrlGrp, m_bAutoFromIP);
			m_htiBakAutoIP = m_ctrlTreeOptions.InsertCheckBox(_T("�Զ��滻IPʱ����ԭIP�������п��ܳ������룩"), m_htiUrlGrp, m_bBakAutoIP);

			// mouse
//			m_htiURLNoMouse = m_ctrlTreeOptions.InsertCheckBox(_T("�ڽ���������ʱ����ʹ�����ӡ��鿴ͼƬ��ѡȡ����"), TVI_ROOT, m_bURLNoMouse);
			//m_htiHideMouse = m_ctrlTreeOptions.InsertCheckBox(_T("�ڽ���������ʱ�������"), TVI_ROOT, m_bHideMouse);
			//m_htiCaptureMouse = m_ctrlTreeOptions.InsertCheckBox(_T("���������ʱ�����������"), TVI_ROOT, m_bCaptureMouse);

			// other func g_bCacheHistory
			m_htiCacheHistory = m_ctrlTreeOptions.InsertCheckBox(_T("*������¼��ʷ��Ļ"), TVI_ROOT, m_bCacheHistory);
			//m_htiIsAutoReply = m_ctrlTreeOptions.InsertCheckBox(_T("�����Զ��ظ����Զ��ظ�ģʽ���Ƿ�ظ�"), TVI_ROOT, m_bIsAutoReply);
			m_htiPythonLog = m_ctrlTreeOptions.InsertCheckBox(_T("��python��Ϣ�����temp\\�µ�python.log��pyerr.log"), TVI_ROOT, m_bPythonLog);
			m_htiAnsiLog = m_ctrlTreeOptions.InsertCheckBox(_T("��¼ԭʼ���ݰ���temp\\ansilog*.ctd"), TVI_ROOT, m_bAnsiLog);
			m_htiEnableVBS = m_ctrlTreeOptions.InsertCheckBox(_T("֧��VBScript�ű�"), TVI_ROOT, m_bEnableVBS);
			//m_htiHttpUploadDlg = m_ctrlTreeOptions.InsertCheckBox(_T("��������http�ϴ������ĶԻ���"), TVI_ROOT, m_bUploadAttAuto);
			m_htiKeyTableFile = m_ctrlTreeOptions.InsertItem(_T("�Զ�������/��ťԴ�ļ�"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			m_ctrlTreeOptions.AddEditBox(m_htiKeyTableFile, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiScriptDir = m_ctrlTreeOptions.InsertItem(_T("Ĭ�Ͻű�Ŀ¼"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			//m_ctrlTreeOptions.AddEditBox(m_htiScriptDir, RUNTIME_CLASS(CTreeOptionsEditEx));

			//m_htiMailWavFile = m_ctrlTreeOptions.InsertItem(_T("�ż������ļ���0��ʾ������"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			//m_ctrlTreeOptions.AddEditBox(m_htiMailWavFile, RUNTIME_CLASS(CTreeOptionsEditEx));
			//m_htiAllowSameSiteName = m_ctrlTreeOptions.InsertCheckBox(_T("��ַ����������"), TVI_ROOT, m_bAllowSameSiteName);
			//m_htiAddrFullName = m_ctrlTreeOptions.InsertCheckBox(_T("��ַ����ʾȫ������λ��վ����"), TVI_ROOT, m_bAddrFullName);
			
			//m_htiBossKeyStyle = m_ctrlTreeOptions.InsertGroup(_T("�ϰ�����"), iImgGrp, TVI_ROOT);
			//m_htiBossKeyStyle0 = m_ctrlTreeOptions.InsertRadioButton(_T("ԭ����ʽ����һ�����أ��ٰ�һ�µ���"), m_htiBossKeyStyle, m_nBossKeyStyle == 0);
			//m_htiBossKeyStyle1 = m_ctrlTreeOptions.InsertRadioButton(_T("FTERM��ʽ�����ǵ�ǰ����ʱ�������ǵ�ǰ����������"), m_htiBossKeyStyle, m_nBossKeyStyle == 1);
			
			//m_htiHotKey = m_ctrlTreeOptions.InsertItem(_T("�����ȼ�����������ã�"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			//m_ctrlTreeOptions.AddEditBox(m_htiHotKey, RUNTIME_CLASS(CTreeOptionsEditEx));
			m_htiControlPort = m_ctrlTreeOptions.InsertItem(_T("���ƶ˿ںţ�����CTerm��ͬʵ����ͨ�ţ�"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			m_ctrlTreeOptions.AddEditBox(m_htiControlPort, RUNTIME_CLASS(CNumTreeOptionsEdit));
			//m_htiRegBBSProto = m_ctrlTreeOptions.InsertCheckBox(_T("��ע���ע�� BBS:// Э��"), TVI_ROOT, m_bRegBBSProto);
			m_htiTimer = m_ctrlTreeOptions.InsertItem(_T("ϵͳ��ʱ��(�ṩ�Զ�����)ʱ��������(0=����)"), TREEOPTSCTRLIMG_EDIT, TREEOPTSCTRLIMG_EDIT, TVI_ROOT);
			m_ctrlTreeOptions.AddEditBox(m_htiTimer, RUNTIME_CLASS(CNumTreeOptionsEdit));
		}
		m_bInitializedTreeOpts = true;
	}

	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiRepeatUserName, m_bRepeatUserName);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiURLNoMouse, m_bURLNoMouse);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiHideMouse, m_bHideMouse);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSiteStatus, m_bSiteStatus);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCaptureMouse, m_bCaptureMouse);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiRefreshTitle, m_bRefreshTitle);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiChildDefaultMax, m_bChildDefaultMax);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAutoSize, m_bAutoSize);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCacheHistory, m_bCacheHistory);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiIsAutoReply, m_bIsAutoReply);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiNoAskClose, m_bNoAskClose);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPythonLog, m_bPythonLog);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAnsiLog, m_bAnsiLog);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiReportSimple, m_bReportSimple);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiEnableVBS, m_bEnableVBS);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAltShowMenu, m_bAltShowMenu);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCaptionButtons, m_bCaptionButtons);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiClickUser, m_bClickUser);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiKeybarWidth, m_nKeybarWidth);
	DDV_MinMaxInt(pDX, m_nKeybarWidth, 5, 250);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiKeybarHeight, m_nKeybarHeight);
	DDV_MinMaxInt(pDX, m_nKeybarHeight, 1, MAX_USERDEFCMD_NUM);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiFixedSysSize, m_nFixedSysSize);
	//DDV_MinMaxInt(pDX, m_nFixedSysSize, 1, 100);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiCharScale, m_nCharScale);
	//DDV_MinMaxInt(pDX, m_nCharScale, 1, 100);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiRowSpace, m_nRowSpace);
	//DDV_MinMaxInt(pDX, m_nRowSpace, -100, MAX_ROW_SPACE);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiTA_CENTER, m_TA_CENTER);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiFont, m_sFont);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiEFont, m_sEFont);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiMONOSPACE, m_bMONOSPACE);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiFixFont, m_bFixFont);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiFixFontSize, m_nFixFontSize);
	//DDV_MinMaxInt(pDX, m_nFixFontSize, 1, 100);
	//DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htiBoldWeight, m_nBoldWeight);
	//DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htigbCharSet, m_gbCharSet);
	//DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htibig5CharSet, m_big5CharSet);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSelectStay, m_bSelectStay);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSelBackHi, m_bSelBackHi);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiSelAntiHalf, m_bSelAntiHalf);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiEnableM, m_bEnableM);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiFullScreenBar, m_bFullScreenBar);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCursorPos, m_bCursorPos);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiTransparent, m_bTransparent);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiAlpha, m_nAlpha);
	//DDV_MinMaxInt(pDX, m_nAlpha, 0, 255);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCtrlVPaste, m_bCtrlVPaste);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCopyUni, m_bCopyUni);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPasteUni, m_bPasteUni);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCopyNoReturn, m_bCopyNoReturn);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiWrapLen, m_nWrapLen);
	DDV_MinMaxInt(pDX, m_nWrapLen, 0, INT_MAX);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCopyRectNoReturn, m_bCopyRectNoReturn);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAutoSaveEdit, m_bAutoSaveEdit);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiEditIME, m_bEditIME);
//	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiEditFontSize, m_nEditFontSize);
//	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCloseIME, m_nCloseIME);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiIMEChar, m_bIMEChar);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPasteConfirm, m_bPasteConfirm);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiFilterQueryIP, m_bFilterQueryIP);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAutoFromIP, m_bAutoFromIP);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiBakAutoIP, m_bBakAutoIP);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPicHoverTime, m_nPicHoverTime);
	//DDV_MinMaxInt(pDX, m_nPicHoverTime, -10, 30000);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPicLoadTimeOut, m_nPicLoadTimeOut);
	DDV_MinMaxInt(pDX, m_nPicLoadTimeOut, 1, 30000);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPicDrag, m_bPicDrag);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiLoadPicThread, m_bLoadPicThread);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPicDlgColor, m_sPicDlgColor);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPicPath, m_PicPath);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiGetPicInfo, m_bGetPicInfo);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiDelPicAsk, m_bDelPicAsk);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPicDlgInfo, m_bPicDlgInfo);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPicTimeOut, m_nPicTimeOut);
	DDV_MinMaxInt(pDX, m_nPicTimeOut, 1, 300);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPicTip, m_bPicTip);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPicNoBorder, m_bPicNoBorder);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPicHide, m_bPicHide);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAutoRetryPic, m_bAutoRetryPic);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiUrlProg, m_sUrlProg);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiFtpProg, m_sFtpProg);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiDownProg, m_nDownProg);

	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiPythonOpenFile, m_bPythonOpenFile);	
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiPlink, m_sPlink);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiLoginFlag, m_sLoginFlag);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiLoginFlag1, m_sLoginFlag1);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiUrlWithConfirm, m_bUrlWithConfirm);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiURLStrip, m_bURLStrip);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiViewDrag, m_bViewDrag);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAutoURLHeader, m_bAutoURLHeader);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiBlinkTimeOut, m_nBlinkTimeOut);
	DDV_MinMaxInt(pDX, m_nBlinkTimeOut, 1, 3000);
	DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htiCaretStyle, m_nCaretStyle);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiCARET_H, m_nCARET_H);
	DDV_MinMaxInt(pDX, m_nCARET_H, -10, 300);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiCARET_W, m_nCARET_W);
	DDV_MinMaxInt(pDX, m_nCARET_W, -10, 300);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCaretCenter, m_bCaretCenter);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCaretBlink, m_bCaretBlink);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_bUploadAttAuto, m_bUploadAttAuto);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiKeyTableFile, m_sKeyTableFile);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiScriptDir, m_sScriptDir);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiMailWavFile, m_sMailWavFile);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAllowSameSiteName, m_bAllowSameSiteName);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiAddrFullName, m_bAddrFullName);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiArticleSaveExt, m_sArticleSaveExt);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiDownloadWithHTML, m_bDownloadWithHTML);	
	//DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htiAskDlg, m_iAskDlg);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiDownTimeout, m_nDownTimeout);
	//DDV_MinMaxInt(pDX, m_nDownTimeout, 1, 30000);
	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiCtdDraw, m_bCtdDraw);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiNoFocusNoCursor, m_bNoFocusNoCursor);
//	DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiDrawByString, m_bDrawByString);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiRecvBufLen, m_nRecvBufLen);
	DDV_MinMaxInt(pDX, m_nRecvBufLen, 1, INT_MAX);
	//DDX_TreeRadio(pDX, IDC_EXT_OPTS, m_htiBossKeyStyle, m_nBossKeyStyle);
	//DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiHotKey, m_sHotKey);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiControlPort, m_nControlPort);
	DDV_MinMaxInt(pDX, m_nControlPort, 1025, INT_MAX);
	//DDX_TreeCheck(pDX, IDC_EXT_OPTS, m_htiRegBBSProto, m_bRegBBSProto);
	DDX_TreeEdit(pDX, IDC_EXT_OPTS, m_htiTimer, m_nTimer);
	DDV_MinMaxInt(pDX, m_nTimer, 0, INT_MAX);
}


BEGIN_MESSAGE_MAP(COptAdvPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptAdvPage)
	ON_MESSAGE(UM_TREEOPTSCTRL_NOTIFY, OnTreeOptsCtrlNotify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptAdvPage message handlers
LRESULT COptAdvPage::OnTreeOptsCtrlNotify(WPARAM wParam, LPARAM lParam)
{
	if (wParam == IDC_EXT_OPTS)
	{
		TREEOPTSCTRLNOTIFY* pton = (TREEOPTSCTRLNOTIFY*)lParam;
		if ((m_htiCaretStyle0 && pton->hItem == m_htiCaretStyle0)
			|| (m_htiCaretStyle0 && pton->hItem == m_htiCaretStyle0)
			|| (m_htiCaretStyle1 && pton->hItem == m_htiCaretStyle1)
			|| (m_htiCaretStyle2 && pton->hItem == m_htiCaretStyle2)
			|| (m_htiCaretStyle3 && pton->hItem == m_htiCaretStyle3)) {
			UpdateData();
			if (m_nCaretStyle < g_nCaretStyleSize) {
				SCaretStyle &sc = CaretStyles[m_nCaretStyle];
				m_nCARET_H = sc.h;
				m_nCARET_W = sc.w;
				m_bCaretCenter = sc.center;
				UpdateData(FALSE);
			}
		}
		else if ((m_htiCARET_H && pton->hItem == m_htiCARET_H)
			|| (m_htiCARET_W && pton->hItem == m_htiCARET_W)
			|| (m_htiCaretCenter && pton->hItem == m_htiCaretCenter)) {
			UpdateData();
			SCaretStyle sc = {m_nCARET_H, m_nCARET_W, m_bCaretCenter};
			m_nCaretStyle = CaretStyle2Index(sc);
			UpdateData(FALSE);
		}
		
		SetModified();
	}
	return 0;
}

BOOL COptAdvPage::OnInitDialog() 
{
	// Ӧ�÷���OnInitDialog()ǰ�棬�����ܸ��¿ؼ�...���Ǽ�updatedata()
	Init();

	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//#define ANSI_CHARSET            0
//#define DEFAULT_CHARSET         1
//#define SYMBOL_CHARSET          2
//#define GB2312_CHARSET          134
//#define CHINESEBIG5_CHARSET     136
inline int Charset2Index(int charset)
{
	int r = 1;
	switch(charset) {
	case ANSI_CHARSET:
		r = 0;
		break;
	case DEFAULT_CHARSET:
		r = 1;
		break;
	case SYMBOL_CHARSET:
		r = 2;
		break;
	case GB2312_CHARSET:
		r = 3;
		break;
	case CHINESEBIG5_CHARSET:
		r = 4;
		break;
	}

	return r;
}

inline int Index2Charset(int idx)
{
	int r = DEFAULT_CHARSET;
	switch(idx) {
	case 0:
		r = ANSI_CHARSET;
		break;
	case 1:
		r = DEFAULT_CHARSET;
		break;
	case 2:
		r = SYMBOL_CHARSET;
		break;
	case 3:
		r = GB2312_CHARSET;
		break;
	case 4:
		r = CHINESEBIG5_CHARSET;
		break;
	}

	return r;
}

//#define FW_DONTCARE         0
//#define FW_THIN             100
//#define FW_EXTRALIGHT       200
//#define FW_LIGHT            300
//#define FW_NORMAL           400
//#define FW_MEDIUM           500
//#define FW_SEMIBOLD         600
//#define FW_BOLD             700
//#define FW_EXTRABOLD        800
//#define FW_HEAVY            900

inline int Index2Weight(int idx)
{
	int r = FW_BOLD;
	if (idx == 0) {
		r = 0;
	}
	else if (0 < idx && idx <= 9) {
		r = idx * 100;
	}

	return r;
}

inline int Weight2Index(int w)
{
	int r = 7;
	if (w == 0) {
		r = 0;
	}
	else if (0 < w && w <= 900) {
		r = w / 100;
	}

	return r;
}

//0 -1: ��ʾ����
//1 0: �����ʣ�Ĭ�ϴ�Ϊ0 PopStatus
//2 1: �����ʣ�Ĭ�ϴ�Ϊ1 EnterNextStage
//3 2: �����ʣ�Ĭ�ϴ�Ϊ2 ChangeStatus
//4 3: �����ʣ��Զ��ж�
//5 other: ������ m_Run.m_nTime=clock();
inline int Action2Index(int a)
{
	int r = 4;
	if (a == -1) {
		r = 0;
	}
	else if (0 < a && a <= 3) {
		r = a + 1;
	}
	else {
		r = 5;
	}

	return r;
}

inline int Index2Action(int idx)
{
	int r = 3;
	if (idx == 0) {
		r = -1;
	}
	else if (0 < idx && idx <= 5) {
		r = idx - 1;
	}

	return r;
}

void COptAdvPage::Init()
{
	m_bRepeatUserName = g_bRepeatUserName;
	//m_bURLNoMouse = g_bURLNoMouse;
#if ENABLE_HIDECURSOR
	m_bHideMouse = g_bHideMouse;
#endif//ENABLE_HIDECURSOR
	//m_bSiteStatus = g_bSiteStatus;
	m_bCaptureMouse = g_bCaptureMouse;
	m_bRefreshTitle = g_bRefreshTitle;
	m_bChildDefaultMax = g_bChildDefaultMax;
	m_bAutoSize = g_bAutoSize;
	m_bCacheHistory = g_bCacheHistory;
	//m_bIsAutoReply = g_bIsAutoReply;
	m_bNoAskClose = g_bNoAskClose;
	m_bPythonLog = g_bPythonLog;
	m_bAnsiLog = g_bAnsiLog;
	m_bReportSimple = g_bReportSimple;
	m_bEnableVBS = g_bEnableVBS;
#if ENABLE_HIDEMENU
	m_bAltShowMenu = g_bAltShowMenu;
	m_bCaptionButtons = g_bCaptionButtons;
#endif//ENABLE_HIDEMENU
	//m_bClickUser = g_bClickUser;
	m_nKeybarWidth = g_nKeybarWidth;
	m_nKeybarHeight = g_nKeybarHeight;
	m_nFixedSysSize = g_nFixedSysSize;
	m_nCharScale = g_nCharScale;
	m_nRowSpace = g_nRowSpace;	
	//m_TA_CENTER = g_TA_CENTER;
	m_sEFont = g_sEFont;
	m_sFont = g_sFont;
	m_bMONOSPACE = g_bMONOSPACE;
	m_bFixFont = g_bFixFont;
	m_nFixFontSize = g_nFixFontSize;
	//m_nBoldWeight = Weight2Index(g_nBoldWeight);
	m_bSelectStay = g_bSelectStay;
	m_bSelBackHi = g_bSelBackHi;
	m_bSelAntiHalf = g_bSelAntiHalf;
	m_bEnableM = g_bEnableM;
	//m_bFullScreenBar = g_bFullScreenBar;
	m_bCursorPos = g_bCursorPos;
	//m_bTransparent = g_bTransparent;
	//m_nAlpha = g_nAlpha;
//	m_bCtrlVPaste = g_bCtrlVPaste;
//	m_bCopyUni = g_bCopyUni;
//	m_bPasteUni = g_bPasteUni;
	m_bCopyNoReturn = g_bCopyNoReturn;
	m_nWrapLen = g_nWrapLen;
	m_bCopyRectNoReturn = g_bCopyRectNoReturn;
	m_bAutoSaveEdit = g_bAutoSaveEdit;
	m_bEditIME = g_bEditIME;
//	m_nEditFontSize = g_nEditFontSize;
	//m_nCloseIME = g_nCloseIME;
	m_bIMEChar = g_bIMEChar;
	//m_gbCharSet =Charset2Index(g_gbCharSet);
	//m_big5CharSet = Charset2Index(g_big5CharSet);
	m_bPasteConfirm = g_bPasteConfirm;
	m_bFilterQueryIP = g_bFilterQueryIP;
#if ENABLE_REPLACEIP
//	m_bAutoFromIP = g_bAutoFromIP;
	m_bBakAutoIP = g_bBakAutoIP;
#endif//ENABLE_REPLACEIP
#if ENABLE_PICTURE
	//m_nPicHoverTime = g_nPicHoverTime;
	m_nPicLoadTimeOut = g_nPicLoadTimeOut;
	m_bPicDrag = g_bPicDrag;
	m_bLoadPicThread = g_bLoadPicThread;
	m_sPicDlgColor = g_sPicDlgColor;
	//m_PicPath = g_PicPath;
	//m_bGetPicInfo = g_bGetPicInfo;
	//m_bDelPicAsk = g_bDelPicAsk;
	//m_bPicDlgInfo = g_bPicDlgInfo;
	m_nPicTimeOut = g_nPicTimeOut;
	//m_bPicTip = g_bPicTip;
	//m_bPicNoBorder = g_bPicNoBorder;
	m_bPicHide = g_bPicHide;
	m_bAutoRetryPic = g_bAutoRetryPic;
#endif//ENABLE_PICTURE
	m_sUrlProg = g_sUrlProg;
	m_sFtpProg = g_szFtpProg;
	m_nDownProg = g_nDownTool;
	m_bPythonOpenFile = g_bPythonOpenFile;
#if ENABLE_PIPESSH
	m_sPlink = g_sPlink;
#endif//ENABLE_PIPESSH
	m_sLoginFlag = g_sLoginFlag;
	m_sLoginFlag1 = g_sLoginFlag1;
	m_bUrlWithConfirm = g_bUrlWithConfirm;
	m_bURLStrip = g_bURLStrip;
	m_bViewDrag = g_bViewDrag;
	m_bAutoURLHeader = g_bAutoURLHeader;
	m_nBlinkTimeOut = g_nBlinkTimeOut;

	m_nCARET_H = g_nCARET_H;
	m_nCARET_W = g_nCARET_W;
	m_bCaretCenter = g_bCaretCenter;
	SCaretStyle sc = {m_nCARET_H, m_nCARET_W, m_bCaretCenter};
	m_nCaretStyle = CaretStyle2Index(sc);
	
	m_bCaretBlink = g_bCaretBlink;
	m_bUploadAttAuto = g_bUploadAttAuto;

#if ENABLE_FUNKEY
	m_sKeyTableFile = StripWorkDir(g_sKeyTableFile);
#endif//ENABLE_FUNKEY
	//m_sScriptDir = StripWorkDir(g_sScriptDir);
	m_sMailWavFile = StripWorkDir(g_szMailWavFile);

//	m_bAllowSameSiteName = g_bAllowSameSiteName;
	m_bAddrFullName = g_bAddrFullName;
//	m_sArticleSaveExt = g_sArticleSaveExt;
//	m_bDownloadWithHTML = g_bDownloadWithHTML;
	//m_iAskDlg = Action2Index(g_iAskDlg);
	//m_nDownTimeout = g_nDownTimeout;
	m_bCtdDraw = g_bCtdDraw;
	m_bNoFocusNoCursor = g_bNoFocusNoCursor;
	//m_bDrawByString = g_bDrawByString;
	m_nRecvBufLen = g_nRecvBufLen;
#if ENABLE_HOTKEY
	//m_nBossKeyStyle = (g_nBossKeyStyle == 0 ? 0 : 1);
	//m_sHotKey = g_HotKeyStr;
#endif//ENABLE_HOTKEY
	m_nControlPort = g_nControlPort > 1025 ? g_nControlPort : ORIGIN_CONTROL_PORT;
	//m_bRegBBSProto = g_bRegBBSProto;
	m_nTimer = g_nTimer;
}

void COptAdvPage::UnInit()
{
	if (!UpdateData())
		return;

	g_bRepeatUserName = m_bRepeatUserName;
	//g_bURLNoMouse = m_bURLNoMouse;
#if ENABLE_HIDECURSOR
	g_bHideMouse = m_bHideMouse;
#endif//ENABLE_HIDECURSOR
	//g_bSiteStatus = m_bSiteStatus;
	g_bCaptureMouse = m_bCaptureMouse;
	g_bRefreshTitle = m_bRefreshTitle;
	g_bChildDefaultMax = m_bChildDefaultMax;
	g_bAutoSize = m_bAutoSize;
	g_bCacheHistory = m_bCacheHistory;
	//g_bIsAutoReply = m_bIsAutoReply;
	g_bNoAskClose = m_bNoAskClose;
	g_bPythonLog = m_bPythonLog;
	g_bAnsiLog = m_bAnsiLog;
	g_bReportSimple = m_bReportSimple;
	g_bEnableVBS = m_bEnableVBS;
#if ENABLE_HIDEMENU
	g_bAltShowMenu = m_bAltShowMenu;
	g_bCaptionButtons = m_bCaptionButtons;
#endif//ENABLE_HIDEMENU
	//g_bClickUser = m_bClickUser;
	g_nKeybarWidth = m_nKeybarWidth;
	g_nKeybarHeight = m_nKeybarHeight;
	g_nFixedSysSize = m_nFixedSysSize;
	g_nCharScale = m_nCharScale;
	g_nRowSpace = m_nRowSpace;
	//g_TA_CENTER = m_TA_CENTER;
	g_sEFont = m_sEFont;
	g_sFont = m_sFont;
	g_bMONOSPACE = m_bMONOSPACE;
	g_bFixFont = m_bFixFont;
	g_nFixFontSize = m_nFixFontSize;
	//g_nBoldWeight = Index2Weight(m_nBoldWeight);
	g_bSelectStay = m_bSelectStay;
	g_bSelBackHi = m_bSelBackHi;
	g_bSelAntiHalf = m_bSelAntiHalf;
	g_bEnableM = m_bEnableM;
	//g_bFullScreenBar = m_bFullScreenBar;
	g_bCursorPos = m_bCursorPos;
	//g_bTransparent = m_bTransparent;
	//g_nAlpha = m_nAlpha;
//	g_bCtrlVPaste = m_bCtrlVPaste;
//	g_bCopyUni = m_bCopyUni;
//	g_bPasteUni = m_bPasteUni;
	g_bCopyNoReturn = m_bCopyNoReturn;
	g_nWrapLen = m_nWrapLen;
	g_bCopyRectNoReturn = m_bCopyRectNoReturn;
	g_bAutoSaveEdit = m_bAutoSaveEdit;
	g_bEditIME = m_bEditIME;
//	g_nEditFontSize = m_nEditFontSize;
	//g_nCloseIME = m_nCloseIME;
	g_bIMEChar = m_bIMEChar;
	//g_gbCharSet = Index2Charset(m_gbCharSet);
	//g_big5CharSet = Index2Charset(m_big5CharSet);
	g_bPasteConfirm = m_bPasteConfirm;
	g_bFilterQueryIP = m_bFilterQueryIP;
#if ENABLE_REPLACEIP
//	g_bAutoFromIP = m_bAutoFromIP;
	g_bBakAutoIP = m_bBakAutoIP;
#endif//ENABLE_REPLACEIP
#if ENABLE_PICTURE
	//g_nPicHoverTime = m_nPicHoverTime;
	g_nPicLoadTimeOut = m_nPicLoadTimeOut;
	g_bPicDrag = m_bPicDrag;
	g_bLoadPicThread = m_bLoadPicThread;
	g_sPicDlgColor = m_sPicDlgColor;
	//g_PicPath = m_PicPath;
	//if (g_PicPath.IsEmpty()) {
	//	g_PicPath = g_szWorkDir + _T("PicCache");// ����б��
	//}	else if (g_PicPath[g_PicPath.GetLength() - 1] == '\\') {
	//	g_PicPath = g_PicPath.Left(g_PicPath.GetLength() - 1);
	//}
	//g_bGetPicInfo = m_bGetPicInfo;
	//g_bDelPicAsk = m_bDelPicAsk;
	//g_bPicDlgInfo = m_bPicDlgInfo;
	g_nPicTimeOut = m_nPicTimeOut;
	//g_bPicTip = m_bPicTip;
	//g_bPicNoBorder = m_bPicNoBorder;
	g_bPicHide = m_bPicHide;
	g_bAutoRetryPic = m_bAutoRetryPic;
#endif//ENABLE_PICTURE
	g_sUrlProg = m_sUrlProg;
	g_szFtpProg = m_sFtpProg;
	g_nDownTool = m_nDownProg;
	g_bPythonOpenFile = m_bPythonOpenFile;
#if ENABLE_PIPESSH
	g_sPlink = m_sPlink;
#endif//ENABLE_PIPESSH
	g_sLoginFlag = m_sLoginFlag;
	g_sLoginFlag1 = m_sLoginFlag1;
	g_bUrlWithConfirm = m_bUrlWithConfirm;
	g_bURLStrip = m_bURLStrip;
	g_bViewDrag = m_bViewDrag;
	g_bAutoURLHeader = m_bAutoURLHeader;
	g_nBlinkTimeOut = m_nBlinkTimeOut;
	g_nCARET_H = m_nCARET_H;
	g_nCARET_W = m_nCARET_W;
	g_bCaretCenter = m_bCaretCenter;
	g_bCaretBlink = m_bCaretBlink;
	g_bUploadAttAuto = m_bUploadAttAuto;

#if ENABLE_FUNKEY
	g_sKeyTableFile = m_sKeyTableFile;
	if (g_sKeyTableFile.IsEmpty()) {
		g_sKeyTableFile = _T("user\\mycmds.txt");
	}
	PrependWorkDir(g_sKeyTableFile);
#endif//ENABLE_FUNKEY

	//g_sScriptDir = m_sScriptDir;
	if (g_sScriptDir.IsEmpty()) {
		g_sScriptDir = _T("script");
	}
	if (g_sScriptDir.GetAt(g_sScriptDir.GetLength() - 1) == '\\') {
		// python sys.path need no '\\'
		g_sScriptDir = g_sScriptDir.Left(g_sScriptDir.GetLength() - 1);
	}
	PrependWorkDir(g_sScriptDir);

	g_szMailWavFile = m_sMailWavFile;
	if (g_szMailWavFile.IsEmpty()) {
		g_szMailWavFile = g_szWavFile;
	}

//	g_bAllowSameSiteName = m_bAllowSameSiteName;
	g_bAddrFullName = m_bAddrFullName;
//	g_sArticleSaveExt = m_sArticleSaveExt;
//	g_bDownloadWithHTML = m_bDownloadWithHTML;
	//g_iAskDlg = Index2Action(m_iAskDlg);
	//g_nDownTimeout = m_nDownTimeout;
	g_bCtdDraw = m_bCtdDraw;
	g_bNoFocusNoCursor = m_bNoFocusNoCursor;
	//g_bDrawByString = m_bDrawByString;
	g_nRecvBufLen = m_nRecvBufLen;

#if ENABLE_HOTKEY
	//g_nBossKeyStyle = m_nBossKeyStyle;
	//strncpy(g_HotKeyStr, m_sHotKey.LockBuffer(), MAX_HOTKEY_NAME);
	//m_sHotKey.UnlockBuffer();
	//g_Hotkey.FromString(m_sHotKey);
#endif//ENABLE_HOTKEY
	
	g_nControlPort = m_nControlPort;
	//g_bRegBBSProto = m_bRegBBSProto;
	g_nTimer = m_nTimer;
}

void COptAdvPage::OnOK() 
{
	UnInit();
	
	CMyPropertyPage::OnOK();
}

UINT COptAdvPage::GetIDD()
{
	return IDD;
}
