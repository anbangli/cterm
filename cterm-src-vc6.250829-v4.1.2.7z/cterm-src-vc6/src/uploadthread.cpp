
//���ƻƺ�վר�õĸ����ϴ�����
//ԭʼ���ߣ�Hendy@byhh, 2007(?)
//�޶���GCser@byhh, 2011-12

#include "stdafx.h"
#include "UploadThread.h"

#include "PostDlg.h"
#include "uploadattdlg.h"

UINT UploadThread(LPVOID pParam)
{
	CPostDlg *pDlg = (CPostDlg*) pParam;
	CString strLoginUrl = _T("http://bbs.whnet.edu.cn/cgi-bin/bbslogin");
	CString strUploadUrl = _T("http://bbs.whnet.edu.cn/cgi-bin/bbsdoupload");
	CString strRequest, strResponse, strPostData;
	CString strStatus;			// ���ڼ�¼״̬

	static HINTERNET hInternetSession = NULL;
	static HINTERNET hConnect = NULL;
	static DWORD dwUtmpNum = 0, dwUtmpKey = 0;		// ��Щ��cookie�йص�
	static CString strUserName;
	HINTERNET hHttpRequest = NULL;
	BOOL bRet = FALSE;
	BYTE buf[4096] = {0};			// ���ݻ�����
	DWORD dwStatus = 0;
	int nStart = -1, nEnd = -1;

	if (pDlg->m_bThreadExit) {
		if (hConnect) {
			Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			dwUtmpNum = 0, dwUtmpKey = 0;
			InternetCloseHandle(hConnect);
			hConnect = NULL;
		}

		if (hInternetSession) {
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
		}

		pDlg->ThreadExit();

		return 0;
	}

	if (hInternetSession == NULL) {
		hInternetSession = InternetOpen(NULL,								// ����ͷ�в�����Agent�ֶ�
		                                INTERNET_OPEN_TYPE_DIRECT,			// ��ʹ�ô���
		                                NULL,								// ��ʹ�ô���
		                                NULL,
		                                0
		                               );
	}

	if (hInternetSession == NULL) {
		TRACE(_T("InternetOpen Failed(%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
		strStatus = _T("�򲻿����ƻƺף�");
		pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
		pDlg->ThreadExit();
		return 0;
	}

	// ���ó�ʱ
	DWORD dwTimeOut = 0;

	// ���ӳ�ʱ
	dwTimeOut = 5000;

	InternetSetOption(hInternetSession, INTERNET_OPTION_CONNECT_TIMEOUT, &dwTimeOut, sizeof(dwTimeOut));

	// ���ͼ����ճ�ʱ
	dwTimeOut = 5000;

	InternetSetOption(hInternetSession, INTERNET_OPTION_SEND_TIMEOUT, &dwTimeOut, sizeof(dwTimeOut));

	InternetSetOption(hInternetSession, INTERNET_OPTION_RECEIVE_TIMEOUT, &dwTimeOut, sizeof(dwTimeOut));

	// ���Դ���
	dwTimeOut = 2;

	InternetSetOption(hInternetSession, INTERNET_OPTION_CONNECT_RETRIES, &dwTimeOut, sizeof(dwTimeOut));

	strStatus = _T("��ʼ����...");

	pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

	DWORD dwServiceType = 0;

	INTERNET_PORT nPort;

	CString strServer, strObject;

	if (!AfxParseURL(strLoginUrl, dwServiceType, strServer, strObject, nPort)) {
		TRACE(_T("��Ч��URL��%s\n"), strLoginUrl);
		strStatus = _T("��Ч�İ��ƻƺ׵�ַ������������ϵ��");
		pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
		pDlg->ThreadExit();
		InternetCloseHandle(hInternetSession);
		hInternetSession = NULL;
		return 0;
	}

	if (hConnect == NULL) {
		hConnect = InternetConnect(
		               hInternetSession,
		               strServer,
		               nPort,
		               NULL,
		               NULL,
		               INTERNET_SERVICE_HTTP,
		               0,
		               0
		           );
	}

	if (hConnect == NULL) {
		TRACE(_T("InternetConnect failed(%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
		strStatus.Format(_T("���Ӱ��ƻƺ�ʧ�ܣ�error code = %u"), GetLastError());
		pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
		InternetCloseHandle(hInternetSession);
		hInternetSession = NULL;
		pDlg->ThreadExit();
		return 0;
	}

	if (pDlg->m_bUpload) {
		//pDlg->GetDlgItem(IDC_UPLOAD)->SetWindowText(_T("ֹͣ(&T)"));
		//pDlg->GetDlgItem(IDC_UPLOAD)->EnableWindow(TRUE);
		pDlg->GetDlgItem(IDOK)->EnableWindow(FALSE);

	}

	if (dwUtmpNum == 0 && dwUtmpKey == 0) {
		strUserName = pDlg->m_strUserName;
		strStatus = _T("��ʼ��¼...");
		pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

//		const TCHAR *sAccept = _T("*/*");
		hHttpRequest = HttpOpenRequest(
		                   hConnect,
		                   _T("POST"),
		                   strObject,
		                   _T("1.1"),
		                   NULL,
		                   NULL,
		                   0,
		                   0
		               );

		if (hHttpRequest == NULL) {
			TRACE(_T("HttpOpenRequest failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			strStatus.Format(_T("������ʧ�ܣ�error code = %u"), GetLastError());
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		if (pDlg->m_bThreadExit) {
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		bRet = FALSE;

		CString strPsw = pDlg->m_strPassWord;
		DecodePassword(strPsw);
		strPostData.Format(_T("id=%s&pw=%s&Submit.x=17&Submit.y=56"), strUserName, strPsw);
		//strPostData = _T("id=shd&pw=%21@%23%24%25%5E%26*%28%29&Submit.x=17&Submit.y=56\r\n");
		int nPostDataLen = strPostData.GetLength();
		strRequest.Format(
		    _T("Accept: */*\r\n")
		    _T("Accept-Language: zh-cn\r\n")
		    _T("Content-Type: application/x-www-form-urlencoded\r\n")
		    _T("Accept-Encoding: gzip, deflate\r\n")
		    _T("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\r\n")
		    _T("Host: bbs.whnet.edu.cn\r\n")
		    _T("Content-Length: %d\r\n")
		    _T("Connection: Keep-Alive\r\n")
		    _T("Cache-Control: no-cache\r\n"), nPostDataLen);			//		-- ���һ��\r\n��API�Զ�����


		bRet = HttpSendRequest(hHttpRequest, strRequest, -1, (LPVOID) strPostData.GetBuffer(nPostDataLen), nPostDataLen);
		strPostData.ReleaseBuffer();

		if (bRet == FALSE) {
			TRACE(_T("HttpSendRequest failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			strStatus.Format(_T("��������ʧ�ܣ�error code = %u"), GetLastError());
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		if (pDlg->m_bThreadExit) {
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		// �����ȡ����������Ӧ
		DWORD dwBytesRead = 0;

		bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);

		buf[dwBytesRead] = '\0';

		strResponse = buf;

		while (bRet && dwBytesRead != 0) {
			bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
			buf[dwBytesRead] = '\0';
			strResponse += (TCHAR*) buf;
		}

		if (pDlg->m_bThreadExit) {
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		//TRACE(strResponse + _T("\n"));
		// �����������������Ӧ
		DWORD dwSize = sizeof(dwStatus);

		bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

		if (bRet == FALSE || dwStatus != 200) {
			TRACE(_T("HttpQueryInfo failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			strStatus.Format(_T("��ѯ������״̬ʧ�ܣ�error code = %u"), GetLastError());
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		InternetCloseHandle(hHttpRequest);

		if (pDlg->m_bThreadExit) {
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		nStart = strResponse.Find(_T("document.cookie='utmpnum="));

		if (nStart == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		// ���ҵ�һ��nutmpnum
		nStart += _tcslen(_T("document.cookie='utmpnum="));

		nEnd = strResponse.Find(_T("\'"), nStart);

		if (nEnd == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		dwUtmpNum = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpnum"), strResponse.Mid(nStart, nEnd - nStart));
		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpuserid"), _T("guest"));
		nStart = strResponse.Find(_T("document.cookie='utmpkey="), nEnd);

		if (nStart == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		nStart += _tcslen(_T("document.cookie='utmpkey="));

		nEnd = strResponse.Find(_T("\'"), nStart);

		if (nEnd == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		dwUtmpKey = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpkey"), strResponse.Mid(nStart, nEnd - nStart));

		nStart = strResponse.Find(_T("document.cookie='utmpnum="), nEnd);

		if (nStart == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		nStart += _tcslen(_T("document.cookie='utmpnum="));

		nEnd = strResponse.Find(_T("\'"), nStart);

		if (nEnd == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		dwUtmpNum = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpnum"), strResponse.Mid(nStart, nEnd - nStart));
		nStart = strResponse.Find(_T("document.cookie='utmpkey="), nEnd);

		if (nStart == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		nStart += _tcslen(_T("document.cookie='utmpkey="));

		nEnd = strResponse.Find(_T("\'"), nStart);

		if (nEnd == -1) {
			TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			strStatus.Format(_T("�û������������"));
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			InternetCloseHandle(hConnect);
			hConnect = NULL;
			InternetCloseHandle(hInternetSession);
			hInternetSession = NULL;
			pDlg->ThreadExit();
			return 0;
		}

		dwUtmpKey = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpuserid"), strUserName);
		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("utmpkey"), strResponse.Mid(nStart, nEnd - nStart));
		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("my_t_lines"), _T(""));
		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("my_link_mode"), _T(""));
		InternetSetCookie("http://bbs.whnet.edu.cn/", _T("my_def_mode"), _T(""));
		// ��¼�ɹ���
		strStatus = _T("��¼�ɹ�");
		pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
	}

	if (pDlg->m_bThreadExit) {
		Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
		dwUtmpNum = 0, dwUtmpKey = 0;
		InternetCloseHandle(hConnect);
		hConnect = NULL;
		InternetCloseHandle(hInternetSession);
		hInternetSession = NULL;
		pDlg->ThreadExit();
		return 0;
	}

	//CUploadAttDlg Dlg;
	//_tcscpy(Dlg.sUrl, _T("http://bbs.whnet.edu.cn/cgi-bin/bbsupload?board=Picture"));
	//if (Dlg.DoModal() == IDOK) {
	//	return 1;
	//}

	if (pDlg->m_bUpload) {
		// ����ֱ�ӽ����ϴ�ҳ��
		CString strBoard;
		strBoard = pDlg->m_strBoardName;

		// ���濪ʼ�ϴ��ļ�
		CString strLocalFile;
		//CStdioFile tmpFile;
		//tmpFile.Open(_T("temp.txt"), CFile::modeCreate | CFile::modeReadWrite);
		//tmpFile.WriteString(_T("�����Ǳ����ϴ��õ������ӣ�\n"));

		for (int i = 0; i < 1; i++) {	//pDlg->m_astrFilesUpload.GetSize(); i ++)	//һ�ν��ϴ�ʹ�õ����ļ�
			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			strLocalFile = pDlg->m_strLocalFile ;	//->m_astrFilesUpload.GetAt(i);
			strStatus.Format(_T("��ʼ�ϴ��ļ� %s ..."), strLocalFile);
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			strObject = _T("/cgi-bin/bbsdoupload");
			hHttpRequest = HttpOpenRequest(
			                   hConnect,
			                   _T("POST"),
			                   strObject,
			                   _T("1.1"),
			                   NULL,
			                   NULL,
			                   INTERNET_FLAG_NO_CACHE_WRITE,
			                   0
			               );
			// debug: http://bbs.whnet.edu.cn/cgi-bin/bbsupload?board=Picture

			if (hHttpRequest == NULL) {
				TRACE(_T("HttpOpenRequest failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("������ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			CFile file;

			if (!file.Open(strLocalFile, CFile::modeRead | CFile::shareDenyNone)) {
				TRACE(_T("Open File failed\n"));
				strStatus.Format(_T("�򿪱����ļ� %s ʧ�ܣ�error code = %u"), strLocalFile, GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// �ȹ���POST���ݣ��Լ���Content-Length
			CString strBoundary;		// �߽��ַ���

			//GenBoundary(strBoundary);
			strBoundary = _T("-----------------------------7d42bf2da035e");
			//CHANGE BY GCSer����������Ӧ���������ģ�ԭ��������--
			strPostData.Format(
			    _T("--%s\r\n")
			    _T("Content-Disposition: form-data; name=\"up\"; filename=\"%s\"\r\n")
			    _T("Content-Type: application/octet-stream\r\n\r\n"), strBoundary, strLocalFile);

			CString strPostData2;	// �ϴ��ļ�ʱPOST ���ݵĵڶ����֣��м�Ҫ����ʵ�ʵ��ļ�����

			// ע�����ļ����ݺ󣬻�Ӧ�ý���һ��\r\n�����԰����ŵ��ڶ����ֵ�POST���ݵ���ǰ��
			//CHANGE BY GCSer����������Ӧ���������ģ�ԭ��������--�������м���Contentƴ���ˡ�����
			strPostData2.Format(
			    _T("\r\n--%s\r\n")
			    _T("Content-Disposition: form-data; name=\"MAX_FILE_SIZE\"\r\n\r\n5000000\r\n")
			    _T("--%s\r\n")
			    _T("Content-Disposition: form-data; name=\"board\"\r\n\r\n%s\r\n")
			    _T("--%s\r\n")
			    _T("Content-Disposition: form-data; name=\"live\"\r\n\r\n%d\r\n")
			    _T("--%s\r\n")
			    _T("Content-Disposition: form-data; name=\"exp\"\r\n\r\n%s\r\n")
			    _T("--%s--\r\n"), strBoundary, strBoundary, strBoard, strBoundary, pDlg->m_nLiveTime,
			    strBoundary, pDlg->m_strDescription, strBoundary);

			DWORD dwContentLen = strPostData.GetLength() + file.GetLength() + strPostData2.GetLength();

			strRequest.Format(
			    _T("Accept: */*\r\n")
			    _T("Referer: http://bbs.whnet.edu.cn/cgi-bin/bbsupload?board=%s\r\n")
			    _T("Accept-Language: zh-cn\r\n")
			    _T("Content-Type: multipart/form-data; boundary=%s\r\n")
			    _T("Accept-Encoding: gzip, deflate\r\n")
			    _T("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\r\n")
			    _T("Host: bbs.whnet.edu.cn\r\n")
			    _T("Content-Length: %d\r\n")
			    _T("Connection: Keep-Alive\r\n")
			    _T("Cache-Control: no-cache\r\n")
			    _T("Cookie: utmpnum=%d; utmpuserid=%s; utmpkey=%u; my_t_lines=; my_link_mode=; my_def_mode=\r\n\r\n"),
			    strBoard, strBoundary, dwContentLen, dwUtmpNum, strUserName, dwUtmpKey);

			TRACE(strRequest + _T("\n"));

			TRACE(strPostData + _T("\n"));

			TRACE(strPostData2 + _T("\n"));

			INTERNET_BUFFERS BufferIn;

			BufferIn.dwStructSize = sizeof(INTERNET_BUFFERS);    // Must be set or error will occur

			BufferIn.Next = NULL;

			BufferIn.lpcszHeader = strRequest;

			BufferIn.dwHeadersLength = strRequest.GetLength();

			BufferIn.dwHeadersTotal = 0;

			BufferIn.lpvBuffer = NULL;

			BufferIn.dwBufferLength = 0;

			BufferIn.dwBufferTotal = dwContentLen; // This is the only member used other than dwStructSize

			BufferIn.dwOffsetLow = 0;

			BufferIn.dwOffsetHigh = 0;

			if (!HttpSendRequestEx(hHttpRequest, &BufferIn, NULL, 0, 0)) {
				TRACE(_T("Error on HttpSendRequestEx %d\n"), GetLastError());
				strStatus.Format(_T("�����ļ��ϴ�����ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// ������������ļ����ݵ�
			DWORD dwBytesWritten = 0;

			bRet = InternetWriteFile(hHttpRequest, (LPVOID)(LPCTSTR) strPostData, strPostData.GetLength(), &dwBytesWritten);

			if (bRet == FALSE) {
				TRACE(_T("InternetWriteFile failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("��������ϴ�����ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				HttpEndRequest(hHttpRequest, NULL, 0, 0);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// �����ļ�����
			DWORD dwTotalSend = strPostData.GetLength();
			memset(buf, 0, 4096);
			DWORD dwBytesRead = file.Read(buf, 4096);	//�ļ��ϴ���һ��
			bRet = InternetWriteFile(hHttpRequest, buf, dwBytesRead, &dwBytesWritten);	// !!!
			dwTotalSend += dwBytesWritten;
			strStatus.Format(_T("�ϴ����ȣ�%d%%"), dwTotalSend * 100 / dwContentLen);
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			while (bRet && dwBytesWritten) {	//�ļ��ֶ��ϴ�
				dwBytesRead = file.Read(buf, 4096);
				if (dwBytesRead == 0) {
					break;
				}
				bRet = InternetWriteFile(hHttpRequest, buf, dwBytesRead, &dwBytesWritten);
				dwTotalSend += dwBytesWritten;
				strStatus.Format(_T("�ϴ����ȣ�%d%%"), dwTotalSend * 100 / dwContentLen);
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			}

			if (!bRet) {
				TRACE(_T("InternetWriteFile failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("��������ϴ�����ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				HttpEndRequest(hHttpRequest, NULL, 0, 0);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// ����������Ϣ
			bRet = InternetWriteFile(hHttpRequest, (LPVOID)(LPCTSTR) strPostData2, strPostData2.GetLength(), &dwBytesWritten);

			if (bRet == FALSE) {
				TRACE(_T("InternetWriteFile failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("��������ϴ�����ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				HttpEndRequest(hHttpRequest, NULL, 0, 0);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			strStatus = _T("�ϴ����ȣ�100%");

			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			if (!HttpEndRequest(hHttpRequest, NULL, 0, 0)) {
				TRACE(_T("Error on HttpEndRequest %lu \n"), GetLastError());
				strStatus.Format(_T("�����������������ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// ���շ���������Ӧ
			strStatus = _T("���շ�������Ӧ...");
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			dwBytesRead = 0;
			bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
			buf[dwBytesRead] = '\0';
			strResponse.Empty();
			strResponse = buf; 			
			//tmpFile.WriteString( strResponse );	//debug

			while (bRet && dwBytesRead != 0) {
				bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
				buf[dwBytesRead] = '\0';
				strResponse += (TCHAR*) buf;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// �����������������Ӧ
			dwStatus = 0;

			DWORD dwSize = sizeof(dwStatus);

			bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

			if (bRet == FALSE || dwStatus != 200) {
				TRACE(_T("HttpQueryInfo failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("��ѯ������״̬ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			InternetCloseHandle(hHttpRequest);
			
			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			// ����������ص�����
			//TRACE(strResponse + _T("\n"));
			//nStart = strResponse.Find(_T("url="));
			nStart = strResponse.Find(_T(">http://"));//CHANGE BY GCSer ��Ϊ�����������ҳ�������仯
/*	char *r1, *r2, *r3, *r4;
	r1 = strstr(temp_str, ">http")+1;	
	if (r1 != NULL) {
		r2 = strstr(r1, " <");
		_tcsncpy(url_str, r1, r2-r1);
		url_str[r2-r1]='\0';
		m_szResultURL = m_szResultURL+ url_str + "\n";
	}
*/
			if (nStart == -1) {
				TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
				nStart = strResponse.Find(_T("<br>"));
				strStatus = (_T("�ϴ��ļ�ʧ�ܣ�"));
				strStatus += strResponse.Left(nStart);
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			nStart += _tcslen(_T(">"));//CHANGE BY GCSer ��Ϊ�����������ҳ�������仯

			nEnd = strResponse.Find(_T(" "), nStart);//CHANGE BY GCSer ��Ϊ�����������ҳ�������仯

			if (nEnd == -1) {
				TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
				nStart = strResponse.Find(_T("<br>"));
				strStatus = (_T("�ϴ��ļ�ʧ�ܣ�"));
				strStatus += strResponse.Left(nStart);
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}
			/*CHANGE BY GCSer ��Ϊ�����������ҳ�������仯�����԰����ע�͵��ˣ��������������һ��
			strObject = _T("/cgi-bin/");

			strObject += strResponse.Mid(nStart, nEnd - nStart);
			strObject.Replace(_T("\r\n"), _T(""));*/

			CString strResult =  strResponse.Mid(nStart, nEnd - nStart);//CHANGE BY GCSer��strResult��������Ҫ���ָ��û��ģ��ϴ��ɹ�����������ɵ�URL��ַ��

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				//tmpFile.Close();
				//CFile::Remove(_T("temp.txt"));
				return 0;
			}

			//CHANGE BY GCSer ��Ϊ�����������ҳ�������仯��������Щ���붼����Ҫ�ˡ�������
			//// ���濪ʼ���󷵻��ϴ��ļ����ӵ�ҳ��
			//strStatus = _T("��ȡ�������ɵ�����...");

			//pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			//hHttpRequest = HttpOpenRequest(
			//                   hConnect,
			//                   _T("GET"),
			//                   strObject,
			//                   _T("1.1"),
			//                   NULL,
			//                   NULL,
			//                   0,
			//                   0
			//               );

			//if (hHttpRequest == NULL) {
			//	TRACE(_T("HttpOpenRequest failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//if (pDlg->m_bThreadExit) {
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hHttpRequest);
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//strRequest.Format(

			//    _T("Accept: */*\r\n")
			//    _T("Accept-Language: zh-cn\r\n")
			//    _T("Accept-Encoding: gzip, deflate\r\n")
			//    _T("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\r\n")
			//    _T("Host: bbs.whnet.edu.cn\r\n")
			//    _T("Connection: Keep-Alive\r\n")
			//    _T("Cookie: utmpnum=%d; utmpuserid=%s; utmpkey=%u; my_t_lines=; my_link_mode=; my_def_mode=\r\n"),
			//    dwUtmpNum, strUserName, dwUtmpKey);
			//bRet = HttpSendRequest(hHttpRequest, strRequest, -1, NULL, 0);

			//if (bRet == FALSE) {
			//	TRACE(_T("HttpSendRequest failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			//	strStatus.Format(_T("���������������ʧ�ܣ�error code = %u"), GetLastError());
			//	pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hHttpRequest);
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//if (pDlg->m_bThreadExit) {
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hHttpRequest);
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//// �����ȡ�����ļ����ӵ�ҳ��
			//dwBytesRead = 0;

			//bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);

			//buf[dwBytesRead] = '\0';

			//strResponse.Empty();

			//strResponse = buf;

			//while (bRet && dwBytesRead != 0) {
			//	bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
			//	buf[dwBytesRead] = '\0';
			//	strResponse += (TCHAR*) buf;
			//}

			//if (pDlg->m_bThreadExit) {
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hHttpRequest);
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//// �����������������Ӧ
			//dwStatus = 0;

			//dwSize = sizeof(dwStatus);

			//bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

			//if (bRet == FALSE || dwStatus != 200) {
			//	TRACE(_T("HttpQueryInfo failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			//	strStatus.Format(_T("��ѯ������״̬ʧ�ܣ�error code = %u"), GetLastError());
			//	pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hHttpRequest);
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//InternetCloseHandle(hHttpRequest);

			//if (pDlg->m_bThreadExit) {
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//// ����������ص�����
			////TRACE(strResponse + _T("\n"));
			//nStart = strResponse.Find(_T("�������سɹ�, URLΪ "));

			//if (nStart == -1) {
			//	TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			//	nStart = strResponse.Find(_T("����"));
			//	strStatus = (_T("�ϴ��ļ�ʧ�ܣ�"));

			//	if (nStart != -1) {
			//		nEnd = strResponse.Find(_T("<br>"), nStart);

			//		if (nEnd != -1) {
			//			strStatus += strResponse.Mid(nStart, nEnd - nStart);
			//		} else {
			//			strStatus += _T("δ֪����");
			//		}
			//	}

			//	pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//nStart += _tcslen(_T("�������سɹ�, URLΪ "));

			//nEnd = strResponse.Find(_T("<br>"), nStart);

			//if (nEnd == -1) {
			//	TRACE(_T("Can not found key words in response, line %d\n"), __LINE__);
			//	nStart = strResponse.Find(_T("<br>"));
			//	strStatus = (_T("�ϴ��ļ�ʧ�ܣ�"));
			//	strStatus += strResponse.Left(nStart);
			//	pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
			//	Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
			//	dwUtmpNum = 0, dwUtmpKey = 0;
			//	InternetCloseHandle(hConnect);
			//	hConnect = NULL;
			//	InternetCloseHandle(hInternetSession);
			//	hInternetSession = NULL;
			//	pDlg->ThreadExit();
			//	tmpFile.Close();
			//	CFile::Remove(_T("temp.txt"));
			//	return 0;
			//}

			//CString strResult = strResponse.Mid(nStart, nEnd - nStart);

			////ȥ��HTML��ʽ��
			//nStart = strResult.Find('<');

			//while (nStart != -1) {   //ȥ���������η�_T("<"))��_T(">")����
			//	nEnd = strResult.Find('>', nStart);

			//	if (nEnd != -1) {
			//		strResult.Delete(nStart, nEnd - nStart + 1);
			//	}

			//	nStart = strResult.Find('<');
			//}

			//strResult.TrimLeft();

			//strResult.TrimRight();
			//// ȥ��URL�еİ���ȶ�����Ϣ
			//nStart = strResult.Find(_T("&"));

			//if (nStart != -1) {
			//	strResult = strResult.Left(nStart);
			//}

			strStatus.Format(_T("�ϴ��ļ� %s �ɹ���"), strLocalFile);
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			TRACE(_T("�ϴ��ɹ����ļ�����Ϊ��\n%s\n"), strResult);
			
			strStatus.Format (_T("�ļ����ӣ�%s"), strResult);
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
						
			//tmpFile.WriteString(strResult + _T("\n"));
			pDlg->m_strUploadURLs += strResult;
			pDlg->m_strUploadURLs += _T("\r\n");

		}

		//tmpFile.Close();
		//WinExec(_T("notepad.exe temp.txt"), SW_SHOW);		//debug
		//CFile::Remove(_T("temp.txt"));	//debug
	} else {
		// ɾ���ļ�
		CString strRemoteFile;

		for (int i = 0; i < pDlg->m_astrFilesDelete.GetSize(); i ++) {
			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				return 0;
			}

			strRemoteFile = pDlg->m_astrFilesDelete.GetAt(i);

			strStatus.Format(_T("��ʼɾ���ļ� %s ..."), strRemoteFile);
			pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);

			strObject.Format(_T("/cgi-bin/bbsudel?file=%s"), strRemoteFile);
			hHttpRequest = HttpOpenRequest(
			                   hConnect,
			                   _T("GET"),
			                   strObject,
			                   _T("1.1"),
			                   NULL,
			                   NULL,
			                   INTERNET_FLAG_NO_CACHE_WRITE,
			                   0
			               );

			if (hHttpRequest == NULL) {
				TRACE(_T("HttpOpenRequest failed (%s line(%d), error = %d\n"), GetLastError(), __FILE__, __LINE__);
				strStatus.Format(_T("������ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				return 0;
			}

			if (pDlg->m_bThreadExit) {
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				return 0;
			}

			strRequest.Format(

			    _T("Accept: */*\r\n")
			    //_T("http://bbs.whnet.edu.cn/cgi-bin/bbsfdoc?board=Abroad\r\n")
			    _T("Accept-Language: zh-cn\r\n")
			    _T("Accept-Encoding: gzip, deflate\r\n")
			    _T("User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\r\n")
			    _T("Host: bbs.whnet.edu.cn\r\n")
			    _T("Connection: Keep-Alive\r\n")
			    _T("Cookie: utmpnum=%d; utmpuserid=%s; utmpkey=%u; my_t_lines=; my_link_mode=; my_def_mode=\r\n"),
			    dwUtmpNum, strUserName, dwUtmpKey);

			bRet = HttpSendRequest(hHttpRequest, strRequest, -1, NULL, 0);

			if (bRet == FALSE) {
				TRACE(_T("Logout failed, HttpSendRequest error = %d\n"), GetLastError());
				strStatus.Format(_T("����ɾ������ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				return 0;
			}

			// �����ȡ����������Ӧ
			BYTE buf[4096];			// ���ݻ�����

			DWORD dwBytesRead = 0;

			bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);

			buf[dwBytesRead] = '\0';

			strResponse = buf;

			while (bRet && dwBytesRead != 0) {
				bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
				buf[dwBytesRead] = '\0';
				strResponse += (TCHAR*) buf;
			}

			DWORD dwStatus = 0;

			DWORD dwSize = sizeof(dwStatus);
			bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

			if (bRet == FALSE || dwStatus != 200) {
				TRACE(_T("HttpQueryInfo error = %d\n"), GetLastError());
				strStatus.Format(_T("��ѯ������״̬ʧ�ܣ�error code = %u"), GetLastError());
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
				Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
				dwUtmpNum = 0, dwUtmpKey = 0;
				InternetCloseHandle(hHttpRequest);
				InternetCloseHandle(hConnect);
				hConnect = NULL;
				InternetCloseHandle(hInternetSession);
				hInternetSession = NULL;
				pDlg->ThreadExit();
				return 0;
			}

			InternetCloseHandle(hHttpRequest);

			// �����������������Ӧ
			nStart = strResponse.Find(_T("����"));

			if (nStart == -1) {
				// ɾ���ɹ�,Refresh��ʾҪˢ�µ�ǰҳ��
				strStatus.Format(_T("�ɹ�ɾ���ļ� %s"), strRemoteFile);
				pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
			} else {
				// �ӷ�������ȡ������Ϣ
				nEnd = strResponse.Find(_T("<br>"), nStart);

				if (nEnd != -1) {
					strStatus = strResponse.Mid(nStart, nEnd - nStart);
					pDlg->SendMessage(WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
				}
			}
		}
	}

	if (!pDlg->m_bContinuously || !pDlg->m_bUpload) {
		// ע����¼
		Logout(hConnect, dwUtmpNum, dwUtmpKey, strUserName);
		dwUtmpNum = 0, dwUtmpKey = 0;
		// �ɹ�����ϴ�����
		InternetCloseHandle(hConnect);
		hConnect = NULL;
		InternetCloseHandle(hInternetSession);
		hInternetSession = NULL;
	}


	pDlg->ThreadExit();

	pDlg->m_bSucceed = TRUE;

	return 0;
}


// �������е������ַ����д���
// �����ַ����� `~!#$%^&()+=|\{}[];:'",<>?/
void DecodePassword(CString &strPsw)
{
	TCHAR key[] = {_T("%`~!#$^&()+=|\\{}[];:\'\",<>?/") };		// �ٷֺŷŵ���ǰ�棬���⽫�Ѿ�����İٷֺ��ٴα���
	CString strKey, strTemp;

	for (unsigned int i = 0; i < _tcslen(key); i ++) {
		strKey = key[i];
		strTemp.Format(_T("%%%02x"), key[i]);
		strPsw.Replace(strKey, strTemp);
	}

	strTemp.Replace(' ', '+');
}

void Logout(HINTERNET hConnect, DWORD dwUtmpNum, DWORD dwUtmpKey, CString strUser)
{
	CString strStatus = _T("��ʼע����¼...");
	::SendMessage(AfxGetMainWnd()->m_hWnd, WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
	CString strObject = _T("/cgi-bin/bbslogout");
	CString strRequest;
	HINTERNET hHttpRequest = HttpOpenRequest(
	                             hConnect,
	                             _T("GET"),
	                             strObject,
	                             _T("1.1"),
	                             NULL,
	                             NULL,
	                             0,
	                             0
	                         );

	if (hHttpRequest == NULL) {
		TRACE(_T("Logout failed, HttpOpenRequest error = %d\n"), GetLastError());
		strStatus.Format(_T("��ע������ʧ�ܣ�error code = %u"), GetLastError());
		::SendMessage(AfxGetMainWnd()->m_hWnd, WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
		return ;
	}

	BOOL bRet = FALSE;

	strRequest.Format(
	    _T("Accept: */*\r\n\
	       Referer: http://bbs.whnet.edu.cn/cgi-bin/bbsfoot\r\n\
	       Accept-Language: zh-cn\r\n\
	       Accept-Encoding: gzip, deflate\r\n\
	       User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.0)\r\n\
	       Host: bbs.whnet.edu.cn\r\n\
	       Connection: Keep-Alive\r\n\
	       Cookie: utmpnum=%d; utmpuserid=%s; utmpkey=%u; my_t_lines=; my_link_mode=; my_def_mode=\r\n"),
	    dwUtmpNum, strUser, dwUtmpKey);

	bRet = HttpSendRequest(hHttpRequest, strRequest, -1, NULL, 0);

	if (bRet == FALSE) {
		TRACE(_T("Logout failed, HttpSendRequest error = %d\n"), GetLastError());
		strStatus.Format(_T("����ע������ʧ�ܣ�error code = %u"), GetLastError());
		::SendMessage(AfxGetMainWnd()->m_hWnd, WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
		InternetCloseHandle(hHttpRequest);
		return ;
	}

	// �����ȡ����������Ӧ
//	BYTE buf[4096];			// ���ݻ�����
//	DWORD dwBytesRead = 0;
//	bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
//	buf[dwBytesRead] = '\0';
//	//strResponse = buf;
//	while(bRet && dwBytesRead != 0)
//	{
//		bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
//		//buf[dwBytesRead] = '\0';
//		//strResponse += buf;
//	}
	// �����������������Ӧ
	DWORD dwStatus = 0;

	DWORD dwSize = sizeof(dwStatus);

	bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

	if (bRet == FALSE || dwStatus != 200) {
		TRACE(_T("HttpQueryInfo error = %d\n"), GetLastError());
		strStatus.Format(_T("��ѯ������״̬ʧ�ܣ�error code = %u"), GetLastError());
		::SendMessage(AfxGetMainWnd()->m_hWnd, WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
		InternetCloseHandle(hHttpRequest);
		return ;
	}

	InternetCloseHandle(hHttpRequest);

	strStatus = _T("�ɹ�ע����");
	::SendMessage(AfxGetMainWnd()->m_hWnd, WM_STATUS_CHANGED, (WPARAM)(LPCTSTR) strStatus, 0);
}

/*CHANGE BY GCSer ��Ϊ�ǲ��ԣ�����UUID�ƺ���������ȱ��ͷ�ļ����߿��ļ������±���ʧ�ܣ����Ծ�ֱ�Ӹ�ע�͵��ˡ�
// ���ɱ߽��ַ���
void GenBoundary(CString &strBoundary)
{
	//Automatically generate a unique boundary separator for this body part by creating a guid
	UUID uuid;
	UuidCreate(&uuid);

	//Convert it to a string
#ifdef _UNICODE
	TCHAR* pszGuid = NULL;
#else
	unsigned char* pszGuid = NULL;
#endif
	UuidToString(&uuid, &pszGuid);

	strBoundary = pszGuid;

	//Free up the temp memory
	RpcStringFree(&pszGuid);
}
*/