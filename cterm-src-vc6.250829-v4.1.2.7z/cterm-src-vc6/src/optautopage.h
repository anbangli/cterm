#if !defined(AFX_OPTAUTOPAGE_H__435197A4_BDD2_47EA_A537_191D918CA493__INCLUDED_)
#define AFX_OPTAUTOPAGE_H__435197A4_BDD2_47EA_A537_191D918CA493__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptAutoPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptAutoPage dialog
#include "MyPropertyPage.h"

class COptAutoPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptAutoPage)

// Construction

public:
	CString m_wavefile;
	COptAutoPage();
	~COptAutoPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(COptAutoPage)
	enum { IDD = IDD_OPT_AUTO };
	CEdit	m_editReplyMSG;
	BOOL	m_bAntiIdle;
	int		m_nAutoLeave;
	UINT	m_IdleTime;
	CString	m_ReplyMsg;
	BOOL	m_bMsgRec;
	BOOL	m_bPlayWav;
	BOOL	m_bPopup;
	CString	m_sAntiIdleStr;
	BOOL	m_bPopupOnMsg;
	BOOL	m_bAutoLockBBS;
	BOOL	m_bBeepWhenMsg;
	BOOL	m_bBeepWhenMail;
	BOOL	m_bMinWhenLeave;
	CString	m_mailsnd;
	BOOL	m_bAutoReply;

	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptAutoPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

private:
	// Generated message map functions
	//{{AFX_MSG(COptAutoPage)
	afx_msg void OnAntiidle();
	afx_msg void OnCheckAutolockbbs();
	virtual BOOL OnInitDialog();
	afx_msg void OnAutoreply();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void Init();
	void UnInit();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTAUTOPAGE_H__435197A4_BDD2_47EA_A537_191D918CA493__INCLUDED_)
