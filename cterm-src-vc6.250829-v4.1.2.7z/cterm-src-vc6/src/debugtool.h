#if !defined(AFX_DEBUGTOOL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_)
#define AFX_DEBUGTOOL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_

//#define _DEBUG_RELEASE //temply
CString ESCStr(const CString &s);
//void AnsiLog(const tstring &str);

#if defined(_DEBUG) || defined(_DEBUG_RELEASE)
extern CString g_sDebugInfo; //_T ( "temp\\debuginfo.txt" )

void dumpBuf(const TCHAR *buf, const int nLen, TCHAR *filename);
void TraceF(TCHAR s[]);
void TraceF(int n, TCHAR *s = _T(""));
void TraceFHex(int n, TCHAR *s = _T(""));

#define TRACEF(s) TraceF((s))
#define TRACEFINT(n) TraceF((n))
#define TRACEFINTS(s,n) TraceF((n),(s))
#define TRACEFHEXS(s,n) TraceFHex((n),(s))

#else

#define TRACEF(s)
#define TRACEFINT(n)
#define TRACEFINTS(s,n)
#define TRACEFHEXS(s,n)

#endif // defined(_DEBUG) || defined(_DEBUG_RELEASE)

#endif // !defined(AFX_DEBUGTOOL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_)
