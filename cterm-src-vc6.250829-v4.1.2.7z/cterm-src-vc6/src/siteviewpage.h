#if !defined(AFX_SITEVIEWPAGE_H__FC1E037F_0764_49F0_85BC_DB75BD649F93__INCLUDED_)
#define AFX_SITEVIEWPAGE_H__FC1E037F_0764_49F0_85BC_DB75BD649F93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteViewPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteViewPage dialog

class CSiteViewPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteViewPage)

// Construction

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CSiteViewPage();
	~CSiteViewPage();
	virtual UINT GetIDD();


//	CFont Font[4];
	bool m_bChange;

// Dialog Data
	//{{AFX_DATA(CSiteViewPage)
	enum { IDD = IDD_SITE_FONT };
//	int		m_nFontSize;
	BOOL	m_bFixFont;
//	int		m_nCharHWRatio;
	BOOL	m_bNotMono;
	BOOL	m_bBold;
	CString m_sFont;
	CString	m_sEFont;
	int		m_nFixedSize;
	BOOL    m_bClearSigna;
	BOOL	m_bBlackList;
	CString	m_sBlackList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteViewPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	CToolTipCtrl m_tooltip;
	// Generated message map functions
	//{{AFX_MSG(CSiteViewPage)
	virtual BOOL OnInitDialog();
//	afx_msg void OnSong();
//	afx_msg void OnHei();
//	afx_msg void OnKai();
//	afx_msg void OnWinfont();
	afx_msg void OnSelFont();
	afx_msg void OnSelFont2();
//	afx_msg void OnFixedsys();
//	afx_msg void OnKillfocusFontname();
	afx_msg void OnCheckMono();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITEVIEWPAGE_H__FC1E037F_0764_49F0_85BC_DB75BD649F93__INCLUDED_)
