// SetSheet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"       // main symbols

#include "SetSheet.h"
#include "MyPropertyPage.h"

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetSheet

//int CSetSheet::m_nLastTab = 0; // ���ܷ�����������������Կ���໥Ӱ��

IMPLEMENT_DYNAMIC(CSetSheet, CPropertySheet)

CSetSheet::CSetSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
		: CPropertySheet(nIDCaption, pParentWnd, iSelectPage),
		m_pLastTabIndex(NULL)
{
}

CSetSheet::CSetSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
		: CPropertySheet(pszCaption, pParentWnd, iSelectPage),
		m_pLastTabIndex(NULL)
{
}

CSetSheet::~CSetSheet()
{
}


BEGIN_MESSAGE_MAP(CSetSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CSetSheet)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetSheet message handlers

BOOL CSetSheet::OnInitDialog()
{
	BOOL bResult = CPropertySheet::OnInitDialog();
#if ENABLE_MULTILANG
//    g_SetDialogStrings(this,IDD);
#endif// ENABLE_MULTILANG

	m_psh.dwFlags |= PSH_NOAPPLYNOW;

#if ENABLE_MULTILANG

	if (g_currLangID != ID_LANG1) {
		int total = GetPageCount();
		CTabCtrl *pTab = GetTabControl();

		if (pTab) {
			int i;

			for (i = 0; i < total; i++) {
				CString sTitle;
				CString szKey;
				szKey.Format(_T("IDD%d_Title"), ((CMyPropertyPage *) GetPage(i))->GetIDD());

				if (GetPrivateProfileString(_T("Dialog"), szKey, _T(""),
				                            sTitle.GetBuffer(20), 20, g_szLanguagePath) != 0) {
					TC_ITEM item;
					item.mask = TCIF_TEXT;
					item.pszText = sTitle.LockBuffer();
					//_tcscpy ( item.pszText, sTitle );
					pTab->SetItem(i, &item);
					sTitle.UnlockBuffer();
				}
			}
		}
	}

#endif// ENABLE_MULTILANG

//	if (m_pLastTabIndex && *m_pLastTabIndex >= 0 && *m_pLastTabIndex < GetPageCount())
//		SetActivePage(*m_pLastTabIndex);

	return bResult;
}

BOOL CSetSheet::OnEraseBkgnd(CDC* pDC)
{
	CRect rect;
	GetClientRect(&rect);
	CPropertySheet::OnEraseBkgnd(pDC);
	pDC->DrawIcon(rect.left + 2, rect.bottom - 34, AfxGetApp()->LoadIcon(IDI_SITE_PROPERITY));
	return TRUE;
}

//DEL void CSetSheet::OnApplyNow()
//DEL {
//DEL 	Default();
//DEL 	//AfxMessageBox(_T("you pressed ID_APPLY_NOW"));
//DEL 	//CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
//DEL 	//CView* pView = pFrameWnd->GetActiveFrame()->GetActiveView();
//DEL 	//pView->SendMessage(WM_USER_CHANGE_OBJECT_PROPERTIES, 0, 0);
//DEL 	//m_stylePage.SetModified(FALSE);
//DEL 	//m_colorPage.SetModified(FALSE);
//DEL 	SendMessage(PSM_CANCELTOCLOSE);
//DEL }

void CSetSheet::AddPage(CMyPropertyPage* pPage)
{
	CPropertySheet::AddPage(pPage);
}

BOOL CSetSheet::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if (m_pLastTabIndex)
	{
		*m_pLastTabIndex = GetActiveIndex();
	}
	
	return CPropertySheet::OnCommand(wParam, lParam);
}

