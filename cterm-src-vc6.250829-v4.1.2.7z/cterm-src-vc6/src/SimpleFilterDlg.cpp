// SimpleFilterDlg.cpp : implementation file
// �������Ի���

#include "stdafx.h"
#include "resource.h"       // main symbols
#include "TelnetSite.h"

#include "SimpleFilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSimpleFilterDlg dialog
#if ENABLE_FILTER

CSimpleFilterDlg::CSimpleFilterDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CSimpleFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSimpleFilterDlg)
	m_bBreak  = FALSE;
	m_index   = _T("");
	m_reply   = _T("");
	m_pFilter = NULL;
	//}}AFX_DATA_INIT

	m_nType = ST_FIREBIRD;
}


void CSimpleFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSimpleFilterDlg)
	DDX_Control(pDX, IDC_DELETE, m_delete);
	DDX_Control(pDX, IDC_FILTER_LIST, m_list);
	DDX_Check(pDX, IDC_BREAK, m_bBreak);
	DDX_Text(pDX, IDC_INDEX_STR, m_index);
	DDV_MaxChars(pDX, m_index, 19);
	DDX_Text(pDX, IDC_REPLY_STR, m_reply);
	DDV_MaxChars(pDX, m_reply, 19);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSimpleFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CSimpleFilterDlg)
	ON_NOTIFY(NM_CLICK, IDC_FILTER_LIST, OnClickFilterList)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_BN_CLICKED(IDC_UP, OnUp)
	ON_BN_CLICKED(IDC_DOWN, OnDown)
	ON_BN_CLICKED(IDC_SETDEFAULT, OnSetdefault)
	ON_BN_CLICKED(IDC_MODIFY, OnModify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSimpleFilterDlg message handlers

BOOL CSimpleFilterDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


	/*	if(m_pFilter==NULL)
			return FALSE;*/

	if (!m_Image.Create(IDB_FILTERS, 16, 2, RGB(0, 255, 0)))
		return FALSE;

#if ENABLE_BTNST
	m_delete.SetFlat(0);

	//m_delete.SetIcon(IDI_DELETE);
#endif//ENABLE_BTNST

	CRect rect;
	m_list.GetClientRect(rect);
	int totalWidth = rect.Width();

	m_list.InsertColumn(0, _T("������"), LVCFMT_LEFT, totalWidth/2);

	m_list.InsertColumn(1, _T("����"), LVCFMT_LEFT, totalWidth/2);

	if (m_pFilter == NULL) CDialog::OnOK();

	m_list.SetImageList(&m_Image, LVSIL_SMALL);

	UpdateList();

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSimpleFilterDlg::UpdateList()
{
	int i, at;
	m_list.DeleteAllItems();

	if (m_pFilter->nNum > MAX_FILTER_NUM) m_pFilter->nNum = MAX_FILTER_NUM;

	for (i = 0; i < m_pFilter->nNum; i++) {
		at = m_list.InsertItem(i, m_pFilter->Filter[i].szIndexStr, (m_pFilter->Filter[i].bBreak) ? 1 : 0);

		if (at >= 0) {
			m_list.SetItemData(at, (DWORD) &m_pFilter->Filter[i]);
			m_list.SetItemText(at, 1, m_pFilter->Filter[i].szReply);
		}
	}
}

void CSimpleFilterDlg::OnClickFilterList(NMHDR* pNMHDR, LRESULT* pResult)
{
	UpdateItemDisplay();
	*pResult = 0;
}

void CSimpleFilterDlg::UpdateItemDisplay()
{
	int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;
	SOneSimpleFilter *pFilter;

	if (pos >= 0) {
		pFilter = (SOneSimpleFilter  *) m_list.GetItemData(pos);
		m_index = pFilter->szIndexStr;
		m_reply = pFilter->szReply;
		m_bBreak = pFilter->bBreak;
		UpdateData(FALSE);
	}
}

void CSimpleFilterDlg::OnDelete()
{
	int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;

	if (pos >= 0) {
		m_pFilter->Delete(pos);
		UpdateList();
		//m_list.SetSelectionMark(0); // not work
		if (pos >= m_list.GetItemCount()) pos = 0;
		m_list.SetItem(pos, 0, LVIF_STATE, NULL, 0, LVIS_SELECTED, LVIS_SELECTED, 0);
		m_list.SetFocus();
		UpdateItemDisplay();
	}
}

// add a filter
void CSimpleFilterDlg::OnOK()
{
	UpdateData();

	if (!m_index.IsEmpty()) {
		m_pFilter->Add(m_index.LockBuffer(), m_reply.LockBuffer(), m_bBreak);
		m_index.UnlockBuffer(); m_reply.UnlockBuffer();
		UpdateList();
	}
}

void CSimpleFilterDlg::OnUp()
{
	int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;
	int nState = m_list.GetItemState(pos, 0xff);
	SOneSimpleFilter *pFilter, Filterbak;

	if (pos >= 1) {
		pFilter = (SOneSimpleFilter  *) m_list.GetItemData(pos);
		memcpy(&Filterbak, pFilter, sizeof(SOneSimpleFilter));
		memcpy(pFilter, (BYTE *) m_list.GetItemData(pos - 1), sizeof(SOneSimpleFilter));
		memcpy((BYTE *) m_list.GetItemData(pos - 1), &Filterbak, sizeof(SOneSimpleFilter));
		UpdateList();
		//m_list.SetSelectionMark(pos);
		m_list.SetItemState(pos - 1, nState, 0xff);
	}
}

void CSimpleFilterDlg::OnDown()
{
	int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;
	int nState = m_list.GetItemState(pos, 0xff);
	SOneSimpleFilter *pFilter, Filterbak;

	if (pos >= 0 && pos < m_pFilter->nNum - 1) {
		pFilter = (SOneSimpleFilter  *) m_list.GetItemData(pos);
		memcpy(&Filterbak, pFilter, sizeof(SOneSimpleFilter));
		memcpy(pFilter, (BYTE *) m_list.GetItemData(pos + 1), sizeof(SOneSimpleFilter));
		memcpy((BYTE *) m_list.GetItemData(pos + 1), &Filterbak, sizeof(SOneSimpleFilter));
		UpdateList();
		m_list.SetItemState(pos + 1, nState, 0xff);
	}
}

void CSimpleFilterDlg::OnSetdefault()
{
	if (MessageBox(_T("���Ҫ�����ǰ���й��������ָ�Ĭ��������"),
			_T("������"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
		m_pFilter->SetDefaultFilter(m_nType);
		UpdateList();
	}
}

void CSimpleFilterDlg::OnModify() 
{
	UpdateData();

	if (!m_index.IsEmpty()) {
		int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;
		
		if (pos >= 0) {
			m_pFilter->Modify(m_index.LockBuffer(), m_reply.LockBuffer(), m_bBreak, pos);
			m_index.UnlockBuffer(); m_reply.UnlockBuffer();
			UpdateList();
		}
	}
}
#endif//ENABLE_FILTER
