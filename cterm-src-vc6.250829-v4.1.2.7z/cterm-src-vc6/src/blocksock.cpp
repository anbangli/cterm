// blocksock.cpp (CBlockingSocketException, CBlockingSocket, CHttpBlockingSocket)
#include "stdafx.h"
#include "blocksock.h"

// Class CBlockingSocketException
IMPLEMENT_DYNAMIC(CBlockingSocketException, CException)

CBlockingSocketException::CBlockingSocketException(TCHAR* pchMessage)
{
	m_strMessage = pchMessage;
	m_nError = WSAGetLastError();
}

BOOL CBlockingSocketException::GetErrorMessage(LPTSTR lpstrError, UINT nMaxError,
        PUINT pnHelpContext /*= NULL*/)
{
	TCHAR text[200];

	if (m_nError == 0) {
		_stprintf(text, _T("%s ����"), (const TCHAR*) m_strMessage);
	} else {
		_stprintf(text, _T("%s ���� #%d"), (const TCHAR*) m_strMessage, m_nError);
	}

	_tcsncpy(lpstrError, text, nMaxError - 1);

	return TRUE;
}

// Class CBlockingSocket
IMPLEMENT_DYNAMIC(CBlockingSocket, CObject)

void CBlockingSocket::Cleanup()
{
	// doesn't throw an exception because it's called in a catch block
	if (m_hSocket == NULL) return;

	VERIFY(closesocket(m_hSocket) != SOCKET_ERROR);

	m_hSocket = NULL;
}

void CBlockingSocket::Create(int nType /* = SOCK_STREAM */)
{
	ASSERT(m_hSocket == NULL);

	if ((m_hSocket = socket(AF_INET, nType, 0)) == INVALID_SOCKET) {
		throw new CBlockingSocketException(_T("����"));
	}
}

void CBlockingSocket::Bind(LPCSOCKADDR psa)
{
	ASSERT(m_hSocket != NULL);

	if (bind(m_hSocket, psa, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("��"));
	}
}

void CBlockingSocket::Listen()
{
	ASSERT(m_hSocket != NULL);

	if (listen(m_hSocket, 5) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("����"));
	}
}

BOOL CBlockingSocket::Accept(CBlockingSocket& sConnect, LPSOCKADDR psa)
{
	ASSERT(m_hSocket != NULL);
	ASSERT(sConnect.m_hSocket == NULL);
	int nLengthAddr = sizeof(SOCKADDR);
	sConnect.m_hSocket = accept(m_hSocket, psa, &nLengthAddr);

	if (sConnect == INVALID_SOCKET) {
		// no exception if the listen was canceled
		if (WSAGetLastError() != WSAEINTR) {
			throw new CBlockingSocketException(_T("����"));
		}

		return FALSE;
	}

	return TRUE;
}

void CBlockingSocket::Close()
{
	ASSERT(m_hSocket != NULL);

	if (closesocket(m_hSocket) == SOCKET_ERROR) {
		// should be OK to close if closed already
		throw new CBlockingSocketException(_T("�ر�"));
	}

	m_hSocket = NULL;
}

void CBlockingSocket::Connect(LPCSOCKADDR psa)
{
	ASSERT(m_hSocket != NULL);
	// should timeout by itself

	if (connect(m_hSocket, psa, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("����"));
	}
}

int CBlockingSocket::Write(const char* pch, const int nSize, const long nSecs, const long tv_usec /*= 0*/)
{
	int nBytesSent = 0;
	int nBytesThisTime;
	const char* pch1 = pch;

	do {
		nBytesThisTime = Send(pch1, nSize - nBytesSent, nSecs, tv_usec);
		nBytesSent += nBytesThisTime;
		pch1 += nBytesThisTime;
	} while (nBytesSent < nSize);

	return nBytesSent;
}

int CBlockingSocket::Send(const char* pch, const int nSize, const long nSecs, const long tv_usec /*= 0*/)
{
	ASSERT(m_hSocket != NULL);
	// returned value will be less than nSize if client cancels the reading
	FD_SET fd = {1, m_hSocket};
	TIMEVAL tv = {nSecs, tv_usec};

	if (select(0, NULL, &fd, NULL, &tv) == 0) {
		throw new CBlockingSocketException(_T("���ͳ�ʱ"));
	}

	int nBytesSent;

	if ((nBytesSent = send(m_hSocket, pch, nSize, 0)) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("����"));
	}

	return nBytesSent;
}

//#ifdef _DEBUG
//	extern DWORD g_piclasttick;
//#endif //_DEBUG
int CBlockingSocket::Receive(char* pch, const int nSize, const long nSecs, const long tv_usec /*= 0*/)
{
	ASSERT(m_hSocket != NULL);
	FD_SET fd = {1, m_hSocket};
	TIMEVAL tv = {nSecs, tv_usec};

//#ifdef _DEBUG
//	DWORD tick = GetTickCount();
//	TRACE(_T("in CBlockingSocket::Receive 1 nSecs=%ld, tv_usec=%ld\n"), nSecs, tv_usec);
//	TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick-g_piclasttick);
//	g_piclasttick = tick;
//#endif //_DEBUG

	if (select(0, &fd, NULL, NULL, &tv) == 0) {
//#ifdef _DEBUG
//	tick = GetTickCount();
//	TRACE(_T("in CBlockingSocket::Receive 2 select timeout\n"));
//	TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick-g_piclasttick);
//	g_piclasttick = tick;
//#endif //_DEBUG
		throw new CBlockingSocketException(_T("���ճ�ʱ"));
	}

//#ifdef _DEBUG
//	tick = GetTickCount();
//	TRACE(_T("in CBlockingSocket::Receive 3 selected\n"));
//	TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick-g_piclasttick);
//	g_piclasttick = tick;
//#endif //_DEBUG

	int nBytesReceived;

	if ((nBytesReceived = recv(m_hSocket, pch, nSize, 0)) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("����"));
	}

	return nBytesReceived;
}

int CBlockingSocket::ReceiveDatagram(char* pch, const int nSize, LPSOCKADDR psa, const long nSecs, const long tv_usec /*= 0*/)
{
	ASSERT(m_hSocket != NULL);
	FD_SET fd = {1, m_hSocket};
	TIMEVAL tv = {nSecs, tv_usec};

	if (select(0, &fd, NULL, NULL, &tv) == 0) {
		throw new CBlockingSocketException(_T("���ճ�ʱ"));
	}

	// input buffer should be big enough for the entire datagram
	int nFromSize = sizeof(SOCKADDR);

	int nBytesReceived = recvfrom(m_hSocket, pch, nSize, 0, psa, &nFromSize);

	if (nBytesReceived == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("�������ݱ�"));
	}

	return nBytesReceived;
}

int CBlockingSocket::SendDatagram(const char* pch, const int nSize, LPCSOCKADDR psa, const long nSecs, const long tv_usec /*= 0*/)
{
	ASSERT(m_hSocket != NULL);
	FD_SET fd = {1, m_hSocket};
	TIMEVAL tv = {nSecs, tv_usec};

	if (select(0, NULL, &fd, NULL, &tv) == 0) {
		throw new CBlockingSocketException(_T("���ͳ�ʱ"));
	}

	int nBytesSent = sendto(m_hSocket, pch, nSize, 0, psa, sizeof(SOCKADDR));

	if (nBytesSent == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("�������ݱ�"));
	}

	return nBytesSent;
}

void CBlockingSocket::GetPeerAddr(LPSOCKADDR psa)
{
	ASSERT(m_hSocket != NULL);
	// _getts the address of the socket at the other end
	int nLengthAddr = sizeof(SOCKADDR);

	if (getpeername(m_hSocket, psa, &nLengthAddr) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("��öԷ�����"));
	}
}

void CBlockingSocket::GetSockAddr(LPSOCKADDR psa)
{
	ASSERT(m_hSocket != NULL);
	// _getts the address of the socket at this end
	int nLengthAddr = sizeof(SOCKADDR);

	if (getsockname(m_hSocket, psa, &nLengthAddr) == SOCKET_ERROR) {
		throw new CBlockingSocketException(_T("����׽���"));
	}
}

//static
CSockAddr CBlockingSocket::GetHostByName(const char* pchName, const USHORT ushPort /* = 0 */)
{
	hostent* pHostEnt = gethostbyname(pchName);

	if (pHostEnt == NULL) {
		throw new CBlockingSocketException(_T("���������"));
	}

	ULONG* pulAddr = (ULONG*) pHostEnt->h_addr_list[0];

	SOCKADDR_IN sockTemp;
	sockTemp.sin_family = AF_INET;
	sockTemp.sin_port = htons(ushPort);
	sockTemp.sin_addr.s_addr = *pulAddr; // address is already in network byte order
	return sockTemp;
}

//static
const char* CBlockingSocket::GetHostByAddr(LPCSOCKADDR psa)
{
	hostent* pHostEnt = gethostbyaddr(
	                        (char*) & ((LPSOCKADDR_IN) psa)->sin_addr.s_addr,
	                        4, PF_INET);

	if (pHostEnt == NULL) {
		throw new CBlockingSocketException(_T("ͨ����ַ���������"));
	}

	return pHostEnt->h_name; // caller shouldn't delete this memory
}

// Class CHttpBlockingSocket
IMPLEMENT_DYNAMIC(CHttpBlockingSocket, CBlockingSocket)

CHttpBlockingSocket::CHttpBlockingSocket()
{
	m_pReadBuf = new char[nSizeRecv];
	m_nReadBuf = 0;
}

CHttpBlockingSocket::~CHttpBlockingSocket()
{
	delete [] m_pReadBuf;
}

int CHttpBlockingSocket::ReadHttpHeaderLine(char* pch, const int nSize, const long nSecs, const long tv_usec /*= 0*/)
// reads an entire header line through CRLF (or socket close)
// inserts zero string terminator, object maintains a buffer
{
	int nBytesThisTime = m_nReadBuf;
	int nLineLength = 0;
	char* pch1 = m_pReadBuf;
	char* pch2;

	do {
		// look for lf (assume preceded by cr)
		if ((pch2 = (char*) memchr(pch1 , '\n', nBytesThisTime)) != NULL) {
			//ASSERT((pch2) > m_pReadBuf);
			//ASSERT(*(pch2 - 1) == '\r');		//-- ��ȡ�����а�,�ϴ�С�ٺϵĻ��о�Ȼ��\n������\r\n
			nLineLength = (pch2 - m_pReadBuf) + 1;

			if (nLineLength >= nSize) nLineLength = nSize - 1;

			memcpy(pch, m_pReadBuf, nLineLength);    // copy the line to caller

			m_nReadBuf -= nLineLength;

			memmove(m_pReadBuf, pch2 + 1, m_nReadBuf);    // shift remaining characters left

			break;
		}

		pch1 += nBytesThisTime;

		nBytesThisTime = Receive(m_pReadBuf + m_nReadBuf, nSizeRecv - m_nReadBuf, nSecs, tv_usec);

		if (nBytesThisTime <= 0) {   // sender closed socket or line longer than buffer
			throw new CBlockingSocketException(_T("��ȡ��Ӧͷ"));
		}

		m_nReadBuf += nBytesThisTime;
	} while (TRUE);

	* (pch + nLineLength) = '\0';

	return nLineLength;
}

int CHttpBlockingSocket::ReadHttpResponse(char* pch, const int nSize, const long nSecs, const long tv_usec /*= 0*/)
// reads remainder of a transmission through buffer full or socket close
// (assume headers have been read already)
{
	// ԭ���뽫�����Ѿ����յ����ֽ�ȫ���������˽��ջ������������û���Ҫ�����ֽ�
	/*int nBytesToRead, nBytesThisTime, nBytesRead = 0;
	if(m_nReadBuf > 0) { // copy anything already in the recv buffer
		memcpy(pch, m_pReadBuf, m_nReadBuf);
		pch += m_nReadBuf;
		nBytesRead = m_nReadBuf;
		m_nReadBuf = 0;
	}
	do { // now pass the rest of the data directly to the caller
		nBytesToRead = min(nSizeRecv, nSize - nBytesRead);
		nBytesThisTime = Receive(pch, nBytesToRead, nSecs, tv_usec);
		if(nBytesThisTime <= 0) break; // sender closed the socket
		pch += nBytesThisTime;
		nBytesRead += nBytesThisTime;
	}
	while(nBytesRead <= nSize);*/

	// Hendy�޸�����:
	int nBytesToRead, nBytesThisTime, nBytesRead = 0;

	if (m_nReadBuf > 0) {   // copy anything already in the recv buffer
		if (m_nReadBuf >= nSize) {
			memcpy(pch, m_pReadBuf, nSize);
			nBytesRead = nSize;
			m_nReadBuf -= nSize;
			memmove(m_pReadBuf, m_pReadBuf + nSize, m_nReadBuf);
			return nBytesRead;
		} else {
			memcpy(pch, m_pReadBuf, m_nReadBuf);
			pch += m_nReadBuf;
			nBytesRead = m_nReadBuf;
			m_nReadBuf = 0;
		}
	}

	do { // now pass the rest of the data directly to the caller
		nBytesToRead = min(nSizeRecv, nSize - nBytesRead);
		nBytesThisTime = Receive(pch, nBytesToRead, nSecs, tv_usec);

		if (nBytesThisTime <= 0) break;   // sender closed the socket

		pch += nBytesThisTime;

		nBytesRead += nBytesThisTime;
	} while (nBytesRead < nSize);			//ע����������������Ѿ�û�����ݶ��㻹Ҫȥ��,�ͻ���ֳ�ʱ����,��˲���ʹ�� <=

	return nBytesRead;
}

// ���ý��ջ�����,��ʹ������������
void CHttpBlockingSocket::ResetRecvBuffer()
{
	memset(m_pReadBuf, 0 , nSizeRecv);
	m_nReadBuf = 0;
}

void LogBlockingSocketException(LPVOID pParam, TCHAR* pch, CBlockingSocketException* pe)
{
	// pParam holds the HWND for the destination window (in another thread)
	CString strGmt = CTime::GetCurrentTime().FormatGmt(_T("%m/%d/%y %H:%M:%S GMT"));
	TCHAR text1[200], text2[50];
	pe->GetErrorMessage(text2, 49);
	wsprintf(text1, _T("WINSOCK ����--%s %s -- %s\r\n"), pch, text2, (const TCHAR*) strGmt);
	::SendMessage((HWND) pParam, EM_SETSEL, (WPARAM) 65534, 65535);
	::SendMessage((HWND) pParam, EM_REPLACESEL, (WPARAM) 0, (LPARAM) text1);
}
