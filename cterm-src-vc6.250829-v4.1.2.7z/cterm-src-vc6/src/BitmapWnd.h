#if !defined(AFX_BITMAPWND_H__9B42A740_049E_11D4_B1CF_000080013F30__INCLUDED_)
#define AFX_BITMAPWND_H__9B42A740_049E_11D4_B1CF_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BitmapWnd.h : header file

/////////////////////////////////////////////////////////////////////////////
// CBitmapWnd window

class CBitmapWnd : public CWnd
{
// Construction

public:
	CBitmapWnd();
// Attributes

public:
// Operations

public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBitmapWnd)

protected:
	//}}AFX_VIRTUAL

// Implementation

public:
	virtual ~CBitmapWnd();

	// Generated message map functions

protected:
	//{{AFX_MSG(CBitmapWnd)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BITMAPWND_H__9B42A740_049E_11D4_B1CF_000080013F30__INCLUDED_)
