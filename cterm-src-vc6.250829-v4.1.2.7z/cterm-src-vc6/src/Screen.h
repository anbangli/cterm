// Screen.h: interface for the CScreen class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCREEN_H__1956AF52_ABD5_451B_8311_8A9C94FBB458__INCLUDED_)
#define AFX_SCREEN_H__1956AF52_ABD5_451B_8311_8A9C94FBB458__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <deque>
#include "const.h"

class CScreen;
struct SOneChar;
class CScreen
{
public:
	CScreen();
	~CScreen(); //final, non-virtual 

public:
	bool Init(int nScrnWidth = DEFAULT_TERM_WIDTH,
		int nScrnHeight = DEFAULT_TERM_HEIGHT,
		int nMaxHistLine = DEFAULT_TERM_HEIGHT);
	// ȡ��ָ��[]����д lineֻ��
	SOneChar *operator[](int y) const;
	const SOneChar *line(int y) const;

#ifdef _DEBUG
	void touched(); // �����Ļ�Ƿ��쳣��д
	void dumpScreen(void);
#endif //_DEBUG

#if ENABLE_SCREENMAP
	void dumpScreen(FILE * fp) const;
	void load(FILE * fp, int scrnNum);
#endif//ENABLE_SCREENMAP

public:
	inline bool IsInited() const
	{
		return m_bInited;
	}

	inline bool Changed(const int i) const
	{
		if (m_bInited && m_nMaxLine - m_nMaxHistLine < i && 0 <= i && i <= m_nMaxLine) {
			const CTermLine *pLine = m_Lines[i % m_nMaxHistLine];
			if (pLine && pLine->buf()) {
				return pLine->Changed();
			}
		}
		return false;
	}
	
	inline void SetChange(const int i, bool b)
	{
		if (m_bInited && m_nMaxLine - m_nMaxHistLine < i && 0 <= i && i <= m_nMaxLine) {
			CScreen::CTermLine *pLine = m_Lines[i % m_nMaxHistLine];
			if (pLine && pLine->buf()) {
				pLine->SetChange(b);
			}
		}
	}

	void InsertLines(int start, int end, int n);
	void ScrollLines(int start, int end, int n);
	int GetNewLines(int y);

private:
	class CTermLine
	{
	public:
		CTermLine();
		~CTermLine();
		
		CTermLine(CString s);
		CTermLine(int len) {
			NewLine(len);
		}
		
		// Attributes
		
	public:
		//��δ�� int m_nLineNum; //�к�
		int m_nLineLen;
		//	int m_bLong;
		
		inline SOneChar *buf() const {
			return m_buf;
		}
		
	public:
		void ClearLine(int startx = 0, int endx = -1);

#if ENABLE_SCREENMAP
		void dumpLine(FILE * fp) const;
		void load(FILE * fp);
#endif//ENABLE_SCREENMAP
		
		inline bool Changed() const
		{
			return m_bChanged;
		}

		inline void SetChange(bool b)
		{
			m_bChanged = b;
		}
		
#ifdef _DEBUG
		void getStr(char *buf) const;
		
		static int total_line_id;
		int new_id; //�����ڴ�©����
#endif //_DEBUG

	private:
		inline void NewLine(int len);
		SOneChar *m_buf;	
	private:
		bool m_bChanged;
	};//class CTermLine
	
private:
	std::vector<CTermLine*> m_Lines;
	inline CScreen::CTermLine *CScreen::GetOneLine(int y);
	SOneChar &GetOneChar(int y, int x);

	void ShiftLines(int start, int end, int num);

private:
	bool m_bInited;
	int m_nMaxHistLine;

	std::deque<CTermLine*> m_linepool;

private:
	int m_nScrnHeight;// ÿ���߶�
	int m_nScrnWidth;// ÿ�п���
	int m_nMaxLine;

	static const CTermLine ErrorLine;
	static CTermLine RubbishLine;
};

#endif // !defined(AFX_SCREEN_H__1956AF52_ABD5_451B_8311_8A9C94FBB458__INCLUDED_)
