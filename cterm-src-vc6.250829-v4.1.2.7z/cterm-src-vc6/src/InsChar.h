#if !defined(AFX_INSCHAR_H__5B5BE652_3D7E_4BE2_B2E3_3C5AD7F01976__INCLUDED_)
#define AFX_INSCHAR_H__5B5BE652_3D7E_4BE2_B2E3_3C5AD7F01976__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InsChar.h : header file
//

#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CInsChar dialog

class CInsChar : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CInsChar)

// Construction
public:
	CInsChar();
	~CInsChar();

	CString GetStr();
// Dialog Data
	//{{AFX_DATA(CInsChar)
	enum { IDD = IDD_INSCHAR };
	CEdit	m_editctrl;
	CString	m_s;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CInsChar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CInsChar)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetfocusEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSCHAR_H__5B5BE652_3D7E_4BE2_B2E3_3C5AD7F01976__INCLUDED_)
