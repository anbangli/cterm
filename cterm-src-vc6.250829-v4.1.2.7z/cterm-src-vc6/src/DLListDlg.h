#if !defined(AFX_DLLISTDLG_H__1B8B9676_2F63_4956_976C_5D0B2EF80476__INCLUDED_)
#define AFX_DLLISTDLG_H__1B8B9676_2F63_4956_976C_5D0B2EF80476__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DLListDlg.h : header file

#include "autorun.h"

#define  DLS_SET         500
#define  DLS_SEARCH_NEXT 501
#define  DLS_COPY        502
/////////////////////////////////////////////////////////////////////////////
// CDLListDlg dialog

struct SDLCondition {	// ���ع���
	UINT nStart, nEnd;
	TCHAR cFlag;
	TCHAR szAuthor[22];
	TCHAR szTitle[2][100];
	int  m_bOr;
	BYTE nStartMonth, nStartDate;
	BYTE nEndMonth, nEndDate;
	int nAllPage;
};


struct SListContinue {	// ����
	SDLCondition Cond;
	int  nIndexFileAt;
	TCHAR szFile[300];
};

class CHTMLConvert;
class CDLListDlg : public CDialog
{
// Construction

public:
	CDLListDlg(CWnd* pParent = NULL);   // standard constructor

	~CDLListDlg();

	CAutoRun     m_Run;
// Dialog Data
	//{{AFX_DATA(CDLListDlg)
	enum { IDD = IDD_DL_LIST };
	CProgressCtrl	m_oneprog;
	CProgressCtrl	m_allprog;
	CString	m_cond;
	CString	m_destfile;
	CString	m_nNowDL;
	CString	m_author;
	int		m_EndDate;
	int		m_EndMonth;
	UINT	m_EndNum;
	CString	m_Flag;
	int		m_bOr;
	int		m_StartDate;
	int		m_StartMonth;
	UINT	m_StartNum;
	CString	m_Title1;
	CString	m_Title2;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLListDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	SDLCondition m_Condition;
	CHTMLConvert *m_pIndexPage, *m_pPage, *m_pBak;
	TCHAR  m_szLast[100];

	// Generated message map functions
	//{{AFX_MSG(CDLListDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnOK();
	afx_msg void OnBrowse();
	virtual void OnCancel();
	afx_msg void OnAdd();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void WriteLink(BOOL bLast = FALSE);
//	void CopyPicture();
	void AddList(SArticleList);
	int m_nNow;
	void SetAllProg(int nNow);
	void DLEnd();
	TCHAR m_szNextFile[300];
	TCHAR m_szPath[300];
	BOOL CreateIndexFile();
	void CopyArticle();
	void SearchNext();
	BOOL m_bAdd;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLLISTDLG_H__1B8B9676_2F63_4956_976C_5D0B2EF80476__INCLUDED_)
