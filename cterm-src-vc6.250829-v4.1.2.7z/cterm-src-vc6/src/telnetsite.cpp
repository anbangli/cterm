#include "stdafx.h"

#include "TelnetSite.h"

#if ENABLE_SITECONFIG
#include "SetSheet.h"
#include "SiteLoginpage.h"
#include "SiteDecodepage.h"
#include "Siteautopage.h"
#include "Siteproxypage.h"
#include "SiteColorPage.h"
#include "SiteViewPage.h"
//#include "SiteBlackListpage.h"
//#include "SiteIniPage.h"
#endif//ENABLE_SITECONFIG

#include "global.h"
#include "paramconfig.h"
#include "mainfrm.h"

//extern CString g_sAddrInfoFile;
//extern CString g_sCustomFontName;

// ���վ�ṹ���ַ�����Ա�е�������Ϣ
void CTelnetSite::StrClear()
{
	TCHAR ss[40];
//	_tcscpy(ss, _T("                                   "));
	_tcscpy(ss, m_Login.m_szSiteName);
	memset(m_Login.m_szSiteName, '\0', sizeof(m_Login.m_szSiteName));
	_tcscpy(m_Login.m_szSiteName, ss);

	_tcscpy(ss, m_Login.m_szAddr);
	memset(m_Login.m_szAddr, '\0', sizeof(m_Login.m_szAddr));
	_tcscpy(m_Login.m_szAddr, ss);

	_tcscpy(ss, m_Login.m_szLoginName);
	memset(m_Login.m_szLoginName, '\0', sizeof(m_Login.m_szLoginName));
	_tcscpy(m_Login.m_szLoginName, ss);

	_tcscpy(ss, m_Login.m_szLoginPSW);
	memset(m_Login.m_szLoginPSW, '\0', sizeof(m_Login.m_szLoginPSW));
	_tcscpy(m_Login.m_szLoginPSW, ss);

#if ENABLE_PROXY
	_tcscpy(ss, m_Login.m_szProxyAddr);
	memset(m_Login.m_szProxyAddr, '\0', sizeof(m_Login.m_szProxyAddr));
	_tcscpy(m_Login.m_szProxyAddr, ss);

	_tcscpy(ss, m_Login.m_szProxyName);
	memset(m_Login.m_szProxyName, '\0', sizeof(m_Login.m_szProxyName));
	_tcscpy(m_Login.m_szProxyName, ss);

	_tcscpy(ss, m_Login.m_szProxyPSW);
	memset(m_Login.m_szProxyPSW, '\0', sizeof(m_Login.m_szProxyPSW));
	_tcscpy(m_Login.m_szProxyPSW, ss);
#endif//ENABLE_PROXY
}

// ��֤վ�ṹ���ַ�����ԱΪ��Ч����ĩβ��Ϊ'\0'
// ������վ���ļ�������û����볤�ȳ�������ķǷ�����
// todo: SOneSimpleFilter, STelnetProxy�Ƚṹ����Ҳ�д�
BOOL SLoginSet::Validate()
{
	m_szSiteName[sizeof(m_szSiteName) - 1] = '\0';
	m_szAddr[sizeof(m_szAddr) - 1] = '\0';
	m_szLoginName[sizeof(m_szLoginName) - 1] = '\0';
	m_szLoginPSW[sizeof(m_szLoginPSW) - 1] = '\0';

#if ENABLE_FILTER
	if (m_AutoLogin.nNum > MAX_FILTER_NUM) m_AutoLogin.nNum = MAX_FILTER_NUM;
	m_AutoLogin.pLoginSet = this;
	m_AutoLogin.Restore();
#endif//ENABLE_FILTER

#if ENABLE_PROXY
	m_szProxyAddr[sizeof(m_szProxyAddr) - 1] = '\0';
	m_szProxyName[sizeof(m_szProxyName) - 1] = '\0';
	m_szProxyPSW[sizeof(m_szProxyPSW) - 1] = '\0';

	if (m_nProxyType < PT_NONE || m_nProxyType > PT_CTERM)
		m_nProxyType = PT_NONE;

#if ENABLE_FILTER
	m_TelnetProxy.Filter.pLoginSet = this; //21:54 2008-03-02 // todo: ������ܲ��ԣ��������ƺ�δ��
#endif//ENABLE_FILTER
#endif//ENABLE_PROXY

	return true;
}

//CTelnetSite::~CTelnetSite();
//{
//	if(m_pszFont)
//		delete m_pszFont;
//}

CTelnetSite &CTelnetSite::operator=(const CTelnetSite &site)
{
	memcpy(this, &site, sizeof(CTelnetSite));       //��ʱ�ģ������Ա����ĳ���ṹʹ���˶�̬�ڴ棬����Ҫ����֮
//	m_pszFont = new CString( *site.m_pszFont );

	//���е�ָ��������������validate, setdefault�ȴ�����Ҫ�ر�����
	//Ŀ¼ֻ��������pLoginSet
#if ENABLE_FILTER
	m_Login.m_AutoLogin.pLoginSet = &m_Login;
#endif//ENABLE_FILTER

#if ENABLE_FILTER
	m_Login.m_TelnetProxy.Filter.pLoginSet = &m_Login;
#endif//ENABLE_FILTER
	return *this;
}

#define OLD_ADDRBOOK_VER 0xabcd4321
#ifdef _UNICODE
#define ADDRBOOK_VER 2
#else
#define ADDRBOOK_VER OLD_ADDRBOOK_VER //��unicode��Ŀǰ��OLD_ADDRBOOK_VER���ݣ��������
#endif

bool CTelnetSite::CopySite()
{
	HGLOBAL hmem;
	BYTE *p = NULL;
	
	const int addrbookver = ADDRBOOK_VER;
	const int selcount = 1;
	int size = sizeof(addrbookver) + sizeof(selcount) + sizeof(CTelnetSite) * selcount;
	hmem = GlobalAlloc(GMEM_FIXED, size);
	
	if (hmem == NULL) {
		CloseClipboard();
		AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
		return false;
	}
	
	p = (BYTE*) GlobalLock(hmem);

	if (p) {
		if (!OpenClipboard(g_pMainWnd->GetSafeHwnd())) {
			AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
		}
		else {
			* ((int*) p) = addrbookver;    // ��ַ���汾��
			p += sizeof(addrbookver);
			* ((int*) p) = selcount;    // ���Ƶ�վ�����
			p += sizeof(selcount);

			memcpy(p, (BYTE*)this, sizeof(CTelnetSite));
			
			EmptyClipboard();
			
			int CF_CTADDR = RegisterClipboardFormat(_T("Cterm_AddrBook"));
			SetClipboardData(CF_CTADDR, hmem);		// �� p ���Ƶ�������
			CloseClipboard();
			GlobalUnlock(hmem);

			return true;
		}
	}
	
	return false;
}

void CTelnetSite::SetDefault(CString sAddr, int nPort, int nType)
{
	_tcscpy(m_Login.m_szSiteName, sAddr);

	_tcscpy(m_Login.m_szAddr, sAddr);	// ��ַ
	CString proto;
	int port = GetPort(sAddr, proto);
	m_Login.m_nPort = (port != 0) ? port : nPort;   //�˿�

	m_Login.m_bSSH = (m_Login.m_nPort == SSH_PORT);
	m_Login.m_bIPv6 = 0;

	//m_Login.SetSiteType((proto.CompareNoCase(_T("telnet")) == 0) ? ST_NORMAL : nType);       // ����
	m_Login.m_nSiteType = ST_NORMAL;
	_tcscpy(m_Login.m_szTermType, "vt100");
	_tcscpy(m_Login.m_szWebURL, _T("http://"));		// Web��ַ
	_tcscat(m_Login.m_szWebURL, m_Login.m_szAddr);  // Web��ַ

	//m_Login.m_bSendEnter=TRUE;		// ���ͻس�

	_tcscpy(m_Login.m_szLoginName, _T(""));	// �û���
	_tcscpy(m_Login.m_szLoginPSW, _T(""));        // ����

#if ENABLE_FILTER
	m_Login.SetDefaultAutoLogin(m_Login.SiteType());	// �������ù�����
	m_Login.m_AutoLogin.pLoginSet = &m_Login;
#endif//ENABLE_FILTER

#if ENABLE_PROXY
	m_Login.m_nProxyType = PT_NONE;
	_tcscpy(m_Login.m_szProxyAddr, _T(""));
	m_Login.m_nProxyPort = TELNET_PORT;		//�����˿�
	m_Login.m_TelnetProxy.szEndSession[0] = 0;

	_tcscpy(m_Login.m_szProxyName, _T(""));
	_tcscpy(m_Login.m_szProxyPSW, _T(""));

#if ENABLE_FILTER
	m_Login.m_TelnetProxy.Filter.pLoginSet = &m_Login;
#endif//ENABLE_FILTER
#endif//ENABLE_PROXY

	m_Login.m_bAutoLogin = false;

//	m_pszFont=new CString(_T("SimSun"));

	m_Decode.SetDefaultDecode();		//	����(��ɫ)
	m_View.SetDefaultView();
}

void SDecodeSet::SetDefaultDecode()		//	����(��ɫ)
{
	m_nType = DT_CTERM;
	m_bEnterAsReturn = FALSE;
	m_bBsIsDel = false;
	m_bDelAsStop = false;
	m_nESCChar = 0;
	m_bDoubleCode = TRUE;		// ˫�ֽڴ�������
	m_nInputCodeConvert = INPUT_NONE;	//None
	m_nOutputCodeConvert = OUTPUT_NONE;	//GB

	m_bHiLightAlways = TRUE;
	
	m_nColorSetNum = 3;		// ��ɫ��������׼
	


//	// Ĭ����ɫ��ΪFTERM
//COLORREF	colorset[16] = { 8404992,
//	                         128,
//	                         32768,
//	                         32896,
//	                         8388608,
//	                         8388736,
//	                         8421376,
//	                         12632256,
//	                         8421504,
//	                         255,
//	                         65280,
//	                         65535,
//	                         16711680,
//	                         16711935,
//	                         16776960,
//	                         16777215
//	                       };
	COLORREF  colorset[16] = {
		RGB(0, 0, 0),
		RGB(128, 0, 0),
		RGB(0, 128, 0),
		RGB(128, 128, 0),
		RGB(0, 0, 128),
		RGB(128, 0, 128),
		RGB(0, 128, 128),
		RGB(192, 192, 192),
		RGB(128, 128, 128),
		RGB(255, 0, 0),
		RGB(0, 255, 0),
		RGB(255, 255, 0),
		RGB(0, 0, 255),
		RGB(255, 0, 255),
		RGB(0, 255, 255),
		RGB(255, 255, 255)
	};

	for (int i = 0; i < 16; i++)
		m_ColorSet[i] = colorset[i];

	m_BackColor = colorset[0];
}
void SViewSet::SetDefaultView()		//Ĭ�ϲ鿴
{
	_tcscpy(m_szFont, _T("SimSun"));	// ��������
	m_bNotMono = FALSE;    //�Ƿ� ���ȿ�
	_tcscpy(m_szEFont, _T("Courier New")); //Ӣ��������
	m_bBold = FALSE;       //�Ƿ����
	m_bFixed = FALSE;      //�Ƿ�̶��ֺ�
	m_nFixedSize = 16;  //�̶��ֺ�
	m_nCharHWRatio = 2; //���߱�
	MaxHistLine = 1024;   //�����ʷ����

	m_bClearSigna = FALSE;  //�Ƿ����ǩ����
	m_bBlackList= FALSE;  //�Ƿ����ú�����
	_tcscpy(m_szBlackList, _T("")); //������
}

/*
void CTelnetSite::GetVarString(CString VarName, CString defVal, CString &var, int maxlen)
{
	GetPrivateProfileString(m_Login.m_szSiteName, VarName, defVal, var.GetBuffer(maxlen), maxlen, g_sAddrInfoFile);
	var.ReleaseBuffer();
}

int CTelnetSite::GetVarInt(CString VarName, int defVal)
{
	return GetPrivateProfileInt(m_Login.m_szSiteName, VarName, defVal, g_sAddrInfoFile);
}

void CTelnetSite::SetVarString(CString VarName, CString Val)
{
	WritePrivateProfileString(m_Login.m_szSiteName, VarName, Val, g_sAddrInfoFile);
}

void CTelnetSite::SetVarInt(CString VarName, int Var)
{
	WritePrivateProfileInt(m_Login.m_szSiteName, VarName, Var, g_sAddrInfoFile);
}
*/

#if ENABLE_FILTER
void SLoginSet::SetDefaultAutoLogin(int nType)		// �Զ���¼֮��������Ĭ��ֵ
{
	//m_AutoLogin.SetDefaultFilter(nType);
	m_AutoLogin.SetDefaultFilter(-1);  //-1: �޹�����
	m_AutoLogin.pLoginSet = this;
}

#endif//ENABLE_FILTER

#if ENABLE_SITECONFIG
BOOL SetOneSite(CTelnetSite *pSite, int nActive) //����վ������
{
	if (pSite == NULL)	return FALSE;

	CTelnetSite TempSite;		// ��ʱվ���Ŀ����Ϊ��ȡ�������ֱ����pSite�Ļ�����ɫҳ���Զ���¼ҳ����ָ���޸�����������ȡ����

	TempSite = *pSite;			// ������ʱ����

	static int nLastTab = 0;
	CSetSheet Sheet(g_LoadString(IDS_SITESET), NULL, nLastTab);
	Sheet.m_psh.dwFlags |= PSH_NOAPPLYNOW;

	// ��ǰ��ʹ��ָ�봫�ݶ��󣬵��Ƿ��������⣬���Ը��ø�����������
	// ��¼ҳ
	CSiteLoginPage LoginPage;
	//LoginPage.m_pLogin=&TempSite.m_Login;
	LoginPage.m_sitename = TempSite.m_Login.m_szSiteName;
	LoginPage.m_siteaddr = TempSite.m_Login.m_szAddr;
	LoginPage.m_siteport = TempSite.m_Login.m_nPort;
	LoginPage.m_nProtocol = TempSite.m_Login.m_bSSH;    // Telnet / SSH
	LoginPage.m_bIPv6 = TempSite.m_Login.m_bIPv6;
	LoginPage.m_sitetype = TempSite.m_Login.SiteType();		//��������
	
	LoginPage.m_sTermType = _T(TempSite.m_Login.m_szTermType);	  //�ն�����
	LoginPage.m_sWebURL = _T(TempSite.m_Login.m_szWebURL);  //Web��ַ
	LoginPage.m_nTermWidth = TempSite.m_Login.m_nTermWidth;
	LoginPage.m_nTermHeight = TempSite.m_Login.m_nTermHeight;
	ValidateWH(LoginPage.m_nTermWidth, LoginPage.m_nTermHeight);
	
//LoginPage.m_bHttpUpload = TempSite.GetVarInt(_T("HttpUpload"), 0);

	// ����ҳ
	CSiteDecodePage DecodePage;
	DecodePage.m_nDecode = TempSite.m_Decode.m_nType ;
	DecodePage.m_bEnter = TempSite.m_Decode.m_bEnterAsReturn;
	DecodePage.m_bBsIsDel = TempSite.m_Decode.m_bBsIsDel; //.GetVarInt(_T("BsIsDel"), TempSite.m_Login.SiteType() == ST_NORMAL);
	DecodePage.m_bDelAsStop = TempSite.m_Decode.m_bDelAsStop;	// TempSite.GetVarInt(_T("DelAsStop"), FALSE);
	DecodePage.m_nEscChar = TempSite.m_Decode.m_nESCChar;  //^[    ^[^[    ^U
	DecodePage.m_bDouble = TempSite.m_Decode.m_bDoubleCode;
	DecodePage.m_nInputCodeInvert = TempSite.m_Decode.m_nInputCodeConvert;
	DecodePage.m_nOutputCodeInvert = TempSite.m_Decode.m_nOutputCodeConvert;

	//�Զ���¼
	CSiteAutoPage AutoLoginPage;		// �Զ���¼ҳ
	AutoLoginPage.m_pLogin = &TempSite.m_Login;
	AutoLoginPage.m_bAutoLogin = TempSite.m_Login.m_bAutoLogin;  //bool(TempSite.m_Login.m_bAutoLogin);
	AutoLoginPage.m_name = TempSite.m_Login.m_szLoginName;
	AutoLoginPage.m_psw = TempSite.m_Login.m_szLoginPSW;
	AutoLoginPage.m_nType = TempSite.m_Login.SiteType();  //������ʽ��¼վ�����ͣ���Ϊ�����ù�����ʱʹ��
	AutoLoginPage.m_bSSHbbsLogin = TempSite.m_Login.m_bSSHbbsLogin;

	// ����ҳ
	CSiteProxyPage    ProxyPage;		// ����ҳ
	ProxyPage.m_pLogin = &TempSite.m_Login;

	// ��ɫҳ
	CSiteColorPage ColorPage;
	ColorPage.m_nColorSet = TempSite.m_Decode.m_nColorSetNum;
	ColorPage.m_pDecode = &TempSite.m_Decode;
	for (int i = 0; i < 16; i++) {
		ColorPage.m_CustColor[i] = pSite->m_Decode.m_ColorSet[i];
	}

	// �鿴ҳ
	CSiteViewPage  ViewPage;

	//�������վ�����
	//TempSite.GetVarString(_T("Font"),
	//                      g_sFont.IsEmpty() ? TempSite.m_Decode.m_szFont : g_sFont,
	//                      ViewPage.m_font, MAXFONTNAME);
	ViewPage.m_sFont = TempSite.m_View.m_szFont;    //��������
	//if (ViewPage.m_font.IsEmpty()) ViewPage.m_font = _T("SimSun");
	ViewPage.m_bBold = TempSite.m_View.m_bBold;    //����
	ViewPage.m_bNotMono = TempSite.m_View.m_bNotMono;  // GetVarInt(_T("MONOSPACE"), g_bMONOSPACE);
	ViewPage.m_sEFont = TempSite.m_View.m_szEFont;  // GetVarString(_T("EFont"), "Courier New", ViewPage.m_eFont, MAXFONTNAME);
	ViewPage.m_bFixFont = TempSite.m_View.m_bFixed;	// GetVarInt(_T("FixFont"), g_bFixFont);
	ViewPage.m_nFixedSize = TempSite.m_View.m_nFixedSize;	// GetVarInt(_T("FixFontSize"), g_nFixFontSize);
	//ViewPage.m_nCharHWRatio = TempSite.GetVarInt(_T("CharHWRatio"), g_nCharHWRatio);
	//ViewPage.m_nCharHWRatio = 2; // ����������߱ȵ���
	ViewPage.m_bClearSigna = TempSite.m_View.m_bClearSigna;
	ViewPage.m_bBlackList = TempSite.m_View.m_bBlackList;
	ViewPage.m_sBlackList = _T(TempSite.m_View.m_szBlackList);	// = TempSite.GetVarInt(_T("bBlackList"), 0);

	//������ҳ
//	CSiteBlackListPage BlackListPage;
//	BlackListPage.m_bBlackList, TempSite.m_View.m_bBlackList;
//	BlackListPage.m_szBlackList = _T(TempSite.m_View.m_szBlackList);	// = TempSite.GetVarInt(_T("bBlackList"), 0);
	//TempSite.GetVarString(_T("BlackList"), _T(""), BlackListPage.m_szBlackList, 1024);

//	CSiteIniPage IniPage;

	Sheet.AddPage(&LoginPage);
	Sheet.AddPage(&DecodePage);
	Sheet.AddPage(&AutoLoginPage);
	Sheet.AddPage(&ProxyPage);
	Sheet.AddPage(&ColorPage);
	Sheet.AddPage(&ViewPage);

//	Sheet.AddPage(&BlackListPage);
//	Sheet.AddPage(&IniPage);

	Sheet.m_pLastTabIndex = &nLastTab;

	if (nActive >= 0 && nActive <= Sheet.GetPageCount()) {
		nLastTab = nActive;
		//Sheet.SetActivePage(nActive); // ��OnInitDialog()���ִ�е�
	}

	g_bHaveModalDlg = true;

	BOOL ret = FALSE;

	if (Sheet.DoModal() == IDOK) {
		// Set to Site..
		if (pSite) {
			//LoginPage
			//memcpy(&pSite->m_Login,&TempSite.m_Login,sizeof(SLoginSet));
			_tcscpy(pSite->m_Login.m_szAddr, (LPCTSTR) LoginPage.m_siteaddr);
			pSite->m_Login.m_nPort = LoginPage.m_siteport;
			pSite->m_Login.m_bSSH = LoginPage.m_nProtocol;
			pSite->m_Login.m_bIPv6 = LoginPage.m_bIPv6;
			pSite->m_Login.SetSiteType(LoginPage.m_sitetype);		// ��������
			
			_tcscpy(pSite->m_Login.m_szTermType, (LPCTSTR) LoginPage.m_sTermType);  //�ն�����
			_tcscpy(pSite->m_Login.m_szWebURL, (LPCTSTR) LoginPage.m_sWebURL);  //Web��ַ
			ValidateWH(LoginPage.m_nTermWidth, LoginPage.m_nTermHeight);
			pSite->m_Login.m_nTermWidth = LoginPage.m_nTermWidth;
			pSite->m_Login.m_nTermHeight = LoginPage.m_nTermHeight;


			// SDecodeSet �а�����ɫ�������������ȴ���ɫҳ�и������в�����Ȼ����ʹ�ý���ҳ�еĲ�����
			// ColorPage
			memcpy(&pSite->m_Decode, &TempSite.m_Decode, sizeof(SDecodeSet));

			// DecodePage
			//memcpy(&pSite->m_Decode,&TempSite.m_Decode,sizeof(SDecodeSet));
			pSite->m_Decode.m_nType = DecodePage.m_nDecode;			// Э��
			pSite->m_Decode.m_bEnterAsReturn = DecodePage.m_bEnter;	// �س�
			
			pSite->m_Decode.m_bBsIsDel = DecodePage.m_bBsIsDel; //.GetVarInt(_T("BsIsDel"), TempSite.m_Login.SiteType() == ST_NORMAL);
			pSite->m_Decode.m_bDelAsStop = DecodePage.m_bDelAsStop;	// TempSite.GetVarInt(_T("DelAsStop"), FALSE);
			pSite->m_Decode.m_nESCChar = DecodePage.m_nEscChar;

			pSite->m_Decode.m_bDoubleCode = DecodePage.m_bDouble;	// ���ִ���
			pSite->m_Decode.m_nInputCodeConvert = DecodePage.m_nInputCodeInvert;
			pSite->m_Decode.m_nOutputCodeConvert = DecodePage.m_nOutputCodeInvert;

			//TempSite.SetVarInt(_T("BsIsDel"), DecodePage.m_bBsIsDel);
			//TempSite.SetVarInt(_T("DelAsStop"), DecodePage.m_bDelAsStop);

			// AutoLoginPage
			pSite->m_Login.m_bAutoLogin = AutoLoginPage.m_bAutoLogin;
			_tcscpy(pSite->m_Login.m_szLoginName, (LPCTSTR) AutoLoginPage.m_name);
			_tcscpy(pSite->m_Login.m_szLoginPSW, (LPCTSTR) AutoLoginPage.m_psw);
			memcpy(&pSite->m_Login.m_AutoLogin, &TempSite.m_Login.m_AutoLogin, sizeof(CSimpleFilter));			
			pSite->m_Login.m_bSSHbbsLogin = AutoLoginPage.m_bSSHbbsLogin;
			//TempSite.SetVarInt(_T("SSHbbs"), AutoLoginPage.m_bSSHbbsLogin);

			//ProxyPage
			if (ProxyPage.m_bChange) {
				memcpy(&pSite->m_Login.m_TelnetProxy.Filter,
				       &ProxyPage.m_pLogin->m_TelnetProxy.Filter,
				       sizeof(CSimpleFilter));

				ASSERT(!(ProxyPage.m_type < PT_NONE || ProxyPage.m_type > PT_CTERM));
				pSite->m_Login.m_nProxyType = (ProxyType) ProxyPage.m_type;

				if (pSite->m_Login.m_nProxyType < PT_NONE || pSite->m_Login.m_nProxyType > PT_CTERM)
					pSite->m_Login.m_nProxyType = PT_NONE;

				_tcscpy(pSite->m_Login.m_szProxyAddr, ProxyPage.m_addr);

				pSite->m_Login.m_nProxyPort = ProxyPage.m_port;	//???

				_tcscpy(pSite->m_Login.m_szProxyName, ProxyPage.m_name);

				_tcscpy(pSite->m_Login.m_szProxyPSW, ProxyPage.m_psw);

				_tcscpy(pSite->m_Login.m_TelnetProxy.szEndSession, ProxyPage.m_endsession);
			}

			// �鿴ҳ
			//_tcsncpy(pSite->m_Decode.m_szFont, ViewPage.m_sFont, 32-1);
			_tcscpy(pSite->m_View.m_szFont, (LPCTSTR) ViewPage.m_sFont);
			pSite->m_View.m_bBold = ViewPage.m_bBold;
			pSite->m_View.m_bNotMono = ViewPage.m_bNotMono;
			_tcscpy(pSite->m_View.m_szEFont, ViewPage.m_sEFont);
			pSite->m_View.m_bFixed = ViewPage.m_bFixFont;	// GetVarInt(_T("FixFont"), g_bFixFont);
			pSite->m_View.m_nFixedSize = ViewPage.m_nFixedSize;	// GetVarInt(_T("FixFontSize"), g_nFixFontSize);


			//�������վ�����
			//TempSite.SetVarString(_T("Font"), ViewPage.m_font);
			//TempSite.SetVarInt(_T("BOLD"),ViewPage.m_bBold);
			//TempSite.SetVarInt(_T("MONOSPACE"), !ViewPage.m_bNotMono);
			//TempSite.SetVarString(_T("EFont"), ViewPage.m_eFont);
			//TempSite.SetVarInt(_T("FixFont"), ViewPage.m_bFixFont);
			//TempSite.SetVarInt(_T("FixFontSize"), ViewPage.m_nFontSize);
			
			//TempSite.SetVarInt(_T("CharHWRatio"), ViewPage.m_nCharHWRatio);
			//TempSite.SetVarInt(_T("HttpUpload"), LoginPage.m_bHttpUpload);
			
			pSite->m_View.m_bClearSigna = ViewPage.m_bClearSigna;
			pSite->m_View.m_bBlackList = ViewPage.m_bBlackList;		// �Ƿ����ú�����

			// ǰ������пո񣬲���ʵ���û�����ǰ�󶼴��ո񣩵ľ�ȷƥ��
			if (!ViewPage.m_sBlackList.IsEmpty()) {
				if (ViewPage.m_sBlackList[0] != ' ') {
					ViewPage.m_sBlackList = _T(" ") + ViewPage.m_sBlackList;
				}
				
				if (ViewPage.m_sBlackList[ViewPage.m_sBlackList.GetLength() - 1] != ' ') {
					ViewPage.m_sBlackList += ' ';
				}
			}
			_tcscpy(pSite->m_View.m_szBlackList, _T(ViewPage.m_sBlackList));	// ������ m_szBlackList
			//g_sCustomFontName = ViewPage.m_sFontName;		

			ret = TRUE;
		}
	}

	g_bHaveModalDlg = false;

	return ret;
}

#endif//ENABLE_SITECONFIG

#if ENABLE_FILTER
int STelnetProxy::DoFilter(BYTE * buf, int len, CProxySock * pSock)
{
	buf[len] = 0;

	if (InString(szEndSession, (TCHAR *) buf))
		return 1;

	Filter.DoFilter(buf, len, pSock);

	return 0;
}
#endif//ENABLE_FILTER