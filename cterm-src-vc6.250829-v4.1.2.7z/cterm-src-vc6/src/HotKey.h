// HotKey.h: interface for the CHotKey class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HOTKEY_H__60557EEB_CC60_435C_BFD6_CC990BE90B4E__INCLUDED_)
#define AFX_HOTKEY_H__60557EEB_CC60_435C_BFD6_CC990BE90B4E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHotKey
{

public:
	CHotKey();
	CHotKey(BYTE cVirt, WORD wKey);
	CHotKey& operator=(const CHotKey& from);
	virtual ~CHotKey();

	void GetString(CString& szBuffer);
	bool FromString(CString& str);
	bool IsEqual(CHotKey &key);

public:
	BYTE m_cVirt;
	WORD m_wKey;
};

#endif // !defined(AFX_HOTKEY_H__60557EEB_CC60_435C_BFD6_CC990BE90B4E__INCLUDED_)
