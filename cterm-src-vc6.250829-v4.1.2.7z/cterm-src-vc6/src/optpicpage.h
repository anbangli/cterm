#if !defined(AFX_OPTTOOLSPAGE_H__946817D6_1F9C_4BE4_9342_31E239DBECB8__INCLUDED_)
#define AFX_OPTTOOLSPAGE_H__946817D6_1F9C_4BE4_9342_31E239DBECB8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptToolsPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptPicPage dialog
#include "MyPropertyPage.h"

class COptPicPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptPicPage)

// Construction

public:

	COptPicPage();
	~COptPicPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(COptPicPage)
	enum { IDD = IDD_OPT_PIC };
	BOOL	m_showpic;
	BOOL	m_bVBSViewPic;
	BOOL	m_bCtrlViewPic;
	BOOL	m_bEmptyPicCache;
	BOOL	m_bPicDownAuto;
	int		m_nPicHoverTime;
	CString	m_szPicPath;
	int		m_nPicFolderSize;
	BOOL	m_bPicBorder;
	BOOL	m_bPicDlgInfo;
	BOOL	m_bGetPicInfo;
	BOOL	m_bPicTip;
	BOOL	m_bClearPicCache;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptPicPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(COptPicPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnChkPic();
	afx_msg void OnPicPath();
	afx_msg void OnChkPicClear();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTTOOLSPAGE_H__946817D6_1F9C_4BE4_9342_31E239DBECB8__INCLUDED_)
