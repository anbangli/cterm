#if !defined(AFX_SHOWIPDLG_H__1DB4A361_F168_11D8_8B10_00A024A7BA74__INCLUDED_)
#define AFX_SHOWIPDLG_H__1DB4A361_F168_11D8_8B10_00A024A7BA74__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ShowIPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CShowIPDlg dialog

class CShowIPDlg : public CDialog
{
// Construction

public:
	CShowIPDlg(CWnd* pParent = NULL);   // standard constructor
	void QueryIP(CString sURL);
// Dialog Data
	//{{AFX_DATA(CShowIPDlg)
	enum { IDD = IDD_SHOWIPDLG };
	CEdit	m_AddrCtrl;
	CString	m_sAddr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShowIPDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CShowIPDlg)
	// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

extern CShowIPDlg * g_pShowIPDlg;
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWIPDLG_H__1DB4A361_F168_11D8_8B10_00A024A7BA74__INCLUDED_)
