// PostTitleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "PostTitleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPostTitleDlg dialog


CPostTitleDlg::CPostTitleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPostTitleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPostTitleDlg)
	m_inputline = _T("");
	m_qmd = 0;
	m_reply = TRUE;
	//}}AFX_DATA_INIT
}


void CPostTitleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPostTitleDlg)
	DDX_Text(pDX, IDC_INPUT, m_inputline);
	DDV_MaxChars(pDX, m_inputline, 80);
	DDX_CBIndex(pDX, IDC_QMD, m_qmd);
	DDX_Check(pDX, IDC_CHK_REPLY, m_reply);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPostTitleDlg, CDialog)
	//{{AFX_MSG_MAP(CPostTitleDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPostTitleDlg message handlers
