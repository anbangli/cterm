// HotKey.cpp: implementation of the CHotKey class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "HotKey.h"

#include "CmdAccelOb.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

#if ENABLE_HOTKEY
CString GetVirtKeyName(WORD wKey);
bool KeyFromString(CString &sWord, WORD& wVirtKey,
	                          bool& bCtrl, bool& bAlt, bool& bShift, TCHAR separator);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

MAPVIRTKEYS mapModVirtSysKeys[] = {
	{MOD_CONTROL, _T("Ctrl") },
	{MOD_ALT, _T("Alt") },
	{MOD_SHIFT, _T("Shift") },
};

CHotKey::CHotKey()
{
	m_cVirt = 0;
	m_wKey = 0;
}

CHotKey::~CHotKey()
{

}

CHotKey::CHotKey(BYTE cVirt, WORD wKey)
{
	m_cVirt = cVirt;
	m_wKey = wKey;
}

CHotKey& CHotKey::operator= (const CHotKey &from)
{
	m_cVirt = from.m_cVirt;
	m_wKey = from.m_wKey;

	return *this;
}

void CHotKey::GetString(CString& szBuffer)
{
	szBuffer = _T("");
	// in case of the object is not assigned, we avoid error messages

	if (m_wKey == 0)
		return;

	// modifiers part
	for (int i = 0; i < sizetable(mapModVirtSysKeys); i++) {
		if (m_cVirt &mapModVirtSysKeys[i].wKey) {
			szBuffer += mapModVirtSysKeys[i].szKey;
			szBuffer += _T("+");
		}
	}

	// and virtual key part
	szBuffer += GetVirtKeyName(m_wKey);
}

bool CHotKey::FromString(CString& str)
{
	m_cVirt = 0;
	m_wKey = 0;

	WORD wVirtKey = 0;
	bool bCtrl = false, bAlt = false, bShift = false;
	bool bBadKey = ! KeyFromString(str, wVirtKey, bCtrl, bAlt, bShift, '+');

	if (!bBadKey) {
		m_wKey = wVirtKey;

		if (bAlt)
			m_cVirt |= MOD_ALT;

		if (bCtrl)
			m_cVirt |= MOD_CONTROL;

		if (bShift)
			m_cVirt |= MOD_SHIFT;
	}

	return bBadKey;
}

bool CHotKey::IsEqual(CHotKey &key)
{
	return this->m_wKey == key.m_wKey && this->m_cVirt == key.m_cVirt;
}

#endif//ENABLE_HOTKEY