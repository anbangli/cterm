// DLDigestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DLDigestDlg.h"
#include "askdlg.h"
#include "ctermview.h"
#include "global.h"
#include "usermsg.h"
#include "paramconfig.h"

#if ENABLE_HTMLDOWN
#include "HTMLConvert.h"	// HTMLת��
#endif//ENABLE_HTMLDOWN

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDLDigestDlg dialog

#if ENABLE_HTMLDOWN

CDLDigestDlg::CDLDigestDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CDLDigestDlg::IDD, pParent),
		m_bWaitHead(FALSE)
{
	//{{AFX_DATA_INIT(CDLDigestDlg)
	m_destfile = _T("");
	m_info = _T("");
	//}}AFX_DATA_INIT
	m_pNowPage = NULL;
	m_bBusy = FALSE;
}


void CDLDigestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDLDigestDlg)
	DDX_Text(pDX, IDC_DESTFILE, m_destfile);
	DDX_Text(pDX, IDC_DLINFO, m_info);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDLDigestDlg, CDialog)
	//{{AFX_MSG_MAP(CDLDigestDlg)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_BN_CLICKED(IDC_RETRY, OnRetry)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDLDigestDlg message handlers

BOOL CDLDigestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CDLDigestDlg::OnTimer(UINT nIDEvent)
{
//	KillTimer(TIMER_DLDIGESTDLG);
	if (m_bBusy) return;

	AutoRunStatus n = m_Run.QueryStatus();

//	if (m_Run.m_nStatus == DDS_JUMPTOEND && !IsEnd()) {
//		//wait end
//		return;
//	}

	TRACE(_T("CDLDigestDlg::OnTimer 1 n:%d m_nStatus:%d next:%d\n"), n, m_Run.m_nStatus, m_Run.m_nNextStatus);

	if (n) {
//TRACE(_T("CDLDigestDlg::OnTimer 2\n"));
		if (n == AutoRun_OK) {   //Ok
//TRACE(_T("CDLDigestDlg::OnTimer 3\n"));
			m_Run.m_nStatus = m_Run.m_nNextStatus;

			if (m_bWaitHead) {
				if (m_Run.m_pView && !m_Run.m_pView->m_Core.IsDigestListHead()) {
					return;
				} else {
					m_bWaitHead = FALSE;
				}
			}
		}
		else if (n == AutoRun_PreExit) {
			PopStatus(_T(""));
		}
		else {
//TRACE(_T("CDLDigestDlg::OnTimer 4\n"));
			if (n == AutoRun_Timeout) {
//TRACE(_T("CDLDigestDlg::OnTimer 5\n"));
				switch (m_Run.m_nStatus) {

				case DDS_SEARCH_NEXT://�ֹ���Ԥ
//				case DDS_UNKNOWN:

				case DDS_COPY: {
//TRACE(_T("CDLDigestDlg::OnTimer 6\n"));
					static int retType = 0; //static ��ס�ϴε�ѡ��

					if (g_iAskDlg == -1) {
						//��ʾ�Ի��򣬽���
//TRACE(_T("CDLDigestDlg::OnTimer 7\n"));
						CAskDlg Dlg;

						if (retType >= 0 && retType <= 3) {
							Dlg.m_nType = retType;
						}

						Dlg.m_bDigest = TRUE;

						m_bBusy = TRUE;
						Dlg.m_nType = 0;

						if (Dlg.DoModal() == IDOK) {
//TRACE(_T("CDLDigestDlg::OnTimer 8\n"));
							retType = Dlg.m_nType;
						} else
							retType = -1;

						m_bBusy = FALSE;
					} else { //�����ʣ���ȡĬ��ֵ
//TRACE(_T("CDLDigestDlg::OnTimer 9\n"));
						retType = g_iAskDlg;
					}

					switch (retType) {

					case 0:
						// ����ĩβ, ����
//TRACE(_T("CDLDigestDlg::OnTimer 10\n"));
						PopStatus();
						break;

					case 1:
						// ������, ��ҳ
//TRACE(_T("CDLDigestDlg::OnTimer 11\n"));
						m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DDS_COPY);
						break;

					case 2:
						// �б�
//TRACE(_T("CDLDigestDlg::OnTimer 12\n"));
						m_Run.ChangeStatus(DDS_SEARCH_NEXT);
						break;

					case 3:
						// �Զ��ж�
						AutoDeal();
						break;

					default: //-1:cancel, other:invalid
//TRACE(_T("CDLDigestDlg::OnTimer 13\n"));
						m_Run.m_nTime = clock();
					}
				}

				break;
				}
			}

			//else AutoRun_Wait, AutoRun_Unknown: do nothing
//TRACE(_T("CDLDigestDlg::OnTimer 14\n"));
			return;
		}

//TRACE(_T("CDLDigestDlg::OnTimer 15 m_Run.m_nStatus=%d\n"), m_Run.m_nStatus);
		switch (m_Run.m_nStatus) {

		case DDS_SEARCH_NEXT:
			SearchNext();
			break;

		case DDS_COPY:
			CopyArticle();
			break;

//		case DDS_UNKNOWN:
//			ProcessUnKnown();
//			break;

		case DDS_UNKNOWN_CONTINUE:
			m_bBusy = TRUE;
			ProcessContinue();
			m_bBusy = FALSE;
			break;

		case DDS_PGDOWN:
			ProcessPgDown();
			break;

		case DDS_JUMPTOEND:
			JumpToEnd();
			break;
//		case DDS_WAITEND:
//			WaitEnd();
//			break;

		case DDS_GETLASTINDEX:
			GetLastIndex(); //������һƪ���
			break;

		case DDS_AUTO: // �Զ��ж�
			AutoDeal();
			break;

		case DDS_DONOTHING: //really do nothing
			break;
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CDLDigestDlg::OnBrowse()
{
	CFileDialogEx fd(FALSE, _T("htm"), _T("index.htm"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("HTML�ļ�(*.htm)|*.htm||"));
	UpdateData();

	if (fd.DoModal() == IDOK) {
		m_destfile = fd.GetPathName();
		UpdateData(FALSE);
	}
}

// ��ͷ��ʼ����
void CDLDigestDlg::OnOK()
{
	UpdateData();

	if (m_destfile.IsEmpty()) return;

	TCHAR ts[400] = _T("");

	_tcscpy(ts, m_destfile);

	m_Status.Create(ts);

	m_nNow = 0;

	//Create First Page
	m_pNowPage = CreateNewPage(m_Status.szFirstFile);

	if (!m_pNowPage) {   //Create Faild
		MessageBox(_T("���ܴ�Ŀ���ļ���"), _T("��������"), MB_OK | MB_ICONERROR);
		return;
	}

	//Enter First Status
	if (m_Run.m_pView->SiteType() == ST_MAPLE) {
		m_Run.EnterNextStage(_T("1"), 1, SST_UNKNOWN, DDS_DONOTHING);
		m_Run.EnterNextStage(_T("\n"), 1, SST_LIST, DDS_JUMPTOEND);       //��Ҳ��֪��Ϊʲô���ҵ���һ�������磬���͵�����һ������Ӧ��ǲ�һ��
//		m_Status.m_nLevel=1;
	} else {
		JumpToHead(DDS_JUMPTOEND);
		//m_Run.EnterNextStage ( _T ( "1\n\x0c" ), 3, SST_LIST, DDS_JUMPTOEND ); //ǿ��ˢ����Ļ����Ϊˮľ�ڹ��λ�ò���ʱ����Ӧ
	}

//	CopyPicture();
	GetDlgItem(IDOK)->EnableWindow(FALSE);

	GetDlgItem(IDC_ADD)->EnableWindow(FALSE);

//	OnCancel();
#ifdef _DEBUG
	SetTimer(TIMER_DLDIGESTDLG, 100, NULL);
#else
	SetTimer(TIMER_DLDIGESTDLG, g_nDownTimeout, NULL);
#endif//_DEBUG
}

CHTMLConvert *CDLDigestDlg::CreateNewPage(TCHAR *szFile, BOOL bList)
{
	CHTMLConvert *pPage = new CHTMLConvert(&m_Run.m_pView->m_Core);

	if (!pPage)	return NULL;

	TCHAR ts[256] = _T(""), sztitle[256] = _T(""), *p = NULL;

	if (!bList) {
		//Article
		if (!pPage->Create(szFile, m_Run.m_pView->m_Site.m_Login.m_szAddr,
		                   m_Run.m_pView->m_Site.m_Login.m_szSiteName, m_Digest.m_szName, FALSE)) {
			delete pPage;
			return NULL;
		}
	} else {
		m_Run.m_pView->m_Core.GetLineStr(ts, 0);
		p = ts;

		while (*p == ' ') p++;

		_tcscpy(sztitle, p);

		if (!pPage->Create(szFile, m_Run.m_pView->m_Site.m_Login.m_szAddr,
		                   m_Run.m_pView->m_Site.m_Login.m_szSiteName, sztitle, FALSE)) {
			delete pPage;
			return NULL;
		}
	}

	return pPage;
}

// �����������һ������
void CDLDigestDlg::GetLastIndex()
{
	if (!m_Run.m_pView) return;

	CCTermCore *pCore = &m_Run.m_pView->m_Core;

	TCHAR       szLine[256] = _T("");

	BOOL       bResult;

	int i;

	for (i = 3; i < (m_Run.m_pView->TermH() - 1); i++) {     //ˮľһ��������ʾ20��
		if (pCore->line(i + pCore->MaxStartLine())[0].GetChar() != ' ')   //��ꡰ->����>����λ��
			break;
	}

	if (i >= (m_Run.m_pView->TermH() - 1))
		return;

	pCore->GetLineStr(szLine, i, 50);

	TRACE(_T("CDLDigestDlg::GetLastIndex szLine=%s\n"), szLine);

	if (m_Run.m_pView->SiteType() == ST_MAPLE)
		bResult = m_Digest.GetDigest_Maple(szLine);
	else
		bResult = m_Digest.GetDigest(szLine);

	if (bResult) {
//		m_iLastOfThisLevel=m_Digest.m_nIndex;
		m_Status.m_iLastOfLevel[m_Status.m_nLevel] = m_Digest.m_nIndex;
		//�ص���һƪ���£���Ŀ¼������ʼ����

		if (m_Run.m_pView->SiteType() == ST_MAPLE) {
			m_Run.EnterNextStage(_T("1"), 1, SST_UNKNOWN, DDS_DONOTHING);
			m_Run.EnterNextStage(_T("\n"), 1, SST_LIST, DDS_SEARCH_NEXT);
		} else {
			JumpToHead(DDS_SEARCH_NEXT);
			//m_Run.EnterNextStage ( _T ( "1\n\x0c" ), 3, SST_LIST, DDS_SEARCH_NEXT );
		}
	} else { //<< Ŀǰû������ >> ����Ŀ¼or [����]
		//m_iLastOfThisLevel=0;
		m_pNowPage->AddLine(_T("\n<font align=\"center\" color=\"#FFFFFF\">û������</font>\n"));
		m_Status.m_iLastOfLevel[m_Status.m_nLevel] = 0;
		PopStatus();
		return;
	}
}

// �����б�ĩβ(���һƪ)
void CDLDigestDlg::JumpToEnd(void)
{
	m_Run.EnterNextStage(_T("\x1b[A\x0c"), 4, SST_LIST, DDS_GETLASTINDEX);
}

// �����б�ĩβ(���һƪ)
void CDLDigestDlg::JumpToHead(const int next)
{
	m_Run.EnterNextStage(_T("1\n\x0c"), 3, SST_LIST, next);
	m_bWaitHead = TRUE;
}

void CDLDigestDlg::SearchNext()
{
	TRACE(_T("CDLDigestDlg::SearchNext\n"));

	if (!m_Run.m_pView) return;

	if (m_nNow >= m_Status.m_iLastOfLevel[m_Status.m_nLevel]) {
		// ��Ŀ¼��������
		PopStatus(_T("\x1b[D"));
		return;
	}

	CCTermCore *pCore = &m_Run.m_pView->m_Core;

	TCHAR szLine[256] = _T(""), ts[20] = _T("");

	BOOL bResult;

	int i;

	for (i = 3; i < (m_Run.m_pView->TermH() - 2); i++) {
		if (pCore->line(i + pCore->MaxStartLine())[0].GetChar() != ' ')   //���->λ��
			break;
	}

	if (i >= (m_Run.m_pView->TermH() - 2))
		return;

	int nStart = i;

	for (i = nStart; i < (m_Run.m_pView->TermH() - 2); i++) {
		pCore->GetLineStr(szLine, i, 50);

		if (rStrip(szLine) < 5) {
			// Empty line
			// Ending DownLoad This List // ȡ���ö������Ǽ����ȴ�
			// ��������Ϊ��Ļû��ˢ�����
			//DLEnd();
#ifdef _DEBUG
			SITESTATUS st = m_Run.m_pView->GetStatus();
			TRACE(_T("CDLDigestDlg::SearchNext i=%d szLine='%s' st=%d\n"), i, szLine, st);
#endif
			//PopStatus(_T("\x1b[D"));
			// ȡ��PopStatus��������Ϊֱ�ӷ��أ������ȴ�
			return;
		}

		if (m_Run.m_pView->SiteType() == ST_MAPLE)
			bResult = m_Digest.GetDigest_Maple(szLine);
		else
			bResult = m_Digest.GetDigest(szLine);

		if (bResult) {
			if (m_Digest.m_nIndex <= m_nNow)   //Have Download
				continue;

//		 if( m_Digest.m_nIndex == nStart )
//			 _stprintf(ts,_T("%d\n\n"),m_Digest.m_nIndex);
			_stprintf(ts, _T("%d\n\n"), m_Digest.m_nIndex);

			m_nNow = m_Digest.m_nIndex;

			//Push
			PushStatus(ts, m_Digest.m_bFile);

			return;
		}
	}

	//over 22
	//����һ����������һ�������ո��ʹ����ƹ�һ�����м�ľ�©����
	//����Ӧ�ð��¼�ͷ��'j'
	//��Ȼ�˴�ˮľ����ͨFB������ͬ����22�зǿգ�������j������������ҳ�����Բ�����������
	m_Run.EnterNextStage(_T("j"), 1, SST_LIST, DDS_PGDOWN);
}

// bFile == true: �ļ�
// bFile == false: Ŀ¼
void CDLDigestDlg::PushStatus(TCHAR *buf, bool bFile)
{
	TRACE(_T("CDLDigestDlg::PushStatus\n"));

	m_Status.Push(m_nNow, m_pNowPage); // PushӦ����m_Status.GetCurrFile()֮ǰ

	CHTMLConvert *pPage = CreateNewPage(m_Status.GetCurrFile(), 0);

	if (!pPage)	return;

	TCHAR ts[300] = _T("");

	int nLen = _tcslen(buf);

	//Write Item into List Page
	AddList();

	m_pNowPage = pPage;

	if (bFile) {
		// m_Status.m_iLastOfLevel[m_Status.m_nLevel] = 1; // ����Ҳ��1ƪ����Ȼû��getlastindex()...���ԣ���Ҳ�ᵼ����ѭ��
		m_Run.EnterNextStage(buf, nLen, SST_ARTICLE, DDS_COPY);
	}
	else {
		m_Run.EnterNextStage(buf, nLen, SST_LIST, DDS_JUMPTOEND); // �����Ժ������Ŀ¼
		m_nNow = 0; // ��һ��
	}

//Give Info
	UpdateData();

	_stprintf(ts, _T("%s - %s"), m_Status.szFileName, m_Digest.m_szName);

	m_info = ts;

	UpdateData(FALSE);
}

void CDLDigestDlg::PopStatus(TCHAR *buf)
{
	TRACE(_T("CDLDigestDlg::PopStatus()\n"));
	WriteLink();
//   CHTMLConvert *pLastPage=m_pNowPage;
	delete m_pNowPage;
	m_pNowPage = m_Status.Pop(m_nNow);

	TRACE(_T("CDLDigestDlg::PopStatus() m_nNow=%d, m_pNowPage=%p\n"), m_nNow, m_pNowPage);

	if (!m_pNowPage) {
		// DownLoad  Over
		DLEnd();
		return;
	}
	else {
		m_Run.EnterNextStage(buf, _tcslen(buf), SST_LIST, DDS_SEARCH_NEXT);
	}

//  delete pLastPage;
//Give Info
	UpdateData();

	TCHAR ts[300] = _T("");

	_stprintf(ts, _T("%s - %s"), m_Status.szFileName, m_pNowPage->GetTitle());

	m_info = ts;

	UpdateData(FALSE);
}

void CDLDigestDlg::CopyArticle()
{
	TRACE(_T("CDLDigestDlg::CopyArticle()\n"));
	SITESTATUS st = m_Run.m_pView->GetStatus();

	if (st == SST_LIST) {
		//Wrong ����wrong������һ��Ŀ¼��ִ�еĶ�������DDS_SEARCH_NEXT
		m_Run.ChangeStatus(DDS_SEARCH_NEXT);
		return;
	}

	if (st == SST_ARTICLE) {
		m_pNowPage->AddScreen();
		m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DDS_COPY);
	} else { //END
		m_pNowPage->AddScreen(TRUE);
		PopStatus();
	}
}

void CDLDigestDlg::ProcessPgDown()
{
	TRACE(_T("CDLDigestDlg::ProcessPgDown()\n"));

	if (!m_Run.m_pView) return;

	CCTermCore *pCore = &m_Run.m_pView->m_Core;

	TCHAR       szLine[256] = _T("");

	BOOL       bResult;

	int i;

	for (i = 3; i < (m_Run.m_pView->TermH() - 2); i++) {
		if (pCore->line(i + pCore->MaxStartLine())[0].GetChar() != ' ')
			break;
	}

	if (i >= (m_Run.m_pView->TermH() - 2))
		return;

	pCore->GetLineStr(szLine, i, 50);

	if (rStrip(szLine) < 5) {      //Empty line
		//Ending DownLoad This List
		//DLEnd();
		PopStatus();
		return;
	}

	if (m_Run.m_pView->SiteType() == ST_MAPLE)
		bResult = m_Digest.GetDigest_Maple(szLine);
	else
		bResult = m_Digest.GetDigest(szLine);

	if (bResult) {
		if (m_Digest.m_nIndex == 1)
			PopStatus();
		else
			m_Run.ChangeStatus(DDS_SEARCH_NEXT);
	} else
		PopStatus();
}

void CDLDigestDlg::AddList()
{
	//m_Digest and m_Status.GetCurrFile create Link
	TCHAR ts[300] = _T(""), szLink[300] = _T("");

	if (m_Digest.m_nIndex % 2)
		m_pNowPage->AddLine(_T("<table border=\"0\" width=\"80%%\" align=\"center\" bgcolor=\"#302010\">\n"));
	else
		m_pNowPage->AddLine(_T("<table border=\"0\" width=\"80%%\" align=\"center\" bgcolor=\"#103010\">\n"));

	_stprintf(szLink, _T("<a href=\"%s\"><font color=\"#FFFFFF\">%s </font></a>"),
	          m_Status.szFileName,
	          m_Digest.m_szName);

	_stprintf(ts, _T("<tr>\n<td width=\"15%%\"><font color=\"#FFFFFF\">%d</font></td>\n<td width=\"30%%\"><font color=\"#FFFFFF\">%s</font></td>\n<td width=\"55%%\">%s</td>\n</tr>\n"),
	          m_Digest.m_nIndex,
	          (m_Digest.m_bFile) ? _T("") : _T("[Ŀ¼]"),
	          szLink);

	m_pNowPage->AddLine(ts);

	m_pNowPage->AddLine(_T("</table>\n"));
}


void CDLDigestDlg::DLEnd()
{
	TRACE(_T("CDLDigestDlg::DLEnd()\n"));
	int i;

	for (i = 0; i < m_Status.m_nLevel; i++) {
		if (m_Status.pPage[i])
			delete m_Status.pPage[i];
	}

	if (m_pNowPage)
		delete m_pNowPage;

	CDialog::OnOK();
}

void CDLDigestDlg::OnCancel()
{
	m_bBusy = TRUE;
	KillTimer(TIMER_DLDIGESTDLG);
//	 if(m_Run.m_bWait&&m_Run.m_nNextStatus==DDS_UNKNOWN)//Push and wait
//       return;

	if (m_Run.m_nStatus) {
		if (MessageBox(_T("����δ���,��¼�ϵ��ļ��Ա����´ν���������?"), _T("�����ж�"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
			CFileDialogEx fd(FALSE, _T("ddc"), _T("*.ddc"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
			               _T("���ؾ������ϵ��¼�ļ�(*.ddc)|*.ddc||"));

			if (fd.DoModal() == IDOK) {
				SDDContinue DDC;
				m_Run.m_pView->m_Core.GetLineStr(DDC.szNowScreen, 0);
				_tcscpy(DDC.szPath, m_Status.szPath);
				_tcscpy(DDC.szFirstFile, m_Status.szFirstFile);

				DDC.m_nLevel = m_Status.m_nLevel;
				int  i;

				for (i = 0; i < DDC.m_nLevel; i++) {
					DDC.nIndex[i] = m_Status.nIndex[i];
					DDC.nFileAt[i] = m_Status.pPage[i]->GetFileAt();
					_tcscpy(DDC.szPageFile[i], m_Status.pPage[i]->m_szFile);
				}

				DDC.nNowAt = m_nNow;

				DDC.nNowFileAt = m_pNowPage->GetFileAt();
				FILE *fp = _tfopen(fd.GetPathName(), _T("wb"));

				if (fp) {
					fwrite(&DDC, sizeof(DDC), 1, fp);
					fclose(fp);
				}
			}
		}
	}

	DLEnd();
}

void CDLDigestDlg::OnAdd()
{
	CFileDialogEx fd(TRUE, _T("ddc"), _T("*.ddc"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("���ؾ������ϵ��¼�ļ�(*.ddc)|*.ddc||"));

	if (fd.DoModal() == IDOK) {
		SDDContinue DDC;
		CHTMLConvert *pPage = NULL;
		FILE *fp = NULL;
		TCHAR sendstr[300] = _T(""), sCommand[10] = _T("");

		fp = _tfopen(fd.GetPathName(), _T("rb"));

		if (!fp) return;

		fread(&DDC, sizeof(DDC), 1, fp);

		fclose(fp);

		_tcscpy(m_Status.szPath, DDC.szPath);

		_tcscpy(m_Status.szFirstFile, DDC.szFirstFile);

		m_destfile = m_Status.szFirstFile;

		UpdateData(FALSE);

		//Construct Stack
		m_Status.m_nLevel = 0;

		if (DDC.m_nLevel) {
			_tcscpy(sendstr, _T(""));

			int i;

			for (i = 0; i < DDC.m_nLevel; i++) {
				m_Status.pPage[i] = NULL;
				pPage = new CHTMLConvert(&m_Run.m_pView->m_Core);

				if (!pPage->Create(DDC.szPageFile[i], DDC.nFileAt[i], &m_Run.m_pView->m_Core)) {
					MessageBox(_T("���ܴ������ص�ҳ��"), _T("�ϵ�����"), MB_OK | MB_ICONERROR);
					delete pPage;
					DLEnd();
					return;
				}

				m_Status.Push(DDC.nIndex[i], pPage);   //Push Page

				m_nNow = 0; // ��һ��

				_stprintf(sCommand, _T("%d\n\n"), DDC.nIndex[i]);
				_tcscat(sendstr, sCommand);
			}
		}//Level

		//Now ,Enter the Page to See The Detail:Process Unknown
		pPage = CreateNewPage(m_Status.GetCurrFile(), 0);

		if (!pPage) return;

		m_pNowPage = pPage;

		_tcscpy(m_szWait, DDC.szNowScreen);

		m_Run.EnterNextStage(sendstr, _tcslen(sendstr), SST_DIGEST_UNKNOWN, DDS_UNKNOWN_CONTINUE);

		//������ʼ���أ����ȵ����ʼ
		SetTimer(TIMER_DLDIGESTDLG, g_nDownTimeout, NULL);
	}
}

void CDLDigestDlg::AutoDeal(void)
{
	TRACE(_T("CDLDigestDlg::ProcessContinue()\n"));

	if (!m_Run.m_pView) {
		return;
	}

	SITESTATUS st = m_Run.m_pView->GetStatus();

	SITESTATUS sub = m_Run.m_pView->m_Status.SubStatus();

	switch (st) {

	case SST_END:
		// todo: �ǲ���Ҫ�ȿ���?
		PopStatus();
		break;

	case SST_ARTICLE:
		m_Run.ChangeStatus(DDS_COPY); //m_Run.EnterNextStage(_T(" "), 1, SST_ARTICLE, DDS_COPY);
		break;

	case SST_LIST:
		m_Run.ChangeStatus(DDS_SEARCH_NEXT);
		break;

	default:
		// todo: �ǲ���Ҫ�ȿ���һ��?
//		SITESTATUS last_st = m_Run.m_pView->m_Status.LastStatus();
//		if (last_st == SST_LIST)
//			m_Run.EnterNextStage(_T("j"), 1, SST_DIGEST_UNKNOWN, DDS_AUTO);//����һ�С�Ը���������м�������¹�һ�У�Ҳ��״̬����ȷ��
//		else if (last_st == SST_ARTICLE)
//			m_Run.ChangeStatus(DDS_COPY);
//		else if (last_st == SST_ARTICLE)
//			m_Run.ChangeStatus(DDS_COPY);
//		else
			m_Run.EnterNextStage(_T("j"), 1, SST_DIGEST_UNKNOWN, DDS_AUTO);//����һ��
	}
}

void CDLDigestDlg::ProcessContinue()
{
	TRACE(_T("CDLDigestDlg::ProcessContinue()\n"));
	SITESTATUS nStatus = m_Run.m_pView->GetStatus();
	SITESTATUS nSubStatus = m_Run.m_pView->m_Status.SubStatus();
	TCHAR szScreen[256] = _T("");
	m_Run.m_pView->m_Core.GetLineStr(szScreen, 0);

	if (_tcsicmp(szScreen, m_szWait) && nStatus == SST_LIST) {
		MessageBox(_T("��ѡ������������ļ����Ƕ�Ӧ�����Ŀ¼��"), _T("�ϵ�����"), MB_OK | MB_ICONERROR);
		DLEnd();
		return;
	}

	if (nStatus == SST_LIST) {
		if (nSubStatus != SST_LIST_DIGEST) {   //no article here
			m_pNowPage->AddLine(_T("\n<font align=\"center\" color=\"#FFFFFF\">û������</font>\n"));
			PopStatus();
			return;
		}

		//New Digest List
		m_nNow = 0;

		m_Run.ChangeStatus(DDS_SEARCH_NEXT);

		return;
	}

	m_Run.ChangeStatus(DDS_COPY);
}

void CDLDigestDlg::WriteLink()
{
	TCHAR ts[300] = _T(""), szLink[100] = _T(""), szFile[300] = _T("");
	_tcscpy(ts,
	        _T("<P ALIGN=\"center\"><font size=\"2\" color=\"#FFFFFF\">\n"));

	if (m_Status.m_nLevel > 0) {
		m_Status.GetFirstFile(szFile);

		if (!isempty(szFile)) {
			_stprintf(szLink, _T("<a href=\"%s\">��ʼҳ��</a>"), szFile);
			_tcscat(ts, szLink);
		}

		m_Status.GetLastLevel(szFile);

		if (!isempty(szFile)) {
			_stprintf(szLink, _T("<a href=\"%s\">|��һ��</a>"), szFile);
			_tcscat(ts, szLink);
		}

		// ע�����ﲻ����m_nNow����Ϊ���������ʱ���ܷ�ӳ��ǰλ��
		if (m_Status.nIndex[m_Status.m_nLevel-1] > 1) {
			m_Status.GetPrevFile(szFile);

			if (!isempty(szFile)) {
				_stprintf(szLink, _T("<a href=\"%s\">|��һƪ</a>"), szFile);
				_tcscat(ts, szLink);
			}
		}

		if (m_Status.nIndex[m_Status.m_nLevel - 1] != m_Status.m_iLastOfLevel[m_Status.m_nLevel - 1]) {
			// ���һƪû�С���һƪ��
			m_Status.GetNextFile(szFile);

			if (!isempty(szFile)) {
				_stprintf(szLink, _T("<a href=\"%s\">|��һƪ</a>"), szFile);
				_tcscat(ts, szLink);
			}
		}
	}

	_tcscat(ts, _T("\n</font></P>"));

	m_pNowPage->AddLine(ts);
}

void CDLDigestDlg::OnStop()
{
	KillTimer(TIMER_DLDIGESTDLG);
}

void CDLDigestDlg::OnRetry()
{
	SetTimer(TIMER_DLDIGESTDLG, g_nDownTimeout, NULL);
	//m_Run.m_pView->Send(_T(" "), 1);      //^L ˢ��
	AutoDeal();
}

//////////////////////////////////////////////////////////////
///// SDDStatusʵ��

SDDStatus::SDDStatus()
{
	memset((void*)nIndex, 0, sizeof(nIndex));
	memset((void*)m_iLastOfLevel, 0, sizeof(m_iLastOfLevel));
	memset((void*)pPage, 0, sizeof(pPage));
	memset((void*)szPath, 0, sizeof(szPath));
	memset((void*)szFile, 0, sizeof(szFile));
	memset((void*)szFirstFile, 0, sizeof(szFirstFile));
	memset((void*)szFileName, 0, sizeof(szFileName));
	m_nLevel = 0;
}

void SDDStatus::Create(TCHAR *szIndex)
{
	_tcscpy(szFirstFile, szIndex);
	_tcscpy(szPath, szFirstFile);

	TCHAR *p = szPath + _tcslen(szFirstFile);

	while (*p != ':' && *p != '\\' && p > szPath)
		p--;

	if (p == szPath)
		*p = 0;
	else
		p[1] = 0;

	m_nLevel = 0;

	// ��ʼ����SDDStatus::SDDStatus()�������
// 	int  i;
//	for (i = 0; i < MAX_LEVEL; i++) {
//		nIndex[i] = 0;
//		pPage[i] = NULL;
//	}
}

void SDDStatus::Push(int &nNow, CHTMLConvert *p)
{
	nIndex[m_nLevel] = nNow;
	pPage[m_nLevel] = p;
	m_nLevel++;
	nNow = 0;
}

CHTMLConvert *SDDStatus::Pop(int &nNow)
{
	TRACE("SDDStatus::Pop m_nLevel = %d, nNow = %d, pPage[m_nLevel] = %x", m_nLevel, nNow, pPage[m_nLevel]);

	if (m_nLevel) {
		nNow = nIndex[m_nLevel-1];
		m_nLevel--;
		CHTMLConvert *p = pPage[m_nLevel];
		pPage[m_nLevel] = NULL;
		return p;
	}
	else {
		return NULL;
	}
}

TCHAR *SDDStatus::GetCurrFile()
{
	if (m_nLevel == 0) {
		_tcscpy(szFile, szFirstFile);
		return szFile;
	} else
		_tcscpy(szFile, szPath);

	_tcscpy(szFileName, _T(""));

	TCHAR ts[10] = _T("");

	for (int i = 0; i < m_nLevel; i++) {
		if (i)
			_stprintf(ts, _T("-%d"), nIndex[i]);
		else
			_stprintf(ts, _T("%d"), nIndex[i]);

		_tcscat(szFileName, ts);
	}

	_tcscat(szFileName, _T(".htm"));

	_tcscat(szFile, szFileName);
	return szFile;
}

void SDDStatus::GetFirstFile(TCHAR *sFirst)
{
	int nLen = _tcslen(szPath);
	_tcscpy(sFirst, szFirstFile + nLen);
}

void SDDStatus::GetNextFile(TCHAR *sNext)
{
	if (m_nLevel == 0)
		return;

	_tcscpy(sNext, _T(""));

	TCHAR ts[10] = _T("");

	for (int i = 0; i < m_nLevel - 1; i++) {
		if (i)
			_stprintf(ts, _T("-%d"), nIndex[i]);
		else
			_stprintf(ts, _T("%d"), nIndex[i]);

		_tcscat(sNext, ts);
	}

	if (m_nLevel - 1)
		_stprintf(ts, _T("-%d"), nIndex[m_nLevel-1] + 1);
	else
		_stprintf(ts, _T("%d"), nIndex[m_nLevel-1] + 1);

	_tcscat(sNext, ts);

	_tcscat(sNext, _T(".htm"));
}

void SDDStatus::GetPrevFile(TCHAR *szPrev)
{
	if (m_nLevel == 0)
		return;

	if (nIndex[m_nLevel-1] < 2)
		return;

	_tcscpy(szPrev, _T(""));

	TCHAR ts[10] = _T("");

	for (int i = 0; i < m_nLevel - 1; i++) {
		if (i)
			_stprintf(ts, _T("-%d"), nIndex[i]);
		else
			_stprintf(ts, _T("%d"), nIndex[i]);

		_tcscat(szPrev, ts);
	}

	if (m_nLevel - 1)
		_stprintf(ts, _T("-%d"), nIndex[m_nLevel-1] - 1);
	else
		_stprintf(ts, _T("%d"), nIndex[m_nLevel-1] - 1);

	_tcscat(szPrev, ts);

	_tcscat(szPrev, _T(".htm"));
}

void SDDStatus::GetLastLevel(TCHAR *szLevel)
{
	if (m_nLevel == 0)
		return;

	if (m_nLevel == 1) {
		GetFirstFile(szLevel);
		return;
	}

	_tcscpy(szLevel, _T(""));

	TCHAR ts[10] = _T("");

	for (int i = 0; i < m_nLevel - 1; i++) {
		if (i)
			_stprintf(ts, _T("-%d"), nIndex[i]);
		else
			_stprintf(ts, _T("%d"), nIndex[i]);

		_tcscat(szLevel, ts);
	}

	_tcscat(szLevel, _T(".htm"));
}

/////////////////////////////////////////////////////////////
///// SDDContinue ʵ��

SDDContinue::SDDContinue()
{
	memset((void*)szNowScreen, 0, sizeof(szNowScreen));
	memset((void*)szPath, 0, sizeof(szPath));
	memset((void*)szFirstFile, 0, sizeof(szFirstFile));
	memset((void*)szPageFile, 0, sizeof(szPageFile));
	memset((void*)nIndex, 0, sizeof(nIndex));
	memset((void*)nFileAt, 0, sizeof(nFileAt));
	m_nLevel = 0;
	nNowAt = 0;
	nNowFileAt = 0;
}

#endif//ENABLE_HTMLDOWN
