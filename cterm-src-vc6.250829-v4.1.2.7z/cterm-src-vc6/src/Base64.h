// Base64.h: interface for the CBase64 class.
// Author: Wes Clyburn (clyburnw@enmu.edu)
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BASE64_H__FD6A25D1_EE0E_11D1_870E_444553540001__INCLUDED_)
#define AFX_BASE64_H__FD6A25D1_EE0E_11D1_870E_444553540001__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#define CODE_BASE64     8

int IsBase64(TCHAR *s);
void DecodeBase64(TCHAR *line);

void EncodeBase64Like(TCHAR *pszIn, TCHAR *pszOut);
void DecodeBase64Like(TCHAR *pszIn, TCHAR *pszOut);

TCHAR *Base64Encode(const TCHAR *szEncoding, int nSize);
TCHAR *Base64Decode(const TCHAR *szDecoding, int nSize);

#endif // !defined(AFX_BASE64_H__FD6A25D1_EE0E_11D1_870E_444553540001__INCLUDED_)
