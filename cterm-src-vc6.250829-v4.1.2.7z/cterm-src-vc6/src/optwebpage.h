#if !defined(AFX_OPTWEBPAGE_H__AE793676_A5A4_4358_8EC0_5B7D1FE37CAB__INCLUDED_)
#define AFX_OPTWEBPAGE_H__AE793676_A5A4_4358_8EC0_5B7D1FE37CAB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptWebPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// COptWebPage dialog

class COptWebPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptWebPage)

// Construction

public:
	COptWebPage();
	~COptWebPage();
	CString m_ipdat;
	//CString m_ftp;
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(COptWebPage)
	enum { IDD = IDD_OPT_WEB };
	int		m_usegoogle;
	int		m_weblong;
	CString	m_homepage;
	BOOL	m_bSearchBox;
	
	BOOL	m_showip;
	BOOL	m_showipauto;

	//int		m_nDownTool;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptWebPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(COptWebPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSetIPdat();
	afx_msg void OnChkIP();
	afx_msg void OnDownipdat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTWEBPAGE_H__AE793676_A5A4_4358_8EC0_5B7D1FE37CAB__INCLUDED_)
