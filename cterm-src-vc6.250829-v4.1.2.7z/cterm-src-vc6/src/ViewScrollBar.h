#if !defined(AFX_VIEWSCROLLBAR_H__15E899E6_ECC1_4602_9A45_D8C3BE8BBF5C__INCLUDED_)
#define AFX_VIEWSCROLLBAR_H__15E899E6_ECC1_4602_9A45_D8C3BE8BBF5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ViewScrollBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CViewScrollBar dialog

class CViewScrollBar : public CDialogBar
{
// Construction
public:
	CViewScrollBar(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CViewScrollBar)
	enum { IDD = IDD_SCROLLBAR };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CViewScrollBar)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

public:
	void SetScrollSize(int nScrn, int nCur);
	void SetSize(int sz);
	void SetPos(int pos);
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CViewScrollBar)
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VIEWSCROLLBAR_H__15E899E6_ECC1_4602_9A45_D8C3BE8BBF5C__INCLUDED_)
