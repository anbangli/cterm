// Screen.cpp: implementation of the CScreen class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Screen.h"
#include "onechar.h"
#include "debugtool.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const CScreen::CTermLine CScreen::ErrorLine(_T("Oops! Something must be wrong!"));
CScreen::CTermLine CScreen::RubbishLine;
	
CScreen::CScreen():
	m_nScrnHeight(DEFAULT_TERM_HEIGHT),
	m_nScrnWidth(DEFAULT_TERM_WIDTH)
{
	m_bInited = false;
	m_nMaxLine = DEFAULT_TERM_HEIGHT - 1;
	m_nMaxHistLine = DEFAULT_TERM_HEIGHT;
}

CScreen::~CScreen()
{
	int total = m_Lines.size();
	int i;

	for (i = 0; i < total; ++i) {
		if (m_Lines[i])
			delete m_Lines[i];
	}

	total = m_linepool.size();

	for (i = 0; i < total; ++i) {
		if (m_linepool[i])
			delete m_linepool[i];
	}
}

bool CScreen::Init(int nScrnWidth, int nScrnHeight, int nMaxHistLine)
{
	ASSERT(nMaxHistLine >= nScrnHeight);

	m_nScrnHeight = nScrnHeight;
	m_nScrnWidth = nScrnWidth;
	m_nMaxHistLine = nMaxHistLine;

//	TRACEFINTS( "in CScreen::Init nScrnHeight= ", nScrnHeight );
	// ����size=8 24-1=23-1=22...=8, ������24-8����
	// ����size=40 24>40Ϊ�٣�����Ҫ����
	// ����size=0 ����24����
	// ����size>=24, ����Ҫ����
	int size = m_Lines.size();
	int i;

	for (i = 0; i < size; i++) {
		m_Lines[i]->ClearLine();
	}

	while (nScrnHeight > size) {
		CTermLine *line = new CTermLine(m_nScrnWidth);
		// ��δ�� line->m_nLineNum = m_nScrnHeight - nScrnHeight;
#ifdef _DEBUG
		//TRACE("in CScreen::Init(), newed %p %d\n", line, line->new_id);
#endif//_DEBUG
		m_Lines.push_back(line);
		nScrnHeight--;
	}

	//TRACE(_T("newed %d lines\n"), m_nScrnHeight);

//	int size = m_Lines.size();
//	TRACEFINTS( "size=", size );

	m_bInited = true; //AddScreen();
	m_nMaxLine = m_nScrnHeight - 1;
	return m_bInited;
}

// ȡ��
// ���ڷ����е�һЩ��������δ�õ�
inline CScreen::CTermLine *CScreen::GetOneLine(int y)
{
	ASSERT(m_bInited);
	ASSERT(0 <= y && y < m_Lines.size());

	return m_Lines[y];
}

// ������ָ�����̫�� ��ʵ��
inline SOneChar &CScreen::GetOneChar(int y, int x)
{
	ASSERT(m_bInited);
	ASSERT(0 <= y && y < m_Lines.size());
	ASSERT(0 <= x && x < m_Lines[x]->m_nLineLen);
	ASSERT(m_Lines[y]->buf());

	return m_Lines[y]->buf()[x];
}

#ifdef _DEBUG
void CScreen::touched()
{
	int sz = m_Lines.size();

	const CTermLine *pLine = NULL;
	for (int i = 0; i < sz; ++i) {
		pLine = m_Lines[i];
		if (pLine->m_nLineLen != m_nScrnWidth
			||pLine->new_id > m_nMaxHistLine + 2)
			goto bad;
		
		sz = pLine->m_nLineLen * sizeof(SOneChar);
		char *p = (char *)pLine->buf();
		for (char *pp = p; pp < p + sz; ++pp) {
			if (*pp != 0) {
				goto bad;
			}
		}
	}

	return;
	
bad:
	{
		CString s;
		s.Format("line %p %d touched!!!!!!!!\n", pLine, pLine->new_id);
		TRACE(s);
		AfxMessageBox(s);
	}
}

void CScreen::dumpScreen(void)
{
	TRACE("----------dump screen---------------\n");

	TRACE("m_nMaxHistLine = %d\n", m_nMaxHistLine);
	TRACE("m_nMaxLine = %d\n", m_nMaxLine);
	TRACE("m_nScrnHeight = %d\n", m_nScrnHeight);
	TRACE("size = %d\n", m_Lines.size());

	char buf[MAX_LINE_CHAR + 1] = _T("");
	int sz = m_Lines.size();

	const CTermLine *pLine = NULL;
	for (int i = 0; i < sz; ++i) {
		pLine = m_Lines[i];
		if (pLine == NULL)
			pLine = &ErrorLine;
		pLine->getStr(buf);
		TRACE("%2d %d %03d %s\n", i, pLine->m_nLineLen, pLine->new_id, buf);//, pLine->m_bChanged
	}

	TRACE("--------end dump screen---------------\n");
}
#endif //_DEBUG

#if ENABLE_SCREENMAP
void CScreen::dumpScreen(FILE * fp) const
{
	char buf[MAX_LINE_CHAR + 1] = _T("");
	int sz = m_Lines.size();

	const CTermLine *pLine = NULL;
	for (int i = m_nMaxLine - m_nScrnHeight + 1; i <= m_nMaxLine; ++i) {
		pLine = m_Lines[i];
		if (pLine == NULL)
			pLine = &ErrorLine;
#ifdef _DEBUG
	char buf[MAX_LINE_CHAR] = "";
	pLine->getStr(buf);
#endif//_DEBUG
		pLine->dumpLine(fp);
	}
}

void CScreen::load(FILE * fp, int scrnNum)
{
#define SCREEN_MAP_HEAD_LEN 100
	fseek(fp, SCREEN_MAP_HEAD_LEN + scrnNum * m_nScrnHeight * m_nScrnWidth * sizeof(SOneChar), SEEK_SET);
	CTermLine * pLine = NULL;
	int num = 0;
	for (int i = m_nMaxLine - m_nScrnHeight + 1; i <= m_nMaxLine; ++i) {
		num = i % m_nMaxHistLine; // ?
		pLine = m_Lines[num];
		pLine->load(fp);
	}
}
#endif//ENABLE_SCREENMAP

// ��������, �򸲸�ǰ�����ȥ����
int CScreen::GetNewLines(int y)
{
	ASSERT(m_bInited);
	ASSERT(0 <= y && y < MAX_HIST_LINE);

	if (y > m_nMaxLine) {
		if (y - m_nMaxLine > m_nScrnHeight) {
			ASSERT(FALSE);    // error!
			return m_nMaxLine;
		}

		m_nMaxLine = y;

		int size = m_Lines.size();

		if (size < m_nMaxHistLine && y >= size) {
			//TRACE(_T("newing %d lines\n"), y - size + 1);
			// new lines

			while (y >= size) {
				CTermLine *line = new CTermLine(m_nScrnWidth);
				//��δ�� line->m_nLineNum = size;
				m_Lines.push_back(line);
				size++;
			}
		} else {
			//ASSERT(size == m_nMaxHistLine);

			// todo: �����Ƿ���ȷ������y - m_nMaxLine > 1?
			// �Ƿ���Ҫshiftlines? Ҳ������Ҫ, ��Ϊ�������ԭ�����߼�����
			// ���ǣ�ֻ����һ�У������ǰ�����ǵ���ȫ�����ˣ�����������ʱû������
			y %= m_nMaxHistLine;
			CTermLine *line = m_Lines[y];
			line->ClearLine();
			//��δ�� line->m_nLineNum = m_nMaxLine; //ԭ����y
			line->SetChange(true);
		}
	}

	return m_nMaxLine;
}

const SOneChar *CScreen::line(int y) const
{
	const CScreen::CTermLine *pLine = NULL;
	if (!(m_bInited && m_nMaxLine - m_nMaxHistLine < y && 0 <= y && y <= m_nMaxLine)) {
		pLine = &ErrorLine; // ָ��һ��������
	} else {
		y %= m_nMaxHistLine;
		pLine = m_Lines[y];
		if (pLine == NULL) {
			pLine = &ErrorLine;
		}
	}
	ASSERT(pLine->buf());
	return pLine->buf();
}

// ȡ�е�buffer
SOneChar *CScreen::operator[](int y) const
{
	CTermLine *pLine = NULL;
	if (!(m_bInited && m_nMaxLine - m_nMaxHistLine < y && 0 <= y && y <= m_nMaxLine)) {
		pLine = &RubbishLine; // ָ��һ������д��buffer
	} else {
#ifdef _DEBUG
//		int size = m_Lines.size();
#endif
//		TRACE( "size=%d\n", size );

		y %= m_nMaxHistLine;
		//m_Lines[y]->m_nLineNum = y; // �����ǰ�к��Ѿ����¹���

//		TRACE( "size=%d\n", size );
		
		pLine = m_Lines[y];
#ifdef _DEBUG
		//TRACE("in CScreen::operator[] %d %p %d\n", y, pLine, pLine->new_id);
#endif//_DEBUG
		if (pLine == NULL) {
			pLine = &RubbishLine;
		}
		else {
			pLine->SetChange(true);
		}
	}
	ASSERT(pLine->buf());
	return pLine->buf();
}

// ��start��֮ǰ����n������
// ԭ����start�е�end������ƽ��n��λ��
// Ӱ�췶Χֻ��start��end֮��
void CScreen::InsertLines(int start, int end, int n)
{
	ASSERT(m_nMaxLine - m_nMaxHistLine < end && end <= m_nMaxLine);
	ASSERT(m_nMaxLine - m_nMaxHistLine < start && start <= m_nMaxLine && start < end);

	int y = end - start;

	if (n <= 0) n = 1;

	if (n >= y) n = y;

	ShiftLines(start, end, -n);

	//��ΪShiftLines���Ѿ������ˣ����Բ���new
	for (int i = 0; i < n; i++) {
		if (!m_linepool.empty()) {
			std::vector<CTermLine*>::iterator it = m_Lines.begin() + (start + i) % m_nMaxHistLine;
			*it = m_linepool.back();
			(*it)->SetChange(true);
			m_linepool.pop_back();
		} else {
			//never here
			// todo: ��TermLine�����¼һ��new���������˳�ʱһ��delete
			m_Lines[(start + i) % m_nMaxHistLine ] = new CTermLine(m_nScrnWidth);
		}
	}
}

// ��end��֮�����n������
// ԭ����start�е�end������ƽ��n��λ��
// Ӱ�췶Χֻ��start��end֮��
void CScreen::ScrollLines(int start, int end, int n)
{
	ASSERT(m_nMaxLine - m_nMaxHistLine < end && end <= m_nMaxLine);
	ASSERT(m_nMaxLine - m_nMaxHistLine < start && start <= m_nMaxLine && start < end);

	int y = end - start;

	if (n <= 0) n = 1;

	if (n >= y) n = y;

	ShiftLines(start, end, n);

	for (int i = 0; i < n; i++) {
		if (!m_linepool.empty()) {
			std::vector<CTermLine*>::iterator it = m_Lines.begin() + (end - i) % m_nMaxHistLine;
			*it = m_linepool.back();
			(*it)->SetChange(true);
			m_linepool.pop_back();
		} else {
			//never here
			m_Lines[(start + i) % m_nMaxHistLine ] = new CTermLine(m_nScrnWidth);
		}
	}
}

// num<0, down
// start��end֮�����ƽ��|num|��λ��
// ����Ӱ��˷�Χ֮�����
// todo: ƽ�ƺ��к�ҲӦ�øı�
void CScreen::ShiftLines(int start, int end, int num)
{
	ASSERT(m_nMaxLine - m_nMaxHistLine < end && end <= m_nMaxLine);
	ASSERT(m_nMaxLine - m_nMaxHistLine < start && start <= m_nMaxLine && start < end);

	if (num == 0) return;

	int i;
	CTermLine *pLine = NULL;

	if (num < 0) {
		num = -num;
		int n = end - start + 1 - num;

//		TRACE("in shift 2: start = %d, end = %d, num = %d, n = %d\n", start, end, num, n);

		for (i = 0; i < num; ++i) {
			// ����
//#pragma warning( disable : 4706 )
			//if (pLine = m_Lines[(end - i) % m_nMaxHistLine]) {
			pLine = m_Lines[(end - i) % m_nMaxHistLine];
			if (pLine) {
				pLine->ClearLine(); // todo: ��û�б�Ҫ������б�Ҫ�������Ƿ���memcpyʵ�ָ���Щ
				pLine->SetChange(false);
				m_linepool.push_back(pLine);
			}
//#pragma warning( default : 4706 )
		}

		for (i = 0; i < n; ++i) {
			pLine = m_Lines[(end - i) % m_nMaxHistLine] = m_Lines[(end - i - num) % m_nMaxHistLine];
			pLine->SetChange(true);
		}

		for (i = start; i <= end - n; ++i) {
			m_Lines[i % m_nMaxHistLine] = NULL;
		}
	} else {
		int n = end - start + 1 - num;

		for (i = 0; i < num; ++i) {
//#pragma warning( disable : 4706 )
			//if (pLine = m_Lines[(start + i) % m_nMaxHistLine]) {
			pLine = m_Lines[(start + i) % m_nMaxHistLine];
			if (pLine) {
				pLine->ClearLine();
				pLine->SetChange(false);
				m_linepool.push_back(pLine);
			}
//#pragma warning( default : 4706 )
		}

		for (i = 0; i < n; ++i) {
			pLine = m_Lines[(start + i) % m_nMaxHistLine] = m_Lines[(start + i + num) % m_nMaxHistLine];
			pLine->SetChange(true);
		}

		for (i = start + n; i <= end; ++i) {
			m_Lines[i % m_nMaxHistLine] = NULL;
		}
	}
}
