// UploadAttDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UploadAttDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUploadAttDlg dialog


CUploadAttDlg::CUploadAttDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CUploadAttDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUploadAttDlg)
	//}}AFX_DATA_INIT
}


void CUploadAttDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUploadAttDlg)
	DDX_Control(pDX, IDC_EXPLORER, m_web);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUploadAttDlg, CDialog)
	//{{AFX_MSG_MAP(CUploadAttDlg)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUploadAttDlg message handlers

//DEL void CUploadAttDlg::OnSize(UINT nType, int cx, int cy)
//DEL {
//DEL 	CDialog::OnSize(nType, cx, cy);
//DEL
//DEL /*	CDC *pDC;
//DEL 	pDC= this->GetDC();
//DEL 	CRect rect, rc;
//DEL 	m_edit.GetClientRect(&rect);
//DEL
//DEL 	if( m_pwndWeb == NULL )   {
//DEL         m_pwndWeb = new CWebBrowser2;
//DEL 		if(m_pwndWeb)	{
//DEL 			if( !m_pwndWeb->Create(_T(""), WS_CHILD|WS_VISIBLE, rect, this, ID_AD_BROWSER) ) {
//DEL 				delete m_pwndWeb;	// ����ʧ��, һ�㲻�ᷢ��
//DEL 				m_pwndWeb=NULL;
//DEL 			}
//DEL 		}
//DEL     }
//DEL 	m_edit.ShowWindow(SW_HIDE);
//DEL 	if (m_pwndWeb)
//DEL 		m_pwndWeb->ShowWindow(SW_NORMAL);
//DEL */
//DEL }

void CUploadAttDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
	m_web.Navigate(sUrl, NULL, NULL, NULL, NULL);
}

//DEL void CUploadAttDlg::OnOK()
//DEL {
//DEL 	CDialog::OnOK();
//DEL }
