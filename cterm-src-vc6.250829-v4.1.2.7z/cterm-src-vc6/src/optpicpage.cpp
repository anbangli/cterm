// OptToolsPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptPicPage.h"

#include   "Shlobj.h "		//�����ļ�������
#pragma comment(lib,"Shell32.lib ")	//�����ļ�������


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptToolsPage property page

IMPLEMENT_DYNCREATE(COptPicPage, CMyPropertyPage)

COptPicPage::COptPicPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptPicPage)
	m_showpic = FALSE;
	m_bVBSViewPic = FALSE;
	m_bCtrlViewPic = FALSE;
	m_bEmptyPicCache = FALSE;
	m_bPicDownAuto = FALSE;
	m_nPicHoverTime = 0;
	m_szPicPath = _T("");
	m_nPicFolderSize = 0;
	m_bPicBorder = FALSE;
	m_bPicDlgInfo = FALSE;
	m_bGetPicInfo = FALSE;
	m_bPicTip = FALSE;
	m_bClearPicCache = FALSE;
	//}}AFX_DATA_INIT
}

COptPicPage::~COptPicPage()
{
}

void COptPicPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptPicPage)
	DDX_Check(pDX, IDC_CHK_PIC, m_showpic);
	DDX_Check(pDX, IDC_CHK_VBSVIEWPIC, m_bVBSViewPic);
	DDX_Check(pDX, IDC_CHK_CTRLVIEWPIC, m_bCtrlViewPic);
	DDX_Check(pDX, IDC_CHK_PIC_EMPTY, m_bEmptyPicCache);
	DDX_Check(pDX, IDC_CHK_PICDOWNAUTO, m_bPicDownAuto);
	DDX_Text(pDX, IDC_EDIT_PIC_HOVER_TIME, m_nPicHoverTime);
	DDV_MinMaxInt(pDX, m_nPicHoverTime, 0, 20000);
	DDX_Text(pDX, IDC_EDIT_PIC_PATH, m_szPicPath);
	DDV_MaxChars(pDX, m_szPicPath, 256);
	DDX_Text(pDX, IDC_EDIT_PIC_FOLDER_SIZE, m_nPicFolderSize);
	DDV_MinMaxInt(pDX, m_nPicFolderSize, 0, 10000);
	DDX_Check(pDX, IDC_CHK_PIC_BORDER, m_bPicBorder);
	DDX_Check(pDX, IDC_CHK_PIC_DLG_INFO, m_bPicDlgInfo);
	DDX_Check(pDX, IDC_CHK_GET_PIC_INFO, m_bGetPicInfo);
	DDX_Check(pDX, IDC_CHK_PIC_TIP, m_bPicTip);
	DDX_Check(pDX, IDC_CHK_PIC_CLEAR, m_bClearPicCache);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptPicPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptPicPage)
	ON_BN_CLICKED(IDC_CHK_PIC, OnChkPic)
	ON_BN_CLICKED(IDC_PIC_PATH, OnPicPath)
	ON_BN_CLICKED(IDC_CHK_PIC_CLEAR, OnChkPicClear)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptPicPage message handlers

extern bool g_bVBSInited;
BOOL COptPicPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



	if (!g_bVBSInited) {
		((CButton*) GetDlgItem(IDC_CHK_VBSVIEWPIC))->SetCheck(0);
		GetDlgItem(IDC_CHK_VBSVIEWPIC)->EnableWindow(FALSE);
	}

	GetDlgItem(IDC_CHK_CTRLVIEWPIC)->EnableWindow(m_showpic);
	GetDlgItem(IDC_CHK_PIC_EMPTY)->EnableWindow(!m_bClearPicCache);
	GetDlgItem(IDC_STATIC_PIC_CACHE)->EnableWindow(!m_bClearPicCache);
	GetDlgItem(IDC_EDIT_PIC_FOLDER_SIZE)->EnableWindow(!m_bClearPicCache);

	

	UpdateData(FALSE);
	

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void COptPicPage::OnChkPic()
{
	UpdateData();
	GetDlgItem(IDC_CHK_CTRLVIEWPIC)->EnableWindow(m_showpic);
}

UINT COptPicPage::GetIDD()
{
	return IDD;
}

void COptPicPage::OnPicPath() 
{
	// ʹ��ʾ����http://topic.csdn.net/t/20030320/20/1556816.html
	// ����˵����http://baike.baidu.com/view/1977841.htm
	BROWSEINFO info; 
	memset(&info, 0, sizeof info); 
	info.lpszTitle = "ѡ���ļ���"; 
	LPCITEMIDLIST pidl; 
	pidl = SHBrowseForFolder(&info); 
	if(pidl != NULL) {
		char pszPath[4096]; 
		if(!SHGetPathFromIDList(pidl,  pszPath)) 
			return; 
		if(strlen(pszPath)   <   3) 
			return; 
		m_szPicPath = pszPath;
		UpdateData(FALSE);
	} 
}



void COptPicPage::OnChkPicClear() 
{
	UpdateData();

	GetDlgItem(IDC_CHK_PIC_EMPTY)->EnableWindow(!m_bClearPicCache);
	GetDlgItem(IDC_STATIC_PIC_CACHE)->EnableWindow(!m_bClearPicCache);
	GetDlgItem(IDC_EDIT_PIC_FOLDER_SIZE)->EnableWindow(!m_bClearPicCache);
}
