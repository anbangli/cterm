#if !defined(AFX_HISTORYDLG_H__2EC39D97_9A99_4F36_B59E_54A4D02E4180__INCLUDED_)
#define AFX_HISTORYDLG_H__2EC39D97_9A99_4F36_B59E_54A4D02E4180__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HistoryDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHistoryDlg dialog
#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

class CCTermView;
class CMessage;

class AFX_CLASS_EXPORT CHistoryDlg : public CDialog
{
// Construction
	CMessage   *m_pMes;

public:
	CString m_szPathName;
	~CHistoryDlg();
	TCHAR *m_pszUserName;
	void InitMes();
	const CCTermView *m_pView;
	CHistoryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CHistoryDlg)
	enum { IDD = IDD_HISTORY };
	CButtonST	m_cancel;
	CButtonST	m_sup;
	CButtonST	m_sdown;
	CButtonST	m_output;
	CListCtrl	m_list;
	CString	m_input;
	CString	m_info;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistoryDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CHistoryDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnInmes();
	afx_msg void OnReplymes();
	afx_msg void OnAllmes();
	afx_msg void OnClickMeslist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSearchup();
	afx_msg void OnSearchdown();
	afx_msg void OnOutfile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CImageList m_Image;
	void UpdateList();
	int m_nMes;
	int m_nShowType;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTORYDLG_H__2EC39D97_9A99_4F36_B59E_54A4D02E4180__INCLUDED_)
