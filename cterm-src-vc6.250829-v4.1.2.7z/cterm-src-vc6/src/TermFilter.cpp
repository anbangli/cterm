// TermFilter.cpp: implementation of the CTermFilter class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "cterm.h"
#include "TermFilter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTermFilter::CTermFilter()
{

}

CTermFilter::~CTermFilter()
{

}
