// MoreLine.cpp: implementation of the CMoreLine class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MoreLine.h"
#include "ctermview.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMoreLine::CMoreLine()
{
	m_bHaveChange = FALSE;
	m_pCore = NULL;
	m_pView = NULL;
}

CMoreLine::~CMoreLine()
{

}

//������ʾ�����У��۵���һ����ʾ
//nStart���������
BOOL CMoreLine::SetLine(CCTermCore *pCore, int nStart)
{
	m_pCore = pCore;
	m_pView = pCore->getView();

	if (nStart > (m_pView->TermH() - 1))
		return FALSE;

	if (m_bHaveChange && nStart == m_nThisLine)
		return FALSE;

	BOOL bTRUE = FALSE;

	if (m_bHaveChange && nStart != m_nThisLine) {
		RemoveChange();
		bTRUE = TRUE;
	}

	TCHAR ts[300];// = _T("");

	int len = pCore->GetLongLine(ts, nStart, true, 1);

	if (len > m_pView->TermW()) {
		m_nLine = (len + (m_pView->TermW() - 1)) / m_pView->TermW() - 1;
		m_nThisLine = nStart;

		if (nStart + m_nLine > (m_pView->TermH() - 1)) {
			ChangeLine(nStart - m_nLine, ts);
			m_nStart = nStart - m_nLine;
		} else {
			ChangeLine(nStart + 1, ts);
			m_nStart = nStart + 1;
		}

		m_bHaveChange = TRUE;

		bTRUE = TRUE;
	}

	return bTRUE;
}

//n�������
void CMoreLine::ChangeLine(int n, TCHAR *ts)
{
	if (!m_pCore || !m_pView) return;

	int i, j;
	TCHAR *p = ts + m_pView->TermW();
	BOOL bEnd = FALSE;
	n += m_pCore->MaxStartLine();

	for (i = n; i < n + m_nLine; i++) {
		SOneChar *pLine = m_pCore->lineW(i);

		for (j = 0;j < m_pView->TermW();j++) {
			m_BakLine[i-n][j] = pLine[j];
			pLine[j].SetColor(0x6f);
			pLine[j].SetAttr(0);

			if (!*p)
				bEnd = TRUE;

			pLine[j].SetChar((bEnd) ? ' ' : *p);

			p++;
		}
	}
}

//m_nStart�������
void CMoreLine::RemoveChange()
{
	if (!m_pCore || !m_pView || !m_bHaveChange) return;

	int i, j;

	for (i = m_nStart; i < m_nStart + m_nLine; i++) {
		SOneChar *pLine = m_pCore->lineW(i + m_pCore->MaxStartLine());

		for (j = 0; j < m_pView->TermW(); j++) {
			pLine[j] = m_BakLine[i - m_nStart][j];
		}
	}

	m_bHaveChange = FALSE;

	m_nLine = 0;
}
