#if !defined(AFX_OPTEDITORPAGE_H__8903B4C2_847E_4038_9374_7E325C7B1AD5__INCLUDED_)
#define AFX_OPTEDITORPAGE_H__8903B4C2_847E_4038_9374_7E325C7B1AD5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptEditorPage.h : header file
//
#include "MyPropertyPage.h"

/////////////////////////////////////////////////////////////////////////////
// COptEditorPage dialog

class COptEditorPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptEditorPage)

// Construction

public:
	COptEditorPage();
	~COptEditorPage();
	virtual UINT GetIDD();

private:
// Dialog Data
	//{{AFX_DATA(COptEditorPage)
	enum { IDD = IDD_OPT_WARP };
	BOOL	m_bAutoWarp;
	int		m_nWidth;
	BOOL	m_bAutoPara;
	BOOL	m_bPlusSpace;
	BOOL	m_bAlwaysAsk;
	BOOL	m_bEditDlg;
	BOOL	m_bCtrlCCopy;
	BOOL	m_bCtrlVPaste;
	UINT	m_fontsize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptEditorPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(COptEditorPage)
	afx_msg void OnAutowarp();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void Init();
	void UnInit();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTEDITORPAGE_H__8903B4C2_847E_4038_9374_7E325C7B1AD5__INCLUDED_)
