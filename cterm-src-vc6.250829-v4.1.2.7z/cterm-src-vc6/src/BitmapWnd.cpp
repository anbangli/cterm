// BitmapWnd.cpp : implementation file
// ������������ʾ��Ӧ��ͼƬ

#include "stdafx.h"
#include "BitmapWnd.h"
#include "usermsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

int UnescapeURI(CString& URI);

/////////////////////////////////////////////////////////////////////////////
// CBitmapWnd

CBitmapWnd::CBitmapWnd()
{
}

CBitmapWnd::~CBitmapWnd()
{
}


BEGIN_MESSAGE_MAP(CBitmapWnd, CWnd)
	//{{AFX_MSG_MAP(CBitmapWnd)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapWnd message handlers
//extern bool g_bStartPageUpdated;
BOOL CBitmapWnd::OnEraseBkgnd(CDC* pDC)
{
//TRACE(_T("in CBitmapWnd::OnEraseBkgnd\n"));
	CRect rect;
	CDC memdc;
	CBitmap Bmp, *pold = NULL;
	GetClientRect(&rect);
	pDC->FillSolidRect(&rect, RGB(0, 0, 0));	//��Ϊ��ɫ����(0,0,0)			//(143,119,155));  flier���õı���ɫ

	memdc.CreateCompatibleDC(pDC);
	Bmp.DeleteObject();
	Bmp.Detach();

	bool bLoaded = false;

	CString fn = g_szWorkDir + _T("user\\mylogo.bmp");
	HBITMAP bitmap = (HBITMAP)LoadImage(AfxGetInstanceHandle(), fn, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

	int bx = 300, by = 75;

	if (bitmap != NULL && Bmp.Attach(bitmap)) {
		bLoaded = true;
		BITMAP b;
		Bmp.GetBitmap(&b);
		bx = b.bmWidth, by = b.bmHeight;
	} else {
		Bmp.Detach();
		//bLoaded = Bmp.LoadBitmap(IDB_LOGO325);
		bLoaded = Bmp.LoadBitmap(IDB_LOGO4);  //2025-02-22
	}

	int showx = bx, showy = by;

	if (showx > static_cast<int>(rect.Width() * 0.8)) {
		showx = static_cast<int>(rect.Width() * 0.8);
		showy = by *showx / bx;
	}

	if (showy > static_cast<int>(rect.Height() * 0.8)) {
		showy = static_cast<int>(rect.Height() * 0.8);
		showx = bx *showy / by;
	}

	if (bLoaded) {
		pold = memdc.SelectObject(&Bmp);

		pDC->SetStretchBltMode(COLORONCOLOR);
		::StretchBlt(pDC->m_hDC, (rect.Width() - showx) / 2, (rect.Height() - showy) / 2, showx, showy, memdc.m_hDC,
		             0, 0, bx, by, SRCCOPY);

		//pDC->BitBlt((rect.Width() - bx) / 2, (rect.Height() - by) / 2, bx, by, &memdc, 0, 0, SRCCOPY);

		memdc.SelectObject(pold);
		Bmp.DeleteObject();
	}

	//else // MessageBox("���뱳��ͼʧ��!","��ʾ",MB_OK);

	memdc.DeleteDC();

	return TRUE;
}
#include "mainfrm.h"
void CBitmapWnd::OnSize(UINT nType, int cx, int cy)
{
//TRACE(_T("in CBitmapWnd::OnSize\n"));
	CWnd::OnSize(nType, cx, cy);
	CDC *pDC = this->GetDC();

	if (!OnEraseBkgnd(pDC))
		return;

	RedrawWindow();
}

void CBitmapWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (point.y < 5) {
		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(), WM_WINDOW_EDGE, (WPARAM) 0, 0);
	}

	CWnd::OnMouseMove(nFlags, point);
}
