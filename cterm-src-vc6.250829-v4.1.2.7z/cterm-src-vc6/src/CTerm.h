// CTerm.h : main header file for the CTERM application
//

#if !defined(AFX_CTERM_H__2AC2BA92_FE64_11D3_B1BC_000080013F30__INCLUDED_)
#define AFX_CTERM_H__2AC2BA92_FE64_11D3_B1BC_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

#include "const.h"

#if ENABLE_ACCELEDIT
#include "AcceleratorManager.h"
#endif//ENABLE_ACCELEDIT

/////////////////////////////////////////////////////////////////////////////
// CCTermApp:
// See CTerm.cpp for the implementation of this class
//

#define  DEFAULT_LANG	_T("DefaultLang")

class CTelnetSite;

class CCTermApp : public CWinApp
{
public:
	CCTermApp();
	~CCTermApp();

public:
	bool ConnectSite(const CTelnetSite &Site, bool bToggle = false) const;
	void OpenCtdFile(CString file) const;
	bool ConnectAddr(const CString strAddress, int port = TELNET_PORT, int nType = ST_FIREBIRD) const;
#if ENABLE_ADDRBOOK
	bool ConnectSite(const CString strName) const;
#endif//ENABLE_ADDRBOOK

#if ENABLE_MULTILANG
	void LoadLanguage(CString szLangSel = _T("")) const;
#endif//ENABLE_MULTILANG

#if ENABLE_FUNKEY
	void LoadUserDefCmdTable(CString filename);
#endif//ENABLE_FUNKEY

public:
	// accessor
#if ENABLE_ACCELEDIT
	const CAcceleratorManager &getAccelManager () const
	{
		return m_AccelManager;
	}
#endif//ENABLE_ACCELEDIT

public:
	// ��������mainfrm���OnCreateNewChild�CreateNewChildҪ�õ���û�취
	HMENU m_hMDIMenu;
	HACCEL m_hMDIAccel;

public:
	// ��CMainFrame::OnSysCommand�е���
	afx_msg void OnAppAbout();

private:
	// override
	BOOL ProcessShellCommand(CCommandLineInfo& rCmdInfo);

//{{AFX_MSG(CCTermApp)
	afx_msg void OnAppHelp();
	afx_msg void OnFileQuick();
	afx_msg void OnUpdateFileAgain(CCmdUI* pCmdUI);
	afx_msg void OnFileAgain();
	afx_msg void OnAppDonate();
	afx_msg void OnAppDonateThank();
	afx_msg void OnAppHomepage();
	afx_msg void OnAppTipsall();
	afx_msg void OnAppFaq();
	afx_msg void OnAppGroup();
	afx_msg void OnReportBug();
	//}}AFX_MSG
#if ENABLE_ACCELEDIT
	afx_msg void OnCustomizeAccel();
#endif//ENABLE_ACCELEDIT
#if ENABLE_TIPDLG
	afx_msg void OnAppTip();
#endif//ENABLE_TIPDLG
#if ENABLE_ADDRBOOK
	afx_msg void OnFileAddrbook();
	afx_msg void OnFavoritesites(UINT nID);
	afx_msg void OnUpdateFavoritesites(CCmdUI* pCmdUI);
#endif//ENABLE_ADDRBOOK
#if ENABLE_UPDATE
	afx_msg void OnAppCheckupdate();
#endif//ENABLE_UPDATE
	DECLARE_MESSAGE_MAP()

private:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCTermApp)
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
#if ENABLE_TIPDLG
	void ShowTipAtStartup(CCommandLineInfo &cmdInfo);
//	void ShowTipOfTheDay(void);
#endif//ENABLE_TIPDLG

#if ENABLE_ACCELEDIT
	BOOL AddCommandAccelFromMenu(CAcceleratorManager& accelManager, CMenu* pMenu, CString subMenuName);
	void InitLoadAccelTable();
#endif//ENABLE_ACCELEDIT

#if ENABLE_UPDATE
	void StartCheckUpdate(bool bAuto) const;
#endif//ENABLE_UPDATE
	//DWORD WINAPI UpadteThreadFunc(LPVOID param);
	
private:
#if ENABLE_ACCELEDIT
	CAcceleratorManager m_AccelManager; // accels editor object
#endif//ENABLE_ACCELEDIT

#if ENABLE_VBS
	// ##### BEGIN ACTIVEX SCRIPTING SUPPORT #####
	ITypeLib*	pITypeLib;    //library AXHost
	ITypeInfo*	ptinfoClsDoc; //coclass Document
	ITypeInfo*	ptinfoIntDoc; //dispinterface IAXHost

	ITypeInfo*	ptinfoClsSprite; //coclass Sprite
	ITypeInfo*	ptinfoIntSprite;	//dispinterface IAXSprite
	// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS
};

extern CCTermApp theApp;

#if ENABLE_VBS
// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
//---------------------------------------------------------------------------
// A little utility which simplifies firing dispatch events.
//---------------------------------------------------------------------------
HRESULT InvokeEvent
(
    IDispatch  *pdisp,    // IDispatch of Sink
    DISPID      dispid,   // DISPID of event
    VARIANTARG *pvararg,  // Args to event
    UINT        carg      // # args
);

// This routine will load a TypeLib and (optionally) find the TypeInfo inside
// which matches the given clsid.  The TypeLib and TypeInfo pointers are
// in/out so you can simply:
//      hr = LoadTypeInfo(..., &g_pMyTypeLib, &m_pMyObjectsTypeInfo);
// and it will fill in g_pMyTypeLib and m_pMyObjectsTypeInfo, if necessary.
//---------------------------------------------------------------------------
HRESULT LoadTypeInfo
(
    LPCTSTR	  lpstrTLBFileName,	 // name of the TLB file
    UINT        itinfo,            // index of TypeInfo requested, only 0 supported
    USHORT      dwMaj,             // Maj version # of TypeLib
    USHORT      dwMin,             // Min version # of TypeLib
    LCID        lcid,              // Locale of TypeLib to load
    REFGUID     libid,             // LIBID of TypeLib  to find
    REFCLSID    clsid,             // CLSID of TypeInfo to find
    REFIID      iid,               // IID   of TypeInfo to find
    BOOL        fDispOnly,         // TRUE=ensure *ptinfoIntInOut is a TKIND_DISPATCH, not vtbl
    ITypeLib  **pptlibInOut,       // Ptr to cache of pTypeLib, typically &g_ptlib
    ITypeInfo **pptinfoClassInOut, // Ptr to cache of pTypeInfo, typically &s_ptinfoCls
    ITypeInfo **pptinfoIntInOut    // Ptr to cache of pTypeInfo, typically &s_ptinfoInt
);



DEFINE_GUID(IID_LIBAXHost,
            0x34E2595E, 0x6314, 0x11D1, 0x8F, 0x0B, 0xF5, 0x41, 0x76, 0xDC, 0xF1, 0x30);

DEFINE_GUID(IID_IAXHost,
            0x34e2595f, 0x6314, 0x11d1, 0x8f, 0xb, 0xf5, 0x41, 0x76, 0xdc, 0xf1, 0x30);

DEFINE_GUID(IID_IAXHostClass,
            0x34E25943, 0x6314, 0x11D1, 0x8F, 0x0B, 0xF5, 0x41, 0x76, 0xDC, 0xF1, 0x30);

// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTERM_H__2AC2BA92_FE64_11D3_B1BC_000080013F30__INCLUDED_)
