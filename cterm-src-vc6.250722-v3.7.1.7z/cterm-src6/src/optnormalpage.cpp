// OptNormalPage.cpp : implementation file
//

#include "stdafx.h"
#include "OptNormalPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptNormalPage property page

IMPLEMENT_DYNCREATE(COptNormalPage, CMyPropertyPage)

COptNormalPage::COptNormalPage() : CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(COptNormalPage)
	m_bAllowMulti = FALSE;
	m_bLastSite = TRUE;
	m_bMinToTray = FALSE;
	m_bSiteReport = FALSE;
	m_bUseMouse = FALSE;
	m_bEnablePython = FALSE;
	m_bAutoMailBack = FALSE;
	m_bAutoUpdate = FALSE;
	m_bDoubleClickTab = FALSE;
	m_bPythonStatus = FALSE;
	m_bAutoLast = FALSE;
	m_bBossMouse = FALSE;
	m_bBossKeyActive = FALSE;
	//}}AFX_DATA_INIT
}

COptNormalPage::~COptNormalPage()
{
}

void COptNormalPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptNormalPage)
	DDX_Control(pDX, IDC_BOSSMOUSE, m_btnBossMouse);
	DDX_Check(pDX, IDC_CHK_ALLOW_MULTI, m_bAllowMulti);
	DDX_Check(pDX, IDC_CHK_LAST_SITE, m_bLastSite);
	DDX_Check(pDX, IDC_CHK_MIN_TO_TRAY, m_bMinToTray);
	DDX_Check(pDX, IDC_CHK_SITE_RPT, m_bSiteReport);
	DDX_Check(pDX, IDC_CHK_USE_MOUSE, m_bUseMouse);
	DDX_Check(pDX, IDC_CHK_ENABLEPYTHON, m_bEnablePython);
	DDX_Check(pDX, IDC_CHK_AUTOMAILBACK, m_bAutoMailBack);
	DDX_Check(pDX, IDC_CHK_AUTOUPDATE, m_bAutoUpdate);
	DDX_Check(pDX, IDC_CHK_DOUBLECLICKTAB, m_bDoubleClickTab);
	DDX_Check(pDX, IDC_CHK_PYTHONSTATUS, m_bPythonStatus);
	DDX_Check(pDX, IDC_CHK_AUTOLAST, m_bAutoLast);
	DDX_Control(pDX, IDC_BOSSHOTKEY, m_editBossHotKey);
	DDX_Check(pDX, IDC_BOSSMOUSE, m_bBossMouse);
	DDX_Check(pDX, IDC_BOSSKEY_ACTIVE, m_bBossKeyActive);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptNormalPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(COptNormalPage)
	ON_BN_CLICKED(IDC_CHK_ENABLEPYTHON, OnChkEnablepython)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_BOSSKEY_ACTIVE, OnBosskeyActive)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptNormalPage message handlers


void COptNormalPage::OnChkEnablepython()
{
	UpdateData();
	GetDlgItem(IDC_CHK_PYTHONSTATUS)->EnableWindow(m_bEnablePython);

}

void COptNormalPage::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CMyPropertyPage::OnShowWindow(bShow, nStatus);
	OnChkEnablepython();
}


BOOL COptNormalPage::OnInitDialog()
{
	CMyPropertyPage ::OnInitDialog();

#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	//m_bBossKeyActive = !(m_BossHotkey.IsEqual(CHotKey()));	//������ע�͵��������ڴ��ж� m_bBossKeyActive ��ֵ
	UpdateData(FALSE);
	m_editBossHotKey.EnableWindow(m_bBossKeyActive);
	m_btnBossMouse.EnableWindow(m_bBossKeyActive);

	//ShowOldKey();
	CString sKey;
	m_BossHotkey.GetString(sKey);
	m_editBossHotKey.SetWindowText(sKey);   //m_editBossHotKey.DisplayKeyboardString();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

UINT COptNormalPage::GetIDD()
{
	return IDD;
}


void COptNormalPage::OnOK() 
{
	UpdateData();
	if (m_bBossKeyActive)
		m_editBossHotKey.SetKey(m_BossHotkey);
	
	CMyPropertyPage::OnOK();
}

void COptNormalPage::OnBosskeyActive() 
{
	UpdateData();

	m_editBossHotKey.EnableWindow(m_bBossKeyActive);
	m_btnBossMouse.EnableWindow(m_bBossKeyActive);
	if (m_bBossKeyActive) {
		m_BossHotkey = CHotKey();	//_T("");
		m_editBossHotKey.SetFocus();
	}	
}
