// SetSheet.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"       // main symbols

#include "inssheet.h"
#include "MyPropertyPage.h"
#include "editdlg.h"
#include "ctermview.h"

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsSheet

IMPLEMENT_DYNAMIC(CInsSheet, CPropertySheet)

CInsSheet::CInsSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
		: CPropertySheet(nIDCaption, pParentWnd, iSelectPage),
		m_pLastTabIndex(NULL),
		bView(false)
{
}

CInsSheet::CInsSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
		: CPropertySheet(pszCaption, pParentWnd, iSelectPage),
		m_pLastTabIndex(NULL)
{
}

CInsSheet::~CInsSheet()
{
}


BEGIN_MESSAGE_MAP(CInsSheet, CPropertySheet)
	//{{AFX_MSG_MAP(CInsSheet)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsSheet message handlers

BOOL CInsSheet::OnInitDialog()
{
	BOOL bResult = CPropertySheet::OnInitDialog();

#if ENABLE_MULTILANG
	if (g_currLangID != ID_LANG1) {
		int total = GetPageCount();
		CTabCtrl *pTab = GetTabControl();

		if (pTab) {
			int i;

			for (i = 0; i < total; i++) {
				CString sTitle;
				CString szKey;
				szKey.Format(_T("IDD%d_Title"), ((CMyPropertyPage *) GetPage(i))->GetIDD());

				if (GetPrivateProfileString(_T("Dialog"), szKey, _T(""),
				                            sTitle.GetBuffer(20), 20, g_szLanguagePath) != 0) {
					TC_ITEM item;
					item.mask = TCIF_TEXT;
					item.pszText = sTitle.LockBuffer();
					//_tcscpy ( item.pszText, sTitle );
					pTab->SetItem(i, &item);
					sTitle.UnlockBuffer();
				}
			}
		}
	}
#endif// ENABLE_MULTILANG

//	if (m_pLastTabIndex && *m_pLastTabIndex >= 0 && *m_pLastTabIndex < GetPageCount())
//		SetActivePage(*m_pLastTabIndex);

	return bResult;
}

void CInsSheet::AddPage(CMyPropertyPage* pPage)
{
	CPropertySheet::AddPage(pPage);
}

BOOL CInsSheet::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	if (m_pLastTabIndex)
	{
		*m_pLastTabIndex = GetActiveIndex();
	}
	
	if (LOWORD(wParam) == IDOK) {
		CMyPropertyPage *pPage = (CMyPropertyPage *)GetActivePage();
		if (m_pParentWnd && pPage) {
			CString s = pPage->GetStr();
			if (m_pParentWnd->IsKindOf(RUNTIME_CLASS(CEditDlg))) {
				((CEditDlg *)m_pParentWnd)->m_editCtrl.ReplaceSel(s);
			}
			else if (m_pParentWnd->IsKindOf(RUNTIME_CLASS(CCTermView))) {
				((CCTermView *)m_pParentWnd)->PasteANSI(s);
			}
		}
		return TRUE;
	}
	else {
		return CPropertySheet::OnCommand(wParam, lParam);
	}
}
