#if !defined(AFX_STATUSSHOWDLG_H__8E1023AF_E688_4231_B14A_44CDC750473B__INCLUDED_)
#define AFX_STATUSSHOWDLG_H__8E1023AF_E688_4231_B14A_44CDC750473B__INCLUDED_

#ifdef _DEBUG_STATUS

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StatusShowDlg.h : header file
//
#include "resource.h"
/////////////////////////////////////////////////////////////////////////////
// CStatusShowDlg dialog

class CCTermView;

class CStatusShowDlg : public CDialog
{
// Construction

public:
	void SetStatus(int n, int sub);
	CStatusShowDlg(CWnd* pParent = NULL);   // standard constructor
	const CCTermView *m_pView;

// Dialog Data
	//{{AFX_DATA(CStatusShowDlg)
	enum { IDD = IDD_SHOWSTATUS };
	CString	m_info;
	CString	m_sContent;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStatusShowDlg)

public:
	virtual BOOL Create(UINT nID, CWnd* pParentWnd);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CStatusShowDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnSend();
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif //_DEBUG_STATUS

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATUSSHOWDLG_H__8E1023AF_E688_4231_B14A_44CDC750473B__INCLUDED_)
