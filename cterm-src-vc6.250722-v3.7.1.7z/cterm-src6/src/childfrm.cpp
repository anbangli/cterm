// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "childfrm.h"
#include "Ctermview.h"
#include "mainfrm.h"
#include <afxpriv.h>
#include "ParamConfig.h"

#include "usermsg.h"
#include "debugtool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL g_SetMenuStrings(CMenu* pMenu, CString subKey);
/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_COMMAND(ID_FILE_CLOSE, OnFileClose)
	ON_WM_SETFOCUS()
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_WM_CHILDACTIVATE()
	ON_COMMAND(ID_FASTAWAY, OnFastaway)
	ON_UPDATE_COMMAND_UI(ID_FASTAWAY, OnUpdateFastaway)
	ON_WM_WINDOWPOSCHANGING()
	ON_MESSAGE(WM_CONNECTOK, OnConnectOK)
	ON_WM_KEYDOWN()
	ON_WM_SIZE()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_MDIACTIVATE()
	ON_WM_SYSCOMMAND()
	ON_WM_GETMINMAXINFO()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	m_pView = NULL;

#if ENABLE_CLOSEDLG
	m_pCloseDlg = NULL;
#endif//ENABLE_CLOSEDLG
}

CChildFrame::~CChildFrame()
{
	m_pView = NULL;
#if ENABLE_CLOSEDLG
	m_pCloseDlg = NULL;
#endif//ENABLE_CLOSEDLG
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	if (!CMDIChildWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	//cs.style &= ~FWS_ADDTOTITLE;

	cs.lpszClass = AfxRegisterWndClass(0);

	if (g_pMainWnd->ChildCount() == 0)
		cs.style |= WS_MAXIMIZE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers
void CChildFrame::OnFileClose()
{
	SendMessage(WM_CLOSE);
}

extern CTelnetSite g_LastSite;
extern int g_nConnectionType;
LRESULT CChildFrame::OnConnectOK(WPARAM wParam, LPARAM lParam)
{
	// �����ӳɹ��򱣴�lastsite
	g_szLastSiteName = g_LastSite.m_Login.m_szProfileName;
	g_nConnectType = g_nConnectionType;

	SetStatusBar(ID_INDICATOR_TERM, _T(""));

	return 1L;
}

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
//TRACE(_T("in CChildFrame::OnCreate\n"));

//����ʱ����
//	HWND hWnd = GetSafeHwnd();
//	::SetWindowLong ( hWnd, GWL_STYLE, GetWindowLong ( hWnd, GWL_STYLE ) & ~WS_VISIBLE );

//	lpCreateStruct->style &= ~WS_VISIBLE;

	if (CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// create a view to occupy the client area of the frame
	m_pView = new CCTermView();

	ASSERT(m_pView);

	if (!m_pView->Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
	                     CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL)) {
		TRACE0("Failed to create view window\n");
		return -1;
	}

	m_pView->OnInitialUpdate();

	SetIcon(AfxGetApp()->LoadIcon(IDI_FILE), TRUE);
	if (g_bRefreshTitle)
		SetTimer(TIMER_CHILDFRMTITLE, 100, NULL);

	return 0;
}

void CChildFrame::OnSetFocus(CWnd* pOldWnd)
{
	CMDIChildWnd::OnSetFocus(pOldWnd);

	if (m_pView)
		m_pView->SetFocus();

	CMainFrame *pMainFrame = (CMainFrame *) AfxGetMainWnd();
	pMainFrame->SetActiveChild(this);
#if ENABLE_SCREENMAP
	m_pView->m_Core.SetScrollSize();
#endif//ENABLE_SCREENMAP
}

// ȡ���Ӵ��ڵ�˳��ţ���Ӧ��Tab�ϵ���ţ�
//int CChildFrame::GetMyIndex()
//{
//	CMainFrame *pMainFrame = (CMainFrame *) AfxGetMainWnd();
//	return pMainFrame->m_Child.GetChildIndex(this);
//}

BOOL CChildFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	if (m_pView->OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// otherwise, do default handling
	return CMDIChildWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CChildFrame::OnClose()
{
//	TRACEFINTS(_T("closing ... \r\n"), m_pView->m_nSessionID);

//	static bool bClosing=true;
//	if(bClosing) // ���ַ���������
//		return;
	CMainFrame *pMainFrame = (CMainFrame *) AfxGetMainWnd();
#if ENABLE_CLOSEDLG

	if (m_pView->IsStarted()) {
		if (!g_bNoAskWhenClose) {
			CCloseDlg Dlg;
			m_pCloseDlg = &Dlg;
			int ret = Dlg.DoModal();
			m_pCloseDlg = NULL;
			// �˶Ի�����ʾ�����У�����һ��ʱ���޲��������ܴ����ѹر�(������վ�����)
			// this�Ѿ�û����! ft
			// ������ʲô������û������
			g_bNoAskWhenClose = Dlg.m_bNoAskWhenClose;

			if (ret == IDOK && Dlg.m_bFastAway) {   //fastaway
				if (m_pView && m_pView->IsStarted())
					m_pView->FastAway();

				return; //�˴�return û��ϵ�����ӶϿ��󻹻�ִ��һ��OnClose��
			}
			else if (ret == IDCANCEL) {
				return;
			}
		}

		// else ֱ�ӹر�
		// if( !(m_pView && m_pView->IsStarted()) )
		//	return;
	}

#endif//ENABLE_CLOSEDLG

	//�п��������ӹ����У���δ����m_bStarted����ȡ������ʱҲ��Ҫreset
	m_pView->m_Sock.Reset(); // todo: �Ƿ���Ҫ�ȴ���

	pMainFrame->DeleteChild(this);

	KillTimer(TIMER_CHILDFRMTITLE);

#if ENABLE_CLOSEDLG
	if (m_pCloseDlg)
		::SendMessage(m_pCloseDlg->m_hWnd, WM_CLOSE, 0, 0);    //if(ret==IDCANCEL) return

#endif//ENABLE_CLOSEDLG

//	TRACEFINTS(_T("closed!\r\n") , m_pView->m_nSessionID);

	CMDIChildWnd::OnClose(); // ��������if(m_pCloseDlg)֮��if(pMainFrame->m_Child.nChild<=0)֮ǰ

	// ִ�����󣬴����Ѿ��رգ���ص�һ�ж�����Ѿ����٣�view, sock�ȵȣ��Ժ��κεط��ٷ��ʶ������
	// ������վʱ���ױ���

	pMainFrame->SendMessage(WM_CHILDCLOSED);

//	bClosing=false;
}

void CChildFrame::OnChildActivate()
{
//TRACEF( "OnChildActivate\n");
//TRACE(_T("in CChildFrame::OnChildActivate\n"));
	CMDIChildWnd::OnChildActivate();
	SetActiveWindow();

	if (m_pView) {
		SetActiveView(m_pView);
	}

	SetTitle();
}

void CChildFrame::OnUpdateFastaway(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_pView->ConnectType() != 0 || m_pView->IsStarted());
}

void CChildFrame::OnFastaway()		// �����뿪
{
	m_pView->FastAway();
}

void CChildFrame::ChangeSize(WINDOWPOS FAR* lpwndpos)
{
	//TRACE( "in CChildFrame::OnWindowPosChanging 0\n");
	if (m_pView->CharHWRatio() > 0
		|| (m_pView->IsFixFont() || m_pView->Font() == _T("Fixedsys"))) {
		// �̶��߿���
		if (m_pView && !IsZoomed() && !IsIconic() && (lpwndpos->flags & SWP_NOSIZE) == 0) {
			//���ʱ�����ڴ�����ǰ��̨�л�ʱcx,cyΪ0;�����ƶ�ʱflags��SWP_NOSIZE������
			//��С��ʱ��cx, cyΪ160,24
//TRACE( "in CChildFrame::OnWindowPosChanging 1\n");

			CRect rect, rect1;
			GetWindowRect(&rect);
			m_pView->GetClientRect(&rect1);    //ע��viewҲ�зǿͻ�������Ȼ�ߴ��С��һ��Ϊ2��
			int ncx = rect.Width() - rect1.Width(), ncy = rect.Height() - rect1.Height();//�ǿͻ����ߴ�

			if (ncx > 0 && ncy > 0) {
				//��С��ʱ�п���Ϊ��
				if (g_bAutoSize && (m_pView->IsFixFont() || m_pView->Font() == _T("Fixedsys"))) {
					// �Զ�����
					int cw, ch;
					m_pView->ComputeCharSize(0, 0, cw, ch); // ǰ���������˴�����
					lpwndpos->cx = ncx + cw *m_pView->TermW() / 2;
					lpwndpos->cy = ncy + ch *m_pView->TermH();

				}
				else {
TRACE("here\n");
					int ratio = m_pView->CharHWRatio();
					if (m_pView->IsFixFont() || m_pView->Font() == _T("Fixedsys")) ratio = 2;

					int dx = lpwndpos->cx - rect.Width();
					int dy = lpwndpos->cy - rect.Height();
					
					if (abs(dx) < abs(dy)) dx = dy;         // dx�Ǿ���ֵ�ϴ���Ǹ�, �仯����Ǹ���������Ŵ�����С
					
					int cx = lpwndpos->cx - ncx, cy = lpwndpos->cy - ncy; //�µĿͻ�����С
					
					if ((cx < m_pView->TermW() * 2 || cy < m_pView->TermH() * 2)
						&& dx < 0) {
						lpwndpos->cx = m_pView->TermW() * 2 + ncx;
						lpwndpos->cy = m_pView->TermH() * 2 * ratio + ncy;
					}
					else {
						int x = cx / m_pView->TermW(); // �µİ���ַ�����
						int y = cy / (m_pView->TermH() * ratio);   //�µİ���ַ����ȣ���cy���������
						
						if (x > y)	x = y;   // ����ȡС
						
						x *= ratio;
						
						int ideal_cx = x *m_pView->TermW() / ratio;
						
						int ideal_cy = x *m_pView->TermH();
						
						int deltaX = cx - ideal_cx;
						
						int deltaY = cy - ideal_cy;
						
						int xinc = (dx > 0) ? max(deltaX / m_pView->TermW(), deltaY / m_pView->TermH() / 2) : 0;
						
						lpwndpos->cx = ideal_cx + xinc * m_pView->TermW() + ncx;
						
						lpwndpos->cy = ideal_cy + xinc * m_pView->TermH() *ratio + ncy;
					}
				}//g_bAutoSize else
			}//ncx > 0 && ncy > 0
		}//m_pView &&
//		else {
//
//			GetParentFrame()->RecalcLayout();
//
//			//		g_pMainWnd
//			//		&& (m_pView->m_bFixFont || m_pView->m_font == _T("Fixedsys"))
//			TRACE( "in CChildFrame::OnWindowPosChanging 2\n");
//			//&& IsZoomed()
//			//&& !IsIconic()
//			//&& (lpwndpos->flags&SWP_NOSIZE) == 0
//			
//			int ncx, ncy, maxsw, maxsh;
//			int ncx1, ncy1, ncx2, ncy2;
//			if (g_pMainWnd->NeedAutoSize(0, 0, ncx, ncy, ncx1, ncy1, ncx2, ncy2, maxsw, maxsh, lpwndpos->flags)) {
//				//			CRect rect, rect1;
//				//			GetWindowRect(&rect);
//				//			GetClientRect(&rect1);
//				//			ncx = rect.Width() - rect1.Width(), ncy = rect.Height() - rect1.Height();
//				
//				TRACE( "in CChildFrame::OnWindowPosChanging 3\n");
//				lpwndpos->cx = ncx1 + ncx2 + maxsw;
//				lpwndpos->cy = ncy1 + ncy2 + maxsh;
//			}
//		}
	}//m_nCharHWRatio > 0
}

void CChildFrame::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos)
{
	//ChangeSize(lpwndpos);

	CMDIChildWnd::OnWindowPosChanging(lpwndpos);
}

void CChildFrame::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
//TRACE(_T("in CChildFrame::OnKeyDown nChar=%d\n"), nChar);
	CMDIChildWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

#if ENABLE_FULLSCRN
void CChildFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI)
{
	if (g_pMainWnd->IsFullScreen()) {
		lpMMI->ptMaxSize.y = g_pMainWnd->m_FullScreenWindowRect.Height();
		lpMMI->ptMaxTrackSize.y = lpMMI->ptMaxSize.y;
		lpMMI->ptMaxSize.x = g_pMainWnd->m_FullScreenWindowRect.Width();
		lpMMI->ptMaxTrackSize.x = lpMMI->ptMaxSize.x;
	}

	CMDIChildWnd::OnGetMinMaxInfo(lpMMI);
}
#endif//ENABLE_FULLSCRN

void CChildFrame::OnSize(UINT nType, int cx, int cy)
{
//TRACE("in CChildFrame::OnSize	%d\n", nType);
	CMDIChildWnd::OnSize(nType, cx, cy);

	if (nType == SIZE_MINIMIZED) {
		BringWindowToTop();
	}
	else if (nType == SIZE_RESTORED) {
		// �����
		CRect r, r0;
		GetWindowRect(&r);
		r0 = r;

		CRect rmain;
		int w = r.Width(), h = r.Height();
		if (w < 100) w = 100;
		if (h < 100) h = 100;

		g_pMainWnd->GetWindowRect(&rmain);

		if (r.left >= rmain.right - 100) {
			r.left = rmain.right - 100;
			r.right = r.left + w;
		}

		if (r.top >= rmain.bottom - 100) {
			r.top = rmain.bottom - 100;
			r.bottom = r.top + h;
		}
		
		if (r.right <= rmain.left + 100) {
			r.right = rmain.left + 100;
			r.left = r.right - w;
		}

		if (r.bottom <= rmain.top + 100) {
			r.bottom = rmain.top + 100;
			r.top = r.bottom - h;
		}

		if (r != r0) {
			g_pMainWnd->ScreenToClient(&r);
			MoveWindow(&r, FALSE);
		}
	}

#if ENABLE_HIDEMENU
	// ��Ϊ����С��֮ǰ�ָ��ˣ�����������һ��
	if (!g_bMenuVisible && (nType == SIZE_MINIMIZED || nType == SIZE_RESTORED))
		g_pMainWnd->SetMenu(NULL);
#endif//ENABLE_HIDEMENU
}

void CChildFrame::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
//TRACE(_T("in CChildFrame::OnWindowPosChanged\n"));
	CMDIChildWnd::OnWindowPosChanged(lpwndpos);
		
	if(g_bAutoSize && m_pView && (m_pView->IsFixFont() || m_pView->Font() == _T("Fixedsys"))) {
		CWnd *pMainFrame = AfxGetMainWnd();
		if (pMainFrame && IsZoomed() && !pMainFrame->IsZoomed()) {

//			CRect rect1;
//			GetWindowRect(&rect1);
//TRACE(_T("rect: %d %d %d %d\n"), rect1.top, rect1.bottom, rect1.left, rect1.right);

			CRect rectWin;
			pMainFrame->GetWindowRect(&rectWin);
			pMainFrame->MoveWindow(&rectWin);

//			GetWindowRect(&rect1);
//TRACE(_T("rect: %d %d %d %d\n"), rect1.top, rect1.bottom, rect1.left, rect1.right);

			//g_pMainWnd->RedrawWindow();
			//m_pView->Refresh();
			//g_pMainWnd->RecalcLayout();
		}
	}
}

void CChildFrame::OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd) 
{
	bool b = true;
	
#if ENABLE_HIDEMENU
	extern HMENU g_hMainMenu2;
	b = (g_bMenuVisible || g_hMainMenu2 == NULL);
#endif//ENABLE_HIDEMENU
	
	if (b) {
		// ����������������Ϊ�˴����Ӳ˵�
		CMDIChildWnd::OnMDIActivate(bActivate, pActivateWnd, pDeactivateWnd);
	}
	else {
		// ������CMDIChildWnd::OnMDIActivate�Ĵ����޸�
		m_bPseudoInactive = FALSE;  // must be happening for real
		
		// make sure MDI client window has correct client edge
		UpdateClientEdge();
		
		// send deactivate notification to active view
		CCTermView* pActiveView = (CCTermView*)GetActiveView();
		if (!bActivate && pActiveView != NULL)
			pActiveView->OnActivateView(FALSE, pActiveView, pActiveView);
		
		// allow hook to short circuit normal activation
		BOOL bHooked = FALSE;
		//#ifndef _AFX_NO_OLE_SUPPORT
		//	if (m_pNotifyHook != NULL && m_pNotifyHook->OnDocActivate(bActivate))
		//		bHooked = TRUE;
		//#endif
		
		// update titles (don't AddToTitle if deactivate last)
		if (!bHooked)
			OnUpdateFrameTitle(bActivate || (pActivateWnd != NULL));
		
		// re-activate the appropriate view
		if (bActivate)
		{
			if (pActiveView != NULL && GetMDIFrame() == GetActiveWindow())
				pActiveView->OnActivateView(TRUE, pActiveView, pActiveView);
		}
		
		// update menus
		if (!bHooked)
		{
			if (g_bMenuVisible) {
				OnUpdateFrameMenu(bActivate, pActivateWnd, NULL);
				GetMDIFrame()->DrawMenuBar();// ��������л�ʱ�˵�������
			}
		}
	}
}

//DEL void CChildFrame::ActivateFrame(int nCmdShow) 
//DEL {
//DEL 	SetTitle();
//DEL 	
//DEL 	CMDIChildWnd::ActivateFrame(nCmdShow);	
//DEL }

void CChildFrame::SetTitle()
{
	SetWindowText(m_szTitle);
#if ENABLE_CAPTIONBUTTON
	if (g_pMainWnd)
		g_pMainWnd->RedrawCaptionButtons();
#endif//ENABLE_CAPTIONBUTTON
}

CString CChildFrame::GetTabTitle() const
{
	CString s(m_szTitle);

#if ENABLE_SWITCHBAR 
	if (!g_bTabFullName) {
		// վ���ǩ�н���ʾվ��������ʾ��λ����վ��
		// ������λ����
		int idx = s.Find('-');
		if (idx != -1)
			s = s.Right(s.GetLength() - idx - 1);
	}

	if (g_bTabUserName && m_pView->IsAutoLogin()) {
		//�Զ���½ʱ��վ���ǩ��ʾ�û���
		s += _T(":");
		s += m_pView->LoginName();
	}
#endif//ENABLE_SWITCHBAR 
	
#ifdef _DEBUG
	//g_bTitleSessionID
	if (true) {
		TCHAR buf[13];
		_stprintf(buf, _T(":%d"), m_pView->SessionID());
		s += buf;
	}
#endif//_DEBUG

	return s;
}

void CChildFrame::OnSysCommand(UINT nID, LPARAM lParam) 
{
//	TRACE("CChildFrame::OnSysCommand %x\n", nID);
// ���û������Ĵ��룬�Ӵ���û��ͼ��Ϳ��ư�ť����ʱ˫����С���Ĵ��ڱ����������������
// CPUռ���ʴ�70%����
// �����յ�SC_KEYMENU��Ϣ
//	if (nID == SC_KEYMENU || (nID & 0xFFF0) == SC_KEYMENU) {
//		TRACE("here1\n");
//	}
		
#if ENABLE_HIDEMENU
	if (!g_bMenuVisible && (nID == SC_MINIMIZE || nID == SC_RESTORE)) {
		// TRACE("here2\n");
		// �ȰѲ˵�����Ϊ�ǿգ��Ա��Ӵ��ڱ���������ͼ��Ϳ��ư�ť
		extern HMENU g_hMainMenu2;
		::SetMenu(g_pMainWnd->GetSafeHwnd(), g_hMainMenu2);
	}
#endif//ENABLE_HIDEMENU
	CMDIChildWnd::OnSysCommand(nID, lParam);
}

void CChildFrame::OnTimer(UINT nIDEvent)
{
	CString szTitle;
	GetWindowText(szTitle);
//TRACE(_T("in CChildFrame::OnTimer szTitle:%s, m_szTitle:%s\n"), szTitle, m_szTitle);

	if (szTitle != m_szTitle && g_bRefreshTitle) {
		AfxSetWindowText(m_hWnd, m_szTitle);
		TRACE("now title is %s\n", szTitle);
	}

	CMDIChildWnd::OnTimer(nIDEvent);
}