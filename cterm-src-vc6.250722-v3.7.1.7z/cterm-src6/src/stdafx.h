// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__2AC2BA94_FE64_11D3_B1BC_000080013F30__INCLUDED_)
#define AFX_STDAFX_H__2AC2BA94_FE64_11D3_B1BC_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#pragma warning(disable:4018 4097 4100 4146 4201 4239 4244 4245 4284 4514 4711 4800)
//warning C4239: nonstandard extension used : 'argument' : conversion from 'class CString' to 'class CString &'

//#define   WINVER   0x0501

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#include <afxadv.h>
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include "resource.h"

#ifndef _UNICODE
#define ENABLE_IPV6	1// ��Ҫ����ǰ�棿
#endif

#if _MSC_VER <= 1200
// vc6
// ��ʹ��winsock2.h����������<afxsock.h>�������õ�winsock.h����������<ws2tcpip.h>��ͻ
#include "afxsock.h"
#else //VS_VC80, etc.
#include <afxsock.h>		// MFC socket extensions
#endif

#define AUTO_SUBCLASS
#define MFCX_PROJ
/*
#define MFCXLIB_STATIC
*/

#define safe_delete(p){if(p){delete p;p=NULL;}}

#include "imm.h"

//////�������������뿪��
// ��ʱ
//#define _DEBUG_RELEASE

// ����
//#define ENABLE_ZMODEM
//#define FOR_BYHH

#define ENABLE_TRANSPARENT	1
#define ENABLE_BTNST	1
#define ENABLE_MESSAGE	1
#define ENABLE_EDITBOX	1
#define ENABLE_BITMAPWND	1
#define ENABLE_COOLMENU	1
#define ENABLE_FUNKEY	1
#define ENABLE_SEARCHBOX	1
#define ENABLE_CONTROLSOCK	1
#define ENABLE_HOTKEY	1
#define ENABLE_TIPDLG	1
#define ENABLE_HTMLDOWN	1
#define ENABLE_BASE64	1
#define ENABLE_ATTACH	1
#define ENABLE_LOCK	1
#define ENABLE_DOWNLOAD	1
#define ENABLE_COPYTCP	1
#define ENABLE_UPDATE	1
#define ENABLE_CLOSEDLG	1
#define ENABLE_CLEARTYPE	1
#define ENABLE_BUF_QUEUE	1
#define ENABLE_FDEX	1// ��չ�ļ��Ի���
#define ENABLE_INSERTANSI 1// ����ANSI��

#define ENABLE_CTD	1
#if ENABLE_CTD
#define ENABLE_RAWCTD 1
#endif//ENABLE_CTD
#define ENABLE_SCREENMAP 1

#define ENABLE_MULTILANG	1
#define ENABLE_NIW_FONT 1// �Ƿ������ǵȿ�����
//#define ENABLE_SCROLL 0// δʵ�֣�����

#define ENABLE_ADDRBOOK	1
#if ENABLE_ADDRBOOK
#define ENABLE_SITECONFIG	1
#define ENABLE_FILTER 1// ENABLE_FILTER��ENABLE_ADDRBOOKҪͬʱ����
#define ENABLE_PROXY	1
#endif//ENABLE_ADDRBOOK

#define ENABLE_SYSCONFIG	1
#if ENABLE_SYSCONFIG
#define ENABLE_OPTADV	1// �߼�ѡ�����״ѡ�
#endif//ENABLE_SYSCONFIG

#define ENABLE_SWITCHBAR	1
#define ENABLE_BBSBAR	1
#define ENABLE_ASCIIBAR	1
#define ENABLE_MMSTATUSBAR	1
#define ENABLE_SCROLLBAR	1

#define ENABLE_HIDEMENU	1
#define ENABLE_CAPTIONBUTTON	1// ��������ť�����ز˵�ʱ��
#define ENABLE_MENUFAVTOP	1
#define ENABLE_HIDECURSOR	1
#define ENABLE_FULLSCRN	1

#define ENABLE_PIPESSH	1

#ifndef _DEBUG
// vbs, drag ��debugʱ������
#define ENABLE_VBS	1
#define ENABLE_DRAG	1
#endif

//only ANSI version
#if !defined(UNICODE) && !defined(_UNICODE)

#define ENABLE_PICTURE	1

#define ENABLE_SHOWIP	1
#if ENABLE_SHOWIP
#define ENABLE_REPLACEIP	1// �Ƿ������Զ��滻IP
#endif

#define ENABLE_PYTHON	1

#if ENABLE_PICTURE
#define ENABLE_PNG	1// pngͼƬ֧��
#endif

#define ENABLE_ACCELEDIT	1// �Զ�����ټ�

#define ENABLE_BATCHDLG	1// ������
#define ENABLE_URLENCODE	1// URL����
#define ENABLE_URLDLG	1
#define ENABLE_POSTDLG	1// ���ĶԻ���

#define ENABLE_CHATDLG	1 // ����Ի���
#define ENABLE_SEARCHDLG	1

#define ENABLE_LINK	1// cterm����

#define ENABLE_EXTENDED	0// ��չ����(��չ�汾)
#if ENABLE_EXTENDED
#define ENABLE_GRAPH	1// ��ͼ������
#define ENABLE_LAYER	1// �����ʾ����ʵ��ѭ����Ч������
#endif

#else //UNICODE
//#include "StringA.h"
#endif//UNICODE

//��DLLʹ��
#ifdef AFX_CLASS_EXPORT
#undef AFX_CLASS_EXPORT
#define AFX_CLASS_EXPORT
#endif
///////�������뿪�ؽ���

#if ENABLE_FDEX
#include "filedialogex.h"
#else
typedef CFileDialog CFileDialogEx;
#endif//ENABLE_FDEX

#if ENABLE_MULTILANG
void g_SetDialogStrings(CDialog *pDlg, UINT uDlgID);
#endif//ENABLE_MULTILANG

#include <tchar.h>

#define STL_USING_ALL
#include "stl.h"

#ifdef _UNICODE
typedef std::wstring tstring;
#else
typedef std::string tstring;
#endif

#define _S(x) (x) // ANSI

inline BOOL isempty(const char *s)
{
	return s[0] == '\0';
}

inline BOOL isempty(const WCHAR *s)
{
	return s[0] == '\0';
}

inline BOOL isdown(int k)
{
#define SHIFTED 0x8000
	return  GetKeyState(k) & SHIFTED;
}

extern CString g_szWorkDir;
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__2AC2BA94_FE64_11D3_B1BC_000080013F30__INCLUDED_)
