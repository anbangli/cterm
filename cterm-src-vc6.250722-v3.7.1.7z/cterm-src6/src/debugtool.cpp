#include "stdafx.h"
#include "debugtool.h"

#if defined(_DEBUG) || defined(_DEBUG_RELEASE)

CString g_sDebugInfo; //for debuginfo.txt

void dumpBuf(const TCHAR *buf, const int nLen, TCHAR *filename)
{
	FILE *fp;
	fp = _tfopen(filename, _T("a"));

	if (fp) {
		const TCHAR info[] = _T("\n----=====Buf Start=====-------\n");
		fwrite(info, _tcslen(info), 1, fp);
		fwrite(buf, nLen, 1, fp);
		const TCHAR info1[] = _T("\n----=====Buf End=====-------\n\n");
		fwrite(info1, _tcslen(info1), 1, fp);
		fclose(fp);
	}
}

void TraceF(TCHAR s[])
{
	FILE *fp = _tfopen(g_sDebugInfo, _T("ab"));

	if (fp) {
		TRACE(_T("%s\r\n"), s);
		_ftprintf(fp, _T("%s\r\n"), s);
		fclose(fp);
	}
}

void TraceF(int n, TCHAR *s)
{
	FILE *fp = _tfopen(g_sDebugInfo, _T("ab"));

	if (fp) {
		TRACE(_T("%s%d\r\n"), s, n);
		_ftprintf(fp, _T("%s%d\r\n"), s, n);
		fclose(fp);
	}
}

void TraceFHex(int n, TCHAR *s)
{
	FILE *fp = _tfopen(g_sDebugInfo, _T("ab"));

	if (fp) {
		TRACE(_T("%s%p\r\n"), s, n);
		_ftprintf(fp, _T("%s%p\r\n"), s, n);
		fclose(fp);
	}
}

#endif// defined(_DEBUG) || defined(_DEBUG_RELEASE)

CString ESCStr(const CString &s)
{
//#if defined(_DEBUG) || defined(_DEBUG_RELEASE)
	CString str = s;
	str.Replace(_T("\r"), _T("\\r")); //��Ч
	str.Replace(_T("\n"), _T("\\n"));
	str.Replace(_T("\x1b"), _T("\\x1b"));
	str.Replace(_T(" "), _T("_")); //�ո���Ų����
	str.Replace(_T("\x0c"), _T("^L"));
	return str;
//#else
//	return s;
//#endif//defined(_DEBUG) || defined(_DEBUG_RELEASE)
}
