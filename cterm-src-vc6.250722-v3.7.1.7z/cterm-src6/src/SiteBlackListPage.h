#if !defined(AFX_SITEBLACKLISTPAGE_H__5AA07E32_3E23_47A0_9BBC_55220A5EA6B1__INCLUDED_)
#define AFX_SITEBLACKLISTPAGE_H__5AA07E32_3E23_47A0_9BBC_55220A5EA6B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteBlackListPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteBlackListPage dialog

class CSiteBlackListPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteBlackListPage)

// Construction
public:
	CSiteBlackListPage(); 
	~CSiteBlackListPage();

// Dialog Data
	//{{AFX_DATA(CSiteBlackListPage)
	enum { IDD = IDD_SITE_BLACKLIST };
	CEdit	m_EditBlackList;
	BOOL	m_bBlackList;
	CString	m_szBlackList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSiteBlackListPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSiteBlackListPage)
	afx_msg void OnCheckBlacklist();
	afx_msg void OnOpenini();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITEBLACKLISTPAGE_H__5AA07E32_3E23_47A0_9BBC_55220A5EA6B1__INCLUDED_)
