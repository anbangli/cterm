// AskDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AskDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAskDlg dialog


CAskDlg::CAskDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CAskDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAskDlg)
	m_nType = 0;
	//}}AFX_DATA_INIT
	m_bDigest = FALSE;
}


void CAskDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAskDlg)
	DDX_Control(pDX, IDC_COM_LIST, m_list);
	DDX_CBIndex(pDX, IDC_COM_LIST, m_nType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAskDlg, CDialog)
	//{{AFX_MSG_MAP(CAskDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAskDlg message handlers

BOOL CAskDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

//
//	if (m_bDigest)
//		m_list.AddString(_T("�����б����밴�б�����"));

	UpdateData(FALSE); // ����m_nType�����б���

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}
