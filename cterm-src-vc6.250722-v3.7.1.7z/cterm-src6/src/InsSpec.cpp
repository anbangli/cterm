// InsSpec.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "InsSpec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsSpec property page

IMPLEMENT_DYNCREATE(CInsSpec, CMyPropertyPage)

CInsSpec::CInsSpec() : CMyPropertyPage(CInsSpec::IDD)
{
	//{{AFX_DATA_INIT(CInsSpec)
	m_type = 0;
	//}}AFX_DATA_INIT
}

CInsSpec::~CInsSpec()
{
}

void CInsSpec::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsSpec)
	DDX_Radio(pDX, IDC_RADIO1, m_type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsSpec, CMyPropertyPage)
	//{{AFX_MSG_MAP(CInsSpec)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsSpec message handlers
CString CInsSpec::GetStr()
{
	UpdateData(TRUE);
	CString r(_T("\x1b"));
	switch (m_type) {
	case 0://
		r += _T("[2J");
		break;
	case 1:
		r += _T("[K");
		break;
	case 2:
		r += _T("[G");
		break;
	case 3:
		r += _T("[100M");// todo: nM
		break;
	case 4:
		r += _T("[0I");
		break;
	case 5:
		r += _T("[1I");
		break;
	case 6:
		r += _T("[2I");
		break;
	case 7:
		r += _T("[3I");
		break;
	}
	return r;
}
