// CTermSock.cpp : implementation file
//

#include "stdafx.h"

#include "CTermSock.h"
#include "ctermview.h"
#include "MainFrm.h"
#include "usermsg.h"
#include "paramconfig.h"
#include "forcode.h"
#include "debugtool.h"

#include <process.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//��������sockָ����б�������delete; �����˳���ʱ�򣬵ȴ�����sock��closeevent
//Ҳ��closeeventҪ����һ������ͬʱ�ȴ�?
//extern std::vector<CCTermSock *> g_SocksList;



/////////////////////////////////////////////////////////////////////////////
// CCTermSock

CCTermSock::CCTermSock() :
		CProxySock(),
		m_StartTime(1978, 8, 16, 0, 0, 0),
		m_hDataReader(NULL),
		m_dataBuf(NULL),
		m_dataLen(0),
		m_nFilterCount(0),
		m_bFilterWarned(false)
{
	m_pView = NULL;
	m_nSendSize = 0;
	m_nReceiveSize = 0;
	m_bUnStable = FALSE;
	_tcscpy(m_szCopyFile, _T(""));

#if ENABLE_COPYTCP
	m_bCopyTCP = false;
	//m_bCopyingTCP = false;
#endif//ENABLE_COPYTCP
}

CCTermSock::~CCTermSock()
{
#if ENABLE_BUF_QUEUE
	if (!m_buf_queue.empty()) {
		//TRACE("buf_queue size = %d\n", m_buf_queue.size());
		for (std::deque<SBuf>::iterator it = m_buf_queue.begin();
			it != m_buf_queue.end();
			++it) {
			if (it->m_buf) delete [] it->m_buf;
		}
	}
#endif//ENABLE_BUF_QUEUE
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CCTermSock, CAsyncSocket)
	//{{AFX_MSG_MAP(CCTermSock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CCTermSock member functions

void CCTermSock::OnReceive(int nErrorCode)
{
//	TRACE ( _T ( "in CCTermSock::OnReceive: %d %d, sleep: %d\n" ), m_nLen, m_nStatus, m_pView->m_bSleeping );
	//if (m_pView->m_bSleeping) {
	//	TRACE(_T("receive when sleeping... \n"));
	//	return; // �����Ĺؼ������
	//}

	CProxySock::OnReceive(nErrorCode);

	ASSERT(m_pBuf);

	if (m_nLen) {
		switch (m_nStatus) {

		case PSOCK_CONNECTING: // ��������ʱ������������ʱ����
		case PSOCK_CONNECTED:
			if (m_pView->ConnectType() == 0 && !m_bStarted)
				OnConnectOK();
			break;
		}
	}

	if (m_nLen > 0) {
#if ENABLE_BUF_QUEUE
		SBuf b = {m_pBuf, m_nLen};
		m_buf_queue.push_back(b);
		//TRACE("push %p buf_queue size = %d\n", m_pBuf, m_buf_queue.size());

		BYTE *buf = m_bufpool.getBuf();
		if (m_pBuf == buf_in)
			buf_in = buf;
		else
			buf_out = buf;

		if (m_pView 
			&& m_pView->Inited()
			&& m_pView->ViewInited())
			m_pView->PostMessage(WM_DATA_COME);
#else
		m_dataBuf = m_pBuf;
		m_dataLen = m_nLen;
		ProcessReceive();
#endif//ENABLE_BUF_QUEUE
	}
}

// �����յ�����Ϣ
void CCTermSock::ProcessReceive()
{
	// || m_pView->m_bSleeping
	//|| !m_pView->m_Core.m_bFinishPacket
	if (!m_pView || !m_pView->m_Core.FinishPacket() || !m_pView->ViewInited()) return;
	
	bool bLoop = true; // for ENABLE_BUF_QUEUE
	do {
#if ENABLE_BUF_QUEUE
		SBuf b;
		if (m_buf_queue.empty()) {
			break;
		}
		else {
			//m_cs_buf_queue.Lock();
			b = m_buf_queue.front();
			m_dataBuf = b.m_buf;
			m_dataLen = b.m_len;
			m_buf_queue.pop_front();
			//TRACE("pop %p buf_queue size = %d\n", m_dataBuf, m_buf_queue.size());
			//m_cs_buf_queue.Unlock();
		}
#else // no ENABLE_BUF_QUEUE
		bLoop = false;
#endif//ENABLE_BUF_QUEUE

		if (m_dataBuf == NULL)
			break;

		//int nOldStatus;
		m_dataBuf[m_dataLen] = 0;
		//	TRACE(_T("in CCTermSock::ProcessReceive\n"));
		
		if (m_dataLen > 0) {
#if ENABLE_COPYTCP
			if (m_pView->ConnectType() == 0) {
				// ����ctd�ļ�, �ſ���
				CopyTcpPack();
			}
#endif//ENABLE_COPYTCP
			
			m_nReceiveSize += m_dataLen;
			
			m_pView->ShowStream(m_dataLen / 50);
			
			m_pView->SetWaitReceive(false);
			
			//TRACE("m_nLen=%d m_bWaitReceive = FALSE\n", m_nLen);
			//	TRACE(_T("7m_bWaitReceive:%d\n"), m_pView->m_bWaitReceive);
			m_bUnStable = FALSE;
			
			//TRACE(_T("2\n"));
			
			if (m_pView) {
				m_pView->m_Core.SetTermType(DT_CTERM);// ���������link ��ʾ����
				
				//nOldStatus = m_pView->GetStatus();
				
				//#ifdef _DEBUG
				//			extern DWORD g_datalasttick;
				//			DWORD tick = GetTickCount();
				//			TRACE(_T("in CCTermSock::ProcessReceive before AddTxt "));
				//			TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick - g_datalasttick);
				//			g_datalasttick = GetTickCount();
				//#endif //_DEBUG
				
				// save for filter
				BYTE * dataBuf = m_dataBuf;
				int dataLen = m_dataLen;

				m_pView->m_Core.AddTxt((char *)m_dataBuf, m_dataLen);
				
				//#ifdef _DEBUG
				//			tick = GetTickCount();
				//			TRACE(_T("in CCTermSock::ProcessReceive after AddTxt "));
				//			TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick - g_datalasttick);
				//			g_datalasttick = GetTickCount();
				//#endif //_DEBUG
				
#if ENABLE_PYTHON
				int id = m_pView->SessionID();
				g_pMainWnd->PythonCallback(_T("OnDataCome"), (long*) &id, 1);
				
				//#ifdef _DEBUG
				//			tick = GetTickCount();
				//			TRACE(_T("in CCTermSock::ProcessReceive after python OnDataCome "));
				//			TRACE(_T(" \t tick=%ld, elapse:%ld\n"), tick, tick - g_datalasttick);
				//			g_datalasttick = GetTickCount();
				//#endif //_DEBUG
				
#endif//ENABLE_PYTHON
				
#if ENABLE_MESSAGE
				//m_pView->m_Status.GetStatus(); //����m_Core.AddTxt()��
				
				if (m_pView->GetStatus() == SST_MESSAGE) {
					//TRACE(_T("3\n"));
					extern bool g_bAutoReply;
					m_pView->PopMessage(g_bAutoReply); // ���ǶԻ�����ʾʱ���ߵ����⣬�����治����ִ���κβ���...�������𣿻�������߾͹ص��Ի���
				}
				
				//else
#endif//ENABLE_MESSAGE
				BYTE & cv = m_pView->m_Site.m_Decode.m_nOutputCodeConvert;
				if (!(cv == OUTPUT_B2G || cv == OUTPUT_G2B || cv == OUTPUT_H2G)) {
					// cv �⼸��ֵ������Ѿ����˹���
					m_pView->m_Site.m_Login.m_AutoLogin.DoFilter(dataBuf, dataLen, this,		//ִ�й�����
						m_pView->m_Site.m_Login.m_bAutoLogin, m_pView->m_Core.CaretAtBottom(), m_pView->isSSH());
				}

				//	m_pView->m_szClick[0] = '\0';//Click Reset
			}
		}//if (m_dataLen > 0)
#if ENABLE_BUF_QUEUE
		else {
			m_bufpool.freeBuf(b.m_buf);
		}
#endif//ENABLE_BUF_QUEUE

		if(!m_pView->m_Core.FinishPacket()) break;
	} while(bLoop);
}

// receive�����ݷǿ�ʱ�Ż���ã����������ӳɹ���
void CCTermSock::OnConnectOK()
{
	//TRACE(_T("CCTermSock::OnConnectOK()\n"));
	m_bStarted = TRUE;
	if (!m_pView->isSSH()) {
		m_pView->SetLogined(true); // TODO ��SSH���޷��жϣ�ֻҪ�����Ͼ��趨Ϊ��
	}

#if ENABLE_PYTHON
	int id = m_pView->SessionID();
	g_pMainWnd->PythonCallback(_T("OnSessionOpen"), (long*) &id, 1);
#endif

	// ���ӳɹ����Ӵ��巢��Ϣ
	if (m_pView)
		(m_pView->GetParentFrame())->SendMessage(WM_CONNECTOK, (WPARAM)0, (LPARAM)0);

	if (!m_pView) {
		Reset();
		return;
	}

	m_pView->m_Core.AddTxt("\x1b[2J", 4, true);

#if ENABLE_PROXY
	m_pView->m_Site.m_Login.m_TelnetProxy.Reset();
#endif//ENABLE_PROXY

	m_StartTime = CTime::GetCurrentTime();

	// ����Ϳ�ʼ��ʾվ�������ˣ�������big5��Ҫ��������
	m_pView->Refresh(); // ��������
}

#if ENABLE_PROXY
void CCTermSock::SetProxy(SLoginSet *pLogin)
{
	if (pLogin->m_nProxyType == PT_NONE) {
		m_bProxy = FALSE;
		return;
	}

	//else
	CProxySock::SetProxy(pLogin->m_nProxyType, pLogin->m_szProxyAddr, pLogin->m_nProxyPort,
	                      pLogin->m_szAddr, pLogin->m_nPort);

	switch (pLogin->m_nProxyType) {

	case PT_TELNET:
		memcpy(&TProxy, &pLogin->m_TelnetProxy, sizeof(STelnetProxy));
		break;

	case PT_SOCK4:
		SetSock4();
		SetProxyUser(pLogin->m_szProxyName, pLogin->m_szProxyPSW); // ���û����䣬release��������
		break;

	case PT_SOCK5:
	case PT_HTTP:
		SetProxyUser(pLogin->m_szProxyName, pLogin->m_szProxyPSW);
		break;

	case PT_CTERM:
		break;
	}
}
#endif//ENABLE_PROXY

void CCTermSock::OnConnectError(int errcode, char *errinfo)
{
	//TRACE(_T("CCTermSock::OnConnectError()\n"));
	Reset();

	if (m_pView) {

		m_pView->m_Core.SetTermType(DT_CTERM);// ���������link ��ʾ����

		m_pView->Refresh(); // ��������

		char formatstr[] = "\x1b[2J%s\r\n\r\n[\x1b[U<command=\"close\" text=\"�رմ���\" color=14>]";
		char *errstr = NULL;

		if (errinfo)
			errstr = errinfo;
		else {
			//	if ( m_pView->m_Site.m_Decode.m_nOutputCodeConvert <= OUTPUT_B2G )
			errstr = "�������ӷ�������";
			//else
			//	errstr = _T ( "Connection failed." );
		}

		char *ts = new char[ strlen(formatstr) + strlen(errstr) + 1 ];

		sprintf(ts, formatstr, errstr);
		//\x1b[g<SBC(192,192,192) FR(0,0,12,10) SBC(255,255,255) FR(1,3,11,9) SFC(100,100,255) L(1,1,11,1)>\x1b[m\\x1b[g<SFC(255,0,0) L(2,4,10,8) L(2,8,10,4)>";
		m_pView->m_Core.AddTxt(ts, strlen(ts));
		m_pView->m_Status.SetStatus(SST_ENTER);

		delete [] ts;

		CString sInfo;

		if (errcode)
			sInfo.Format(_T("connect error: %d"), errcode);
		else // 0
			sInfo = _T("disconnected");

		SetStatusBar(ID_INDICATOR_TERM, sInfo);
	}

	//fprintf(stderr, "Error Opening socket, error %d: %s\n",
	//      WSAGetLastError(), PrintError(WSAGetLastError()));
}

int CCTermSock::Send(const void* lpBuf, int nBufLen, int nFlags)
{
	m_bUnStable = TRUE;
	return SendAndLog(lpBuf, nBufLen, nFlags);
}

int CCTermSock::SendIt(const void* lpBuf, int nBufLen, int nFlags)
{
	if (nBufLen <= 0 || !m_pView)
		return 0;

#if ENABLE_PYTHON
//	long nArgs[4]={m_pView->m_nSessionID, long(lpBuf), nBufLen};
//	g_pMainWnd->PythonCallback(_T("OnSend"), nArgs, 3);
#endif

	m_nSendSize += nBufLen;

	m_pView->ClearLastInputTime();

	int ret = -1;

	bool b = true;
#if ENABLE_PIPESSH
	if (m_pView->PipeOpen()) {
		m_pView->WritePipeData(lpBuf, nBufLen);
		b = false;
	}
#endif//ENABLE_PIPESSH
	
	if (b) {
		ret = CAsyncSocket::Send(lpBuf, nBufLen, nFlags);
	}

	return ret;
}

int CCTermSock::SendAndLog(const void* lpBuf, int nBufLen, int nFlags, const TCHAR * trigger)
{
	if (nBufLen <= 0 || !m_pView)
		return 0;
	
	int ret = SendIt(lpBuf, nBufLen, nFlags);

	char c = *((char *)lpBuf);
	if (c == '\r' || c == '\n') {
		if (m_pView->m_Status.isReplyMsg()) {
			m_pView->m_Status.SetReplyMsgEnd();
		}
	}

//TRACE ( _T ( "in CCTermSock::Send.  sending \"%s\", len: %d\n" ), lpBuf, nBufLen );
	/*		for(int i=0; i<nBufLen;i++)
	{
	TRACE(_T("\t %x "), *(TCHAR *)((TCHAR*)lpBuf+i), nBufLen);
	}
	TRACE(_T("\n"), (TCHAR*)lpBuf+i, nBufLen);
	*/
	AnsiLog(lpBuf, nBufLen, true, trigger);

#if ENABLE_COPYTCP
#define g_bCopyTCP_Key true
	if (m_bCopyTCP && g_bCopyTCP_Key && m_pView->ConnectType() == 0) {
		FILE *fp = _tfopen(m_szCopyFile, _T("ab"));       // ���´򿪴��ļ�

		if (fp) {
			// ��չANSI��*[lenk<...> ��ʾ����
			int len = nBufLen;

			if (len > MAX_KEYRECORD_LEN) len = MAX_KEYRECORD_LEN;

			fprintf(fp, "%s[%dk<", m_pView->m_pESCChar, len);

			fwrite((char*) lpBuf, len, 1, fp);

			fwrite(">" , 1, 1, fp);

			fclose(fp);
		}
	}
#endif//ENABLE_COPYTCP

	return ret;
}

void CCTermSock::OnClose(int nErrorCode)
{
#if ENABLE_PIPESSH
	if (m_pView)
		m_pView->KillPlinkProcess();
#endif//ENABLE_PIPESSH

#if defined(_DEBUG_RELEASE) || defined(_DEBUG)
	FILE *fp = NULL;
#endif
//	TRACEFINTS(_T("closing sock ...\r\n"), m_pView->m_nSessionID);


#if ENABLE_BUF_QUEUE
	while (!m_buf_queue.empty()) {
		ProcessReceive();
	}
#endif//ENABLE_BUF_QUEUE

	m_bStarted = FALSE;
	Reset();  //	OnConnectError( 0, _T( "�ѶϿ�" ) );
	AfxGetMainWnd()->SendMessage(WM_DISCONNECTED, WPARAM(m_pView->SessionID()), 0);

#ifdef _DEBUG
	AnsiLog("\nClosed\n", 8, true);
#endif

	// CAsyncSocket::OnClose(nErrorCode);
	if (g_bSiteReport && m_pView) {
//		m_pView->Refresh();
		//��big5������£����Ҫ��ʾ����վ�㱨�棬��ʱҪͬ����ʾbig5���gb�룬
		//����big5δ��ת�룬��Ϊ�������嶼�����룬��ˣ�������Ӣ�ı��������

		m_pView->m_Core.SetTermType(DT_CTERM);//���������link ��ʾ����
		char buf[1024] = "";
		//TCHAR buf1[];
		char ts[110] = "";
		CTimeSpan Dif;

		if (m_StartTime.GetYear() == 1978)
			Dif = CTimeSpan(0, 0, 0, 0);
		else
			Dif = CTime::GetCurrentTime() - m_StartTime;

		if (g_bReportSimple) {
			sprintf(buf, "\x1b[%d;%dH\x1b[0;1;31mClosed!\x1b[m", m_pView->TermH(), m_pView->TermW() - 6);
		}
		else if (m_pView->m_Site.m_Decode.m_nOutputCodeConvert <= OUTPUT_B2G) {
			strcpy(buf,
			       "\x1b[21;0H"
			       "          \x1b[1;32m�X�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�[\x1b[0m\x1b[K\r\n"
			       "          \x1b[1;32m�U          \x1b[1;37m��վ��������ѶϿ���                          \x1b[1;32m�U\x1b[0m\x1b[K\r\n");
			//int n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m�U          \x1b[1;37mͣ��ʱ��  ��%10d Сʱ%2d��               \x1b[1;32m�U\x1b[0m\x1b[K\r\n", Dif.GetDays() *24 + Dif.GetHours(), Dif.GetMinutes());
			//int m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m�U          \x1b[1;37m�ϴ��ֽ�����%10d Bytes                  \x1b[1;32m�U\x1b[0m\x1b[K\r\n", m_nSendSize);
			//m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m�U          \x1b[1;37m�����ֽ�����%10d Bytes                  \x1b[1;32m�U\x1b[0m\x1b[K\r\n", m_nReceiveSize);
			//m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			strcat(buf,
			       "          \x1b[1;32m�U          \x1b[1;37m���س���[\x1b[U<command=\"reconnect\" text=\"��������\" color=14>]��\x1b[1;37m�����[\x1b[U<command=\"close\" text=\"�رմ���\" color=14>]          \x1b[1;32m�U\x1b[0m\x1b[K\r\n"
			       "          \x1b[1;32m�^�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�T�a\x1b[0m\x1b[K");
			//n=strlen(buf);
		} else {
			strcpy(buf,
			       "\x1b[21;0H"
			       "          \x1b[1;32m============================================================\x1b[0m\x1b[K\r\n"
			       "          \x1b[1;32m        \x1b[1;37mConnection to host is shutdown.                          \x1b[1;32m \x1b[0m\x1b[K\r\n");
			//int n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m        \x1b[1;37mConnection time: %5d hour(s) %2d minute(s)               \x1b[1;32m \x1b[0m\x1b[K\r\n", Dif.GetDays() *24 + Dif.GetHours(), Dif.GetMinutes());
			//int m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m        \x1b[1;37mUploaded  : %10d Bytes                  \x1b[1;32m \x1b[0m\x1b[K\r\n", m_nSendSize);
			//m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			sprintf(ts, "          \x1b[1;32m        \x1b[1;37mDownloaded: %10d Bytes                  \x1b[1;32m \x1b[0m\x1b[K\r\n", m_nReceiveSize);
			//m=strlen(ts);
			strcat(buf, ts);
			//n=strlen(buf);
			strcat(buf,
			       "          \x1b[1;32m        \x1b[1;37mPress Enter to \x1b[U<command=\"reconnect\" text=\"Reconnect\" color=14>, \x1b[1;37m other keys to \x1b[U<command=\"close\" text=\"Close\" color=14>                  \x1b[1;32m \x1b[0m\x1b[K\r\n"
			       "          \x1b[1;32m============================================================\x1b[0m\x1b[K");
			//n=strlen(buf);
		}

		m_pView->m_Core.AddTxt(buf, strlen(buf), true);

		m_pView->m_Status.SetStatus(SST_ENTER);
	}//no g_bSiteReport
	else {
		CFrameWnd *pFrame = m_pView->GetParentFrame();

		if (pFrame)
			pFrame->SendMessage(WM_CLOSE, 0, 0);

		//ִ������䴰���Ѿ��ر��ˣ��������д�������Ǻ��Ӵ���(view)��ص��κζ�������һ�����������һ����Ϣ
	}//if(g_bSiteReport)
}

#if ENABLE_COPYTCP
// ����TCP��
void CCTermSock::CopyTcpPack(BOOL bTRUE, CString szFile)
{
	//Start or Stop Copy
	FILE *fp = NULL;

	if (bTRUE) {
		fp = _tfopen(szFile, _T("wb"));

		if (fp) {
			_tcscpy(m_szCopyFile, szFile); //???
			fclose(fp);
		} else {
			_tcscpy(m_szCopyFile, _T(""));
		}

		m_bCopyTCP = true;
	} else {
		_tcscpy(m_szCopyFile, _T(""));
		m_bCopyTCP = false;
	}

	return;
}

void CCTermSock::CopyTcpPack() const
{
	if (!m_bCopyTCP)   //if ( m_szCopyFile[0] == '\0' )
		return;

	//��֤ԭ�Ӳ���
//	if ( m_bCopyingTCP ) return;
//	m_bCopyingTCP = true;

//	BYTE *Buf;
//	int  i, n = 0;

	if (m_dataLen <= 0) return;

	FILE *fp = _tfopen(m_szCopyFile, _T("ab"));       //���´򿪴��ļ�

	if (fp) {
//		Buf = ( BYTE * ) malloc ( m_nLen * 2 );
//		if ( Buf )
//		{
//			for ( i = 0;i < m_nLen;i++ )
//			{
//				if ( buf[i] )
//				{
//					Buf[n] = buf[i];
//					n++;
//					if ( buf[i] == 27 )
//					{
//						Buf[n] = buf[i];
//						n++;
//					}
//				}
//			}
//			Buf[n] = 0;
//			fwrite ( Buf, n, 1, fp );
//			free ( Buf );
//		}
		fwrite(m_dataBuf, m_dataLen, 1, fp);
		fclose(fp);
	}

//	m_bCopyingTCP = false;
}

#endif//ENABLE_COPYTCP

void CCTermSock::AnsiLog(const void * buf /*NULL for create*/, int len, bool bSend, const TCHAR * trigger)
{
	if (g_bAnsiLog && m_pView->ConnectType() == 0) {
		char path[300] = "";
		sprintf(path, "%s%s%d%s", g_szWorkDir, "temp\\ansilog", m_pView->SessionID(), ".ctd");
		FILE *fp = fopen(path, buf ? "ab" : "wb");

		if (fp) {
			if (buf && len > 0) {
				int len1 = len;
				if (trigger) {
					len1 += _tcslen(trigger) + 2;
				}
				fprintf(fp, "\n%s%010d\n", bSend ? "SEND" : "RECV", len1);
				if (trigger) {
					fprintf(fp, "<%s>", trigger);// �ɹ���������
				}
				fwrite((char*) buf, len, 1, fp);
			}
			fclose(fp);
		}
	}
}

void CCTermSock::OnOutOfBandData(int nErrorCode)
{
	CAsyncSocket::OnOutOfBandData(nErrorCode);
}

void CCTermSock::DisConnect()
{
	Reset();
	OnConnectError(0, _S("�ѶϿ�"));
}

void CCTermSock::OnConnect(int nErrorCode)
{
	AnsiLog(NULL, 0);
	CProxySock::OnConnect(nErrorCode);
}

int CCTermSock::SendFilter(const void *lpBuf, int nBuffLen, const TCHAR * trigger)
{
	m_bUnStable = TRUE;
	if (++m_nFilterCount > 100 && !m_bFilterWarned) {
		m_bFilterWarned = true;
		if (AfxMessageBox(_T("������ִ�еĴ���̫�࣬������û����ֹ���Ƿ�������ֹ��\n��ֹ�����޸�վ�������еĹ��������ã�����%E��"), MB_YESNO) == IDYES) {
			m_pView->m_Site.m_Login.m_AutoLogin.Disable();
		}
	}
	return SendAndLog(lpBuf, nBuffLen, 0, trigger);
}
