// CTermView.cpp : implementation file
// select���

#include "stdafx.h"
#include "CTermView.h"
#include "paramconfig.h"
#include "ShowIPDlg.h"

void CCTermView::ClearSelect()
{
	if (m_rectSelect != CRect(0, 0, 0, 0)) {
		int s = m_nStartLine + m_rectSelect.top;
		int e = m_nStartLine + m_rectSelect.bottom;

		m_rectSelect = CRect(0, 0, 0, 0);

		m_Core.SetChange(s, e);

		RedrawLine(s, e);

		SendMessage(WM_SETCURSOR, (WPARAM) GetSafeHwnd(), (LPARAM) MAKELONG(HTCLIENT, 0));	//����ѡ������
	}
}

void CCTermView::SelectRect(const CPoint &p1, const CPoint &p2, const CPoint &lastpt)
{
	int i;
	int x0, y0, x1, y1;

	CPoint pA(p1), pB(p2);
	if (pA.x < pB.x) {
		x0 = pA.x;
		x1 = pB.x;
	} else {
		x1 = pA.x;
		x0 = pB.x;
	}

	if (pA.y < pB.y) {
		y0 = pA.y;
		y1 = pB.y;
	} else {
		y0 = pB.y;
		y1 = pA.y;
	}

	if (g_bSelAntiHalf) {
//#define DOUBLE_SELECT_MODE_0
//#ifdef DOUBLE_SELECT_MODE_0 //ģʽ0���������������ǰ�����٣�����֮
		int a0 = 0, a1 = 0, b0 = 0, b1 = 0;

		for (i = y0;i <= y1;i++) {
			//��ֹѡ�������
			if (m_Core.GetCharType(x0, i) == 2) {
				a0++;
			}

			if (m_Core.GetCharType(x1 - 1, i) == 1) {
				a1++;
			}

			//�������
			if (x0 > 0) {
				if (m_Core.GetCharType(x0 - 1, i) == 2) {
					b0++;
				}
			}

			if (x1 < m_nTermWidth) {
				if (m_Core.GetCharType(x1, i) == 1) {
					b1++;
				}
			}
		}

		if (a0 > b0) x0--;

		if (a1 > b1) x1++;

	}//if ( g_bAntiHalf )

	m_rectSelect.left = x0;

	m_rectSelect.right = x1;

	m_rectSelect.top = y0;

	m_rectSelect.bottom = y1;

	//	if(pB.x==lastpt.x)
	//RedrawLine( min(pB.y,lastpt.y), max(pB.y,lastpt.y));
	//		RedrawLine(pB.y,lastpt.y);
	//	else

	int s = m_nStartLine + min(y0, lastpt.y), e = m_nStartLine + max(y1, lastpt.y);
	m_Core.SetChange(s, e);

	RedrawLine(s, e);
}

// ������ѡ�������ѡ��֮��ת��
void CCTermView::SelectToRect()
{
	if (m_rectSelect.Width() == 0) return;

	int s = m_nStartLine + m_rectSelect.top, e = m_nStartLine + m_rectSelect.bottom;
	m_Core.SetChange(s, e);

	RedrawLine(s, e);
}

// �Ǿ���ѡ��
void CCTermView::Select(const CPoint &p1, const CPoint &p2, const CPoint &lastpt)
{
	int start, end;
	CPoint pA(p1), pB(p2);
	start = pA.x + pA.y *m_nTermWidth;
	end = pB.x + pB.y *m_nTermWidth;

	if (start > end) {
		int t = start;
		start = end;
		end = t;
		CPoint pt = pA;
		pA = pB;
		pB = pt;
	}

	//TRACE(_T("in CCTermView::Select. pA:%d, %d; pB:%d, %d; lastpt:%d, %d;s,e:%d, %d\n"), pA.x,pA.y,pB.x,pB.y, lastpt.x, lastpt.y, start, end);
	// ��ֹѡ�������
	if (g_bSelAntiHalf) {
		if (m_Core.GetCharType(pA.x, pA.y) == 2) {
			start--;
			pA.x--;
		}

		if (m_Core.GetCharType(pB.x - 1, pB.y) == 1) {
			end++;
			pB.x++;
		}
	}

	int y0 = min(pA.y, lastpt.y);

	int y1 = max(pB.y, lastpt.y);

	m_rectSelect = CRect(pA, pB);

	int s = m_nStartLine + y0, e = m_nStartLine + y1;
	m_Core.SetChange(s, e);

	RedrawLine(s, e);
}

//����y��x���ַ��Ƿ�λ��ѡ������
//y: ��������
bool CCTermView::IsCharSelected(int y, int x) const
{
	if (m_rectSelect.Height() == 0 && m_rectSelect.Width() == 0) return false;

	y -= m_nStartLine;

	bool bRet = false;

	if (g_bSelectRect) {
		bRet = (m_rectSelect.left <= x && x < m_rectSelect.right
		        && m_rectSelect.top <= y && y <= m_rectSelect.bottom);
	} else {
		int start = m_rectSelect.left + m_rectSelect.top * m_nTermWidth;
		int end = m_rectSelect.right + m_rectSelect.bottom * m_nTermWidth;
		int loc = y * m_nTermWidth + x;

		bRet = (start <= loc && loc < end);
	}

	return bRet;
}

int CCTermView::getSelMaxlen(bool bANSI)
{
	int ret = 0;
	if (IsCopySelected()) {
		if (g_bSelectRect) {
			ret = (m_rectSelect.right - m_rectSelect.left) * (m_rectSelect.bottom - m_rectSelect.top + 1);
		}
		else {
			int start = m_rectSelect.left + m_rectSelect.top * m_nTermWidth;
			int end = m_rectSelect.right + m_rectSelect.bottom * m_nTermWidth;
			
			ret = end - start;
		}
		ret += (m_rectSelect.Height() + 1) * 2; //buf[nLen] = '\xd'; buf[nLen+1] = '\xa';

	}
	else if (m_bClickRectURL) {
		ret = max(g_pShowIPDlg->m_sAddr.GetLength(), strlen(m_szClick));
	}
	
	if (ret <= 0) {
		// empty select
		ret = 256 * m_nTermHeight;
	}

	++ret; // for '\0'

	if (g_bCopyUni) {
		ret *= 2;
	}

	if (bANSI) {
		ret *= (18 + 2 * (m_nESCChar == 1) ? 2 : 1); //.[0;1;31m.[I
		ret += 4;
	}
	
	return ret;
}
