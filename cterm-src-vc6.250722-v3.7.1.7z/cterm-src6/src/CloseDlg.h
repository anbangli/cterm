#if !defined(AFX_CLOSEDLG_H__93BE9E6C_D630_43B0_9EB9_FABFB1FCD061__INCLUDED_)
#define AFX_CLOSEDLG_H__93BE9E6C_D630_43B0_9EB9_FABFB1FCD061__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CloseDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCloseDlg dialog
#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

class CCloseDlg : public CDialog
{
// Construction

public:
	BOOL m_bFastAway;
	CCloseDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCloseDlg)
	enum { IDD = IDD_CLOSEDLG };
	CButtonST	m_ok;
	BOOL	m_bNoAskWhenClose;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCloseDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CCloseDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnCloseit();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLOSEDLG_H__93BE9E6C_D630_43B0_9EB9_FABFB1FCD061__INCLUDED_)
