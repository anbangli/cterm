#if !defined(AFX_SITEPROXYPAGE_H__6332C14D_9C08_41E1_99CC_3625ED37A7CD__INCLUDED_)
#define AFX_SITEPROXYPAGE_H__6332C14D_9C08_41E1_99CC_3625ED37A7CD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteProxyPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteProxyPage dialog

struct SLoginSet;
class CSiteProxyPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteProxyPage)

// Construction

public:
	BOOL m_bChange;
	SLoginSet *m_pLogin;
	CSiteProxyPage();
	~CSiteProxyPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(CSiteProxyPage)
	enum { IDD = IDD_SITE_PROXY };
	CComboBox	m_type_ctrl;
	CString	m_endsession;
	CString	m_addr;
	CString	m_name;
	UINT	m_port;
	CString	m_psw;
	int		m_type;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteProxyPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CSiteProxyPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeProxytype();
	afx_msg void OnTelnetset();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITEPROXYPAGE_H__6332C14D_9C08_41E1_99CC_3625ED37A7CD__INCLUDED_)
