// AddrQuickDlg.cpp : implementation file
//

#include "stdafx.h"

#include "AddrQuickDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddrQuickDlg dialog


CAddrQuickDlg::CAddrQuickDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CAddrQuickDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddrQuickDlg)
	m_addr = _T("");
	m_port = (TELNET_PORT);
	m_bIPv6 = FALSE;
	m_ssh = FALSE;
	//}}AFX_DATA_INIT
}


void CAddrQuickDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddrQuickDlg)
	DDX_Text(pDX, IDC_ADDR, m_addr);
	DDX_Text(pDX, IDC_PORT, m_port);
	DDX_Check(pDX, IDC_IPV6, m_bIPv6);
	DDX_Check(pDX, IDC_SSH, m_ssh);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddrQuickDlg, CDialog)
	//{{AFX_MSG_MAP(CAddrQuickDlg)
	ON_BN_CLICKED(IDC_SSH, OnSsh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddrQuickDlg message handlers
void CAddrQuickDlg::OnOK()
{
	UpdateData();

	m_Site.SetDefault(m_addr, m_port);

	m_Site.m_Login.m_bSSH = m_ssh;

	m_Site.SetVarInt(_T("IsIPv6"), m_bIPv6);

	CDialog::OnOK();
}

BOOL CAddrQuickDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	m_Site.SetDefault(_T(""));

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CAddrQuickDlg::OnSsh()
{
	UpdateData(TRUE);

	if (m_ssh)
		m_port = SSH_PORT;
	else
		m_port = TELNET_PORT;

	UpdateData(FALSE);
}
