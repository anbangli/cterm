// SiteFontPage.cpp : implementation file
//

#include "stdafx.h"
#include "SiteFontPage.h"
#include "const.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteFontPage property page

IMPLEMENT_DYNCREATE(CSiteFontPage, CMyPropertyPage)

CSiteFontPage::CSiteFontPage() : CMyPropertyPage(CSiteFontPage::IDD)
{
	//{{AFX_DATA_INIT(CSiteFontPage)
	m_sFontName = _T("SimSun");
	m_nFontSize = 16;
	m_bFixFont = FALSE;
	m_nCharHWRatio = 2;
	m_eFont = _T("");
	m_bNotMono = FALSE;
	m_bBold = FALSE;
	//}}AFX_DATA_INIT
}

CSiteFontPage::~CSiteFontPage()
{
}

void CSiteFontPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteFontPage)
	DDX_Text(pDX, IDC_FONTNAME, m_sFontName);
	DDV_MaxChars(pDX, m_sFontName, MAXFONTNAME);
	DDX_Text(pDX, IDC_FONTSIZE, m_nFontSize);
	DDV_MinMaxInt(pDX, m_nFontSize, 12, 36);
	DDX_Check(pDX, IDC_CHECK2, m_bFixFont);
	DDX_Text(pDX, IDC_EDIT_HWRATIO, m_nCharHWRatio);
	DDX_Text(pDX, IDC_EDIT_EFONT, m_eFont);
	DDX_Check(pDX, IDC_CHECK_MONO, m_bNotMono);
	DDX_Check(pDX, IDC_CHECK_BOLD, m_bBold);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteFontPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteFontPage)
	ON_BN_CLICKED(IDC_SONG, OnSong)
	ON_BN_CLICKED(IDC_HEI, OnHei)
	ON_BN_CLICKED(IDC_KAI, OnKai)
	ON_BN_CLICKED(IDC_WINFONT, OnWinfont)
	ON_BN_CLICKED(IDC_SETFONT, OnSetFont)
	ON_BN_CLICKED(IDC_FIXED, OnFixedsys)
	ON_EN_KILLFOCUS(IDC_FONTNAME, OnKillfocusFontname)
	ON_BN_CLICKED(IDC_CHECK_MONO, OnCheckMono)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteFontPage message handlers

CString g_sCustomFontName = _T("SimSun");    //�����ϴε�ѡ��

BOOL CSiteFontPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



	CButton *pBut = NULL;
	m_bChange = TRUE;

//	Font[0].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,m_szFont);		//վ��ṹ�ж��������
//	Font[1].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("SimSun"));
//	Font[2].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("SimHei"));
//	Font[3].CreateFont(9,0,0,0,0x190,0,0,0,0x86,3,2,1,2,_T("Kaiti"));  //_T("Kaiti_GB2312");
	//	pOldFont=pDC->SelectObject(&Font[0]);	// ԭ������


	m_sFontName = g_sCustomFontName;
//	m_nFontSize=16;
//	m_bFixFont=FALSE;

	//GetDlgItem(IDC_SETFONT)->EnableWindow(0);

	if (!m_font.CompareNoCase(_T("SimSun")))			// ���ʹ����SimSun
		pBut = (CButton *) GetDlgItem(IDC_SONG);
	else if (!m_font.CompareNoCase(_T("SimHei")))			// ���ʹ����SimHei
		pBut = (CButton *) GetDlgItem(IDC_HEI);
	else if (!m_font.CompareNoCase(_T("Kaiti")))			// ���ʹ����Kaiti_GB2312  //Kaiti_GB2312
		pBut = (CButton *) GetDlgItem(IDC_KAI);
	else if (!m_font.CompareNoCase(_T("Fixedsys")))
		pBut = (CButton *) GetDlgItem(IDC_FIXED);
	else {		// ������������趨�ļ�������
		m_sFontName = m_font;
		//GetDlgItem(IDC_SETFONT)->EnableWindow(TRUE);
		pBut = (CButton *) GetDlgItem(IDC_WINFONT);
	}

	if (pBut) pBut->SetCheck(1);

	UpdateData(FALSE);

	GetDlgItem(IDC_EDIT_EFONT)->EnableWindow(m_bNotMono);
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_SETFONT), IDS_TIP_FONTDLG_1);
	}

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSiteFontPage::OnSong()
{
	m_font = _T("SimSun");
	//GetDlgItem(IDC_SETFONT)->EnableWindow(FALSE);
}

void CSiteFontPage::OnHei()
{
	m_font = _T("SimHei");
	//GetDlgItem(IDC_SETFONT)->EnableWindow(FALSE);
}

void CSiteFontPage::OnKai()
{
	m_font = _T("Kaiti");	//_T("Kaiti_GB2312");
	//GetDlgItem(IDC_SETFONT)->EnableWindow(FALSE);
}

void CSiteFontPage::OnFixedsys()
{
	m_font = _T("Fixedsys");
	//GetDlgItem(IDC_SETFONT)->EnableWindow(FALSE);
}

void CSiteFontPage::OnWinfont()
{
//	TCHAR ts[100];
	//GetDlgItem(IDC_SETFONT)->EnableWindow(1);
	//GetDlgItem(IDC_SETFONT)->GetWindowText(ts,100);

	if (m_sFontName.IsEmpty()) {
		m_sFontName = _T("SimSun");
		UpdateData(FALSE);
		//m_font=_T("SimSun");
		//GetDlgItem(IDC_SETFONT)->SetWindowText(m_szFont);
	}

	m_font = m_sFontName;
}

void CSiteFontPage::OnSetFont()
{
	CFont Font;
	LOGFONT fontset;
	Font.CreatePointFont(120, m_font);

	if (!Font.GetLogFont(&fontset)) return;

	CFontDialog Dlg(&fontset, CF_EFFECTS | CF_SCREENFONTS | CF_NOVERTFONTS);    //|CF_TTONLY|CF_SCALABLEONLY

	if (Dlg.DoModal() == IDOK) {
		CString s = Dlg.GetFaceName();

		if (s.GetLength() > MAXFONTNAME) {
			CString s;
			s.Format(_T("��ѡ��������������%d���ַ�������"), MAXFONTNAME);
			AfxMessageBox(s);
		}
		else {
			//m_nFontSize = Dlg.GetSize() / 10; //Return Value: The font��s size, in tenths of a point.
			m_sFontName = s;
			m_font = m_sFontName;

			CButton *pBut = (CButton *) GetDlgItem(IDC_WINFONT);
			if (pBut) pBut->SetCheck(1);

			UpdateData(FALSE);
		}

		//GetDlgItem(IDC_SETFONT)->SetWindowText(m_szFont);
	}
}

BOOL CSiteFontPage::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}

	return CMyPropertyPage::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}

void CSiteFontPage::OnKillfocusFontname()
{
	UpdateData(TRUE);
	m_font = m_sFontName;
}

UINT CSiteFontPage::GetIDD()
{
	return IDD;
}

void CSiteFontPage::OnCheckMono() 
{
	UpdateData();
	GetDlgItem(IDC_EDIT_EFONT)->EnableWindow(m_bNotMono);	//���������Ƿ������
}
