// �ظ���Ϣ

#if !defined(AFX_MESSAGEDLG_H__DE8FE313_E8AC_4D94_9E5C_94EDF09ACF8E__INCLUDED_)
#define AFX_MESSAGEDLG_H__DE8FE313_E8AC_4D94_9E5C_94EDF09ACF8E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MessageDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMessageDlg dialog

class CCTermView;

class CMessageDlg : public CDialog
{
// Construction

public:
	BOOL m_bMultiLine;

	CMessageDlg(CWnd* pParent = NULL, bool bSend = false);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CMessageDlg)
	enum { IDD = IDD_MESSAGE };
	CEdit	m_ctrlSender;
	CEdit	m_reply;
	CButton	m_ok;
	CButton	m_cancel;
	CButton	m_his;
	CString	m_inmes;
	CString	m_sender;
	CString	m_time;
	CString	m_replystr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMessageDlg)

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CMessageDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnHis();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnButton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CCTermView *m_pView;
	bool m_bSend; // �Ƿ��ͻ��ǻظ�
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MESSAGEDLG_H__DE8FE313_E8AC_4D94_9E5C_94EDF09ACF8E__INCLUDED_)
