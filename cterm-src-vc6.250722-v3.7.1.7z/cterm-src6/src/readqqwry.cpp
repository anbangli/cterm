// ReadQQWry.cpp: implementation of the CReadQQWry class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ReadQQWry.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CReadQQWry::CReadQQWry()
{
}

CReadQQWry::CReadQQWry(CString &strPath)
{
	m_strPath = strPath;
}

CReadQQWry::~CReadQQWry()
{
}

//δ�ҵ������ؿմ�
CString CReadQQWry::QueryIP(CString &strIP)
{
	if (strIP.GetLength() < 7 || !('0' <= strIP[0] && strIP[0] <= '9'))
		m_strAddr = _T("");
	else {

		CString ipfile = g_szWorkDir + _T("user\\myips.txt");

		m_strAddr = QueryMyIP(strIP, ipfile);    //���Ȳ�ѯ�Զ���IP

		if (m_strAddr.IsEmpty()) {
			if (m_file.Open(m_strPath, CFile::modeRead | CFile::shareDenyNone)) {
				m_file.Read(&m_FirstStartIpOffset, sizeof(m_FirstStartIpOffset));      //��һ��IP�ľ���ƫ��
				m_file.Read(&m_LastStartIpOffset, sizeof(m_LastStartIpOffset));      //���һ��IP�ľ���ƫ��
				DWORD dwIP = inet_addr(strIP);
				int nItemCount = (m_LastStartIpOffset - m_FirstStartIpOffset) / 7,
				                 nItemStart = 0,
				                              nItemEnd = nItemCount,
				                                         nCurItem = 0;
				BOOL bFound = FALSE;

				DWORD dwLastStartIP = 0, dwLastEndIP = 0;        // ��������������

				do {
					nCurItem = (nItemStart + nItemEnd) / 2;
					GetInfo(nCurItem);

					// ������������ж�

					if (m_dwStartIP == dwLastStartIP && m_dwEndIP == dwLastEndIP) {
						// �������ظ���ѯ������ټ�����ȥ���������ѭ��
						break;
					}

					dwLastStartIP = m_dwStartIP;

					dwLastEndIP = m_dwEndIP;

					if (dwIP < m_dwStartIP) {
						nItemEnd = nCurItem;
						continue;
					}

					if (dwIP > m_dwEndIP) {
						nItemStart = nCurItem;
						continue;
					}

					//�ҵ���
					bFound = TRUE;

					break;
				} while (nCurItem <= nItemEnd);

				m_file.Close();

				if (bFound) {
					int idx = m_strAddr.Find(_T("CZ88.NET"));

					if (idx == m_strAddr.GetLength() - 8) {
						m_strAddr = m_strAddr.Left(idx);
					}

					m_strAddr.TrimLeft();

					m_strAddr.TrimRight();

					// || _tcsstr ( m_strAddr, _T ( "IANA" ) ) //192.122.134.*
//					if ( m_strAddr.IsEmpty() )
//						m_strAddr = _T( "" ); //_T ( "  ?  " );		//δ֪�ص�_T(";	δ֪�ص㣬Ҳ����")?"���Ա����Զ��滻IPʱʶ��(δ�õ�)
//					else

					if (!m_strAddr.IsEmpty() && m_strAddr.GetLength() < 4) {   //too short
						m_strAddr.Insert(0, _T("  "));
						m_strAddr += _T("  ");
					}
				} else {
					m_strAddr = _T("");   //_T ( "  ?  " );	//δ�ҵ���ؼ�¼
				}
			} else {
				m_strAddr = _T("IP���ݿ��ļ���ʧ��");	//δ�ҵ���ؼ�¼
			}
		}
	}

	return m_strAddr;
}

CString CReadQQWry::inet_ntoa(DWORD dwIP)
{
	CString strIP;
	strIP.Format(_T("%d.%d.%d.%d"),
	             dwIP >> 24,
	             (dwIP & 0xff0000) >> 16,
	             (dwIP & 0xff00) >> 8,
	             dwIP & 0xff
	            );

	return strIP;
}

DWORD CReadQQWry::inet_addr(LPCTSTR pchIP)
{
	CString strIP(pchIP), strSec;
	DWORD dwIP = 0;
	int nSec = 0;
	strIP += _T(".");
	int nPos = strIP.Find(_T("."));
	int nOffset = 24;

	while (nPos != -1 && nOffset >= 0) {
		strSec = strIP.Left(nPos);
		strIP = strIP.Right(strIP.GetLength() - nPos - 1);
		nSec = _ttoi(strSec);

		if (nSec > 255 || nSec < 0)
			return 0;

		dwIP |= nSec << nOffset;

		nOffset -= 8;

		nPos = strIP.Find(_T("."));
	}

	if (nPos != -1 || nOffset >= 0)   //IP��ַ��Ч
		return 0;

	return dwIP;
}

void CReadQQWry::GetInfo(int nIndex)
{
	CString strCountry, strLocal;
	DWORD dwOffset;//ָ��������ʼIP�ľ���ƫ����
	dwOffset = m_FirstStartIpOffset + nIndex * 7;
	BYTE buf[7];
	m_file.Seek(dwOffset, CFile::begin);
	m_file.Read(buf, 7);
	m_dwStartIP = buf[0] | buf[1] << 8 | buf[2] << 16 | buf[3] << 24;
	m_dwEndIPOffset = buf[4] | buf[5] << 8 | buf[6] << 16;
	m_file.Seek(m_dwEndIPOffset, CFile::begin);
	memset(buf, 0, 7);
	m_file.Read(buf, 4);
	m_dwEndIP = buf[0] | buf[1] << 8 | buf[2] << 16 | buf[3] << 24;
	m_file.Read(&m_bCountryFlag, 1);

	switch (m_bCountryFlag) {

	case 1:

	case 2:
		strCountry = GetFlagString(m_dwEndIPOffset + 4);
		strLocal = (m_bCountryFlag == 1) ? _T("") : GetFlagString(m_dwEndIPOffset + 8);
		break;

	default://����ֱ�Ӹ�����conutry + local
		strCountry = GetFlagString(m_dwEndIPOffset + 4);
		strLocal = GetFlagString(m_file.GetPosition());
		break;
	}

	m_strAddr = strCountry + strLocal;
}

CString CReadQQWry::GetFlagString(DWORD offset)
{
	CString strSec;
	BYTE flag;
	BYTE buf[3];

	while (TRUE) {
		m_file.Seek(offset, CFile::begin);
		m_file.Read(&flag, 1);

		if (flag == 1 || flag == 2) {
			m_file.Read(buf, 3);

			if (flag == 2) {
				m_bCountryFlag = 2;
				m_dwEndIPOffset = offset - 4;
			}

			offset = buf[0] | buf[1] << 8 | buf[2] << 16;
		} else
			break;
	}

	if (offset < 12)
		return CString(_T(""));

	return GetString(offset);
}

CString CReadQQWry::GetString(DWORD offset)
{
	CString strSec;
	m_file.Seek(offset, CFile::begin);
	//����ֽڶ�ȡ,ֱ������������'\0'
	TCHAR ch = 0;

	while (TRUE) {
		m_file.Read(&ch, 1);

		if (ch == '\0')
			break;

		strSec += ch;
	}

	return strSec;
}

//��ѯ�Զ���IP
CString CReadQQWry::QueryMyIP(CString sURL, CString m_file)
{
	bool bFound = false;
	CString strAddr;

#if ENABLE_PYTHON
	// �ű���ѯ
//	if (g_bEnablePython && g_bSysPythonScriptLoaded) {
//		CString title, author;
//		CString *p[] = { &title, &author };
//		bool bRet = g_pMainWnd->PythonCallback(_T("QueryIP"),
//			NULL, 0,
//			p);
//		
//		if (bRet)
//			pic->sExtInfo = author + ":" + title;
//	}
#endif //ENABLE_PYTHON
	
	if (!bFound) {
		TCHAR location1[256]/* = _T("")*/, location2[256]/* = _T("")*/;
		FILE *fp = NULL;
		TCHAR buf[256]/* = _T("")*/;
		
		if ((fp = _tfopen(m_file, _T("r"))) != NULL) {
			//���ʮ����תΪbinary
			
			DWORD theip = inet_addr(sURL);
			
			//u_int theip_t[4];
			//_stscanf ( sURL, _T ( "%u.%u.%u.%u" ), theip_t + 0, theip_t + 1, theip_t + 2, theip_t + 3 ); *�Ų��ḳֵ
			//u_int theip = 0;
			//for ( int i = 0; i < 4 ; i++ )
			//	theip += LOBYTE ( LOWORD ( theip_t[i] ) ) << ( ( 3 - i ) * 8 );
			
			_fgetts(buf, 255, fp);    //header
			//		u_int ip_t[8];
			
			do {
				DWORD ip1 = 0, ip2 = 0;//��ʼ��������Ϊ0�������õ����
				_fgetts(buf, 255, fp);
				TCHAR sIP1[256], sIP2[256];
				int n = _stscanf(buf, _T("%s\t%s\t%s\t%s\n"),
			                 sIP1, sIP2,
							 location1, location2);
				//int n = _stscanf ( buf, _T ( "%u.%u.%u.%u\t%u.%u.%u.%u\t%s\t%s\n" ),
				//                 ip_t + 0, ip_t + 1, ip_t + 2, ip_t + 3,
				//               ip_t + 4, ip_t + 5, ip_t + 6, ip_t + 7,
				//             location1, location2 );
				
				if (n == 4) {
					ip1 = inet_addr(sIP1);
					ip2 = inet_addr(sIP2);
					//for ( int i = 0; i < 4 ; i++ )
					//{
					//ip1 += LOBYTE ( LOWORD ( ip_t[i] ) ) << ( ( 3 - i ) * 8 );
					//ip2 += LOBYTE ( LOWORD ( ip_t[i+4] ) ) << ( ( 3 - i ) * 8 );
					//}
					
					if (ip1 <= theip && theip <= ip2) {
						bFound = true;
						break; //while
					}
				}
			} while (!feof(fp));
			
			fclose(fp);
		}
			
		if (bFound) {
			strAddr += location1;
			strAddr += location2;
		}
	}


	return strAddr;
}