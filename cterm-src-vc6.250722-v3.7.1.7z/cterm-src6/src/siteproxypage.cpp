// SiteProxyPage.cpp : implementation file
//

#include "stdafx.h"
#include "SiteProxyPage.h"
#include "TelnetSite.h"

#if ENABLE_FILTER
#include "simplefilterdlg.h"	//������
#endif//ENABLE_FILTER

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteProxyPage property page

#if ENABLE_PROXY

IMPLEMENT_DYNCREATE(CSiteProxyPage, CMyPropertyPage)

CSiteProxyPage::CSiteProxyPage() : CMyPropertyPage(CSiteProxyPage::IDD)
{
	//{{AFX_DATA_INIT(CSiteProxyPage)
	m_endsession = _T("");
	m_addr = _T("");
	m_name = _T("");
	m_port = 0;
	m_psw = _T("");
	m_type = 0;
	//}}AFX_DATA_INIT
}

CSiteProxyPage::~CSiteProxyPage()
{
}

void CSiteProxyPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteProxyPage)
	DDX_Control(pDX, IDC_PROXYTYPE, m_type_ctrl);
	DDX_Text(pDX, IDC_ENDSESSION, m_endsession);
	DDX_Text(pDX, IDC_PROXYADDR, m_addr);
	DDX_Text(pDX, IDC_PROXYNAME, m_name);
	DDX_Text(pDX, IDC_PROXYPORT, m_port);
	DDX_Text(pDX, IDC_PROXYPSW, m_psw);
	DDX_CBIndex(pDX, IDC_PROXYTYPE, m_type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteProxyPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteProxyPage)
	ON_CBN_SELCHANGE(IDC_PROXYTYPE, OnSelchangeProxytype)
	ON_BN_CLICKED(IDC_TELNETSET, OnTelnetset)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteProxyPage message handlers

BOOL CSiteProxyPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	m_type = m_pLogin->m_nProxyType;

	if (m_type < PT_NONE || m_type > PT_CTERM)
		m_type = PT_NONE;		//exit(-1);

	UpdateData(FALSE);

	OnSelchangeProxytype();

	if (true) {
		// m_type == PT_NONEҲ�������ַ���Ա��´�ʹ��
		m_addr = m_pLogin->m_szProxyAddr;
		m_port = m_pLogin->m_nProxyPort;
		m_name = m_pLogin->m_szProxyName;
		m_psw = m_pLogin->m_szProxyPSW;
		m_endsession = m_pLogin->m_TelnetProxy.szEndSession;
	}

	m_bChange = TRUE;

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSiteProxyPage::OnSelchangeProxytype()
{
	UpdateData();
	//if(!GetDlgItem(IDC_PROXYNAME))return;

	switch (m_type) {

	case PT_NONE: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(0);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(0);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(0);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(0);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(0);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(0);
		break;
	}

	case PT_TELNET: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(1);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(0);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(0);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(1);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(1);
		m_port = TELNET_PORT;
		break;
	}

	case PT_SOCK4: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(1);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(0);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(0);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(0);
		m_port = 1080;
		break;
	}

	case PT_SOCK5: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(1);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(1);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(0);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(0);
		m_port = 1080;
		break;
	}

	case PT_HTTP: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(1);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(1);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(1);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(1);
		break;
	}
		
	case PT_CTERM: {
		GetDlgItem(IDC_PROXYADDR)->EnableWindow(1);
		GetDlgItem(IDC_PROXYPORT)->EnableWindow(1);
		GetDlgItem(IDC_PROXYNAME)->EnableWindow(0);
		GetDlgItem(IDC_PROXYPSW)->EnableWindow(0);
		GetDlgItem(IDC_ENDSESSION)->EnableWindow(0);
		GetDlgItem(IDC_TELNETSET)->EnableWindow(0);
		m_port = 20248;
		break;
	}

	default: {
		MessageBox(_T("Wrong Proxy Type"));       //never here
		break;
	}
	}

	UpdateData(FALSE);
}

void CSiteProxyPage::OnTelnetset()
{
	CSimpleFilterDlg Dlg;
	Dlg.m_pFilter = &m_pLogin->m_TelnetProxy.Filter;

	if (Dlg.DoModal() == IDOK) {
	}
}

void CSiteProxyPage::OnShowWindow(BOOL bShow, UINT nStatus)
{

}

UINT CSiteProxyPage::GetIDD()
{
	return IDD;
}

#endif//ENABLE_PROXY
