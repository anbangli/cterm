// FuncKey.cpp: implementation of the FuncKey class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FuncKey.h"
#include "global.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

#if defined(ENABLE_FUNKEY)

bool KeyFromString(CString &sWord, WORD& wVirtKey,
	                          bool& bCtrl, bool& bAlt, bool& bShift, TCHAR separator);
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
bool ParseFuncKey(CString &sLine, SFuncKey &theKey)
{
	CString sWord = _T("");
	int nLineLen = sLine.GetLength();

	//command id
	int i = GetWord(sLine, sWord, ';');

	if (!sWord.IsEmpty()) {
		WORD id = _ttoi(sWord.GetBuffer(1));

		if (id)
			theKey.cmditem.nCmdID = ID_FIRST_USERDEFCMD + id - 1;
		else
			return false;
	} else
		return false;

	//key
	i = GetWord(sLine, sWord, ';', i);

	bool bBadKey = false;

	if (!sWord.IsEmpty()) {   //alt+ctrl+shift+F3
		WORD wVirtKey = 0;
		bool bCtrl = false, bAlt = false, bShift = false;
		bBadKey = ! KeyFromString(sWord, wVirtKey, bCtrl, bAlt, bShift, '+');

		if (!bBadKey) {
			theKey.key = wVirtKey;

			if (bAlt) theKey.fVirt |= FALT | FNOINVERT | FVIRTKEY;

			if (bCtrl) theKey.fVirt |= FCONTROL | FNOINVERT | FVIRTKEY;

			if (bShift) theKey.fVirt |= FSHIFT | FNOINVERT | FVIRTKEY;
		}
	} else { //null key string _T("  ")
		bBadKey = true;
		theKey.key = 0;
//		return false; //��������Ч
	}

	if (i >= nLineLen) return false;

	//label
	//��ʾ�ڶ��ƿ�ݼ����б����ť�ı�ǩ��
	i = GetWord(sLine, sWord, ';', i);

	if (!sWord.IsEmpty()) {
		theKey.sLabel = sWord;
	}

	if (i >= nLineLen) return false;

	//bButton?
	i = GetWord(sLine, sWord, ';', i);

	if (!sWord.CompareNoCase(_T("true"))) {
		theKey.bButton = true;
	} else if (bBadKey) {
		//����������һ������Ч��
		return false;
	}

	if (i >= nLineLen) return false;

	//data
	i = GetWord(sLine, sWord, ';', i);

	if (!sWord.IsEmpty()) {
		sWord.Replace(_T("\\;"), _T(";"));

		if (sWord[0] == '"') {   //data string
			theKey.cmditem.sScriptTxt = sWord; //TranslateString(sWord);
			theKey.cmditem.nType = 0; // 0: ��������(translate) <=> RunPythonCode(_T("sendParsedString('+sScriptTxt+")'")
		} else if (sWord.Left(3) == _T("py:")) {
			theKey.cmditem.sScriptTxt = sWord.Right(sWord.GetLength() - 3);
			theKey.cmditem.nType = 1; // 1: ִ��python���� <=> RunPythonCode(sScriptTxt)
		} else if (sWord.Left(4) == _T("pyf:")) {
			theKey.cmditem.sScriptTxt = sWord.Right(sWord.GetLength() - 4);
			theKey.cmditem.nType = 2; // 2: ִ��python�ű� <=> RunPythonScript(sScriptTxt)
		} else {
			return false;
		}
	} else {
		//����Ϊ�գ���Ч
		return false;
	}

	if (i >= nLineLen) return true;

	//tips
	i = GetWord(sLine, sWord, ';', i);

	if (!sWord.IsEmpty()) {
		theKey.cmditem.sTip = TranslateString(sWord);
	}

	return true;
}

#endif//ENABLE_FUNKEY