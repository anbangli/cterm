#include "stdafx.h"
#include "BYHHID2WEB.h"
#include <afxinet.h>

#pragma comment(lib, "wininet")


UINT BYHHID2WEBThread(LPVOID pParam)
{
	if (pParam == NULL)
		return 0;

	PBYHHID2WEBPARAM pData = (PBYHHID2WEBPARAM) pParam;

	CString strServer = _T("bbs.whnet.edu.cn"), strObject, strOptional;

	INTERNET_PORT nPort = 80;

	BOOL bRet = FALSE;

	HINTERNET hInternetSession = InternetOpen(NULL, INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);

	if (hInternetSession == NULL) {
		delete pData;
		return 0;
	}

	HINTERNET hConnect = InternetConnect(hInternetSession, strServer, nPort, NULL, NULL, INTERNET_SERVICE_HTTP, 0, 0);

	if (hConnect == NULL) {
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	// �Ȳ�ѯ����
	strObject.Format(_T("/cgi-bin/bbsdoc?board=%s"), pData->strBoard);

	HINTERNET hHttpRequest = HttpOpenRequest(hConnect, _T("POST"), strObject, _T("1.1"), NULL, NULL,
	                         INTERNET_FLAG_NO_COOKIES | INTERNET_FLAG_DONT_CACHE | INTERNET_FLAG_RELOAD, 0);

	if (hHttpRequest == NULL) {
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	strOptional.Format(_T("start=%u"), pData->nArticleID);

	int nDataLen = strOptional.GetLength();
	bRet = HttpSendRequest(hHttpRequest, NULL, 0, (LPVOID) strOptional.GetBuffer(nDataLen), nDataLen);
	strOptional.ReleaseBuffer();

	if (bRet == FALSE) {
		TRACE(_T("HttpSendRequest failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
		InternetCloseHandle(hHttpRequest);
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	// �����ȡ����������Ӧ
	DWORD dwBytesRead = 0;

	BYTE buf[4096] = {0};

	bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);

	buf[dwBytesRead] = '\0';

	CString strResponse = buf;

	while (bRet && dwBytesRead != 0) {
		bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
		buf[dwBytesRead] = '\0';
		strResponse += (char *)buf;
	}

	DWORD dwStatus;

	DWORD dwSize = sizeof(dwStatus);
	bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

	if (bRet == FALSE || dwStatus != 200) {
		TRACE(_T("HttpQueryInfo failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
		InternetCloseHandle(hHttpRequest);
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	InternetCloseHandle(hHttpRequest);

	// �����������������Ӧ
#ifdef _DEBUG
	//TRACE(_T("\n%s\n"), strResponse.GetBuffer(0));
	//strResponse.ReleaseBuffer();
#endif
	int nStart = strResponse.Find(_T("<td width=36>"));		// ���±�ŵ���ʼ

	if (nStart == -1) {
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	nStart += _tcslen(_T("<td width=36>"));

	int nEnd = strResponse.Find(_T("</td>"), nStart);

	if (nEnd == -1) {
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	UINT nArticle = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

	if (pData->nArticleID < nArticle || pData->nArticleID >= nArticle + 20) {
		// ����Ŀǰ���ƻƺ׵�WEB��ѯ�����е����⣬��Ҫ�Ƚϵ�����Ҫ��ѯ�������ڲ��ڵ�ǰҳ��
		if (pData->nArticleID < nArticle) {
			// ��������һҳ
			strOptional.Format(_T("start=%u"), nArticle - 20);
		} else {
			// ��������һҳ
			strOptional.Format(_T("start=%u"), nArticle + 20);
		}

		// ����ȡ�������������ڵ�ҳ
		strObject.Format(_T("/cgi-bin/bbsdoc?board=%s"), pData->strBoard);

		HINTERNET hHttpRequest = HttpOpenRequest(hConnect, _T("POST") , strObject, _T("1.1"), NULL, NULL,
		                         INTERNET_FLAG_NO_COOKIES | INTERNET_FLAG_DONT_CACHE | INTERNET_FLAG_RELOAD, 0);

		if (hHttpRequest == NULL) {
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		nDataLen = strOptional.GetLength();

		bRet = HttpSendRequest(hHttpRequest, NULL, 0, (LPVOID) strOptional.GetBuffer(nDataLen), nDataLen);
		strOptional.ReleaseBuffer();

		if (bRet == FALSE) {
			TRACE(_T("HttpSendRequest failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		// �����ȡ����������Ӧ
		dwBytesRead = 0;

		ZeroMemory(buf, 4096);

		bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);

		buf[dwBytesRead] = '\0';

		CString strResponse = buf;

		while (bRet && dwBytesRead != 0) {
			bRet = InternetReadFile(hHttpRequest, buf, 4096, &dwBytesRead);
			buf[dwBytesRead] = '\0';
			strResponse += (char *)buf;
		}

		dwSize = sizeof(dwStatus);

		bRet = HttpQueryInfo(hHttpRequest, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &dwStatus, &dwSize, NULL);

		if (bRet == FALSE || dwStatus != 200) {
			TRACE(_T("HttpQueryInfo failed (%s line(%d)), error = %d\n"), GetLastError(), __FILE__, __LINE__);
			InternetCloseHandle(hHttpRequest);
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		InternetCloseHandle(hHttpRequest);

		nStart = strResponse.Find(_T("<td width=36>"));		// ���±�ŵ���ʼ

		if (nStart == -1) {
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		nStart += _tcslen(_T("<td width=36>"));

		nEnd = strResponse.Find(_T("</td>"), nStart);

		if (nEnd == -1) {
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		nArticle = _ttoi(strResponse.Mid(nStart, nEnd - nStart));

		if (pData->nArticleID < nArticle || pData->nArticleID >= nArticle + 20) {
			// ��Ȼ�����ڴ�ҳ��������
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}
	}

	// �������ָ��������µ�����
	while (nArticle != pData->nArticleID) {
		nStart = strResponse.Find(_T("<td width=36>"), nEnd);		// ���±�ŵ���ʼ

		if (nStart == -1) {
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		nStart += _tcslen(_T("<td width=36>"));

		nEnd = strResponse.Find(_T("</td>"), nStart);

		if (nEnd == -1) {
			InternetCloseHandle(hConnect);
			InternetCloseHandle(hInternetSession);
			delete pData;
			return 0;
		}

		nArticle = _ttoi(strResponse.Mid(nStart, nEnd - nStart));
	}

	nStart = strResponse.Find(_T("<td><a href="), nEnd);

	if (nStart == -1) {
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	nStart += _tcslen(_T("<td><a href="));

	nEnd = strResponse.Find(_T(">"), nStart);

	if (nEnd == -1) {
		InternetCloseHandle(hConnect);
		InternetCloseHandle(hInternetSession);
		delete pData;
		return 0;
	}

	CString strURL = _T("http://www.byhh.net/cgi-bin/");

	strURL += strResponse.Mid(nStart, nEnd - nStart);
	ShellExecute(NULL, _T("open"), strURL, NULL, NULL, SW_SHOW);

	InternetCloseHandle(hConnect);
	InternetCloseHandle(hInternetSession);
	delete pData;
	return 0;
}

void BYHHID2WEB(const CString &strBoard, const UINT nArticle)
{
	PBYHHID2WEBPARAM pData = new BYHHID2WEBPARAM;
	pData->nArticleID = nArticle;
	pData->strBoard = strBoard;

	AfxBeginThread(BYHHID2WEBThread, pData);
}
