// usermsg.h : �Զ�����Ϣ

#define WM_TRAYMENU WM_USER + 900
#define WM_STEAMIN  WM_USER + 901
#define WM_DUPSITE  WM_USER + 902
#define WM_MSGPOP   WM_USER + 903
#define WM_SETSITE  WM_USER + 904
#define WM_HAVE_MAIL WM_USER + 905
#define WM_DISCONNECTED WM_USER + 906
#define WM_CREATE_NEW_CHILD WM_USER + 907
#define WM_SET_SCRIPT_INFO WM_USER + 908
#define WM_CONNECTOK WM_USER + 909

// ͼƬ��Ϣ, ��ʽ:
//
// lParam=0, wParam: �����е�һ��ָ��:
// ����λ�ã�
//		DownloadURL(), found; GetFileThread(), nRet==200, found; GetFileThread(), 9, download SUCCESS;
//		GetFileThread(), nRet == 304(never here); GetFileThread(), 404, etc, fail;
//		IsPictureCached(), found (�ú�������ʹ��);
// lParam=1, wParam: ָ��һ��URL��CStringָ�� ... ViewPicNow(); OnOpenUrlPic(),  //ȡ���ýӿ�
// lParam=1, wParam:
//		��ʼ������
//		����һ���ṹ��PICSTRUCT
// lParam=3, wParam; ָ��ǰloading��list���pic
//		LoadPicThread()װ����ɺ�OnTimer()���س�ʱ
#define FLAG_PIC_GOT	0
#define FLAG_PIC_NEW	1
#define FLAG_PIC_LOAD	2

#define WM_NETEVENT  (WM_APP + 5)

#ifndef WM_UNINITMENUPOPUP
#define WM_UNINITMENUPOPUP 0x0125
#endif//WM_UNINITMENUPOPUP

#define WM_PICTURE (WM_USER + 910)
#define WM_SETSTATUSCOUNT (WM_USER + 911)
#define WM_DNSRESOLVED (WM_USER + 912)
#define WM_WINDOW_EDGE (WM_USER + 913)

// �������¶Ի���
#define WM_UPDATEDLG		(WM_USER + 914)
#define WM_CHILDCLOSED		(WM_USER + 915)

//�ܵ������ݵ���������ssh
#define	WM_PIPE_DATA	(WM_USER + 916)
#define UM_TREEOPTSCTRL_NOTIFY	(WM_USER + 917)
#define WM_DATA_COME		(WM_USER + 918)
#define WM_CBLBUTTONCLICKED (WM_USER + 919)
#define ID_RESTORE_CHILD (WM_USER + 920)
#define WM_UPDATEPARAM (WM_USER + 921)

#if ENABLE_SCREENMAP
// ���������� wParam=nPos
#define WM_SCROLLBAR (WM_USER + 922)
#endif//ENABLE_SCREENMAP

#define  WM_SHOWTIP	(WM_USER + 923)

#define TIMER_FLASHWINDOW 1984
#define TIMER_GLOBLE_IDLE 1978

#define TIMER_BLINK 3001
#define TIMER_CTERM 3002
#define TIMER_PICURLHOVER 3003

#define TIMER_ADDUSER 3004
#define TIMER_ADDRBOOK 3005
#define TIMER_BATDLG 3006
#define TIMER_DLARTICLEDLG 3007
#define TIMER_DLDIGESTDLG 3008
#define TIMER_DLLISTDLG 3009
#define TIMER_CHILDFRMTITLE 3010
#define TIMER_SITECOLORPAGE 3011
#define TIMER_LOADPIC 3012
#define TIMER_SLEEP 3013
#define TIMER_CTD_FILE 3014
#define TIMER_CSM 3015

