// InsCursor.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "InsCursor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInsCursor property page

IMPLEMENT_DYNCREATE(CInsCursor, CMyPropertyPage)

CInsCursor::CInsCursor() : CMyPropertyPage(CInsCursor::IDD)
{
	//{{AFX_DATA_INIT(CInsCursor)
	m_x = 0;
	m_y = 0;
	m_type = 0;
	//}}AFX_DATA_INIT
}

CInsCursor::~CInsCursor()
{
}

void CInsCursor::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsCursor)
	DDX_Control(pDX, IDC_EDIT2, m_yctrl);
	DDX_Control(pDX, IDC_EDIT1, m_xctrl);
	DDX_Text(pDX, IDC_EDIT1, m_x);
	DDX_Text(pDX, IDC_EDIT2, m_y);
	DDX_Radio(pDX, IDC_RADIO1, m_type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsCursor, CMyPropertyPage)
	//{{AFX_MSG_MAP(CInsCursor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsCursor message handlers
CString CInsCursor::GetStr()
{
	UpdateData();
	CString r, s;
	switch(m_type) {
	case 0: // ���
		if (m_y > 0) {
			s.Format(_T("\x1b[%dB"), m_y);
			r += s;
		}
		else if (m_y < 0) {
			s.Format(_T("\x1b[%dA"), -m_y);
			r += s;
		}

		if (m_x > 0) {
			s.Format(_T("\x1b[%dC"), m_x);
			r += s;
		}
		else if (m_x < 0) {
			s.Format(_T("\x1b[%dD"), -m_x);
			r += s;
		}
		break;
	case 1: // ����
		r.Format(_T("\x1b[%d;%dH"), m_x, m_y); // todo: ���Ʒ�Χ
		break;
	case 2: // ����
		r = _T("\x1b[s");
		break;
	case 3: // �ָ�
		r = _T("\x1b[u");
		break;
	}

	return r;
}


//void CInsCursor::OnChangeEdit1() 
//{
/*
	// ��δ���ȷ�������������...���ޱ�Ҫ
  CString s;
	m_xctrl.GetWindowText(s);
	int len = s.GetLength();
	int r = true;
	if (len > 0) {
		if (s[0] != '-' && !isdigit(s[0])) {
			r = false;
		}
		
		if (r) {
			for (int i = 1; i < len; ++i) {
				if (!isdigit(s[i])) {
					r = false;
					break;
				}
			}
		}
	}

	if (r) {
		UpdateData();
	}
	else {
		s.Format(_T("%d"), m_x);
		m_xctrl.SetWindowText(s);
	}
	*/
//}
