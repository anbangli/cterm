////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Thierry Maurel
// All rights reserved
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc., and
// I'll try to keep a version up to date.  I can be reached as follows:
//    tmaurel@caramail.com   (or tmaurel@hol.fr)
//
////////////////////////////////////////////////////////////////////////////////
// File    : AccelMapDlg.cpp
// Project : AccelsEditor
////////////////////////////////////////////////////////////////////////////////
// Version : 1.0                       * Author : T.Maurel
// Date    : 17.08.98
//
// Remarks : implementation file
//
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "AccelMapDlg.h"

#include "CmdAccelOb.h"
#include "paramconfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CAccelMapDlg dialog
/////////////////////////////////////////////////////////////////////////////
//
//
CAccelMapDlg::CAccelMapDlg(CAcceleratorManager* pAccelManager,
                           CWnd* pParent /*=NULL*/)
		: CDialog(CAccelMapDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAccelMapDlg)
	//}}AFX_DATA_INIT

	m_pAccelManager = pAccelManager;
}


/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAccelMapDlg)
	DDX_Control(pDX, IDC_ALREADY_AFFECTED, m_AlreadyAffected);
	DDX_Control(pDX, IDC_EDIT_KEY, m_Key);
	DDX_Control(pDX, IDC_CURRENTS, m_Currents);
	DDX_Control(pDX, IDC_COMMANDS, m_Commands);
	//}}AFX_DATA_MAP
}


/////////////////////////////////////////////////////////////////////////////
//
//
BEGIN_MESSAGE_MAP(CAccelMapDlg, CDialog)
	//{{AFX_MSG_MAP(CAccelMapDlg)
	ON_BN_CLICKED(IDC_ASSIGN, OnAssign)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_LBN_SELCHANGE(IDC_COMMANDS, OnSelChangeCommands)
	ON_BN_CLICKED(IDC_ADDCOMMAND, OnAddcommand)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CAccelMapDlg message handlers
/////////////////////////////////////////////////////////////////////////////
//
//
BOOL CAccelMapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


	if (m_pAccelManager == NULL) {
		EndDialog(IDCANCEL);
		return FALSE;
	}

	// Force the dialog styles.
	ModifyStyle(0, WS_POPUPWINDOW | WS_CAPTION | WS_SYSMENU);

	// Initialize the helper
	m_helper.SetAccelManager(m_pAccelManager);

	m_helper.SetGUIObjects(&m_Key, &m_Currents, &m_Commands, &m_AlreadyAffected);

	// Control the number of commands available.
	if (m_pAccelManager->IsMapStringCommandsEmpty()) {

		((CButton*) GetDlgItem(IDC_ASSIGN))->EnableWindow(FALSE);
		((CButton*) GetDlgItem(IDC_REMOVE))->EnableWindow(FALSE);
		((CButton*) GetDlgItem(IDC_RESET))->EnableWindow(FALSE);

		m_Key.EnableWindow(FALSE);

	} else {
		// Init the commands listbox
		InitCommands();
	}

	// If the programmer doesn't called CreateDefaultTable()
	if (!m_pAccelManager->IsDefaultTableAvailable())
		((CButton*) GetDlgItem(IDC_RESET))->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}


/////////////////////////////////////////////////////////////////////////////
// All of the below functions translate the call to the CAccelDlgHelper
// associated object.
/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::OnSelChangeCommands()
{
	m_helper.SelChangeCommands();
	UpdateData(FALSE);
}


/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::OnAssign()
{
	UpdateData();
	m_helper.Assign();
	UpdateData(FALSE);
}


/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::OnRemove()
{
	m_helper.Remove();
	UpdateData(FALSE);
}


/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::OnReset()
{
	m_helper.Reset();
}


/////////////////////////////////////////////////////////////////////////////
//
//
void CAccelMapDlg::InitCommands()
{
	m_helper.InitCommands();
}

#ifdef _DEBUG
#include "newcmddlg.h"
#endif//_DEBUG

void CAccelMapDlg::OnAddcommand()
{
#ifdef _DEBUG
	CNewCmdDlg dlg;
	dlg.DoModal();
//	m_pAccelManager->CreateEntry(ID_FIRST_USERDEFCMD, _T("user define command1"));
#else
#if ENABLE_FUNKEY
	ShellExecute(NULL, _T("open"), g_sKeyTableFile, NULL, NULL, SW_SHOWMAXIMIZED);
#endif//ENABLE_FUNKEY
#endif
}
