// ���´�����WindowXP �Լ� Window2003 ����ͨ��
#ifndef _THUNK_H_
#define _THUNK_H_

#pragma pack(push, 1)
struct ThunkData
{
	BYTE m_mov;
	DWORD m_this;
	DWORD m_jmp;
	void* Init(void* pThis)
	{
		// mov ecx, this
		m_mov = 0xB9;// mov ecx,
		m_this = PtrToUlong(pThis);// this
		// mov eax, dword ptr [ecx] //8B01
		// jmp dword ptr [eax] //FF20
		m_jmp = 0x20FF018B;
		
		::FlushInstructionCache( ::GetCurrentProcess(), this, sizeof(ThunkData) );
		return this;
	}
	
	void* GetCodeAddress()
	{
		return this;
	}
};

#pragma pack(pop)

class CThunk
{
public:
	
	CThunk()
	{
		_thunkData = (ThunkData *)VirtualAlloc(NULL, sizeof(ThunkData), MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	}
	
	~CThunk()
	{
		if (_thunkData != NULL)
			VirtualFree(_thunkData, 0, MEM_RELEASE);
	}

public:
	void* Init(void* pthis)
	{
		ASSERT(_thunkData != NULL);
		if (_thunkData != NULL)
			return _thunkData->Init(pthis);
		else
			return NULL;
	}
	
	void* GetCodeAddress()
	{
		ASSERT(_thunkData != NULL);
		if (_thunkData != NULL)
			return _thunkData->GetCodeAddress();
		else
			return NULL;
	}

private:
	ThunkData* _thunkData;
};
#endif 
