// AutoLoginPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"       // main symbols
#include "SiteAutoPage.h"
#include "TelnetSite.h"

#if ENABLE_FILTER
#include "simplefilterdlg.h"	//������
#endif//ENABLE_FILTER

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteAutoPage property page

IMPLEMENT_DYNCREATE(CSiteAutoPage, CMyPropertyPage)

CSiteAutoPage::CSiteAutoPage() : CMyPropertyPage(GetIDD()),
	m_bPWChanged(false)
{
	//{{AFX_DATA_INIT(CSiteAutoPage)
	m_name = _T("");
	m_psw = _T("");
	m_bAutoLogin = FALSE;
	m_bSSHbbsLogin = FALSE;
	//}}AFX_DATA_INIT
	m_nType = ST_FIREBIRD;
}

CSiteAutoPage::~CSiteAutoPage()
{
}

void CSiteAutoPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteAutoPage)
	DDX_Control(pDX, IDC_PSW, m_editPSW);
	DDX_Control(pDX, IDC_NAME, m_editName);
	DDX_Text(pDX, IDC_NAME, m_name);
	DDV_MaxChars(pDX, m_name, 20);
	//DDX_Text(pDX, IDC_PSW, m_psw);
	//DDV_MaxChars(pDX, m_psw, 20);
	DDX_Check(pDX, IDC_CHECK_AUTOLOGIN, m_bAutoLogin);
	DDX_Check(pDX, IDC_SSHBBSLOGIN, m_bSSHbbsLogin);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteAutoPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteAutoPage)
	ON_BN_CLICKED(IDC_SCRIPT, OnScript)
	ON_BN_CLICKED(IDC_CHECK_AUTOLOGIN, OnCheckAutologin)
	ON_EN_SETFOCUS(IDC_PSW, OnSetfocusPsw)
	ON_EN_CHANGE(IDC_PSW, OnChangePsw)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteAutoPage message handlers

// ��������ť
void CSiteAutoPage::OnScript()
{
#if ENABLE_FILTER
	CSimpleFilterDlg Dlg;
	Dlg.m_nType = m_nType;
	Dlg.m_pFilter = &m_pLogin->m_AutoLogin;
	Dlg.DoModal();
#endif//ENABLE_FILTER
}

void CSiteAutoPage::OnCheckAutologin()
{
	UpdateData();
	m_editName.EnableWindow(m_bAutoLogin);
	m_editPSW.EnableWindow(m_bAutoLogin);
}

BOOL CSiteAutoPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	m_editName.EnableWindow(m_bAutoLogin);
	m_editPSW.EnableWindow(m_bAutoLogin);
	if (m_bAutoLogin) {
		m_editPSW.SetWindowText(_T("******")); // ��ʼ��ʾΪ�����룬��ֹ����͵��
	}
	m_bPWChanged = false; // SetWindowText������ON_EN_CHANGE

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

UINT CSiteAutoPage::GetIDD()
{
	return IDD;
}

void CSiteAutoPage::OnSetfocusPsw() 
{
	m_editPSW.SetWindowText(_T("")); // �ÿ�
	m_bPWChanged = false;
}

void CSiteAutoPage::OnChangePsw() 
{
	m_bPWChanged = true; // �޸�������
}

void CSiteAutoPage::OnOK() 
{
	if (m_bPWChanged) {
		m_editPSW.GetWindowText(m_psw); // �������ֻд�����ģ���ʾ���Ǽ�����
	}

	if (!m_bAutoLogin) {
		m_name.Empty();
		m_psw.Empty();
	}
	
	CMyPropertyPage::OnOK();
}
