/****************************************************************************
MainFrm.cpp : implementation of the CMainFrame class
****************************************************************************/
#include "stdafx.h"

#include <mmsystem.h>
#include <io.h>
#include <AFXPRIV.h>
#include <MULTIMON.H>

#include "CTerm.h"
#include "MainFrm.h"
#include "ctermview.h"
#include "childfrm.h"
#include "forcode.h"
#include "paramconfig.h"
#include "usermsg.h"

#if ENABLE_CONTROLSOCK
#include "controlsock.h"
#endif//ENABLE_CONTROLSOCK

#if ENABLE_MESSAGE
#include "HistoryDlg.h"
#endif//ENABLE_MESSAGE

#if ENABLE_ADDRBOOK
#include "addrbookDlg.h"
#endif//ENABLE_ADDRBOOK

#if ENABLE_LOCK
#include "lockdlg.h"
#endif//ENABLE_LOCK

#if ENABLE_CHATDLG
#include "ChatDlg.h"
#endif//ENABLE_CHATDLG

#if ENABLE_SEARCHDLG
#include "SearchDlg.h"
#endif//ENABLE_SEARCHDLG

#if ENABLE_DOWNLOAD
#include "dlarticledlg.h"
#include "dllistdlg.h"
#include "dldigestdlg.h"
#endif//ENABLE_DOWNLOAD

#if ENABLE_BATCHDLG
#include "batdlg.h"
#endif//ENABLE_BATCHDLG

#if ENABLE_POSTDLG
#include "PostTitleDlg.h"
#include "PostDlg.h"	//byhh
#endif//ENABLE_POSTDLG

#if ENABLE_SHOWIP
#include "QueryIPDlg.h"
#endif//ENABLE_SHOWIP

#if ENABLE_SHOWIP
#include "ShowIPDlg.h"
#endif//ENABLE_SHOWIP

#if ENABLE_PICTURE
#include "picshowdlg.h"
#include "PicSizeDlg.h"
#endif//ENABLE_PICTURE


#if ENABLE_URLENCODE
#include "urlencode.h"
#endif//ENABLE_URLENCODE

#ifdef FOR_BYHH
#include "BYHHID2WEB.h"		//byhh	�ɰ���ź����±��ת��WEBҳ
#endif//FOR_BYHH

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#include "global.h"

#include "debugtool.h"

#if ENABLE_VBS
#include <atlconv.h>
#endif //ENABLE_VBS

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// �ⲿ��������

// �ⲿ��������
extern CTelnetSite g_LastSite;
extern CString g_LastFileName;

//extern CString g_sKeyTableFile;// �Ѿ�ParaConfig.h �������������ļ��Ѿ� Include�����Բ���Ҫ�ظ������������� debug ʱ������
extern CString g_szLanguagePath;	//���������ļ���·��
extern CString g_szSettingPath;	//�������õ��ļ�·��
extern CString g_langStr[];
extern CMenu *g_LangMenu; //����ѡ��˵�

#if ENABLE_PYTHON
extern bool g_bPythonInited;
#endif

// �ⲿ��������
static bool g_bCodeInited = false;	// �����Զ�ת���Ƿ��ѳ�ʼ��
bool g_bAutoReply = false;	// �Զ��ظ�
//static bool g_bLeaved = false;		// �뿪״̬
static bool g_bInLocking = false;	// ����CTerm

bool g_bMenuPoping = false; // ������ʾ����ʽ�˵�����������꣩

#if ENABLE_HIDEMENU
HMENU g_hMainMenu1, g_hMainMenu2;
#endif//ENABLE_HIDEMENU

#if ENABLE_TRANSPARENT

#define WS_EX_LAYERED 0x00080000
#define LWA_ALPHA 2
typedef BOOL (WINAPI *lpfn)(HWND hWnd, COLORREF cr, BYTE bAlpha, DWORD dwFlags);

lpfn g_pSetLayeredWindowAttributes = NULL;
#endif // ENABLE_TRANSPARENT

CMainFrame *g_pMainWnd = NULL; // only one
extern const TCHAR g_sBarVer[] = _T("3.259");		// �������汾�����޸��˹�����֮����Ҫ�޸Ĵ���ֵ

#if ENABLE_COPYTCP
CCTermView *g_pCopyView = NULL; //һ��ֻ����һ��view copy?
BOOL g_bInCopyTcp = FALSE;
#endif

const UINT WM_TASKBARCREATED = ::RegisterWindowMessage(_T("TaskbarCreated"));

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
//{{AFX_MSG_MAP(CMainFrame)
ON_MESSAGE(WM_SCROLLBAR, OnScrollBar)
ON_MESSAGE(WM_CHILDCLOSED, OnChildClosed)
ON_MESSAGE(WM_DISPLAYCHANGE, OnDisplayChange)
ON_WM_SYSCOMMAND()
ON_WM_CREATE()
ON_WM_CLOSE()
ON_WM_SIZE()
ON_WM_MOVE()
ON_WM_WINDOWPOSCHANGING()
ON_MESSAGE(WM_TRAYMENU, OnTrayMenu)
ON_WM_ACTIVATE()
ON_MESSAGE(WM_STEAMIN, OnStreamIn)
ON_MESSAGE(WM_DUPSITE, OnDupSite)
ON_UPDATE_COMMAND_UI(ID_SELECT_RECT, OnUpdateSelectRect)
ON_COMMAND(ID_SELECT_RECT, OnSelectRect)
ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
ON_MESSAGE(WM_HAVE_MAIL, OnHaveMail)
ON_UPDATE_COMMAND_UI(ID_RIGHTCODE, OnUpdateRightcode)
ON_COMMAND(ID_RIGHTCODE, OnRightcode)
ON_COMMAND(ID_BBS_DIGEST, OnBbsDigest)
ON_COMMAND(ID_BBS_G, OnBbsG)
ON_COMMAND(ID_BBS_CLEAR, OnBbsClear)
ON_COMMAND(ID_EDIT_COPYANSI, OnEditCopyANSI)
ON_COMMAND(ID_EDIT_PASTEANSI, OnEditPasteANSI)
ON_UPDATE_COMMAND_UI(ID_EDIT_COPYANSI, OnUpdateEditCopyANSI)
ON_UPDATE_COMMAND_UI(ID_EDIT_PASTEANSI, OnUpdateEditPasteANSI)
ON_UPDATE_COMMAND_UI(ID_BBS_CLEAR, OnUpdateBbsClear)
ON_UPDATE_COMMAND_UI(ID_BBS_G, OnUpdateBbsG)
ON_COMMAND(ID_TEST, OnTest)
ON_UPDATE_COMMAND_UI(ID_AUTOCOPY, OnUpdateAutocopy)
ON_COMMAND(ID_AUTOCOPY, OnAutocopy)
ON_UPDATE_COMMAND_UI(ID_BBS_DIGEST, OnUpdateBbsDigest)
ON_COMMAND(ID_BBS_SUPERPASTE, OnBbsSuperPaste)
ON_UPDATE_COMMAND_UI(ID_BBS_SUPERPASTE, OnUpdateBbsSuperPaste)
ON_WM_TIMER()
ON_MESSAGE(WM_CREATE_NEW_CHILD, OnCreateNewChild)
ON_MESSAGE(WM_DISCONNECTED, OnDisConnected)
ON_COMMAND(ID_WINDOW_NEXT, OnWindowNext)
ON_COMMAND(ID_CTRL_TAB, OnCtrlTab)
ON_COMMAND(ID_CTRL_SHIFT_TAB, OnCtrlShiftTab)
ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWCENTER, OnUpdateViewShowcenter)
ON_COMMAND(ID_VIEW_STATUSBAR, OnViewStatusbar)
ON_UPDATE_COMMAND_UI(ID_VIEW_STATUSBAR, OnUpdateViewStatusbar)
ON_COMMAND(ID_BBS_SAMETITLE, OnBbsSametitle)
ON_UPDATE_COMMAND_UI(ID_BBS_SAMETITLE, OnUpdateBbsSametitle)
ON_COMMAND(ID_INDICATOR_SCRIPT, OnPaneScript)
ON_COMMAND(ID_VIEW_SHOWCENTER, OnViewShowcenter)
ON_UPDATE_COMMAND_UI(ID_BBS_H, OnUpdateBbsH)
ON_UPDATE_COMMAND_UI(ID_BBS_BROWSE, OnUpdateBbsBrowse)
ON_COMMAND(ID_BBS_H, OnBbsH)
ON_COMMAND(ID_BBS_BROWSE, OnBbsBrowse)
ON_COMMAND(ID_MAIN_RESTORE, OnMainRestore)
ON_COMMAND(ID_UPONEFILE, OnUponefile)
ON_REGISTERED_MESSAGE(WM_TASKBARCREATED, OnTaskBarCreated)
ON_COMMAND(ID_TOGGLEANSI, OnToggleansi)
ON_UPDATE_COMMAND_UI(ID_TOGGLEANSI, OnUpdateToggleansi)
ON_COMMAND(ID_ALWAYSTOP, OnAlwaystop)
ON_COMMAND(ID_WEB_GO, OnWebGo)
ON_UPDATE_COMMAND_UI(ID_ALWAYSTOP, OnUpdateAlwaystop)
ON_COMMAND(ID_VIEW_MIN, OnViewMin)
ON_COMMAND(ID_VIEW_MAX, OnViewMax)
ON_COMMAND(ID_VIEW_SIMPLE, OnViewSimple)
ON_COMMAND(ID_SHOW_POSTS, OnShowPosts)
ON_WM_PAINT()
ON_COMMAND(ID_VIEW_SCROLLBAR, OnViewScrollbar)
ON_UPDATE_COMMAND_UI(ID_VIEW_SCROLLBAR, OnUpdateViewScrollbar)
ON_COMMAND(ID_CLOSEALL, OnCloseall)
ON_COMMAND(ID_FONTSCALE, OnFontscale)
ON_COMMAND(ID_CONSOLE, OnConsole)
ON_UPDATE_COMMAND_UI(ID_CONSOLE, OnUpdateConsole)
	ON_COMMAND(ID_FILE_DUP, OnFileDup)
	ON_UPDATE_COMMAND_UI(ID_FILE_DUP, OnUpdateFileDup)
	ON_COMMAND(ID_FILE_RECONNECT, OnFileReconnect)
	ON_UPDATE_COMMAND_UI(ID_FILE_RECONNECT, OnUpdateFileReconnect)
	ON_COMMAND(ID_VIEW_COMPACT, OnViewCompact)
	ON_COMMAND(ID_FILE_COPYSITE, OnFileCopysite)
	ON_UPDATE_COMMAND_UI(ID_FONTSCALE, OnUpdateFontscale)
	ON_COMMAND(ID_BBS_PIC, OnBbsPic)
	ON_UPDATE_COMMAND_UI(ID_BBS_PIC, OnUpdateBbsPic)
	ON_COMMAND(ID_BBS_SIGNATURE, OnBbsSignature)
ON_WM_HSCROLL()
	ON_UPDATE_COMMAND_UI(ID_BBS_SEARCH, OnUpdateBbsSearch)
	ON_COMMAND(ID_BBS_SEARCH, OnBbsSearch)
	ON_UPDATE_COMMAND_UI(ID_BBS_SIGNATURE, OnUpdateBbsSignature)
	//}}AFX_MSG_MAP

#if ENABLE_CAPTIONBUTTON
ON_MESSAGE(WM_CBLBUTTONCLICKED, OnCBLButtonClicked)
#endif//ENABLE_CAPTIONBUTTON
ON_MESSAGE(WM_UNINITMENUPOPUP, OnUnInitMenuPopup)
#if defined(ENABLE_VBS) || defined(ENABLE_PYTHON)
ON_COMMAND(ID_RUN_SCRIPT, OnRunScript)
#endif

#if ENABLE_PICTURE
ON_COMMAND(ID_TOOL_PICDOWNAUTO, OnToolPicDownAuto)
ON_UPDATE_COMMAND_UI(ID_TOOL_PICDOWNAUTO, OnUpdateToolPicDownAuto)
ON_COMMAND(ID_TOOL_PICBOX, OnToolPicbox)
#endif//ENABLE_PICTURE

#if ENABLE_FULLSCRN
ON_COMMAND(ID_VIEW_FULLSCREEN, OnViewFullscreen)
ON_WM_GETMINMAXINFO()
ON_UPDATE_COMMAND_UI(ID_VIEW_FULLSCREEN, OnUpdateViewFullScreen)
ON_MESSAGE(WM_WINDOW_EDGE, OnWindowEdge)
#endif//ENABLE_FULLSCRN
#if ENABLE_ASCIIBAR
ON_COMMAND(ID_VIEW_ASCIIBAR, OnViewAsciibar)
ON_UPDATE_COMMAND_UI(ID_VIEW_ASCIIBAR, OnUpdateViewAsciibar)
#endif//ENABLE_ASCIIBAR
#if ENABLE_BBSBAR
ON_COMMAND(ID_VIEW_BBSBAR, OnViewBbsbar)
ON_UPDATE_COMMAND_UI(ID_VIEW_BBSBAR, OnUpdateViewBbsbar)
#endif//ENABLE_BBSBAR
#if ENABLE_HIDEMENU
ON_COMMAND(ID_VIEW_MENU, OnViewMenu)
ON_UPDATE_COMMAND_UI(ID_VIEW_MENU, OnUpdateViewMenu)
#endif//ENABLE_HIDEMENU
#if ENABLE_TRANSPARENT
ON_COMMAND(ID_TRANSPARENT_INC, OnTransparentInc)
ON_COMMAND(ID_TRANSPARENT_DEC, OnTransparentDec)
#endif // ENABLE_TRANSPARENT
#if ENABLE_HOTKEY
ON_MESSAGE(WM_HOTKEY, OnHotKey)
#endif//ENABLE_HOTKEY
#if ENABLE_UPDATE
ON_MESSAGE(WM_UPDATEDLG, OnUpdateDlg)
#endif//ENABLE_UPDATE
#if ENABLE_SYSCONFIG
ON_MESSAGE(WM_UPDATEPARAM, UpdateParam)
ON_COMMAND(ID_AUTOSAVECONFIG, OnAutosaveconfig)
ON_UPDATE_COMMAND_UI(ID_AUTOSAVECONFIG, OnUpdateAutosaveconfig)
ON_COMMAND(ID_SAVECONFIG, OnSaveconfig)
ON_COMMAND(ID_RELOADCONFIG, OnReloadconfig)
ON_COMMAND(ID_SYS_SETUP, OnSysSetup)
#endif//ENABLE_SYSCONFIG
#if ENABLE_COPYTCP
ON_COMMAND(ID_COPYTCP, OnCopytcp)
ON_UPDATE_COMMAND_UI(ID_COPYTCP, OnUpdateCopytcp)
#endif//ENABLE_COPYTCP
#if ENABLE_BATCHDLG
ON_COMMAND(ID_BAT, OnBat)
ON_UPDATE_COMMAND_UI(ID_BAT, OnUpdateBat)
#endif//ENABLE_BATCHDLG
#if ENABLE_EDITBOX
ON_UPDATE_COMMAND_UI(ID_EDIT_DLG, OnUpdateEditDlg)
ON_COMMAND(ID_EDIT_DLG, OnEditDlg)
#endif//ENABLE_EDITBOX
#if ENABLE_POSTDLG
ON_COMMAND(ID_BBS_POST, OnBbsPost)
ON_UPDATE_COMMAND_UI(ID_BBS_POST, OnUpdateBbsPost)
#endif//ENABLE_POSTDLG
#if ENABLE_MESSAGE
ON_MESSAGE(WM_MSGPOP, OnPopMsg)
ON_COMMAND(ID_SHOW_MSGS, OnShowMsgs)
#endif//ENABLE_MESSAGE
#if ENABLE_LOCK
ON_COMMAND(ID_LEAVE, OnLeave)
//	ON_UPDATE_COMMAND_UI(ID_LEAVE, OnUpdateLeave)
#endif//ENABLE_LOCK
#if ENABLE_SWITCHBAR
ON_COMMAND(ID_TAB_LEFT, OnTabLeft)
ON_COMMAND(ID_TAB_RIGHT, OnTabRight)
ON_COMMAND(ID_VIEW_TAB, OnViewTab)
ON_UPDATE_COMMAND_UI(ID_VIEW_TAB, OnUpdateViewTab)
ON_NOTIFY(NM_CLICK, ID_SWITCH_TAB, OnClickSwitchTab)
ON_NOTIFY(NM_RCLICK, ID_SWITCH_TAB, OnRclickSwitchTab)
ON_NOTIFY(TCN_SELCHANGE, ID_SWITCH_TAB, OnSelchangeSwitchTab)
#endif//ENABLE_SWITCHBAR
#if ENABLE_CTD
ON_COMMAND(ID_OPENCTD, OnOpenctd)
#endif//ENABLE_CTD
#if ENABLE_RAWCTD
ON_COMMAND(ID_CTDRECORD, OnCtdrecord)
ON_UPDATE_COMMAND_UI(ID_CTDRECORD, OnUpdateCtdrecord)
#endif//ENABLE_RAWCTD
#if ENABLE_FUNKEY
ON_COMMAND(ID_SETUP_KEY_1, OnCustomizeCommand)
ON_COMMAND(ID_SETUP_KEY, OnCustomizeCommand)
ON_COMMAND(ID_VIEW_KEYBAR, OnViewKeybar)
ON_UPDATE_COMMAND_UI(ID_VIEW_KEYBAR, OnUpdateViewKeybar)
#endif//ENABLE_FUNKEY
#if ENABLE_SEARCHDLG
ON_COMMAND(ID_BBS_SEARCH, OnBbsSearch)
#endif//ENABLE_SEARCHDLG
#if ENABLE_SHOWIP
ON_COMMAND(ID_TOOL_QUERYIP, OnToolQueryIP)
ON_COMMAND(ID_VIEW_SHOWIPAUTO, OnViewShowipauto)
ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWIPAUTO, OnUpdateViewShowipauto)
#endif//ENABLE_SHOWIP
#if ENABLE_DOWNLOAD
ON_COMMAND(ID_BBS_FULLTEXT, OnBbsFulltext)
ON_UPDATE_COMMAND_UI(ID_BBS_FULLTEXT, OnUpdateBbsFulltext)
ON_COMMAND(ID_DLMANY, OnDlmany)
ON_UPDATE_COMMAND_UI(ID_DLMANY, OnUpdateDlmany)
#endif//ENABLE_DOWNLOAD
#if ENABLE_VBS
ON_COMMAND(ID_DOWNLOAD_TOOL, OnDownloadTool)
ON_COMMAND(ID_STOP_SCRIPT, OnStopScript)
ON_UPDATE_COMMAND_UI(ID_STOP_SCRIPT, OnUpdateStopScript)
#endif// ENABLE_VBS
#if ENABLE_PYTHON
ON_COMMAND(ID_REINIT_PYTHON, OnReinitPython)
ON_MESSAGE(WM_SET_SCRIPT_INFO, OnSetScriptInfo)
#endif/ENABLE_PYTHON
#if ENABLE_SITECONFIG
ON_UPDATE_COMMAND_UI(ID_CONFIG_SITE, OnUpdateConfigSite)
ON_COMMAND(ID_CONFIG_SITE, OnConfigSite)
ON_COMMAND(ID_CONFIG_SITE_AUTOLOGIN, OnConfigSiteAutologin)
ON_COMMAND(ID_CONFIG_SITE_FONT, OnConfigSiteFont)
ON_COMMAND(ID_CONFIG_SITE_DECODE, OnConfigSiteDecode)
ON_COMMAND(ID_CONFIG_SITE_COLOR, OnConfigSiteColor)
#endif//ENABLE_SITECONFIG
#if ENABLE_SEARCHBOX
ON_COMMAND(ID_FOCUS_SEARCHBOX, OnFocusSearchbox)
#endif//ENABLE_SEARCHBOX
#ifdef FOR_BYHH
ON_UPDATE_COMMAND_UI(ID_BBS_WEB, OnUpdateBbsWeb)
ON_COMMAND(ID_BBS_WEB, OnBbsWeb)
#endif//FOR_BYHH

ON_NOTIFY_EX_RANGE(TTN_NEEDTEXTW, 0, 0xFFFF, OnToolTipText)

#if ENABLE_FUNKEY
ON_COMMAND_RANGE(ID_FIRST_USERDEFCMD, ID_FIRST_USERDEFCMD + MAX_USERDEFCMD_NUM, OnUserDefCmd)
ON_UPDATE_COMMAND_UI_RANGE(ID_FIRST_USERDEFCMD, ID_FIRST_USERDEFCMD + MAX_USERDEFCMD_NUM, OnUpdateKeyButton)
#endif//ENABLE_FUNKEY

ON_COMMAND_RANGE(ID_SWITCH_VIEW_FIRST, ID_SWITCH_VIEW_FIRST + 8, OnSwitchView)

ON_UPDATE_COMMAND_UI_RANGE(ID_MENU_SEPARATOR1, ID_MENU_SEPARATOR1 + 3, OnUpdateFakeMenu)

#if ENABLE_MULTILANG
ON_COMMAND_RANGE(ID_LANG1, ID_LANG1 + MAX_LANG_NUM, OnLang)
ON_UPDATE_COMMAND_UI_RANGE(ID_LANG1, ID_LANG1 + MAX_LANG_NUM, OnUpdateLang)
#endif// ENABLE_MULTILANG
END_MESSAGE_MAP()

// ״̬��
static UINT indicators[] = {
	ID_SEPARATOR,           // status line indicator
		ID_INDICATOR_SCRIPT, // �ű�������Ϣ: ������ʼ����ִ�У�ִ����ɣ�������Ϣ��������ʾ��Ϣ��
		ID_INDICATOR_TERM, //
		ID_INDICATOR_PIC, // ͼƬ������Ϣ
		ID_INDICATOR_CURSOR, // ���λ��
		ID_INDICATOR_LINE, // ���λ��
		//ID_INDICATOR_OVR, �������ж�bbs�ǲ��뻹�Ǹ�д
		ID_INDICATOR_CAPS,
		ID_INDICATOR_NUM,
		ID_INDICATOR_VER,
};

static UINT tooltipIndicators[] = {
	0,                        // status line indicator
		IDS_INDICATOR_SCRIPT_TIP,             // Pane 1 tooltip resource ID
		IDS_INDICATOR_TERM_TIP,
		IDS_INDICATOR_PIC_TIP,
		IDS_INDICATOR_CURSOR_TIP,
		IDS_INDICATOR_XY_TIP,
		0,
		0,
		IDS_INDICATOR_VER_TIP,
};

static HICON hIconArray[] = {
	NULL,           // status line indicator
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
		NULL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame():
	m_bTrayIconVisible(false),
		m_bTopMost(FALSE),
#if ENABLE_FUNKEY
		m_UserMenu(NULL),
#endif//ENABLE_FUNKEY
		m_pLockDlg(NULL),
		m_bCreated(false)
	{
#if ENABLE_HOTKEY
		m_bBossHided = false;
		m_bOwnHotkey = false;
#endif//ENABLE_HOTKEY
		
#if ENABLE_FUNKEY
		m_pKeyBar = NULL;
		m_nKeyButtonCount = 0;
		m_bKeyUpdating = true;
#endif//ENABLE_FUNKEY
		
#if ENABLE_FULLSCRN
		m_bFullScreen = FALSE;
		m_pwndFullScrnBar = NULL;
#endif//ENABLE_FULLSCRN
		
		m_nid.cbSize = sizeof(NOTIFYICONDATA);
		
#if ENABLE_VBS
		// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
		m_pIActiveScript = NULL;
		m_pIActiveScriptParse = NULL;
		// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS
		
		m_bToolBar = true;
#if ENABLE_SWITCHBAR
		m_bDlgBar = true;
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
		m_bKeyBar = true;
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
		m_bBBSBar = true;
#endif//ENABLE_BBSBAR
		m_bStatusBar = true;
#if ENABLE_ASCIIBAR
		m_bAsciiBar = true;
#endif//ENABLE_ASCIIBAR
		m_bScrollBar = true;
#if ENABLE_FULLSCRN
		m_bFullScreenBar = true;
#endif//ENABLE_FULLSCRN
	}
	
//////////////////////////////////////////////////////////////////	
	CMainFrame::~CMainFrame()
	{
		if (g_bCodeInited) {
			DeInitCode();
			g_bCodeInited = false;
		}
		
#if ENABLE_FUNKEY
		if (m_UserMenu) {
			m_UserMenu->DestroyMenu();
			m_UserMenu->Detach();
			delete m_UserMenu;
		}
#endif//ENABLE_FUNKEY
		
#if ENABLE_VBS
		// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
		if (m_pIActiveScriptParse)
			m_pIActiveScriptParse->Release();
		
		if (m_pIActiveScript) {
			m_pIActiveScript->Close();
			m_pIActiveScript->Release();
		}
		
		// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS
	}

//////////////////////////////////////////////////////////////////
	// ���ش�ϵͳ�����ڴ�ϵͳ�˵��˳�ʱ�����������������������Ƿ�����
	void CMainFrame::OnSysCommand(UINT nID, LPARAM lParam)
	{
		if ((nID & 0xFFF0) == ID_APP_ABOUT) {
			CCTermApp *pApp = (CCTermApp *)AfxGetApp();
			if (pApp) {
				pApp->OnAppAbout();
				//pApp->PostMessage(WM_COMMAND, (WPARAM)ID_APP_ABOUT, (LPARAM)0); // û����Ϣ����
			}
		}
#if ENABLE_HIDEMENU
		else if (nID == ID_VIEW_MENU) {
			// ���ü�& 0xFFF0
			OnViewMenu();
		}
#endif//ENABLE_HIDEMENU
		else if (nID == ID_ALWAYSTOP) {
			OnAlwaystop();
		}
		else if (nID == ID_VIEW_COMPACT) {
			OnViewCompact();
		}
		else {
			CWnd::OnSysCommand(nID, lParam);
		}
	}
	
	extern const TCHAR* szItemName;
	void InitPython();
#if ENABLE_TRANSPARENT
	void SetTransparent(HWND hWnd);
#endif//ENABLE_TRANSPARENT

//////////////////////////////////////////////////////////////////
	int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
	{
		LoadWindowConfig();
		
		OpenConsole();
		
#if ENABLE_TRANSPARENT
		if (g_bTransparent) {
			SetTransparent(GetSafeHwnd());
		}
#endif // ENABLE_TRANSPARENT
		
		if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
			return -1;
		
#if ENABLE_BITMAPWND
		if (!m_wndClient.SubclassWindow(m_hWndMDIClient))
			return -1;
		
		m_wndClient.ShowWindow(SW_SHOW);
		
#endif//ENABLE_BITMAPWND
		
		// ��������
		if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP	| CBRS_GRIPPER | CBRS_TOOLTIPS |
			CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||	!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
			//TRACE0(_T("Failed to create toolbar\n"));
			return -1;      // fail to create
		
#if ENABLE_SEARCHBOX
		m_wndToolBar.Init();
		
		m_wndToolBar.ShowCombo();	//������Ҫ���ص�ַ��
		
#endif//ENABLE_SEARCHBOX
		
#if ENABLE_ASCIIBAR
		//AsciiBar
		// ȥ��WS_VISIBLE
		if (!m_wndAsciiBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | CBRS_RIGHT | CBRS_GRIPPER | CBRS_TOOLTIPS |
			CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(0, 0, 0, 0), ID_TOOLBAR_ASCII) || !m_wndAsciiBar.LoadToolBar(IDR_ASCIIBAR))
			return -1;      // fail to create
		
		//m_wndAsciiBar.Init();
#endif//ENABLE_ASCIIBAR
		
#if ENABLE_SWITCHBAR
		// վ���ǩ��
		if (!m_wndSwitchBar.Create(this, IDR_SWITCH_BAR, CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM, ID_TOOLBAR_TAB))
			return -1;		// fail to create
		m_wndSwitchBar.tab()->SetMinTabWidth(g_nTabWidMin);
		m_TabList.Create(IDB_TAB_TYPELIST, 16, 1, RGB(0, 255, 0));
		m_wndSwitchBar.tab()->ShowWindow(SW_HIDE);		// ����֮������ʾ���ֹ��
#endif//ENABLE_SWITCHBAR
		
		// ��չ��״̬��
		if (!m_wndStatusBar.Create(this)
			||	!m_wndStatusBar.SetIndicators(indicators, sizeof(indicators) / sizeof(UINT)
#if ENABLE_MMSTATUSBAR
			, tooltipIndicators,	hIconArray
#endif//ENABLE_MMSTATUSBAR
			))
			return -1;      // fail to create
		
		CString ver;
		
		ver.Format(_T("%d.%d.%d"), g_Ver[0], g_Ver[1], g_Ver[2]);
		
#ifdef _DEBUG
		ver += _T("d");
#elif defined(_DEBUG_RELEASE)
		ver += _T("dr");
#endif//_DEBUG
		SetStatus(ID_INDICATOR_VER, ver);
		
#if ENABLE_COOLMENU
		// �˵�
		m_pMenuMgr.Install(this);
		m_pMenuMgr.LoadToolbar(IDR_MAINFRAME);
		m_pMenuMgr.LoadToolbar(IDR_ASCIIBAR);
#endif//ENABLE_COOLMENU
		
		EnableDocking(CBRS_ALIGN_ANY);
		m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
		
#if ENABLE_ASCIIBAR
		m_wndAsciiBar.EnableDocking(CBRS_ALIGN_ANY);
		DockControlBar(&m_wndAsciiBar, AFX_IDW_DOCKBAR_TOP);
#endif//ENABLE_ASCIIBAR
		
		DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP);
		
#if ENABLE_SWITCHBAR
		m_wndSwitchBar.EnableDocking(CBRS_ALIGN_TOP | CBRS_ALIGN_BOTTOM);
		DockControlBar(&m_wndSwitchBar, AFX_IDW_DOCKBAR_TOP);
#endif//ENABLE_SWITCHBAR
		
#if ENABLE_SCROLLBAR
		m_wndScrollBar.Create(this, IDD_SCROLLBAR, CBRS_ALIGN_RIGHT, ID_TOOLBAR_SCROLL);
		m_wndScrollBar.EnableDocking(CBRS_ALIGN_ANY);
		DockControlBar(&m_wndScrollBar, AFX_IDW_DOCKBAR_RIGHT);
		//m_wndScrollBar.ShowWindow(SW_HIDE);			// Ĭ�ϲ���ʾ������
#endif//ENABLE_SCROLLBAR
		
		//m_pKeyBar->EnableDocking(CBRS_ALIGN_ANY);
		//DockControlBar(m_pKeyBar, AFX_IDW_DOCKBAR_RIGHT);
		
#if ENABLE_ASCIIBAR
		DockControlBarLeftOf(&m_wndAsciiBar, &m_wndToolBar);
		m_wndAsciiBar.ShowWindow(SW_HIDE);			// Ĭ�ϲ���ʾ ASCII ������
#endif//ENABLE_ASCIIBAR
		
#if ENABLE_BBSBAR
		if (CreateBBSBar() == -1)
			return -1;
#endif//ENABLE_BBSBAR
		
#if ENABLE_FUNKEY
		// ��ʼ�� KeyBar
		if (CreateKeyBar() == -1)
			return -1;
#endif//ENABLE_FUNKEY
		
		CWinApp *pApp = AfxGetApp();
		
		CString sBarver = pApp->GetProfileString(_T("setup"), _T("BarVer"), _T("3.259"));
		
		if (sBarver.Compare(g_sBarVer) == 0)	//��ֹ��ͬ�汾�Ĺ�������ͬ�����ִ���
			LoadBarState(_T("Bars\\CTerm"));			// ��ȡ������λ��
		
		// �������
		m_nid.cbSize = sizeof(NOTIFYICONDATA);
		
		m_nid.hWnd = m_hWnd;
		
		m_nid.uID  = 1001;
		
		m_nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
		
		m_nid.uCallbackMessage = WM_TRAYMENU;
		
		m_nid.hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
		
		_tcscpy(m_nid.szTip, _T("CTerm"));
		
		g_pMainWnd = this;
		
#if ENABLE_MULTILANG
		DeleteFile(g_defaultLangPath);
		
		//�������п������ԣ�װ��˵�
		//������IDR_MAINFRAME
		LoadAllLanguage(); //Ҫ��SetUserMenu()֮ǰ
		
		CMenu *pMainMenu = g_pMainWnd->GetMenu();
		
		if (pMainMenu) {
			AddLangMenu(pMainMenu);
			g_OutMenuStrings(pMainMenu, _T(""));  //����Ĭ��//Ҫ��usermenu֮ǰ
			
			//���ò˵��ϵ�����
			
			if (g_currLangID != ID_LANG1) {
				g_SetMenuStrings(pMainMenu, _T(""));
			}
		}
		
#endif// ENABLE_MULTILANG
		
#if ENABLE_HIDEMENU
		if (g_hMainMenu1 == NULL) {
			g_hMainMenu1 = ::GetMenu(GetSafeHwnd());
			ASSERT(g_hMainMenu1);
		}
#endif//ENABLE_HIDEMENU
		
		SetMenuFav();	// �վ�����ڶ����˵�
		
#if ENABLE_FUNKEY
		SetUserMenu();
#endif//ENABLE_FUNKEY
		
#if ENABLE_HIDEMENU
		ToggleMenu(g_bMenuVisible);
#endif//ENABLE_HIDEMENU
		
#if ENABLE_VBS
		//#ifndef _DEBUG
		// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
		//Now the script engine
		USES_CONVERSION;
		
		LPCOLESTR lpszT = T2COLE(szItemName);
		
		if (g_bEnableVBS) {
			if (CreateScriptEngine(lpszT) == S_OK) {
				g_bVBSInited = true;
			}
			else {
				//			AfxMessageBox(_T("Can't load the VBScript Engine. Please read FAQ to solve this problem."));
				g_bVBSInited = false;
			}
		}
		
		// #####  END  ACTIVEX SCRIPTING SUPPORT #####
		//#endif //_DEBUG
#endif// ENABLE_VBS
		
#if ENABLE_CHATDLG
		if (!g_wndChat.Create(IDD_CHATDLG, this))
			return -1;
		
#endif//ENABLE_CHATDLG
		
		g_bCodeInited = InitCode();		//������� ����
		
#if ENABLE_HOTKEY
		//	if(g_nInstanceNumber==1) //��ע��һ��
		//		RegisterBossHotKey();
		ReRegisterBossHotKey();
		
#endif//ENABLE_HOTKEY
		
#if ENABLE_SHOWIP
		g_pShowIPDlg = new CShowIPDlg;	// IP
		g_pShowIPDlg->Create(IDD_SHOWIPDLG, this);
#endif//ENABLE_SHOWIP
		
#if ENABLE_PICTURE
		g_pPicShowDlg = new CPicShowDlg;
		g_pPicShowDlg->Create(IDD_PIC_SHOW, this);
#endif//ENABLE_PICTURE
		
#if ENABLE_PYTHON
		InitPython();
#endif
		
#if ENABLE_LOCK
		if (g_nTimer > 0) {
			SetTimer(TIMER_GLOBLE_IDLE, g_nTimer * 1000, NULL);
		}
#endif ENABLE_LOCK
		
		//TRACEF(_T("cterm started!\r\n"));
		CMenu* pSysMenu = GetSystemMenu(FALSE);
		if (pSysMenu != NULL){
			//pSysMenu->AppendMenu(MF_SEPARATOR);
#if ENABLE_HIDEMENU
			// ��Щ����Ҫ��OnSysCommand()�ֶ�������Ӧ
			pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND, ID_VIEW_MENU, _T("��ʾ/���ز˵���(&O)"));
			pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND, ID_VIEW_COMPACT, _T("��ʾ������(&D)"));
//			CMenu * pMainMenu = GetMenu();
//			if (pMainMenu) {
//				CMenu * pViewMenu = pMainMenu->GetSubMenu(2); // ��ʾ
//				if (pViewMenu) {
//					{
//						for (int i = 0; i < 10; ++i) {
//							CMenu * ttt = pViewMenu->GetSubMenu(i); // ģʽ
//							int a=0;
//						}
//					}
//					CMenu * pModeMenu = pViewMenu->GetSubMenu(8); // ģʽ
//					if (pModeMenu) {
//						HMENU h = pModeMenu->GetSafeHmenu();
//						pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND | MF_POPUP, (UINT)h, _T("��������ʾģʽ(&P)"));
//					}
//				}
//			}
			//		pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND, ID_RESTORE_CHILD, _T("�ָ��Ӵ���"));
#endif//ENABLE_HIDEMENU
			pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND, ID_ALWAYSTOP, _T("������ǰ(&T)"));
			pSysMenu->InsertMenu(SC_CLOSE, MF_STRING | MF_BYCOMMAND, ID_APP_ABOUT, _T("���� CTerm(&A)..."));
			pSysMenu->InsertMenu(SC_CLOSE, MF_SEPARATOR | MF_BYCOMMAND);
		}
	
		init_iconv();
		
		return 0;
}


//////////////////////////////////////////////////////////////////
#if ENABLE_SCROLLBAR
void CMainFrame::SetScrollSize(int nScrn, int nCur)
{
	m_wndScrollBar.SetScrollSize(nScrn, nCur);
}
#endif//ENABLE_SCROLLBAR

#if ENABLE_CAPTIONBUTTON
void CMainFrame::CreateCaptionButtons()
{
	static bool bInited = false;
	if (!bInited) {
		// only once
		// subclass the window
		m_cbExtra.Init(GetSafeHwnd());
		bInited = true;
	}

	if (m_cbExtra.getNumCaptions() <= 0) {
		//CaptionButton
		COLORREF crTransparent = RGB(255,0,255);
		// set the number of regular captions
		m_cbExtra.SetNumOfDefaultCaptions(3);
		// set the images' transparency color
		m_cbExtra.SetTransparentColor(crTransparent);
		
		HINSTANCE hInstance = AfxGetInstanceHandle();
		// set the bitmap to be displayed
		m_cbExtra.SetSelectionBitmap((HBITMAP)LoadImage(hInstance,MAKEINTRESOURCE(IDB_SELECTION),IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS|LR_DEFAULTCOLOR));
		
		HBITMAP hMouseOverBitmap = (HBITMAP)LoadImage(hInstance,MAKEINTRESOURCE(IDB_MOUSEOVER),IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS|LR_DEFAULTCOLOR);
		
		// caption 2
		HBITMAP hCaption1Bitmap = (HBITMAP)LoadImage(hInstance,MAKEINTRESOURCE(IDB_BITMAP2),IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS|LR_DEFAULTCOLOR);
		HBITMAP hCaption1BitmapHilite = CCaptionButton::CombineBitmaps(hCaption1Bitmap,hMouseOverBitmap,crTransparent);
		m_cbExtra.New(CB_CLOSE, hCaption1BitmapHilite, hCaption1Bitmap, "Close");
		
		// caption 3
		HBITMAP hCaption2Bitmap = (HBITMAP)LoadImage(hInstance,MAKEINTRESOURCE(IDB_BITMAP3),IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS|LR_DEFAULTCOLOR);
		HBITMAP hCaption2BitmapHilite = CCaptionButton::CombineBitmaps(hCaption2Bitmap,hMouseOverBitmap,crTransparent);
		m_cbExtra.New(CB_MAX, hCaption2BitmapHilite, hCaption2Bitmap, "Maximize/Restore");
		
		HBITMAP hCaption3Bitmap = (HBITMAP)LoadImage(hInstance,MAKEINTRESOURCE(IDB_BITMAP6),IMAGE_BITMAP,0,0,LR_LOADMAP3DCOLORS|LR_DEFAULTCOLOR);
		HBITMAP hCaption3BitmapHilite = CCaptionButton::CombineBitmaps(hCaption3Bitmap,hMouseOverBitmap,crTransparent);
		m_cbExtra.New(CB_MIN, hCaption3BitmapHilite, hCaption3Bitmap, "Minimize");
	}
}

void CMainFrame::DeleteCaptionButtons()
{
	if (m_cbExtra.getNumCaptions() >= 3) {
		m_cbExtra.Delete(CB_CLOSE);
		m_cbExtra.Delete(CB_MAX);
		m_cbExtra.Delete(CB_MIN);
	}
}

#endif//ENABLE_CAPTIONBUTTON

#if ENABLE_TRANSPARENT
void CMainFrame::OnTransparentInc()
{
	if (g_bTransparent && g_pSetLayeredWindowAttributes) {
		// ע�⣺͸��������ζ��alpha��С
		if (--g_nAlpha < 0)
			g_nAlpha = 255; // ѭ��
		
		CString s;
		
		s.Format(_T("alpha: %d"), g_nAlpha);
		
		SetStatus(ID_SEPARATOR, s);
		
		HWND hWnd = AfxGetMainWnd()->GetSafeHwnd();
		
		if (hWnd) {
			g_pSetLayeredWindowAttributes(hWnd, 0, g_nAlpha, LWA_ALPHA);
		}
	}
}

void CMainFrame::OnTransparentDec()
{
	if (g_bTransparent && g_pSetLayeredWindowAttributes) {
		if (++g_nAlpha > 255)
			g_nAlpha = 0; // ѭ��
		
		CString s;
		
		s.Format(_T("alpha: %d"), g_nAlpha);
		
		SetStatus(ID_SEPARATOR, s);
		
		HWND hWnd = AfxGetMainWnd()->GetSafeHwnd();
		
		if (hWnd) {
			g_pSetLayeredWindowAttributes(hWnd, 0, g_nAlpha, LWA_ALPHA);
		}
	}
}

void SetTransparent(HWND hWnd)
{
	if (g_bTransparent) {
		HMODULE hUser32 = GetModuleHandle(_T("USER32.DLL"));
		
		if (hUser32) {
			g_pSetLayeredWindowAttributes = (lpfn) GetProcAddress(hUser32, "SetLayeredWindowAttributes");
			
			//����layeredwindow��ʹ֮�ɼ�(͸����255)
			
			if (g_pSetLayeredWindowAttributes) {
				::SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
				g_pSetLayeredWindowAttributes(hWnd, 0, g_nAlpha, LWA_ALPHA);
			}
		}
	}
	else {
		if (g_pSetLayeredWindowAttributes) {
			g_pSetLayeredWindowAttributes(hWnd, 0, 255, LWA_ALPHA);
		}
		::SetWindowLong(hWnd, GWL_EXSTYLE, GetWindowLong(hWnd, GWL_EXSTYLE) & ~WS_EX_LAYERED);//ȥ��͸��
	}
}
#endif // ENABLE_TRANSPARENT


void CMainFrame::OnViewScrollbar() 
{
	ShowControlBar(&m_wndScrollBar, !m_wndScrollBar.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewScrollbar(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_wndScrollBar.IsVisible());
}

#if ENABLE_BBSBAR
// BBS ������
void CMainFrame::OnViewBbsbar()
{
	ShowControlBar(&m_wndBbsBar, !m_wndBbsBar.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewBbsbar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndBbsBar.IsVisible());  
}

int CMainFrame::CreateBBSBar()
{
	//////////////// ��ʼ��BBSbar
	// BBS���ƹ�����
	if (!m_wndBbsBar.CreateEx(this, TBSTYLE_FLAT | TBSTYLE_AUTOSIZE | CCS_ADJUSTABLE,
		WS_CHILD  | WS_VISIBLE | CBRS_BOTTOM | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY, CRect(0, 0, 0, 0), ID_TOOLBAR_BBS) || !m_wndBbsBar.LoadToolBar(IDR_BBSBAR))
		return -1;      // fail to create
	
	CString sInfo;
	
	TBBUTTON button = { -1, 0, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE, 0, 0};
	
	TBBUTTON button1 = {0, 0, NULL, TBSTYLE_SEP, 0, 0};	//�ָ���
	
	m_wndBbsBar.SetSizes(CSize(58, 30), CSize(1, 1));    //sizeImage�������0��0��ǰһ��CSize���ƹ������Ŀ��Ⱥ͸߶�
	
	CToolBarCtrl &bbsbarCtrl = m_wndBbsBar.GetToolBarCtrl();
	
	bbsbarCtrl.DeleteButton(0);  //��Դ�й���������Ϊ��
	
	int BBSKeyIDs[][2] = {
		{ID_BBS_DIGEST, IDS_BBS_DIGEST},
		{ID_BBS_G, IDS_BBS_G},
		{ID_BBS_H, IDS_BBS_H},
		{ID_BBS_BROWSE, IDS_BBS_BROWSE},
		{ID_BBS_SEARCH, IDS_BBS_SEARCH},
		//		{ID_BBS_WEB, IDS_BBS_WEB},		//FOR_BYHH		//��ֵ��ǣ�ʹ�� #ifdef ʱ����ͨ�ð汾�л���ɹ�������һ���հ�λ��
		{0, 0}, //SEPARATOR
		{ID_BBS_CLEAR, IDS_BBS_CLEAR},
		{ID_BBS_SAMETITLE, IDS_BBS_SAMETITLE},
		{ID_BBS_FULLTEXT, IDS_BBS_FULLTEXT},
		{ID_BBS_POST, IDS_BBS_POST},
		{ID_BBS_PIC, IDS_BBS_PIC},
		{ID_BBS_SUPERPASTE, IDS_BBS_SUPERPASTE}
	};
	
	int count = sizeof(BBSKeyIDs) / (2 * sizeof(int));
	
	for (int i = 0 ; i < count ; i++) {
		BOOL ret = FALSE;
		
		if (BBSKeyIDs[i][0] != 0) {
			button.idCommand = BBSKeyIDs[i][0];
			ret = bbsbarCtrl.InsertButton(bbsbarCtrl.GetButtonCount(), &button);
		} else
			bbsbarCtrl.InsertButton(bbsbarCtrl.GetButtonCount(), &button1);
		
		if (ret) {
			sInfo.LoadString(BBSKeyIDs[i][1]);
			m_wndBbsBar.SetButtonText(m_wndBbsBar.CommandToIndex(BBSKeyIDs[i][0]), sInfo);
		}
	}
	
	m_wndBbsBar.EnableDocking(CBRS_ALIGN_ANY);
	
	DockControlBar(&m_wndBbsBar, AFX_IDW_DOCKBAR_BOTTOM);
	
	//DockControlBarLeftOf(&m_wndBbsBar, &m_wndToolBar);		// Ĭ�ϰѹ������ʹ��ڹ�����������һ��	// ���У��������
	return 0;
}
#endif//ENABLE_BBSBAR

#if ENABLE_FUNKEY
void CMainFrame::OnUserDefCmd(UINT nID)
{
	//TRACE(_T("in CMainFrame::OnUserDefCmd \t nID=%d"), nID);
	
	UINT i = nID - ID_FIRST_USERDEFCMD;
	ASSERT(0 <= i && i < MAX_USERDEFCMD_NUM);
	
	if (!(0 <= i && i < MAX_USERDEFCMD_NUM))
		return;
	
	ASSERT(m_keyTable[i].nCmdID == nID);
	
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	SUserDefCmd &rItem = m_keyTable[i];
	
	ASSERT(rItem.nCmdID);
	
	if (rItem.nCmdID == 0) // n/a
		return;
	
	CString sData = TranslateString(rItem.sScriptTxt);
	
	// 0: ��������(translate) <=> RunPythonCode(_T("sendParsedString('+sScriptTxt+")'")
	// 1: ִ��python���� <=> RunPythonCode(sScriptTxt)
	// 2: ִ��python�ű� <=> RunPythonScript(sScriptTxt)
	switch (rItem.nType) {
		
	case 0:
		if (pFrame && pFrame->m_pView && pFrame->m_pView->IsStarted())
			pFrame->m_pView->Send(sData.GetBuffer(1), sData.GetLength());
		
		break;
		
#if ENABLE_PYTHON
		
	case 1:
		RunPythonCode(sData, m_Child.nChild > 0 ? m_Child.nIDs[m_Child.nActive] : -1);
		
		break;
		
	case 2:
		RunPythonScript(rItem.sScriptTxt, m_Child.nChild > 0 ? m_Child.nIDs[m_Child.nActive] : -1);
		
		break;
		
#endif//ENABLE_PYTHON
	}
	
#ifdef _DEBUG
	//	CString s;
	//	s.Format(_T("you pressed button %d; data is %s"), i,
	//		m_keyTable[i].sScriptTxt);
	//	AfxMessageBox(s);
#endif
}

void CMainFrame::OnUpdateKeyButton(CCmdUI* pCmdUI)
{
	UINT i = pCmdUI->m_nID - ID_FIRST_USERDEFCMD;
	ASSERT(0 <= i && i < MAX_USERDEFCMD_NUM);
	//#ifndef _DEBUG
	//����Ϊ����disable
	bool bEnable = false;
	
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	SITESTATUS nStatus = SST_UNKNOWN;
	SITESTATUS nSubStatus = SST_UNKNOWN;
	
	if (pFrame && pFrame->m_pView) {
		nStatus = pFrame->m_pView->GetStatus();
		nSubStatus = pFrame->m_pView->m_Status.SubStatus();
	}
	
	if (false) { //m_keyTable[i].sLabel==_T("Post")) //sample //����������IDָ��
		if (nStatus == SST_LIST &&	nSubStatus == SST_LIST_ARTICLE)
			bEnable = true;
	} else if (m_keyTable[i].sScriptTxt.IsEmpty()) {
		bEnable = false;
	} // ���·ǿ�
	else if (m_keyTable[i].nType == 0) {
		//send data
		if (m_Child.nChild > 0
			&& m_Child.pFrames[m_Child.nActive]
			&& m_Child.pFrames[m_Child.nActive]->m_pView
			&& m_Child.pFrames[m_Child.nActive]->m_pView->IsStarted())
			bEnable = true;
	}
	else {
		bEnable = true;
	}
	
	pCmdUI->Enable(bEnable);
	
	//#endif
}

void CMainFrame::OnCustomizeCommand()
{
	m_bKeyUpdating = ! m_bKeyUpdating; //true:ˢ���Զ��尴ť, false: ��.ckt
	//CString sInfo = g_LoadString(m_bKeyUpdating ? IDS_SETUP_KEY : IDS_UPDATE_KEY);
	CString sInfo;
	sInfo.LoadString(m_bKeyUpdating ? IDS_SETUP_KEY : IDS_UPDATE_KEY); //������
	
	if (m_bKeyUpdating) {
		bool bVisible = false;
		
		if (m_pKeyBar) {
			bVisible = m_pKeyBar->IsVisible();
		}
		
		//���´���keybar��usermenu
		CreateKeyBar();
		
		SetUserMenu();
		
		CCTermApp *pApp = (CCTermApp *) AfxGetApp();
		
		pApp->LoadUserDefCmdTable(g_sKeyTableFile);
		
		if (bVisible) {
			ShowControlBar(m_pKeyBar, TRUE, FALSE);
		}
		
		//��������������Ϊ�ڰ��¡����¡���ť��Ҫ�ȵ����������أ�keybar�Ż�ˢ��
		//����ʱ�޸���keybar ...
		//PostMessage(WM_COMMAND,);
		
		//		sInfo.LoadString (IDS_SETUP_KEY);//�����ơ�
		m_pKeyBar->SetButtonText(m_pKeyBar->CommandToIndex(ID_SETUP_KEY), sInfo);
	} else {
		ShellExecute(NULL, _T("open"), g_sKeyTableFile, NULL, NULL, SW_SHOWNORMAL);
		
		//		if (g_currLangID == ID_LANG1)
		//		{
		//			sInfo.LoadString (IDS_UPDATE_KEY);//�����¡�
		//		}
		//		else
		//		{
		//			sInfo = _T("Update");
		//		}
		m_pKeyBar->SetButtonText(m_pKeyBar->CommandToIndex(ID_SETUP_KEY), sInfo);
	}
	
	if (m_UserMenu) {
		m_UserMenu->ModifyMenu(0, MF_BYPOSITION | MF_STRING, ID_SETUP_KEY, sInfo);
	}
	
	//#endif
}

void CMainFrame::OnViewKeybar()
{
	ShowControlBar(m_pKeyBar, !m_pKeyBar->IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewKeybar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_pKeyBar->IsVisible());
}

//��KeyBar������һ���Զ��尴ť
void CMainFrame::InsertButton(int nCmdID, CString &sLabel, int nIndex)
{
	//	ASSERT(ID_FIRST_USERDEFCMD<=nCmdID && nCmdID<ID_FIRST_USERDEFCMD+MAX_USERDEFCMD_NUM);
	
	/*bool bVisible=false;
	if(m_pKeyBar->IsVisible())
	{
	bVisible=true;
	ShowControlBar(m_pKeyBar,FALSE,FALSE);
}*/
	
	//��ǰ�˺�Ĵ����Ŀ����Ϊ��׷�Ӻ�İ�ť��������ʾ
	CToolBarCtrl& keybarCtrl = m_pKeyBar->GetToolBarCtrl();
	TBBUTTON button = { -1, nCmdID, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE, 0, 0};	//, 0, 0}; // -1: û��ͼ��
	
	if (nIndex == -1) //Ĭ��׷��
		nIndex = keybarCtrl.GetButtonCount();
	
	keybarCtrl.InsertButton(nIndex, &button);
	
	m_pKeyBar->SetButtonText(nIndex, sLabel);	//m_pKeyBar->CommandToIndex(nCmdID) �����������!!!
	
	//	m_nButtonIndices[m_nKeyButtonCount]=j;
	m_nKeyButtonCount++;
	
	keybarCtrl.AutoSize();
	
	//m_pKeyBar->SetSizes(CSize(keybarCtrl.GetButtonCount()*4,24), CSize(1,1));
	
	/*if(m_pKeyBar->IsFloating())
	{
	CPoint pt;
	CRect rect;
	((CMiniDockFrameWnd*)m_pKeyBar->GetParent()->GetParent())->GetWindowRect(&rect);
	pt=rect.TopLeft();
	
	  DockControlBar(m_pKeyBar);
	  FloatControlBar(m_pKeyBar, pt);
	  }
	  else
	  {
	  CDockBar* pOldDockBar=(CDockBar*)m_pKeyBar->GetParent();
	  FloatControlBar(m_pKeyBar, CPoint(150,100));
	  pOldDockBar->ReDockControlBar(m_pKeyBar);// can't redock here if already docked here
	  }
	  
		if(bVisible)//������ʾ
	ShowControlBar(m_pKeyBar,TRUE,FALSE);*/
}

int CMainFrame::CreateKeyBar()
{
	m_nKeyButtonCount = 0;
	
	bool bFloating = false;
	
	CPoint pt;
	CDockState state;
	bool bUpdate = false;
	if (m_pKeyBar) {
		bUpdate = true;
		
		//oldStyle = m_pKeyBar->GetBarStyle();
		bFloating = m_pKeyBar->IsFloating();
		if (bFloating) {
			CRect rect;
			((CMiniDockFrameWnd*)m_pKeyBar->GetParent()->GetParent())->GetWindowRect(&rect);
			pt=rect.TopLeft();
		} else {
			GetDockState(state); 
		}
		
		m_pKeyBar->DestroyWindow();
		delete m_pKeyBar;
		m_pKeyBar = NULL;
	}
	
	m_pKeyBar = new CToolBar();
	
	if (m_pKeyBar && !m_pKeyBar->CreateEx(this,
		TBSTYLE_FLAT | TBSTYLE_AUTOSIZE | CCS_ADJUSTABLE,
		WS_CHILD | WS_VISIBLE | CBRS_RIGHT | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC,
		CRect(0, 0, 0, 0),
		ID_TOOLBAR_KEY)) {
		delete m_pKeyBar;
		m_pKeyBar = NULL;
		return -1;      // fail to create
	}
	
	//////////////// ��ʼ��keybar
	m_pKeyBar->SetSizes(CSize(g_nKeybarWidth, g_nKeybarHeight), CSize(1, 1));
	
	CToolBarCtrl& keybarCtrl = m_pKeyBar->GetToolBarCtrl();
	
	//keybarCtrl.DeleteButton(0); // ��Դ�й���������Ϊ��
	TBBUTTON button = {-1, ID_SETUP_KEY, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE, 0, 0};
	
	keybarCtrl.InsertButton(keybarCtrl.GetButtonCount(), &button);
	
	CString sInfo;
	
	sInfo.LoadString(IDS_SETUP_KEY);
	
	m_pKeyBar->SetButtonText(m_pKeyBar->CommandToIndex(ID_SETUP_KEY), sInfo);
	
	m_pKeyBar->EnableDocking(CBRS_ALIGN_ANY);
	
	if (bUpdate) {
		if (bFloating) {
			//m_pKeyBar->SetBarStyle(oldStyle);
			FloatControlBar(m_pKeyBar, pt);
		} else {
			SetDockState(state);
		}
	} else {
		DockControlBar(m_pKeyBar, AFX_IDW_DOCKBAR_RIGHT);
	}
	//DockControlBarLeftOf(m_pKeyBar, &m_wndBbsBar);
	
	//�ָ���
	//TBBUTTON button1={0,0,NULL,TBSTYLE_SEP,0,0};
	//keybarCtrl.InsertButton(keybarCtrl.GetButtonCount(), &button1);
	
	//CToolTipCtrl* tooltip=m_pKeyBar->GetToolTips(); //NULL
	//	CRect toolrect;
	//	m_pKeyBar->GetItemRect(m_pKeyBar->CommandToIndex(ID_SETUP_KEY), &toolrect);
	//		&toolrect,
	//		ID_SETUP_KEY);
	
	//	SetTimer(100,300,NULL);
	return 0;
}

#endif//ENABLE_FUNKEY

// wParam��һ��CTelnetSiteָ����ļ���ָ��
// lParam��һ����ʾ��ָʾ���ļ�����վ��
extern int g_nConnectionType;
LRESULT CMainFrame::OnCreateNewChild(WPARAM wParam, LPARAM lParam)
{
	ASSERT(lParam <= 1);
	ASSERT(wParam != 0);
	//TRACE(_T("in CMainFrame::OnCreateNewChild\n"));
	
	//	m_wndSwitchBar.ShowTextMsg(0);		// �������ֹ��
	
	CTelnetSite *pNewSite = NULL;
	
	if (lParam == 0) {
		// վ��
		//TRACE(_T("CMainFrame::OnCreateNewChild 4\r\n "));
		pNewSite = (CTelnetSite *) wParam;
	}
	
	CCTermApp * pApp = (CCTermApp *) AfxGetApp();
	
	//	TRACEF("CMainFrame::OnCreateNewChild 1\r\n ");
	//TRACE(_T("CMainFrame::OnCreateNewChild 1\r\n "));
	CChildFrame * pChildWnd = (CChildFrame *) CreateNewChild(
		RUNTIME_CLASS(CChildFrame), IDR_CTERMTYPE, pApp->m_hMDIMenu, pApp->m_hMDIAccel);
	
	pChildWnd->ActivateFrame();
	
#if defined(ENABLE_PIPESSH)
	if (lParam == 0) {
		// ��ʲô��˼��
		if (pNewSite && pNewSite->m_Login.m_bSSH)	{
			pChildWnd->ShowWindow(SW_HIDE);
		}
	}
#endif//defined(ENABLE_PIPESSH)
	
	pChildWnd->m_pView->ShowWindow(SW_HIDE);
	pChildWnd->m_pView->SetConnectionType(g_nConnectionType);
	
	if (lParam == 0) {
		// վ��
		//TRACE(_T("CMainFrame::OnCreateNewChild 4\r\n "));
		//CTelnetSite* pNewSite = (CTelnetSite*) wParam;
		pChildWnd->m_pView->m_Site = *pNewSite;
		delete pNewSite;
		pChildWnd->SetTitle(CString(pChildWnd->m_pView->m_Site.m_Login.m_szProfileName));
	}
	else if (lParam == 1) {
		// �ļ�
		TCHAR* pszFile = (TCHAR *) wParam;
		pChildWnd->SetTitle(GetShortFileName(pszFile));
	}
	
	pChildWnd->SetTitle();
	
	//	TRACEF("CMainFrame::OnCreateNewChild 2\r\n ");
	//TRACE(_T("CMainFrame::OnCreateNewChild 2\r\n "));
	
	// ����󻯣���ʼ������Ǵ��
	if (g_bChildDefaultMax)
		pChildWnd->MDIMaximize();
	
	//TRACE(_T("CMainFrame::OnCreateNewChild 5\r\n "));
	
	AddChild(pChildWnd);  // ���з���ID�����ô��ڱ���
	
	//TRACE(_T("CMainFrame::OnCreateNewChild 6\r\n "));
	
	// �����������Ӵ���ʱ�����˵�, ��IDR_CTERMTYPE
	// Ӧ�÷�������ǰ�� ��������ӳ�
	// ��Ӧ��AddChild֮��
	if (m_Child.nChild == 1) {
		SetChildMenu();
	}//m_Child.nChild == 1
	
#if ENABLE_HIDEMENU
	if (!g_bMenuVisible) {
		ToggleMenu(false);
	}
#endif//ENABLE_HIDEMENU
	
	//TRACE(_T("CMainFrame::OnCreateNewChild 8\r\n "));
	
	//TRACEF(_T ("%d: creating new child ...\r\n"));
	
	pChildWnd->m_pView->SetUserPath(g_szUserPath);
	
	//TRACEF(pChildWnd->m_pView->m_Site.m_Login.m_szAddr);
	
	if (lParam == 0) {
		// վ��
		pChildWnd->m_pView->Navigator();
	}
	else if (lParam == 1) {
		// �ļ�
#if ENABLE_CTD
		TCHAR* pszFile = (TCHAR *)wParam;
		pChildWnd->m_pView->Navigator(pszFile);
#endif//ENABLE_CTD
	}
	
	SendMessage(WM_PAINT);// Ϊ����ȷ��ʾ������
	
	pChildWnd->SetFocus();
	
	pChildWnd->m_pView->ShowWindow(SW_SHOW);
	
	if (g_bAutoSize && !IsZoomed() && pChildWnd->IsZoomed()
		&& (pChildWnd->m_pView->IsFixFont() || pChildWnd->m_pView->Font() == _T("Fixedsys"))) {
		CRect rectWin;
		GetWindowRect(&rectWin);
		//ScreenToClient(&rectWin);
		MoveWindow(&rectWin); // ����WM_SIZE
	}
	
	pChildWnd->m_pView->SetTimer(TIMER_BLINK, g_nBlinkTimeOut, NULL);
	
	return 1;
}

void CMainFrame::SetChildMenu()
{
	{
#if ENABLE_HIDEMENU
		if (g_hMainMenu2 == NULL) {
			g_hMainMenu2 = ::GetMenu(GetSafeHwnd());
		}
#endif//ENABLE_HIDEMENU
		
		{
			SetMenuFav(); //��bInserted���棬��Ϊ���ܱ仯����Ҫ���ִ��
			CMenu* pMainMenu = GetMenu();
			static bool bInserted = false;
			
			if (!bInserted && pMainMenu) { //only once
#if ENABLE_MULTILANG
				g_OutMenuStrings(pMainMenu, _T(""));  //����Ĭ��//only once //Ҫ��UserMenu֮ǰ
				AddLangMenu(pMainMenu);
#endif// ENABLE_MULTILANG
				
#if ENABLE_FUNKEY
				if (g_bShowUserMenu) {
					if (m_UserMenu) {
						//�Զ����ڹ���֮��
						//					CString sName = g_LoadString (IDS_CUSTOMIZED);
						//					if (g_currLangID > ID_LANG1 && sName.IsEmpty())
						//						sName = _T("Customized");
						pMainMenu->InsertMenu(GetSubMenuPos(pMainMenu, 'T'),
							MF_BYPOSITION | MF_POPUP | MF_STRING, (UINT) m_UserMenu->m_hMenu, g_LoadString(IDS_CUSTOMIZED));
						//TRACE("USER menu inserted\r\n");
						//					CString s;
						//					m_UserMenu->GetMenuString (ID_SETUP_KEY, s, MF_BYCOMMAND);
						
					}
				}
#endif//ENABLE_FUNKEY
				bInserted = true;
			}
			
			//��������ҲҪ��bInserted���棬��Ϊ����Ҳ���ܱ仯����Ҫ���ִ��
#if ENABLE_MULTILANG
			//���ò˵��ϵ�����(������Ҫ���ִ��: ��δ�0�Ӵ��ڵ�1�Ӵ���, ��Ҫ�л��˵�)
			if (pMainMenu) {
				g_SetMenuStrings(pMainMenu, _T(""));
			}
#endif// ENABLE_MULTILANG
			
			DrawMenuBar(); // �ػ��˵��������������ص���ʾ
		}
		
	}
}

void CMainFrame::OnSwitchView(UINT nID)
{
	//TRACE(_T("in CMainFrame::OnSwitchView nID:%d\n"), nID);
	if (nID - ID_SWITCH_VIEW_FIRST < m_Child.nChild) {
		SwitchView(nID - ID_SWITCH_VIEW_FIRST);
	}
}

//�л�����nIdx���Ӵ���
void CMainFrame::SwitchView(UINT nIdx)
{
	//����ʱ������һ�����Ϊ 0 �ı�ǩ��������ʾ������ҳ����˱�ǩ����վ������ 1.
	CChildFrame *pFrame;
	ASSERT(nIdx <= m_Child.nChild);
	
	if (nIdx >= 0 && nIdx <= m_Child.nChild) {
		//0 for background
		pFrame = m_Child.pFrames[nIdx];
		//���ܴ�ʱ�����ѹر�
		
		if (pFrame && ::IsWindow(pFrame->GetSafeHwnd())) {
			if (pFrame->IsIconic())
				pFrame->ShowWindow(SW_RESTORE);
			
			ASSERT(pFrame);
			
			MDIActivate(pFrame);
			
			pFrame->BringWindowToTop();
		}
	}
	else {
		int i;
		
		for (i = 0; i < m_Child.nChild; i++) {
			pFrame = m_Child.pFrames[i];
			ASSERT(pFrame);
			pFrame->ShowWindow(SW_SHOWMINIMIZED);
		}
		
#if ENABLE_SWITCHBAR
		m_wndSwitchBar.tab()->SetCurSel(0);	// GetCurSel();
#endif//ENABLE_SWITCHBAR
	}
	
#if ENABLE_HIDEMENU
	if (!g_bMenuVisible)
		ToggleMenu(false);
#endif//ENABLE_HIDEMENU
	
	SetStatus(ID_INDICATOR_TERM, _T(""));
}

#if ENABLE_SWITCHBAR
//void CMainFrame::SetChildTab(CChildFrame *pChild)
//{
//	if(::IsWindow(m_wndSwitchBar.GetSafeHwnd())) {
//		int i = m_Child.GetChildIndex(pChild);
//		m_wndSwitchBar.tab()->SetCurSel(i);
//	}
//}

// �˵�����ʾ������վ���������
void CMainFrame::OnViewTab()
{
	if (m_wndSwitchBar.IsVisible())
		ShowControlBar(&m_wndSwitchBar, FALSE, FALSE);
	else
		ShowControlBar(&m_wndSwitchBar, TRUE, FALSE);
}

void CMainFrame::OnUpdateViewTab(CCmdUI* pCmdUI)
{
	if (m_wndSwitchBar.IsVisible())
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnSelchangeSwitchTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	int n = m_wndSwitchBar.tab()->GetCurSel();
	
	if (n >= 0 && n <= m_Child.nChild) {
		SwitchView(n);
	}
	
	*pResult = 0;
}

void CMainFrame::OnClickSwitchTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	int n = m_wndSwitchBar.tab()->GetCurSel();
	
	if (n >= 0 && n <= m_Child.nChild) {
		static DWORD dwLastClick = 0;	// ��һ�ε��ʱ��
		static int   nLastClickTab = 0;	// ��һ�ε����Tab����ֹ�ڿ����л�ʱ����Ϊ�Ƕ�ͬһTab��˫����
		DWORD dwCurClick = GetTickCount();
		SwitchView(n);
		//��Ϊ��1����ǩ��CTerm�ģ������Ĳ���վ���
		//n--;
		//TRACE(_T("\nin CMainFrame::OnClickSwitchTab\n"));
		//TRACE(_T("dwCurClick: %d, dwLastClick:%d, %d\n"), dwCurClick, dwLastClick, dwCurClick-dwLastClick);
#define TAB_DOUBLE_CLICK_TIME 500
		
		if (g_bDblClkTab && n == nLastClickTab && (dwCurClick - dwLastClick) < TAB_DOUBLE_CLICK_TIME) {
			TRACE(_T("\ndouble clicked\n"));
			m_Child.pFrames[n]->m_pView->FastAway();
		}
		
		dwLastClick = dwCurClick;
		
		nLastClickTab = n;
	}
}

void CMainFrame::OnRclickSwitchTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	CMenu menu, *pmenu = NULL;
	menu.LoadMenu(IDR_TAB_MENU);
	
#if ENABLE_MULTILANG
	if (g_currLangID != ID_LANG1) {
		g_OutMenuStrings(&menu, _T(""));  //����Ĭ��
		g_SetMenuStrings(&menu, _T(""));
	}
#endif// ENABLE_MULTILANG
	
	pmenu = (CMenu *) menu.GetSubMenu(0);
	
	CPoint point;
	
	GetCursorPos(&point);
	
	int i = m_wndSwitchBar.HitTest();
	
	if (i != -1) {
		SwitchView(i);
		pmenu->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
		pmenu->DestroyMenu();
		*pResult = 1; // ��������Ϊ1, ��ʾ�Ѵ��������ⵯ��BAR_MENU
	}
}

void CMainFrame::MoveChild(const int offset)
{
	// �ƶ�
	if (offset != 0) {
		const int n = m_Child.nActive;
		moveTab(n, offset); // Ҫ����m_Child.move֮ǰ
		m_Child.move(n, offset);
		m_wndSwitchBar.tab()->SetCurSel(m_Child.nActive); // m_Child.nActive����
	}
}

void CMainFrame::swapTab(const int i, const int j)
{
	// ֻҪ�ƶ�title
	if (0 <= i && i <= m_Child.nChild
		&& 0 <= j && j <= m_Child.nChild
		&& ::IsWindow(m_wndSwitchBar.tab()->GetSafeHwnd())) {
		CChildFrame *pChild = m_Child.pFrames[i];
		CChildFrame *pChild1 = m_Child.pFrames[j];
		if (pChild && pChild1) {
			CString title = pChild->GetTabTitle();
			CString title1 = pChild1->GetTabTitle();
			
			TCITEM tcItem;
			tcItem.pszText = title.LockBuffer();
			tcItem.mask = TCIF_TEXT;
			m_wndSwitchBar.tab()->SetItem(j, &tcItem);
			title.UnlockBuffer();
			
			tcItem.pszText = title1.LockBuffer();
			tcItem.mask = TCIF_TEXT;
			m_wndSwitchBar.tab()->SetItem(i, &tcItem);
			title1.UnlockBuffer();
		}
	}
}

void CMainFrame::moveTab(const int i, const int offset)
{
	int n = m_Child.nChild;
	if (offset != 0 && n > 1 && 0 <= i && i < n) {
		int desti = i + offset;
		bool forward = (offset > 0);
		
		if (forward) {
			desti %= n;
		}
		else {
			if (desti < 0) {
				desti = n - ( -desti % n );
			}
		}
		
		ASSERT(0 <= i && i < n);
		if (i != desti)
			swapTab(i, desti);
	}
}

void CMainFrame::OnTabLeft() 
{
	MoveChild(-1);
}

void CMainFrame::OnTabRight() 
{
	MoveChild(1);
}

#endif//ENABLE_SWITCHBAR

// ��һ������
void CMainFrame::OnWindowNext()
{
	if (m_Child.nChild > 1) {
		int n = m_Child.nActive;
		
		if (n < m_Child.nChild - 1)
			n++;
		else
			n = 0;
		
		SwitchView(n);
	}
}

void CMainFrame::OnCtrlTab()
{
	OnWindowNext();
}

void CMainFrame::OnCtrlShiftTab()
{
	if (m_Child.nChild > 1) {
		int n = m_Child.nActive;
		
		if (0 < n && n <= m_Child.nChild - 1)
			n--;
		else
			n = m_Child.nChild - 1;
		
		SwitchView(n);
	}
}

void CMainFrame::OnUpdateFakeMenu(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(FALSE);
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	CWinApp *pApp = NULL;
	pApp = AfxGetApp();
	cs.x = pApp->GetProfileInt(_T("WinState"), _T("XPos"), 0);
	cs.y = pApp->GetProfileInt(_T("WinState"), _T("YPos"), 0);
	cs.cx = pApp->GetProfileInt(_T("WinState"), _T("Width"), 640);
	cs.cy = pApp->GetProfileInt(_T("WinState"), _T("Height"), 480);
	ValidateWinSize(cs.x, cs.y, cs.cx, cs.cy);
	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

#if ENABLE_ASCIIBAR
void CMainFrame::OnViewAsciibar() 		//ASCII��
{
	if (m_wndAsciiBar.IsVisible())
		ShowControlBar(&m_wndAsciiBar, FALSE, FALSE);
	else
		ShowControlBar(&m_wndAsciiBar, TRUE, FALSE);
}

void CMainFrame::OnUpdateViewAsciibar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndAsciiBar.IsVisible());
}
#endif//ENABLE_ASCIIBAR

#if ENABLE_HIDEMENU
void CMainFrame::OnViewMenu()
{
	//TRACE("in CMainFrame::OnViewMenu g_bMenuVisible = %d\n", g_bMenuVisible);
	ToggleMenu(g_bMenuVisible = !g_bMenuVisible);
	
	//	CMenu *pSys = GetSystemMenu(FALSE);
	//	pSys->CheckMenuItem(ID_VIEW_MENU, (g_bMenuVisible ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND);
}

void CMainFrame::ToggleMenu(bool bVisible)
{
	if (!bVisible) {
		// ����
		if (m_Child.nChild == 1) {
			if (g_hMainMenu2 == NULL) {
				g_hMainMenu2 = ::GetMenu(GetSafeHwnd());
			}
		}
		else if (m_Child.nChild <= 0) {
			if (g_hMainMenu1 == NULL) {
				g_hMainMenu1 = ::GetMenu(GetSafeHwnd());
			}
		}
		
		// ������ҡ�����
		// ��δ���Ҳ��������
		//		CMenu *pFrameMenu = GetMenu();
		//        if (pFrameMenu != 0 && m_Child.nChild > 1)
		//        {
		//            BOOL bMaximized;
		//            CMDIChildWnd* pActive = MDIGetActive(&bMaximized);
		//            if ((pActive!= 0) && bMaximized)
		//            {
		//                if (pFrameMenu->GetSubMenu(0) == pActive->GetSystemMenu(FALSE))
		//                {
		//                    //VERIFY( pFrameMenu->RemoveMenu( 0, MF_BYPOSITION ) );
		//		//			VERIFY( pFrameMenu->RemoveMenu( SC_MINIMIZE, MF_BYCOMMAND ) );
		//		//			VERIFY( pFrameMenu->RemoveMenu( SC_RESTORE, MF_BYCOMMAND ) );
		//		//			VERIFY( pFrameMenu->RemoveMenu( SC_CLOSE, MF_BYCOMMAND ) );
		//					//VERIFY( pFrameMenu->ReomveMenu( 0, MF_BYPOSITION ) );
		////                    VERIFY( pFrameMenu->DeleteMenu( SC_MINIMIZE, MF_BYCOMMAND ) );
		////                    VERIFY( pFrameMenu->DeleteMenu( SC_RESTORE, MF_BYCOMMAND ) );
		////                    VERIFY( pFrameMenu->DeleteMenu( SC_CLOSE, MF_BYCOMMAND ) );
		//                    VERIFY(pActive->ModifyStyle(0, WS_SYSMENU));
		////					VERIFY( pActive->DeleteMenu( SC_MINIMIZE, MF_BYCOMMAND ) );
		////					VERIFY( pActive->DeleteMenu( SC_RESTORE, MF_BYCOMMAND ) );
		////					VERIFY( pActive->DeleteMenu( SC_CLOSE, MF_BYCOMMAND ) );
		//                }
		//            }
		//        }
		
		SetMenu(NULL);   
		DrawMenuBar();
#if ENABLE_CAPTIONBUTTON
		if (m_Child.nChild > 0 && g_bCaptionButtons) {
			CreateCaptionButtons();
		}
#endif//ENABLE_CAPTIONBUTTON
	}
	else {
		//if (pMainMenu1 && ::IsMenu(pMainMenu1->m_hMenu))
		if (m_Child.nChild > 0 && g_hMainMenu2) {
			::SetMenu(GetSafeHwnd(), g_hMainMenu2);
		}
		else if (g_hMainMenu1) {
			::SetMenu(GetSafeHwnd(), g_hMainMenu1);
		}
		
		CMenu *pFrameMenu = GetMenu();
		if (pFrameMenu && m_Child.nChild > 0) {
			//			int cnt = pFrameMenu->GetMenuItemCount();
			//			TRACE("GetMenuItemCount %d\n", cnt);
			//			while ((cnt = pFrameMenu->GetMenuItemCount()) > 13) {
			//				VERIFY( pFrameMenu->RemoveMenu( 0, MF_BYPOSITION ) );
			//				VERIFY( pFrameMenu->RemoveMenu( SC_MINIMIZE, MF_BYCOMMAND ) );
			//				VERIFY( pFrameMenu->RemoveMenu( SC_RESTORE, MF_BYCOMMAND ) );
			//				VERIFY( pFrameMenu->RemoveMenu( SC_CLOSE, MF_BYCOMMAND ) );
			//			}
			
			// ɾ�������ͼ��
			CString str;
			pFrameMenu->GetMenuString(1, str, MF_BYPOSITION);
			while (str.IsEmpty()) {
				VERIFY(pFrameMenu->RemoveMenu(0, MF_BYPOSITION));
				pFrameMenu->GetMenuString(1, str, MF_BYPOSITION);
			}
			
			int cnt = pFrameMenu->GetMenuItemCount();
			UINT id = pFrameMenu->GetMenuItemID(cnt - 4);
			while (id == SC_CLOSE) {
				VERIFY(pFrameMenu->RemoveMenu(cnt - 4, MF_BYPOSITION));
				VERIFY(pFrameMenu->RemoveMenu(cnt - 5, MF_BYPOSITION));
				VERIFY(pFrameMenu->RemoveMenu(cnt - 6, MF_BYPOSITION));				
				cnt = pFrameMenu->GetMenuItemCount();
				id = pFrameMenu->GetMenuItemID(cnt - 4);
				pFrameMenu->EnableMenuItem(SC_CLOSE, MF_BYCOMMAND | MF_ENABLED); // ���ҡ�������������
			}
			//			pFrameMenu->GetMenuString(SC_MINIMIZE, str, MF_BYCOMMAND);
			//			pFrameMenu->GetMenuString(SC_RESTORE, str, MF_BYCOMMAND);
			//			pFrameMenu->GetMenuString(SC_CLOSE, str, MF_BYCOMMAND);
			//			pFrameMenu->GetMenuString(SC_MINIMIZE, str, MF_BYCOMMAND);
		}
		
		DrawMenuBar();
		
#if ENABLE_CAPTIONBUTTON
		DeleteCaptionButtons();
#endif//ENABLE_CAPTIONBUTTON
	}
	g_bMenuVisible = bVisible;
}

void CMainFrame::OnUpdateViewMenu(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(g_bMenuVisible);
}
#endif//ENABLE_HIDEMENU

void FinalizePython();

//----------------------------------------------------------------------------

bool g_ClosingAll = false;
int g_editcount = 0;
void CMainFrame::OnClose()
{
	//TRACEF(_T ("mainframe closeing 1\r\n"));
	
	int i;
	
	if (!g_bNoAskClose) {
		for (i = 0; i < m_Child.nChild; i++) {
			if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView
				&& m_Child.pFrames[i]->m_pView->IsStarted()
#if ENABLE_CTD
				&& m_Child.pFrames[i]->m_pView->ConnectType() == 0
#endif//ENABLE_CTD
				) {
				if (MessageBox(_T("���д���������.\n����˳���?"), _T("�رճ���"), MB_YESNO | MB_ICONQUESTION) == IDNO)
					return;
				
				break;
			}
		}
	}

	g_ClosingAll = true;

	// �ر������Ӵ���
	for (i = 0; i < m_Child.nChild; i++) {
		if (m_Child.pFrames[i]) m_Child.pFrames[i]->SendMessage(WM_CLOSE);
	}

	if (g_editcount > 0) AfxMessageBox(_T("�༭���������֣��ѱ��浽user\\mypost.txt��"));
	
	//TRACEF(_T ("mainframe closeing 2\r\n"));
	
#if ENABLE_HIDEMENU
	if (!g_bMenuVisible) {
		// �ָ��˵��������ڴ�й©
		ToggleMenu(true);
		g_bMenuVisible = false;
	}
#endif//ENABLE_HIDEMENU
	
#if ENABLE_FULLSCRN
	if (IsFullScreen())
		OnViewFullscreen(); //�Ȼָ�����ȫ��״̬
#endif//ENABLE_FULLSCRN
	
	//free((void*)AfxGetApp()->m_pszProfileName); //����Ҫ�ˣ�ÿ��ChangeIniFile�󶼸���ָ�
	//AfxGetApp()->m_pszProfileName=_tcsdup(m_szOldIni);
	SaveBarState(_T("Bars\\CTerm"));	// ���湤����λ��
	
	SaveWindowConfig();
	
	//UserSet.Save();
	Shell_NotifyIcon(NIM_DELETE, &m_nid);
	
	m_bTrayIconVisible = false;
	
	
	//TRACEF(_T ("mainframe closeing 3\r\n"));
	
#if ENABLE_SHOWIP
	if (g_pShowIPDlg) {
		g_pShowIPDlg->DestroyWindow();
		delete g_pShowIPDlg;
	}
	
#endif//ENABLE_SHOWIP
	
#if ENABLE_PICTURE
	if (g_pPicShowDlg) {
		g_pPicShowDlg->DestroyWindow();
		delete g_pPicShowDlg;
	}
	
	ClosePicThreads();	// �ر�����ͼƬ�����߳�
	
#endif //ENABLE_PICTURE
	
#if ENABLE_HOTKEY
	
	if (m_bOwnHotkey) {
		UnregisterHotKey(this->m_hWnd, 1); //ע���ȼ�
		UnregisterHotKey(this->m_hWnd, 2);
		m_bOwnHotkey = false;
		g_bHotKeyRegistered = false;
		
#if ENABLE_CONTROLSOCK
		//����Լ����������ʵ����������ע���ȼ�����Ϣ
		ControlSock.BroadCast(CS_REREG_BOSSKEY);
#endif//ENABLE_CONTROLSOCK
	}
	
#endif//ENABLE_HOTKEY
	
	//TRACEF(_T ("mainframe closeing 0\r\n"));
#if ENABLE_PYTHON
	PythonCallback(_T("OnCTermClose"), NULL, 0);
#endif
	
#if ENABLE_PYTHON
	FinalizePython();
#endif//ENABLE_PYTHON
	
	//TRACEF(_T ("mainframe closeing 4\r\n"));
	
#if ENABLE_ACCELEDIT
	CCTermApp *pApp = (CCTermApp*) AfxGetApp();
	HACCEL hOldTable = pApp->getAccelManager().m_pWndConnected->m_hAccelTable;
	
	::DestroyAcceleratorTable(hOldTable);
	
#endif	//ENABLE_ACCELEDIT
	
	//TRACEF(_T ("mainframe closeing 5\r\n"));
	
#if ENABLE_FUNKEY
	// Key Bar
	if (m_pKeyBar) {
		if (IsWindow(m_pKeyBar->GetSafeHwnd())) {
			m_pKeyBar->DestroyWindow();
			m_pKeyBar->Detach();
		}
		
		delete m_pKeyBar;
		m_pKeyBar = NULL;
	}
	
#endif//ENABLE_FUNKEY



	HANDLE hFind = NULL;
	WIN32_FIND_DATA fileinfo;
	DWORD64 dwSize = 0;
	BOOL bEmpty = FALSE;
	if (g_bEmptyPicCache) {		// �˳�ʱ���ͼƬ�����ļ��У�ɾ��ԭ��ͼƬ�ļ�������ͳ������ͼƬ�ļ��Ĵ�С
		hFind = FindFirstFile(g_PicPath + _T("\\*.*"),&fileinfo);
		do {		//�����ļ���
			if(fileinfo.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
				// �ļ���
			} else {
				dwSize += fileinfo.nFileSizeLow;	//ͳ���ļ���С
			}
		}while (FindNextFile(hFind,&fileinfo));
		
		if ( dwSize > g_nPicFolderSize *1024 *1024 ) {		//��������������ô�С��������ʱ����MBΪ��λ��
			CPicSizeDlg dlg;
			dlg.m_szPicPath=g_PicPath;
			dlg.DoModal();
			//if (dlg.DoModal() == IDOK) {
			//	bEmpty = TRUE;
			//}
		}
	}

/*	CFileFind fileFind;
	if 	( !g_bEmptyPicCache  || bEmpty ) {		// �˳�ʱ���ͼƬ�����ļ��У�����ɾ�����򳬹���С��ȷ��ɾ����
		fileFind.FindFile(g_PicPath + _T("\\*.*"));
		while (fileFind.FindNextFile()) {
			if (fileFind.IsDots() || fileFind.IsDirectory() ) {
				continue;
			} else {
				SetFileAttributes(fileFind.GetFilePath(), FILE_ATTRIBUTE_NORMAL);	//�Ƚ��ļ�������Ϊ����
				DeleteFile(fileFind.GetFilePath());
			}
		}
	}
*/

	// ���ܷ���ExitInstance��
	g_nInstanceNumber--;
	
	CMDIFrameWnd::OnClose();
}

// ȡ��i��frameָ��
// ����Ϊ-1��δ������ȡ�����
CChildFrame *CMainFrame::GetNthFrame(const int i) const
{
	if (m_Child.nChild <= 0) {
		return NULL;
	}
	else if (i == -1 && m_Child.pFrames[m_Child.nActive]) {
		return m_Child.pFrames[m_Child.nActive];
	}
	else if (i >= 0 && i < m_Child.nChild) {
		return m_Child.pFrames[i];
	}
	else {
		return NULL;
	}
}

// ȡ��i��viewָ��
// ����Ϊ-1��δ������ȡ�����
CCTermView *CMainFrame::GetNthView(const int i)
{
	CChildFrame *pFrame = GetNthFrame(i);
	
	if (pFrame) {
		return pFrame->m_pView;
	} else
		return NULL;
}

// ��nSessionIDȡviewָ��
// ��nSessionID==-1����ȡ�û����
CCTermView *CMainFrame::GetView(const int nSessionID)
{
	CChildFrame* pFrame = GetFrame(nSessionID);
	
	if (pFrame)
		return pFrame->m_pView;
	else
		return NULL; // δ�ҵ�
}

// ��nSessionIDȡframeָ��
// ��nSessionID==-1����ȡ�û����
CChildFrame* CMainFrame::GetFrame(const int nSessionID)
{
	if (nSessionID == -1 && m_Child.nChild > 0) {
		return m_Child.pFrames[m_Child.nActive];
	}

	if (nSessionID <= 0 || nSessionID >= m_Child.nMaxID)
		return NULL;
	
	for (int i = 0; i < m_Child.nChild; i++) {
		if (m_Child.nIDs[i] == nSessionID)
			return m_Child.pFrames[i];
	}
	
	return NULL; // δ�ҵ�
}

void CMainFrame::AddChild(CChildFrame *pChild)
{
	if (!pChild) return;
	
	m_Child.Add(pChild);
	
#if ENABLE_SWITCHBAR
	m_wndSwitchBar.tab()->ShowWindow(SW_NORMAL);
	
	CString title = pChild->GetTabTitle();
	
	m_wndSwitchBar.tab()->InsertItem(TCIF_RTLREADING | TCIF_TEXT, m_Child.nChild, title, 0, 0);
	m_wndSwitchBar.tab()->SetCurSel(m_Child.nChild);
	m_wndSwitchBar.tab()->SetMinTabWidth(g_nTabWidMin);
#endif//ENABLE_SWITCHBAR
	
#if ENABLE_CAPTIONBUTTON
	if (m_Child.nChild == 1 && !g_bMenuVisible && g_bCaptionButtons) {
		CreateCaptionButtons();
	}
#endif//ENABLE_CAPTIONBUTTON
}

//*****************************************************************************
int CChildList::nMaxID = 1; // ��1��ʼ����

void CChildList::Add(CChildFrame *pChild)
{
	int i;
	
	for (i = 0;i < nChild;i++) {
		if (pFrames[i] == pChild)
			return;
	}
	
	pFrames[nChild] = pChild;
	
	//����ID
	pChild->m_pView->SetSessionID(nMaxID);
	nIDs[nChild] = nMaxID++;
	
	nActive = nChild;
	nChild++;
}

// ��֧���ƶ���active
int CChildList::move(const int i, const bool forward)
{
	int ii = i;
	if (0 <= i && nChild > 1 && i < nChild && i == nActive) {
		int end = forward ? nChild - 1 : 0;
		int st = forward ? 0 : nChild - 1;
		int step = forward ? 1 : -1;
		if (i == end) {
			CChildFrame *tFrm = pFrames[i];
			int tID = nIDs[i];
			for (int j = end; (forward ? j > st : j < st); j -= step) {
				pFrames[j] = pFrames[j - step];
				nIDs[j] = nIDs[j - step];
			}
			pFrames[st] = tFrm;
			nIDs[st] = tID;
			
			ii = st;
		}
		else {
			CChildFrame *tFrm = pFrames[i + step];
			pFrames[i + step] = pFrames[i];
			pFrames[i] = tFrm;
			
			int tID = nIDs[i + step];
			nIDs[i + step] = nIDs[i];
			nIDs[i] = tID;
			
			ii += step;
		}
		
		nActive = ii;
	}
	return ii;
}

void CChildList::move(const int i, int offset)
{
	if (offset != 0 && nChild > 1 && 0 <= i && i < nChild) {
		int desti = i + offset;
		bool forward = (offset > 0);
		if (!forward) offset = -offset;
		offset %= nChild;
		
		if (forward) {
			if (desti > nChild) {
				offset = i - desti % nChild;
				forward = !forward;
			}
		}
		else {
			if (desti < 0) {
				offset = nChild - ( -desti % nChild ) - i;
				forward = !forward;
			}
		}
		
		int ii = i;
		for (int j = 0; j < offset; ++j) {
			ii = move(ii, forward);
		}
	}
}

int CChildList::Delete(CChildFrame *pChild)
{
	int i, j;
	
	for (i = 0;i < nChild;i++) {
		if (pFrames[i] == pChild) {
			if (i == nActive)
				nActive--; //��ʱ��Ϊǰһ��, childfrm::setfocus()ʱ�������
			
			for (j = i;j < nChild - 1;j++) {
				pFrames[j] = pFrames[j + 1];
				nIDs[j] = nIDs[j + 1];
				//pFrames[j]->m_pView->SessionID()--; //m_nSessionID��Ӧ��
				//ASSERT(0<=pFrames[j]->m_pView->SessionID() && pFrames[j]->m_pView->SessionID()<nChild);
			}
			
			nIDs[nChild - 1] = 0;
			pFrames[nChild - 1] = NULL;
			
			nChild--;
			
			break;
		}
	}
	
	if (nChild <= 0)
		nActive = -1;
	
	return i;
}

int CChildList::GetChildIndex(CChildFrame *pChild)
{
	if (!pChild) return -1;
	
	int i;
	
	for (i = 0;i < nChild;i++) {
		if (pFrames[i] == pChild)
			return i;
	}
	
	return -1;
}

int CChildList::GetChildIndex(CCTermView *pView)
{
	return GetChildIndex((CChildFrame *) pView->GetParentFrame());
}

//*****************************************************************************
void CMainFrame::DeleteChild(CChildFrame *pChild)
{
#if ENABLE_COPYTCP
	
	if (pChild->m_pView == g_pCopyView && g_bInCopyTcp) {
		OnCopytcp();
		//�������ֻ��Ҫִ�������䣺
		//_tcscpy (m_Sock.m_szCopyFile, _T (""));
		//m_Sock.m_bCopyTCP = false;
	}
	
#endif//ENABLE_COPYTCP
	
	int i = m_Child.Delete(pChild);
	
#if ENABLE_SWITCHBAR
	m_wndSwitchBar.tab()->DeleteItem(i);
	
	if (m_Child.nChild == 0) {
		m_wndSwitchBar.tab()->ShowWindow(SW_HIDE);		//��ʾ���ֹ��
	}
	
#endif//ENABLE_SWITCHBAR
	
#if ENABLE_CAPTIONBUTTON
	if (m_Child.nChild <= 0) {
		DeleteCaptionButtons();
	}
#endif//ENABLE_CAPTIONBUTTON
}

void CMainFrame::OnMove(int x, int y)
{
	CMDIFrameWnd::OnMove(x, y);
	//SetForegroundWindow(); // ԭ������䲻֪��ʲô�ã����������ʾ����ʱ������ȥ��
}

LRESULT CMainFrame::OnTrayMenu(WPARAM wParam, LPARAM lParam)
{
	int x, y;
	x = LOWORD(wParam);
	y = HIWORD(wParam);
	
	switch (lParam) {
		
	case WM_LBUTTONUP:
		PostMessage(WM_COMMAND, (WPARAM)ID_MAIN_RESTORE, (LPARAM)0); // ������SendMessage
//		PopupSelf(); // �����ڴ�ֱ��ִ��PopupSelf����
		break;
		
	case WM_RBUTTONDOWN:
#if ENABLE_LOCK
		
		if (!g_bInLocking)	//�������У��������˵�
#endif//ENABLE_LOCK
			PopUpTrayMenu(x, y);
		break;
	}
	
	return 0;
}


void CMainFrame::PopUpTrayMenu(int x, int y)
{
	CMenu menu, *pmenu = NULL;
	CPoint point;
	UpdateData();
	menu.LoadMenu(IDR_TRAYMENU);
#if ENABLE_MULTILANG
	
	if (g_currLangID != ID_LANG1) {
		g_OutMenuStrings(&menu, _T(""));  //����Ĭ��
		g_SetMenuStrings(&menu, _T(""));
	}
	
#endif// ENABLE_MULTILANG
	pmenu = (CMenu *) menu.GetSubMenu(0);
	
	::GetCursorPos(&point);
	
	//����207.46.89.15������Andy���Ե���    ���ظ�:05-11-10 11:39 [�ظ�����]
	// CTerm��ϵͳ�����и�bug�������һ���ʾ�˵��Ժ󣬵�������ط��˵�������ʧ�������windows TrayIcon��bug������ʾ�˵�֮ǰ��ҪSetForegroundWindow.��ο�MSDN���¡�
	SetForegroundWindow();
	
	pmenu->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	
	pmenu->DestroyMenu();
}

extern "C" WINBASEAPI HWND WINAPI GetConsoleWindow();

void CMainFrame::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	if (nState == WA_ACTIVE || nState == WA_CLICKACTIVE) {
		ActivateView();
		
		CMDIFrameWnd::OnActivate(nState, pWndOther, bMinimized);
		
		KillTimer(TIMER_FLASHWINDOW);
		
		CString sTitle;
		GetWindowText(sTitle);
		_tcscpy(m_nid.szTip, sTitle);
		m_nid.hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
		Shell_NotifyIcon(NIM_MODIFY, &m_nid);
		
		if (g_bOpenConsole && m_bCreated) {
			HWND hc = GetConsoleWindow();
			CRect r;
			::GetWindowRect(hc, &r);
			//ScreenToClient(&r);
			::SetWindowPos(hc, GetSafeHwnd(), r.left, r.top, r.Width(), r.Height()
				, SWP_SHOWWINDOW | SWP_NOACTIVATE);
			//::SetForegroundWindow(hc); //����������ȥ������
			//::SendMessage(hc, WM_KILLFOCUS, 0, 0);
			//SetFocus();
			//SetForegroundWindow();
		}
	}
}

void CMainFrame::ActivateView()
{
	//	TRACEF("CMainFrame::ActivateView\n");
	CMDIFrameWnd::OnActivate(WA_ACTIVE, NULL, FALSE);  // ���ȥ��������
	
	if (m_Child.nChild) {
		CChildFrame * pFrame = (CChildFrame *) MDIGetActive();
		
		if (pFrame)
			pFrame->SendMessage(WM_CHILDACTIVATE, 0, 0);
	}
	else {
#if ENABLE_BITMAPWND
		if (::IsWindow(m_wndClient.m_hWnd)) {
			m_wndClient.SetFocus();
		}
#endif//ENABLE_BITMAPWND
	}
}

LRESULT CMainFrame::OnStreamIn(WPARAM wParam, LPARAM lParam)
{
#if ENABLE_CHATDLG
	BYTE *pBuf = NULL;
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	//	m_wndFlash.m_nStatus+=wParam;
	
	if (wParam && pFrame && pFrame->m_pView->GetStatus() == SST_CHATROOM) {
		pBuf = (BYTE *) lParam;
		g_wndChat.AddToList(pBuf, wParam);
	}
	
#endif//ENABLE_CHATDLG
	return 1;
}

// wParam: site to dup
// lParam: filternum, if not 0
LRESULT CMainFrame::OnDupSite(WPARAM wParam, LPARAM lParam)
{
	CTelnetSite* pNewSite = new CTelnetSite; // delete in OnCreateNewChild
	*pNewSite = * ((CTelnetSite*) wParam);
	
#if ENABLE_FILTER
	pNewSite->m_Login.m_AutoLogin.Restore();
#endif//ENABLE_FILTER
	
	OnCreateNewChild((WPARAM)(pNewSite), 0);
	
	return 1;
}


//============================================================================

void CMainFrame::OnUpdateSelectRect(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame) {
		pCmdUI->Enable(0);
	}
	else {
		pCmdUI->Enable(1);
		
		if (g_bSelectRect)
			pCmdUI->SetCheck(1);
		else
			pCmdUI->SetCheck(0);
	}
}

void CMainFrame::OnUpdateEditCopy(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CMainFrame::OnUpdateEditPaste(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}


void CMainFrame::OnUpdateEditCopyANSI(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CMainFrame::OnUpdateEditPasteANSI(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

//=============================================================================
// ����ѡ��
void CMainFrame::OnSelectRect()
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame) {
		g_bSelectRect = !g_bSelectRect;
		
		for (int i = 0;i < m_Child.nChild;i++) {
			pFrame = m_Child.pFrames[i];
			pFrame->m_pView->SelectToRect();
		}
	}
}

void CMainFrame::DoCopy(bool bANSI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;
	
	int maxlen = pFrame->m_pView->getSelMaxlen(bANSI);
	if (maxlen > 0) {
		HGLOBAL hmem;
		TCHAR * p = startcopy(maxlen, hmem);
		if (p) {
			pFrame->m_pView->copyAction(p, bANSI);
		}
		endcopy(hmem);
	}
}

void CMainFrame::OnEditCopy()			// ��ͨ����
{
	DoCopy(g_bAnsiCP);
}

void CMainFrame::OnEditCopyANSI()		// ��ɫ����
{
	DoCopy(true);
}

void CMainFrame::DoPaste(bool bANSI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;
	
	HGLOBAL hmem;
	
	TCHAR *str = NULL;
	
	if (!OpenClipboard()) {
		AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
		return;
	}
	
	UINT cf = g_bPasteUni ? CF_UNICODETEXT : CF_TEXT;
	
	hmem = GetClipboardData(cf); //CF_TEXT
	
	if (hmem) {
		str = (TCHAR *) GlobalLock(hmem);
		
		if (bANSI)
			pFrame->m_pView->PasteANSI(str);
		else
			pFrame->m_pView->Paste(str);
	}
	
	GlobalUnlock(hmem);
	
	CloseClipboard();
}

void CMainFrame::OnEditPaste()			// ��ͨճ��
{
	DoPaste(g_bAnsiCP);
}

void CMainFrame::OnEditPasteANSI()		// ��ɫճ��
{
	DoPaste(true);
}

// ���ż���������Ϣ
LRESULT CMainFrame::OnHaveMail(WPARAM wParam, LPARAM lParam)
{
	if (g_szMailWavFile != "0" && lParam == 1) {
		CString MailWavFile = g_szMailWavFile;
		if (MailWavFile.GetLength() < 2 || (MailWavFile[1] != ':' && MailWavFile[0] !='\\')) {
			// not absolute path
			PrependWorkDir(MailWavFile);
		}

		sndPlaySound(MailWavFile, SND_ASYNC);
	}
	
	return 1;
}

#if ENABLE_MESSAGE
LRESULT CMainFrame::OnPopMsg(WPARAM wParam, LPARAM pParam)
{
	ASSERT(wParam);
	
	if (!g_bAutoReply) {
		// ����״̬���ֹ��ظ�
		if (g_bPlayWav) {
			sndPlaySound(g_szWavFile, SND_ASYNC);
		}
		
		if (g_bPopupOnMsg) {
			((CMDIChildWnd*)(((CCTermView *) wParam)->GetParentFrame()))->MDIActivate(); //�л�Ϊ�����
			PopupSelf(true);
		}
		else if (GetForegroundWindow() != this) {
			UINT id = SetTimer(TIMER_FLASHWINDOW, 500, NULL); //��˸
			TRACE(_T("begin flash window id:%d\n"), id);
		}
		
	}
	
	return 1;
}

#endif//ENABLE_MESSAGE

typedef void (WINAPI *PROCSWITCHTOTHISWINDOW)(HWND, BOOL);

//void CMainFrame::Popup(bool bClick)
//{
//	HMODULE hUser32 = GetModuleHandle("user32");
//	PROCSWITCHTOTHISWINDOW SwitchToThisWindow =
//		(PROCSWITCHTOTHISWINDOW)GetProcAddress(hUser32, "SwitchToThisWindow");
//	SwitchToThisWindow(GetSafeHwnd(), FALSE);
//}

void CMainFrame::PopupSelf(bool bClick)
{
	//TRACEF("PopupSelf\n");
	//SetForegroundWindow();
	if (!IsWindowVisible()) {
		//TRACE(_T("void CMainFrame::PopupSelf, bZoomed:%d\n"), bZoomed);
		Shell_NotifyIcon(NIM_DELETE, &m_nid);
		m_bTrayIconVisible = false;
	}
	
	if (m_bZoomed)
		ShowWindow(SW_SHOWMAXIMIZED);
	else
		ShowWindow(SW_SHOWNORMAL);
	
	HMODULE hUser32 = GetModuleHandle("user32");
	PROCSWITCHTOTHISWINDOW SwitchToThisWindow =
		(PROCSWITCHTOTHISWINDOW)GetProcAddress(hUser32, "SwitchToThisWindow");
	if (SwitchToThisWindow) {
		SwitchToThisWindow(GetSafeHwnd(), TRUE);
	}
	else {
		SetActiveWindow();
		SetFocus();
		SetForegroundWindow();
		BringWindowToTop();
	}
	
	// û�к����⼸���� controlsock popupselfʱ������
	// ��Ҫ�⼸���������Ϣ����ʱ�л�
	SetWindowPos(&wndTopMost, 0, 0, 100, 100, SWP_NOMOVE | SWP_NOSIZE);
	SetWindowPos(&wndNoTopMost, 0, 0, 100, 100, SWP_NOMOVE | SWP_NOSIZE);  // ��䲻���٣����������ǰ
	if (m_bTopMost)
		SetWindowPos(&wndTopMost, 0, 0, 100, 100, SWP_NOMOVE | SWP_NOSIZE);
	
	// û���⼸�䣬��Ϣ����ʱ�л�������Ϣ���޽���
	// �����⼸���ڴ�tray����ʱ�ֲ��������������޽���
	// ���ԼӸ�����
	if (bClick) { //
		CRect rectWindow;
		GetWindowRect(&rectWindow);
		
		CPoint pt;
		GetCursorPos(&pt);
		// todo: Windows NT/2000/XP: This function has been superseded. Use SendInput instead.
		SetCursorPos(rectWindow.left + 40, rectWindow.top + 10);
		mouse_event(MOUSEEVENTF_LEFTDOWN, rectWindow.left + 40, rectWindow.top + 10, 0, 0);
		mouse_event(MOUSEEVENTF_LEFTUP, rectWindow.left + 40, rectWindow.top + 10, 0, 0);
		SetCursorPos(pt.x, pt.y);  // �������᲻����
	}
	
	if (g_bInLocking) {
#if ENABLE_LOCK
		UnlockSys();
#endif//ENABLE_LOCK
	}
}

//����\�ָ����еĹ�����
//�ر��ǵ����Ǹ���ʱ
//bOnlyFloating: ֻ����floating��
void CMainFrame::HideBars(bool bRestore, bool bOnlyFloating)
{
	TRACE(_T("in CMainFrame::HideBars \n"));
	
	if (bRestore) {
		ShowControlBar(&m_wndToolBar, m_bToolBar, TRUE);
#if ENABLE_SWITCHBAR
		ShowControlBar(&m_wndSwitchBar, m_bDlgBar, TRUE);
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
		ShowControlBar(m_pKeyBar, m_bKeyBar, TRUE);
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
		ShowControlBar(&m_wndBbsBar, m_bBBSBar, TRUE);
#endif//ENABLE_BBSBAR
		ShowControlBar(&m_wndStatusBar, m_bStatusBar, TRUE);
#if ENABLE_ASCIIBAR
		ShowControlBar(&m_wndAsciiBar, m_bAsciiBar, TRUE);
#endif//ENABLE_ASCIIBAR
		
#if ENABLE_FULLSCRN
		if (m_pwndFullScrnBar)
			ShowControlBar(m_pwndFullScrnBar, m_bFullScreenBar, TRUE);
#endif//ENABLE_FULLSCRN
		
		ShowControlBar(&m_wndScrollBar, m_bScrollBar, TRUE);
	} else {
		BOOL bHide = TRUE;
		
		m_bToolBar = m_wndToolBar.IsVisible();
		
		if (bOnlyFloating) {
			bHide = m_bToolBar && m_wndToolBar.IsFloating();
		}
		
		if (bHide) ShowControlBar(&m_wndToolBar, FALSE, TRUE);
		
#if ENABLE_SWITCHBAR
		m_bDlgBar = m_wndSwitchBar.IsVisible();
		if (bOnlyFloating) {
			bHide = m_bDlgBar && m_wndSwitchBar.IsFloating();
		}
		if (bHide) ShowControlBar(&m_wndSwitchBar, FALSE, TRUE);
#endif//ENABLE_SWITCHBAR
		
#if ENABLE_FUNKEY
		m_bKeyBar = m_pKeyBar->IsVisible();
		if (bOnlyFloating) {
			bHide = m_bKeyBar && m_pKeyBar->IsFloating();
		}
		if (bHide) ShowControlBar(m_pKeyBar, FALSE, TRUE);
#endif//ENABLE_FUNKEY
		
#if ENABLE_BBSBAR
		m_bBBSBar = m_wndBbsBar.IsVisible();
		if (bOnlyFloating) {
			bHide = m_bBBSBar && m_wndBbsBar.IsFloating();
		}
		if (bHide) ShowControlBar(&m_wndBbsBar, FALSE, TRUE);
#endif//ENABLE_BBSBAR
		
		m_bStatusBar = m_wndStatusBar.IsVisible();
		
		if (bOnlyFloating) {
			bHide = m_bStatusBar && m_wndStatusBar.IsFloating();
		}
		
		if (bHide) ShowControlBar(&m_wndStatusBar, FALSE, TRUE);
		
#if ENABLE_ASCIIBAR
		m_bAsciiBar = m_wndAsciiBar.IsVisible();
		if (bOnlyFloating) {
			bHide = m_bAsciiBar && m_wndAsciiBar.IsFloating();
		}
		if (bHide) ShowControlBar(&m_wndAsciiBar, FALSE, TRUE);
#endif//ENABLE_ASCIIBAR
		
#if ENABLE_FULLSCRN
		if (m_pwndFullScrnBar) {
			m_bFullScreenBar = m_pwndFullScrnBar->IsVisible();
			ShowControlBar(m_pwndFullScrnBar, FALSE, TRUE);
		}
#endif//ENABLE_FULLSCRN

		m_bScrollBar = m_wndScrollBar.IsVisible();
		ShowControlBar(&m_wndScrollBar, FALSE, TRUE);
	}
	
	TRACE(_T("out CMainFrame::HideBars \n"));
}

#if ENABLE_HOTKEY
void CMainFrame::OnBossKey()
{
	if (!g_bBossKeyActive)		//�ϰ��δ�����ֱ�ӷ���
		return;		

	if (m_bBossHided) {		//������
		PopupSelf();
		HideBars(true);
		SetAutoReply();
		m_bBossHided = false;
		g_bAutoReply = FALSE;
	} else {	//δ����
		if (g_nBossKeyStyle == 1 && ::GetForegroundWindow() != GetSafeHwnd()) {
			PopupSelf();
		} else {
			HideBars(false, true); // �����з�ͣ����������������
			
			if (true) { //g_bBossMinimize
				//SendMessage(WM_SIZE,SIZE_MINIMIZED,0);
				ShowWindow(SW_HIDE);
				Shell_NotifyIcon(NIM_DELETE, &m_nid);
				m_bTrayIconVisible = false;
			}
			else {
				//	ShowWindow(SW_HIDE);
				//	Shell_NotifyIcon(NIM_ADD, &m_nid);  //��֪Ϊʲô������ʾ
				//	m_bTrayIconVisible = true;
			}
			
			//SetAutoReply(_T("�ꡫ���ϰ����ˣ�"));
			g_bAutoReply = TRUE;
			
			m_bBossHided = true;
			
			if (g_bBossExecute)
				ShellExecute(NULL, _T("open"), g_szBossPrograme, NULL, NULL, SW_SHOWDEFAULT);
		}
	}
}

// ���ϰ������״̬�ָ����ȼ�������ΪCtrl+Alt+B
LRESULT CMainFrame::OnHotKey(WPARAM wParam, LPARAM lParam)
{
	// ����ж���ȼ�ʵ�ֲ�ͬ���ܵĵĻ������ж��ȼ�
#if ENABLE_CONTROLSOCK
	if (wParam == 0 && lParam == 0) {
		// `�����Ҽ�ͬʱ��
		ControlSock.BroadCast(CS_BOSSKEY, true);
	}
	else {
		CHotKey k(LOWORD(lParam), HIWORD(lParam));
		
		if (k.IsEqual(g_Hotkey)) {
			// ������ʵ�������ȼ���Ϣ
			ControlSock.BroadCast(CS_HOTKEY, true);
		} else if (k.IsEqual(g_BossHotkey)) {
			ControlSock.BroadCast(CS_BOSSKEY, true);
		}
	}
#endif//ENABLE_CONTROLSOCK
	return 1L;
}

//ע���ϰ���ָ��ȼ�,Ĭ��ΪCtrl+Alt+B (BossKey)
void CMainFrame::RegisterBossHotKey()
{
	// �ϰ��
	// FromStringҪ�ӡ�������ʵ���޸���g_BossHotKeyStr����ʵ������ִ��LoadWindowConfig��Ҫ�����ﷴӳ������
	g_BossHotkey.FromString(CString(g_BossHotKeyStr));
	if (g_BossHotkey.m_cVirt == 0 && g_BossHotkey.m_wKey == 0) {
		UnregisterHotKey(this->m_hWnd, 1);
	} else {
		
		if (!(g_BossHotkey.m_cVirt &MOD_ALT)
			&& !(g_BossHotkey.m_cVirt &MOD_CONTROL)
			&& !(g_BossHotkey.m_cVirt &MOD_SHIFT)
			&& _istalpha(g_BossHotkey.m_wKey)) {
			// û�����μ�������Ctrl+Alt
			g_BossHotkey.m_cVirt |= MOD_CONTROL | MOD_ALT;
		}
		
		if (!RegisterHotKey(this->m_hWnd, 1, g_BossHotkey.m_cVirt, (unsigned) g_BossHotkey.m_wKey)) {
			SetStatus(ID_INDICATOR_PIC, _T("�ȼ�ע��ʧ�ܣ�"));
		}
	}
	
	// �ȼ�(����)
	g_Hotkey.FromString(CString(g_HotKeyStr));
	if (g_Hotkey.m_cVirt == 0 && g_Hotkey.m_wKey == 0) {
		UnregisterHotKey(this->m_hWnd, 2);
	} else {
		if (!(g_Hotkey.m_cVirt &MOD_ALT)
			&& !(g_Hotkey.m_cVirt &MOD_CONTROL)
			&& !(g_Hotkey.m_cVirt &MOD_SHIFT)
			&& _istalpha(g_Hotkey.m_wKey)) {
			// û�����μ�������Ctrl+Shift
			g_BossHotkey.m_cVirt |= MOD_CONTROL | MOD_SHIFT;
		}
		
		if (!RegisterHotKey(this->m_hWnd, 2, g_Hotkey.m_cVirt, (unsigned) g_Hotkey.m_wKey)) {
			SetStatus(ID_INDICATOR_PIC, _T("�ȼ�ע��ʧ�ܣ�"));
		}
	}
}

//����ע���ȼ�
void CMainFrame::ReRegisterBossHotKey(bool bChange)
{
	if (bChange && m_bOwnHotkey) {
		UnregisterHotKey(this->m_hWnd, 1);
		UnregisterHotKey(this->m_hWnd, 2);
		RegisterBossHotKey();
	} else if (!g_bHotKeyRegistered && g_nInstanceNumber > 0) {
		//����һ����ֻ��һ��ʵ��ע�����ȼ�
		g_bHotKeyRegistered = true;
		m_bOwnHotkey = true; //ֻ��һ��ʵ���ĸñ���Ϊtrue;
		RegisterBossHotKey();
	}
}

#endif//ENABLE_HOTKEY


#if ENABLE_COPYTCP
void CMainFrame::OnCopytcp()
{
	CChildFrame *pFrame = NULL;
	CFileDialogEx fd(FALSE, _T("ctd"), _T("*.ctd"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("CTerm �ն��ļ�(*.ctd)|*.ctd||"));
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView && pFrame->m_pView->ConnectType() == 0) {
		if (!g_bInCopyTcp) {
			if (fd.DoModal() == IDOK) {
				g_bInCopyTcp = TRUE;
				pFrame->m_pView->CopyTcpPack(TRUE, fd.GetPathName());
				g_pCopyView = pFrame->m_pView;
			}
		} else {
			g_bInCopyTcp = FALSE;
			pFrame->m_pView->CopyTcpPack(FALSE, _T(""));
			g_pCopyView = NULL;
		}
	}
}

void CMainFrame::OnUpdateCopytcp(CCmdUI* pCmdUI)
{
	if (MDIGetActive()) {
		pCmdUI->Enable(1);
		
		if (g_bInCopyTcp)
			pCmdUI->SetCheck(1);
		else
			pCmdUI->SetCheck(0);
	} else
		pCmdUI->Enable(0);
	
}

#endif//ENABLE_COPYTCP


#if ENABLE_DOWNLOAD
void CMainFrame::OnUpdateBbsFulltext(CCmdUI* pCmdUI) 	// ��ƪ�������� -- �Ƿ����
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if ((nSta == SST_LIST &&
			(nSub == SST_LIST_ARTICLE ||
			(nSub == SST_LIST_DIGEST && pFrame->m_pView->m_Status.IsDigestFile()))) //�ų��˾�����Ŀ¼�����
			|| nSta == SST_ARTICLE || nSta == SST_END) { // �����б�������״̬
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
	
}

void CMainFrame::OnUpdateDlmany(CCmdUI* pCmdUI)		// �������� - �������������� -- �Ƿ����
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	SITESTATUS nStatus, nSubStatus;
	
	if (pFrame && pFrame->m_pView) {
		nStatus = pFrame->m_pView->GetStatus();
		nSubStatus = pFrame->m_pView->m_Status.SubStatus();
		
		if	(nStatus == SST_LIST &&			// ������ �;�����
			(nSubStatus == SST_LIST_ARTICLE || nSubStatus == SST_LIST_DIGEST)) {
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnBbsFulltext() 	// ��ƪ��������
{
	CDLArticleDlg Dlg;
	CChildFrame *pFrame = NULL;
	SITESTATUS nStatus, nSubStatus;
	pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		nStatus = pFrame->m_pView->GetStatus();
		nSubStatus = pFrame->m_pView->m_Status.SubStatus();
		Dlg.m_pView = pFrame->m_pView;
		SetAutoReply(_T("�����������£����Ժ������� :-)"));
		//	if ((nStatus==SST_LIST && (nSubStatus==SST_LIST_ARTICLE || nSubStatus==SST_LIST_DIGEST)) || nStatus==SST_ARTICLE || nStatus==SST_END)		//�����б����Ķ������У�������ĩβ�������ص�ƪ
		g_bHaveModalDlg = true;
		Dlg.DoModal();
		g_bHaveModalDlg = false;
		SetAutoReply();
	}
}

void CMainFrame::OnDlmany()							// �������� - ��������������
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame || !pFrame->m_pView) return;
	
	if (pFrame->m_pView->Sleeping()) return;
	
	SITESTATUS nStatus, nSub;
	
	nStatus = pFrame->m_pView->GetStatus();
	
	nSub = pFrame->m_pView->m_Status.SubStatus();
	
	SetAutoReply(_T("�����������£����Ժ������� :-)"));
	
	switch (nStatus) {
		
	case SST_ARTICLE:		//�Ķ������У�������ĩβ�������ص�ƪ
		
	case SST_END: {
		CDLArticleDlg Dlg;
		Dlg.m_pView = pFrame->m_pView;
		Dlg.DoModal();
				  }
		
		break;
		
#if ENABLE_HTMLDOWN
	case SST_LIST:
		
		switch (nSub) {
			
		case SST_LIST_ARTICLE: {	// �����б���,��������
			CDLListDlg    Dlg2;
			Dlg2.m_Run.Create(pFrame->m_pView);
			g_bHaveModalDlg = true;
			Dlg2.DoModal();
			g_bHaveModalDlg = false;
							   }
			
			break;
			
		case SST_LIST_DIGEST: {	// ��������,���ؾ���
			CDLDigestDlg  Dlg3;
			Dlg3.m_Run.Create(pFrame->m_pView);
			g_bHaveModalDlg = true;
			Dlg3.DoModal();
			g_bHaveModalDlg = false;
							  }
			
			break;
		}
#endif//ENABLE_HTMLDOWN
		
		break;
	}
	
	SetAutoReply();
}

#endif//ENABLE_DOWNLOAD

//�ú������ڸı�ظ���ʱ����
//����ֱ����g_bAutoReply����
//������֮��Ҫ�ղ�������һ���Ա�ָ�
void CMainFrame::SetAutoReply(TCHAR *s)
{
	//    static CString old;
	g_bAutoReply = (s != NULL);
	
	if (s != NULL) {
		//		old=g_szReply;
		g_szReply = s;
	} else //restore
		g_szReply = g_szInitReply;
}

void CMainFrame::OnUpdateRightcode(CCmdUI* pCmdUI)	//������� �Ƿ����
{
	pCmdUI->Enable(g_bCodeInited);
}

void CMainFrame::OnRightcode()		//�������
{
	CChildFrame *pFrame = NULL;                                                                                                                                                                                                                                          
	CCTermCore  *pCore = NULL;
	TCHAR        ts[MAX_LINE_CHAR+1];
	int         i;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		pCore = &pFrame->m_pView->m_Core;
		// i: ��ǰ������
		
		for (i = 0;i < (pFrame->m_pView->TermH() - 1);i++) {
			int len = pCore->GetLongLine(ts, i, false, 1);
			CleverCodeConvert(ts, len);
			pCore->PutLine(ts, i + pCore->MaxStartLine());
		}
		
		pFrame->m_pView->Refresh();// todo: ������ҲӦ��getstatus����Ļ���ݸı��ˣ�Ȼ��...
	}
}

#if ENABLE_BATCHDLG
void CMainFrame::OnUpdateBat(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame || (g_pBat && g_pBat->IsWindowVisible())
#if ENABLE_CTD
		|| pFrame->m_pView->ConnectType() != 0
#endif//ENABLE_CTD
		)
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CMainFrame::OnBat()
{
	//    if(g_pBat)
	//		delete g_pBat;
	//	g_pBat=NULL;
	//	g_pBat=new CBatDlg;
	//	Ϊ�����鷳����ģ̬�İ�
	//	if(g_pBat)
	//		g_pBat->Create(IDD_BAT_DLG,GetDesktopWindow());
	//	else
	//		return;
	
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame->m_pView->IsStarted())
		return;
	
	SetAutoReply(_T("����ִ�������������Ժ������� :-)"));
	
	CBatDlg dlg;
	
	dlg.m_Run.Create(pFrame->m_pView);
	
	dlg.DoModal();
	
	SetAutoReply();
}

#endif//ENABLE_BATCHDLG

#if ENABLE_SITECONFIG
void CMainFrame::OnUpdateConfigSite(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	pCmdUI->Enable(
		pFrame == NULL
		|| (pFrame != NULL && pFrame->m_pView->ConnectType() == 0)
		);
}

void CMainFrame::OnConfigSiteDecode()
{
	ConfigSite(1);
}

void CMainFrame::OnConfigSiteAutologin()
{
	ConfigSite(2);
}

void CMainFrame::OnConfigSiteFont()
{
	ConfigSite(4);
}

void CMainFrame::OnConfigSiteColor()
{
	ConfigSite(5);
}

// nActiveָ���ҳ
void CMainFrame::ConfigSite(int nActive)
{
	CAddrBookDlg AddrBook;
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		CString sProfile = pFrame->m_pView->m_Site.m_Login.m_szProfileName;
		int type = pFrame->m_pView->ConnectionType();
		if (type == 0) {
			// �ӵ�ַ������
			CTelnetSite *pSite = AddrBook.FindSite(g_szUser, g_sAddressBook, sProfile);
			
			if (pSite == NULL) {
				MessageBox(_T("վ��δ�ҵ�!"), _T("����վ��"), MB_OK | MB_ICONERROR);
				return;
			}
			
			// �ڵ�ַ�����ҵ�,����Խ�������
			CString oldAddr = pSite->m_Login.m_szAddr;
			
			if (SetOneSite(pSite, nActive)) {
				//�����ֵ���һ���Ի��򣬶��ҽ�Ҫ����view
				//��view����ʱ���ܹرյ�, �Ի���֪��ʱ�ر�
				//������Ҫ���ж�һ��
				pFrame = (CChildFrame *) MDIGetActive();
				
				if (pFrame && pFrame->m_pView && sProfile == pFrame->m_pView->m_Site.m_Login.m_szProfileName) {
					// ��һ�����Ƿ�ֹ���ߺ󣬵�ǰ���ڸı�
					BYTE oldstate = pFrame->m_pView->m_Site.m_Login.m_AutoLogin.m_bEnable;
					BYTE oldstate1 = pFrame->m_pView->m_Site.m_Login.m_AutoLogin.m_bUserNameEntered;
					pFrame->m_pView->m_Site = *pSite;
					pFrame->m_pView->m_Site.m_Login.m_AutoLogin.pLoginSet = & (pFrame->m_pView->m_Site.m_Login);
					
					pFrame->m_pView->LoadSiteInfo(false);
					
					// �ָ�������������ʱ״̬
					pFrame->m_pView->m_Site.m_Login.m_AutoLogin.m_bEnable = oldstate;
					pFrame->m_pView->m_Site.m_Login.m_AutoLogin.m_bUserNameEntered = oldstate1;
					
					AddrBook.SaveSite(pSite);
					
					pFrame->m_pView->Refresh();
					
					if (oldAddr != pSite->m_Login.m_szAddr) // ����ַ���޸�, ��Ҫ���½���DNS
						pFrame->m_pView->SetDNSResolved(false);
					
					//pFrame->m_pView->Refresh();
					RefreshAll();
					
					if (sProfile == g_LastSite.m_Login.m_szProfileName) {
						g_LastSite = *pSite;
					}
				}
			}
		}
		else if (type == 1) {
			//��������
			if (SetOneSite(&pFrame->m_pView->m_Site, nActive)) {
				pFrame->m_pView->LoadSiteInfo(false);
				pFrame = (CChildFrame *) MDIGetActive();
				
				if (pFrame && pFrame->m_pView) {
					//�Ƿ���Ҫִ������ǰ��Ĳ����أ�
					//pFrame->m_pView->Refresh();
					RefreshAll();
					
					if (sProfile == g_LastSite.m_Login.m_szProfileName) {
						g_LastSite = pFrame->m_pView->m_Site;
					}
					
				}
			}
		}//else if (type == 1)
	}//pFrame && pFrame->m_pView
	else {
		// no window
		int type = g_nConnectionType;
		if (type == 0) {
			// �ӵ�ַ������
			if (SetOneSite(&g_LastSite, nActive)) {
				AddrBook.SaveSite(&g_LastSite);
			}
			//CString sProfile = g_LastSite.m_Login.m_szProfileName;			
			//CTelnetSite *pSite = AddrBook.FindSite(CString(g_szUser), g_sAddressBook, sProfile);
			//if (pSite == NULL) {
			//	MessageBox(_T("վ��δ�ҵ�!"), _T("����վ��"), MB_OK | MB_ICONERROR);
			//	return;
			//}
			
			//if (SetOneSite(pSite, nActive)) {
			//	AddrBook.SaveSite(pSite);
			//	g_LastSite = *pSite;
			//}
		}
		else if (type == 1) {
			SetOneSite(&g_LastSite, nActive);
		}
		
	}
}

void CMainFrame::OnConfigSite()
{
	ConfigSite();
}

#endif//ENABLE_SITECONFIG

#if ENABLE_EDITBOX
void CMainFrame::OnUpdateEditDlg(CCmdUI* pCmdUI)
{
#ifndef _DEBUG
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView
#if ENABLE_CTD
		&& pFrame->m_pView->ConnectType() == 0
#endif//ENABLE_CTD
		) {
		SITESTATUS nStatus = pFrame->m_pView->GetStatus();
		//		pCmdUI->Enable (nStatus == SST_WRITE);
		pCmdUI->SetCheck(pFrame->m_pView->IsEditView());
	}
	else {
		pCmdUI->Enable(FALSE);
	}
	
#else //HAVE _DEBUG
	pCmdUI->Enable();
#endif //_DEBUG
}

void CMainFrame::OnEditDlg()
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	if (!pFrame || !pFrame->m_pView) return;
	
	if (pFrame->m_pView->IsEditView())
		pFrame->m_pView->ShowEditView(FALSE);
	else
		pFrame->m_pView->ShowEditView(TRUE);
}

#endif//ENABLE_EDITBOX


////////////////////////////////////////////////////////////

#if ENABLE_MESSAGE
void ShowMsgHistory()
{
	CString ts;
	ts = g_szUserPath + _T("*.msg");
	CFileDialogEx fd(TRUE, _T("msg"), ts, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("��Ϣ��¼�ļ�(*.msg)|*.msg||"));
	
	if (fd.DoModal() == IDOK) {
		ts = fd.GetPathName();
		
		if (IsInDir(ts, g_szUserPath) != NULL) {
			// todo: �ϸ���˵��Ŀ¼Ҳ����
			AfxMessageBox(_T("���ܴ򿪱��˵ļ�¼!"));
			return;
		}
		else {
			CHistoryDlg Dlg;
			Dlg.m_szPathName = ts;
			Dlg.DoModal();
		}
	}
}

void CMainFrame::OnShowMsgs()		// �鿴��Ϣ��¼
{
	//CChildFrame *pFrame = (CChildFrame *)MDIGetActive();
	//if (!pFrame || !pFrame->m_pView) return;
	//pFrame->m_pView->SendMsg();
	ShowMsgHistory();
}
#endif//ENABLE_MESSAGE

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_SYSKEYDOWN) {
		// alt-f ��ʾ�˵�
		//TRACE("WM_SYSKEYDOWN, %d\n", isdown('I'));
#if ENABLE_HIDEMENU
		if (!g_bMenuVisible && g_bAltShowMenu
			&& (
			isdown('F')
			|| isdown('E')
			|| isdown('I')
			|| isdown('B')
			|| isdown('T')
			|| isdown('W')
			|| isdown('H')
			|| isdown('U')
			)) {
			ToggleMenu(true);
		}
#endif//ENABLE_HIDEMENU
	} else if (pMsg->message == WM_KEYDOWN) {
		//TRACE(_T("in CMainFrame::PreTranslateMessage WM_KEYDOWN nChar=%d\n"), pMsg->wParam);
		if (m_Child.nChild <= 0) {
			CWnd *fw = NULL;
			
#pragma warning( disable : 4706 )
			if (pMsg->wParam == VK_RETURN
#if ENABLE_SEARCHBOX
				&& (fw = GetFocus()) && fw->GetParent() != &(m_wndToolBar.m_wndUrl)
#endif//ENABLE_SEARCHBOX
				) {
				CCTermApp * pApp = (CCTermApp *)AfxGetApp();
				if (pApp) {
					if (g_nConnectionType == 2) {
						//AfxMessageBox("here");
						//AfxMessageBox(g_szLastSiteName);
						pApp->OpenCtdFile(g_szLastSiteName);
					}
					else {		
						pApp->ConnectSite(g_LastSite, true);
					}
				}
			}
#if ENABLE_FULLSCRN
			else if (pMsg->wParam == VK_ESCAPE && IsFullScreen()) {
				OnViewFullscreen(); // �Ȼָ�����ȫ��״̬
			}
#endif//ENABLE_FULLSCRN
		}
#pragma warning( default : 4706 )
		
#if ENABLE_SWITCHBAR
		else if (m_Child.nChild > 1) { //�������ϴ���
			//���ü����л�tab��ť����ʱ...������ֱ�Ӹķ����ɰ�ť������
			CWnd *fw = GetFocus();
			
			if (fw && fw->GetParent() == &m_wndSwitchBar) {
				bool bCtrl = isdown(VK_CONTROL);
				if (pMsg->wParam == VK_LEFT) {
					if (bCtrl) {
						// �ƶ�tab
						MoveChild(-1);
					}
					else {
						OnCtrlShiftTab();						
					}
				}
				else if (pMsg->wParam == VK_RIGHT) {
					if (bCtrl) {
						MoveChild(1);
					}
					else {
						OnWindowNext();
					}
				}
				return TRUE;
			}
		}
		
#endif//ENABLE_SWITCHBAR
	}
#if ENABLE_SWITCHBAR
	else if (pMsg->message == WM_MOUSEWHEEL && m_Child.nChild > 1) {
		//��ת���Ļ���tabû����ʱ�����յ�WM_MOUSEWHEEL
		int i = m_wndSwitchBar.HitTest();
		
		if (i != -1) {
			m_wndSwitchBar.SendMessage(WM_MOUSEWHEEL, pMsg->wParam, pMsg->lParam);
		}
	}
#endif//ENABLE_SWITCHBAR
	
	return CMDIFrameWnd::PreTranslateMessage(pMsg);
}

/******************************************************************************

  BBS ���ƹ�����
  
******************************************************************************/
void CMainFrame::OnBbsDigest()		// ��������
{
	CChildFrame *pFrame = NULL;
	pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE)	// ֻ���ڰ��������б�ʱ�ſ���
		pFrame->m_pView->Send("x", 1);
}


void CMainFrame::OnBbsG()		// ^G �Ķ�
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE)	// ֻ���ڰ��������б�ʱ�ſ���
		pFrame->m_pView->Send("\a", 1);   //^G = \0x07 = BEL = \a
}


// bat 071026: ������ǰ�Ƚ��ر�������������׼KBS�ˣ����Բ�����⴦����

// ���ǹ�����һ�����⣺YTHT ֻ�����������б��п�ʮ��Ӧ�����ӹ��ܣ������ڰ�����Ҳ����
// ���ǽ���ǣ����϶༶�������ͻ���ɻ��ң����ǲ�Ҫ��Ϊ�á�
void CMainFrame::OnBbsH()	// Hʮ��
{
	CChildFrame *pFrame = (CChildFrame *)MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && (nSub == SST_LIST_BOARD || nSub == SST_LIST_ARTICLE)) {
		if (pFrame->m_pView->SiteType() == ST_YTHT)
			pFrame->m_pView->Send("\t", 1);  // YTHT��TAB
		
		//ytht�У��������б����� TAB ����ʾʮ����Hһ��Ҳ���ԣ�������LQQM��ȴֻ����ʾ�ײ����������������TAB��������¼
		else
			pFrame->m_pView->Send("H", 1);  // ����վ��һ����H��
	}
}

void CMainFrame::OnBbsBrowse()
{
	CChildFrame *pFrame = (CChildFrame *)MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && (nSub == SST_LIST_BOARD || nSub == SST_LIST_ARTICLE)) {
		pFrame->m_pView->Send(",", 1);
		//if (pFrame->m_pView->SiteType() == ST_YTHT)
		//	pFrame->m_pView->Send(",", 1);  // YTHT��TAB
		//else
		//	pFrame->m_pView->Send("H", 1);  // ����վ��һ����H��
	}
}
void CMainFrame::OnBbsSametitle()	//ͬ�����Ķ�
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) 	// ֻ���ڰ��������б�ʱ�ſ���
		if (pFrame->m_pView->SiteType() == ST_SMTH)
			pFrame->m_pView->Send("\a2\n", 3);   //^G = \0x07 = BEL = \a (KBS������ ^T��)
		else
			pFrame->m_pView->Send("\x14", 1);   //^T = \0x14
}

#if ENABLE_POSTDLG
void CMainFrame::OnBbsPost()		// F5����  ������ظ����£���д�귢��
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nStatus = pFrame->m_pView->GetStatus();
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nStatus == SST_LIST && nSub == SST_LIST_ARTICLE && nStatus != SST_WRITE) { // ���������б�������
		CPostTitleDlg Dlg;
		if (Dlg.DoModal() == IDOK) {
			if (Dlg.m_inputline.IsEmpty())	//����������Ϊ�գ����˳�
				return;
			
			//���ⲻΪ�գ�����
			pFrame->m_pView->Send("\x10", 1);  //^P
			
			if (pFrame->m_pView->SiteType() == ST_MAPLE)
				pFrame->m_pView->Send("\n", 1);
			
			pFrame->m_pView->Send(Dlg.m_inputline.GetBuffer(1), Dlg.m_inputline.GetLength());	//����
			pFrame->m_pView->Send("\n", 1);	//����
			
			switch (Dlg.m_qmd) {
			case 0: {	//���ǩ����
				if (pFrame->m_pView->SiteType() == ST_SMTH		// SMTH/YTHT: L
					|| pFrame->m_pView->SiteType() == ST_YTHT)
					pFrame->m_pView->Send("l\n", 2);
				
				if (pFrame->m_pView->SiteType() == ST_FIREBIRD		// FB/LILY:x
					|| pFrame->m_pView->SiteType() == ST_LILY)
					pFrame->m_pView->Send("x\n", 2);
				
				if (pFrame->m_pView->SiteType() == ST_MAPLE)		// MAPLE:?
					pFrame->m_pView->Send("x\n", 2);
				
				break;
					}
			case 1: {
				pFrame->m_pView->Send("1\n", 2);	    // ��1��
				break;
					}
				
			case 2: {
				pFrame->m_pView->Send("2\n", 2);	    // ��2��
				break;
					}
				
			case 3: {
				pFrame->m_pView->Send("3\n", 2);	    // ��3��
				break;
					}
				
			case 4: {
				pFrame->m_pView->Send("4\n", 2);	    // ��4��
				break;
					}
				
			case 5: {
				pFrame->m_pView->Send("5\n", 2);	    // ��5��
				break;
					}
			}
			
			/*			switch (Dlg.m_quote)
			{
			case 0:	{	pFrame->m_pView->Send (_T("s\n"),2);	break;	}
			case 1:	{	pFrame->m_pView->Send (_T("y\n"),2);	break;	}
			case 2:	{	pFrame->m_pView->Send (_T("r\n"),2);	break;	}
			case 3:	{	pFrame->m_pView->Send (_T("a\n"),2);	break;	}
			case 4:	{	pFrame->m_pView->Send (_T("n\n"),2);	break;	}
			}
			*/
			if (!Dlg.m_reply)	//Ĭ�����ǿ��Իظ��ģ�ֻ�в��ɻظ�����Ҫ����
				pFrame->m_pView->Send("u\n", 2);	//����
			
			//if (Dlg.m_bUploadAtt)
			//	pFrame->m_pView->Send("u\n", 2);	//����, KBS/SMTH���ϴ�����
			//else
			pFrame->m_pView->Send("\n", 1);	//����
		} 
	} else if (nStatus == SST_ARTICLE) {
		pFrame->m_pView->Send("q", 1);	//�����Ķ�
		pFrame->m_pView->Send("r", 1);
		//���ڸô��жϲ���re�����ɹ�
		pFrame->m_pView->Send("\n", 1);
		
		if (pFrame->m_pView->SiteType() == ST_MAPLE)
			pFrame->m_pView->Send("\n\n\n", 3);
	} else if ((nStatus == SST_END) && (nSub == SST_END_ARTILE || nSub == SST_END_MAIL)) {	//����ĩβ
		pFrame->m_pView->Send("r", 1);
		//���ڸô��жϲ���re�����ɹ�
		pFrame->m_pView->Send("\n", 1);
		
		if (pFrame->m_pView->SiteType() == ST_MAPLE)
			pFrame->m_pView->Send("\n\n\n", 3);
	} else if (nStatus == SST_WRITE) {	// д����ʱ
		if (
#if ENABLE_EDITBOX
			pFrame->m_pView->IsEditView()
#else
			false
#endif//ENABLE_EDITBOX
			) {		//���༭���ڿɼ�
#if ENABLE_EDITBOX
			pFrame->m_pView->m_EditDlg.OnPost();
#endif//ENABLE_EDITBOX
		}
		else {
			pFrame->m_pView->Send("\x17\n", 2);  //^W
		}
	}
}

void CMainFrame::OnUpdateBbsPost(CCmdUI* pCmdUI)			// �����Ƿ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if ((nSta == SST_LIST && nSub == SST_LIST_ARTICLE)
			|| nSub == SST_END_ARTILE || nSub == SST_END_MAIL || nSta == SST_ARTICLE
			|| nSta == SST_WRITE) {	//nStatus==SST_END
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnBbsPic()		// ������ͼ  /�ϴ�����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	TCHAR ts[MAX_LINE_CHAR]="";
	_tcscpy(ts, pFrame->m_pView->m_Site.m_Login.m_szAddr);
	if (pFrame->m_pView->SiteType() != ST_SMTH	&& !(_tcsstr(ts, _T(".byhh.")) || _tcsstr(ts, _T(".whnet.")))) {
		AfxMessageBox(_T("�˹���Ŀǰ��֧�� SMTH/KBS �͵� BBSϵͳ �� ���ƻƺ�վ���ݲ�֧������BBSϵͳ��վ�㡣"));	// ����� SMTH ϵͳ, ����; ���򷵻ء�
		return;
	}


	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();

	//�������������ͼƬ������������	
	CString sFileName;
//	if (nSta ==SST_LIST || nSta == SST_ARTICLE  ||  nSta == SST_END || nSta == SST_WRITE	
//		|| _tcsstr(ts, _T(".byhh.")) ||  _tcsstr(ts, _T(".whnet."))) {
		//�μ�������ҳ�еġ�ճ�����͡�ת����ʽ�����֣� http://blog.csdn.net/mp5li/article/details/6255776
	HANDLE hBitmap=NULL;  
	CxImage *image = new CxImage();  
	CTime time;
	if (OpenClipboard()) hBitmap=GetClipboardData(CF_DIB);  
	if (hBitmap)	image->CreateFromHANDLE(hBitmap);  
	CloseClipboard(); 
	if (image->IsValid()){  //
		time = CTime::GetCurrentTime() ;
		sFileName.Format("%s-%4d%02i%02i-%02i%02i%02i%s",g_PicPath + _T("\\CTerm"),	//ͼƬ�ļ���
			time.GetYear(),time.GetMonth(),time.GetDay(), time.GetHour(), time.GetMinute(),time.GetSecond(),".jpg");
		image->SetJpegQuality( 75 );		// jpg ͼƬ����
		image->Save(sFileName.LockBuffer(), CXIMAGE_FORMAT_JPG);	//����ͼƬ��ͼƬ�ļ���
		//TODO: ����Ϊ JPG���Լ�СͼƬ��������ǳ������⣺�����ļ�Ϊ 0 �ֽڡ���������ֻ�ܱ���ΪPNG��ʽ��������

		// Ȼ���������գ����ļ����ַ��������������(�Ա���һ����ͼ����ʱ�����ظ�����)
		if (OpenClipboard() )	{
			HGLOBAL hmem=GlobalAlloc(GHND,sFileName.GetLength()+1);
			TCHAR * pmem;
			pmem = (TCHAR *) GlobalLock(hmem);
			EmptyClipboard();
			memcpy(pmem, (LPCTSTR)sFileName, sFileName.GetLength()+1);
			SetClipboardData(CF_TEXT,hmem);
			CloseClipboard();
			GlobalFree(hmem); 
		}
	}

	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {	// ���������б�
		CPostTitleDlg Dlg;
		Dlg.m_inputline = _T("CTerm ��ͼ");
		if (Dlg.DoModal() == IDOK) {
			if (Dlg.m_inputline.IsEmpty()) 	//����������Ϊ�գ����˳�
				return;
			else 
				_tcscpy(ts, Dlg.m_inputline);
			pFrame->m_pView->Send("\x10", 1);  //^P
			//if (pFrame->m_pView->SiteType() == ST_MAPLE) pFrame->m_pView->Send("\n", 1);
			pFrame->m_pView->Send(ts, _tcslen(ts));	//����
			pFrame->m_pView->Send("\n", 1);	//�س�
			//���������������Ƿ�����ϴ����������
			if (!sFileName.IsEmpty()) 
				MessageBox(_T("�������е�ͼƬ�ѱ���Ϊ��\n\n")+ sFileName+_T(" \n���ļ����Ѹ��Ƶ��������У� "), _T("ͼƬ"), MB_ICONINFORMATION | MB_OK);
			if (pFrame->m_pView->SiteType() == ST_SMTH )	
				pFrame->m_pView->Send("u\n", 2);	// SMTH����վ�㣺����"u"���س�����Ļ�ϻ���ʾ�ϴ���ַ
		}
	}else if (nSta == SST_ARTICLE || (nSta == SST_END && nSub == SST_END_ARTILE)) { //�Ķ����»�����ĩβ	//  SST_END_MAIL))
		pFrame->m_pView->Send("r", 1);
		if (!sFileName.IsEmpty()) 
			MessageBox(_T("�������е�ͼƬ�ѱ���Ϊ��\n\n")+ sFileName+_T(" \n���ļ����Ѹ��Ƶ��������У� "), _T("ͼƬ"), MB_ICONINFORMATION | MB_OK);
		if (pFrame->m_pView->SiteType() == ST_SMTH )	
			pFrame->m_pView->Send("u\n", 2);	// SMTH����վ�㣺����"u"���س�����Ļ�ϻ���ʾ�ϴ���ַ
		//���������������Ƿ�����ϴ����������
	}else if (nSta == SST_WRITE) {
		if (!sFileName.IsEmpty()) 
			MessageBox(_T("�������е�ͼƬ�ѱ���Ϊ��\n\n")+ sFileName+_T(" \n���ļ����Ѹ��Ƶ��������У� "), _T("ͼƬ"), MB_ICONINFORMATION | MB_OK);
		if (pFrame->m_pView->SiteType() == ST_SMTH )	
				pFrame->m_pView->Send("\x1bz", 2);  // 	// SMTH����վ�㣺���� ESC-z����Ļ�ϻ���ʾ�ϴ���ַ
	}
	//����SMTHϵͳ���Զ���ϵͳ����վ��״̬�������ʾ�С������ϴ���ַ������� CCTermCore::RedrawIt ֮����� CCTermView::UploadAtt()

	//���ڰ��ƻƺ�վ���������ר���ϴ�����
	if (_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".byhh.")) ||  _tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".whnet."))) {
		CPostDlg Dlg2;
		Dlg2.m_strSiteName = pFrame->m_pView->m_Site.m_Login.m_szAddr;
		Dlg2.m_strBoardName = pFrame->m_pView->m_szBbsBoard;	 //m_Status.GetBoardName();	// ??
		Dlg2.m_strUserName = pFrame->m_pView->m_Site.m_Login.m_szLoginName;
		Dlg2.m_strPassWord = pFrame->m_pView->m_Site.m_Login.m_szLoginPSW;
		Dlg2.m_strLocalFile= sFileName;
		Dlg2.DoModal();
		CString str1 = Dlg2.m_strUploadURLs;		//����ϴ��˸�������Ҫת���༭����
#if ENABLE_EDITBOX
		if (!str1.IsEmpty()) {
			pFrame->m_pView->m_EditDlg.m_edit += "\r\n";		//_T("\n\n�������ӣ�\n");
			pFrame->m_pView->m_EditDlg.m_edit += str1;
			pFrame->m_pView->m_EditDlg.OnShowWindow(TRUE, 1);
		}
#endif//ENABLE_EDITBOX
		pFrame->m_pView->Send("\n", 1);	//�س�
	}

}

void CMainFrame::OnUpdateBbsPic(CCmdUI* pCmdUI) // ������ͼ�Ƿ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if ((nSta == SST_LIST && nSub == SST_LIST_ARTICLE)
			|| nSub == SST_END_ARTILE || nSub == SST_END_MAIL || nSta == SST_ARTICLE
			|| nSta == SST_WRITE) {	//nStatus==SST_END
			pCmdUI->Enable();
			return;
		}
	}
	pCmdUI->Enable(0);
}

#endif//ENABLE_POSTDLG

void CMainFrame::OnBbsClear()	// ���δ�����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nStatus = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	bool bBoard = (nSub == SST_LIST_BOARD && nStatus != SST_WRITE);
	
	if (bBoard) { // �����б�״̬
		//int i=2;//,j=0;
		//while (!pFrame->m_pView->m_Core.IsBlankLine(i) && i<(pFrame->m_pView->m_nTermHeight))
		//	i++;
		
		TCHAR s[10] = _T("");
		//for (j=0;j<=i;j++) {
		_stprintf(s, _T("%c  "), pFrame->m_pView->m_szReturnChar[0]);
		pFrame->m_pView->Send(s, 3);
	}
	
	if (bBoard || (nStatus == SST_LIST && nSub == SST_LIST_ARTICLE)) {
		if (pFrame->m_pView->SiteType() == ST_SMTH  && !_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".hit.")))	// �������ڰ��������б�״̬	//�϶���ΪKBS�޸���
			pFrame->m_pView->Send("f", 1);
		else if (pFrame->m_pView->SiteType() == ST_YTHT && !_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".tju.")))
			pFrame->m_pView->Send("ff", 2);
		else
			pFrame->m_pView->Send("c", 1);  //FB, MAPLE
	}
	
	if (bBoard)
		pFrame->m_pView->Send("q", 1);
}

#if ENABLE_SEARCHDLG
void CMainFrame::OnBbsSearch()
{
	CSearchDlg *Dlg = new CSearchDlg;// CSearchDlg::OnDestroy()��delete
	
	//CChildFrame *pFrame = NULL;
	//pFrame = (CChildFrame *) MDIGetActive();
	//SITESTATUS nSta = pFrame->m_pView->GetStatus();
	//SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	//if (nSub == SST_LIST_ARTICLE) {
		// ֻ���ڰ��������б�ʱ�ſ���
		Dlg->Create(IDD_SEARCH, NULL);
		Dlg->ShowWindow(SW_SHOW);
	//}
}


void CMainFrame::OnUpdateBbsSearch(CCmdUI* pCmdUI)	// �������� �Ƿ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
//		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST) {
			// && nSub == SST_LIST_ARTICLE
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

#endif//ENABLE_SEARCHDLG

void CMainFrame::OnBbsSuperPaste()
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame)
		return;		//�������ڴ��ڣ��˳�
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE)		// ֻ���ڰ��������б�ʱ�ſ���
		OnEditPaste();
}


/////////////  ����BBSBAR��ť״̬  ///////////////////////////////
void CMainFrame::OnUpdateBbsDigest(CCmdUI* pCmdUI)	// ��������
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {	//&& nSta!=SST_WRITE)
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnUpdateBbsG(CCmdUI* pCmdUI)	// ^G
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {	// && nSta!=SST_WRITE)
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnUpdateBbsH(CCmdUI* pCmdUI)		// H
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if ((pFrame->m_pView->SiteType() == ST_YTHT
			&& !_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T("tan."))
			)			// YTHTֻ���ڰ����б�ʱ�ſ��ã���������̳ȴ���ԡ�
			|| _tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".hbu."))
			|| _tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".tju."))
			) {
			// ����BBS�������ʵֻ���ڰ����б�ʱ�ſ���
			if (nSta == SST_LIST && nSub == SST_LIST_BOARD) {
				pCmdUI->Enable();
				return;
			}
		} else if (nSta == SST_LIST && (nSub == SST_LIST_BOARD || nSub == SST_LIST_ARTICLE)) {	// ����վ�����ڰ����б��Ͱ����ڿ���
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnUpdateBbsBrowse(CCmdUI* pCmdUI)
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		 if (nSta == SST_LIST && (nSub == SST_LIST_ARTICLE)) {	
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnUpdateBbsSametitle(CCmdUI* pCmdUI)	// ͬ���� �Ƿ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
	
}

void CMainFrame::OnUpdateBbsClear(CCmdUI* pCmdUI)		//����Ϊ�Ѷ�
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && (nSub == SST_LIST_ARTICLE || nSub == SST_LIST_BOARD)) {
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

void CMainFrame::OnUpdateBbsSuperPaste(CCmdUI* pCmdUI)	// ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

/******************************************************************************/

#if ENABLE_CTD
void CMainFrame::OnOpenctd()
{
	OpenCtdCsm();
}

// ���ն��ļ�
void CMainFrame::OpenCtdCsm()
{
	CFileDialogEx fd(TRUE, _T(""), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("CTerm �ն�/ӳ���ļ�(*.ctd;*.csm)|*.ctd;*.csm||"));
	if (fd.DoModal() == IDOK) {
		CString sFile = fd.GetPathName();
		g_nConnectionType = 2;
		g_LastFileName = sFile;
		OnCreateNewChild((WPARAM)sFile.LockBuffer(), (LPARAM)1);   //1: �ļ�. ��Ϊ�����Գ���ķ�ʽ�ӽű���ctd���ʿ�ֱ�ӵ���
		sFile.UnlockBuffer();
	}
}

#if ENABLE_RAWCTD
void CMainFrame::ShowAsciiBar()
{
	ShowControlBar(&m_wndAsciiBar, TRUE, FALSE);
}

void CMainFrame::OnCtdrecord() 
{
	g_bAnsiLog = !g_bAnsiLog;
	//	if (!g_bAnsiLog) {
	// ��¼����
	// �����ļ��Ի��򣬽���ʱ�ļ�������Ŀ���ļ�
	//	}
}

void CMainFrame::OnUpdateCtdrecord(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_bAnsiLog);
}
#endif//ENABLE_RAWCTD

#endif//ENABLE_CTD

#if ENABLE_LOCK
void CMainFrame::OnLeave()
{
	if (!g_bInLocking) LockSys(); // ���δ�뿪�����뿪�������޶���
}

void CMainFrame::LockSys()
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame) {	// �������ڴ��ڣ����ܽ����뿪״̬������ʲô������
		g_nGlobalIdleTime = 0;
		g_bInLocking = false;
		g_bAutoReply = FALSE;
		return;
	}
	
	if (g_bInLocking) return;
	
#if ENABLE_PYTHON
	if (g_bAutoLockBBS) {
		RunPythonCode(_T("LockBBS()"));
	}
#endif//ENABLE_PYTHON
	
	g_bInLocking = TRUE;
	
	g_bAutoReply = TRUE;
	
	if (!IsWindowVisible()) {
		CString sTitle;
		GetWindowText(sTitle);
		_tcscpy(m_nid.szTip, sTitle + _T(" [�뿪]"));
		Shell_NotifyIcon(NIM_MODIFY, &m_nid);
	}
	
	if (!m_bBossHided)
	{
		if (g_bMinWhenLeave) {
			ShowWindow(SW_HIDE);
			CString sTitle;
			GetWindowText(sTitle);
			_tcscpy(m_nid.szTip, sTitle + _T(" [�뿪]"));
			Shell_NotifyIcon(NIM_MODIFY, &m_nid);
			Shell_NotifyIcon(NIM_ADD, &m_nid);
			m_bTrayIconVisible = true;
		}
		else {
			CLockDlg dlgLock;
			m_pLockDlg = &dlgLock;
			//dlgLock.m_pLockPsw = g_szPSW;
			dlgLock.DoModal();
			m_pLockDlg = NULL;
			
			UnlockSys();
			if(!IsWindowVisible()) {
				PopupSelf();
			}
		}
	}
	//else // �ѱ��ϰ�����أ�����С����������������ʾͼ��
}

void CMainFrame::UnlockSys()
{
	if (g_bInLocking) {
		if (m_pLockDlg) {
			// �����û��
			//m_pLockDlg->SendMessage(WM_CLOSE); // �����ز���
			m_pLockDlg->EndDialog(-1); // ��������...����OnOK���ߵ���һ����װ��OnOK��֪���ɲ�����
		}
		// �������û�ʱ������������...�������lockdlg�Ļ�
		UnlockScreen();
		
		CString sTitle;
		GetWindowText(sTitle);
		_tcscpy(m_nid.szTip, sTitle);
		Shell_NotifyIcon(NIM_MODIFY, &m_nid);
		Shell_NotifyIcon(NIM_DELETE, &m_nid);
		m_bTrayIconVisible = false;
		
		//	if (!IsWindowVisible()) {
		//		PopupSelf();
		//	}
		
		g_nGlobalIdleTime = 0;
		
		g_bInLocking = FALSE;
		g_bAutoReply = FALSE;
	}
}

void CMainFrame::UnlockScreen()
{
	//����
#if ENABLE_PYTHON
	
	if (g_bAutoLockBBS) {
		RunPythonCode(_T("UnlockBBS()"));
		/*		CChildFrame *pFrame=(CChildFrame *)MDIGetActive();
		if (!pFrame) return;		//�������ڴ��ڣ��˳�
		
		  pFrame->m_pView->Send(pFrame->m_pView->m_Site.m_Login.m_szLoginPSW, _tcslen(pFrame->m_pView->m_Site.m_Login.m_szLoginPSW));
		pFrame->m_pView->Send(_T("\n\x1b[D"),4);//DF��������D��Ϊ�˼���MAPLE*/
	}
	
#endif//ENABLE_PYTHON
}

void CMainFrame::OnUpdateLeave(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(!g_bInLocking);
}

#endif//ENABLE_LOCK

//*****************************************************************************
void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	//	TRACEF("CMainFrame::OnSize\n");
	//TRACE(_T("in CMainFrame::OnSize \t nType=%d \n"), nType);
	CMDIFrameWnd::OnSize(nType, cx, cy);
	
	if (nType == SIZE_MINIMIZED) {
		if (g_bMinToTray) {
			ShowWindow(SW_HIDE);
			Shell_NotifyIcon(NIM_ADD, &m_nid);
			m_bTrayIconVisible = true;
		}
	}
	else {
		m_bZoomed = IsZoomed();
		if (nType == SIZE_MAXIMIZED) {
#if ENABLE_SWITCHBAR
			m_wndSwitchBar.SetTabSize();
#endif//ENABLE_SWITCHBAR
		
		//SetForegroundWindow(); // ����ᵼ����Զ�����潹�㣻�л���Զ������ʱ��cterm��õ�һ��SIZE_MAXIMIZED����Ϣ
		
		// ������β�֪��ʲô�ã���ɾ��
		//#if ENABLE_EDITBOX
		//		CChildFrame* pFrame = (CChildFrame*) MDIGetActive();
		//
		//		if (pFrame && pFrame->m_pView && pFrame->m_pView->IsEditView()) {
		//			pFrame->m_pView->ShowEditView(TRUE);
		//			pFrame->m_pView->m_EditDlg.SetFocus();
		//		}
		//#endif//ENABLE_EDITBOX
		}
	}
}

//void CMainFrame::OnF10()
//{
//	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
//	
//	if (pFrame && pFrame->m_pView) {
//		//pFrame->m_pView->SendMessage(WM_KEYDOWN, VK_F10, 0);
//		pFrame->m_pView->Send("\x1b[21~", 5);
//	}
//}

//void CMainFrame::OnF1()
//{
//	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
//	if (pFrame && pFrame->m_pView) {
//		if (pFrame->m_pView->SiteType() == ST_SMTH) {
//			pFrame->m_pView->Send("\x1b[11~", 5);
//		}
		
//#if ENABLE_EDITBOX
//		else {
//			OnEditDlg();
//		}
		
//#endif//ENABLE_EDITBOX
//	}
//}

void CMainFrame::OnUpdateAutocopy(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(g_bAutoCopy);
}

void CMainFrame::OnAutocopy()
{
	g_bAutoCopy = !g_bAutoCopy;

	if (g_bAutoCopy) {
		CChildFrame *pFrame = (CChildFrame *) MDIGetActive();	
		if (pFrame && pFrame->m_pView && pFrame->m_pView->IsCopySelected()) {
			// ��ѡ������Ҫ�Զ�����
			DoCopy(g_bAnsiCP);
		}
	}
}

////////////////////////////////////////////////
///		ȫ����ʾ�Ĵ���
#if ENABLE_FULLSCRN
void CMainFrame::OnViewFullscreen()
{
	SetFullscreen(!IsFullScreen());
}

void CMainFrame::SetFullscreen(bool bFull)
{
	WINDOWPLACEMENT wpNew;
	
	static BOOL bZoomed = FALSE;//ȫ��ǰ�Ƿ����״̬
	
	TRACE(_T("in CMainFrame::OnViewFullscreen\n"));
	
	if (bFull) {
#if ENABLE_HIDEMENU
		if (!g_bMenuVisible) {
			ToggleMenu(true); // ����ʾ������ߴ粻��
			g_bMenuVisible = false;
		}
#endif//ENABLE_HIDEMENU
		
		// need to hide all status bars
		HideBars();
		
		// We'll need these to restore the original state.
		GetWindowPlacement(&m_wpPrev);
		
		MONITORINFO mi;
		mi.cbSize = sizeof(MONITORINFO);
		RECT &rDesk = mi.rcMonitor;
		HMONITOR hm = MonitorFromWindow(GetSafeHwnd(), MONITOR_DEFAULTTONEAREST);
		if (!GetMonitorInfo(hm, &mi)) {
			::GetWindowRect(::GetDesktopWindow(), &rDesk);
		}
		TRACE("rDesk before adjuct: %d %d %d %d\n", rDesk.left,	rDesk.top, rDesk.right, rDesk.bottom);
		//Adjust RECT to new size of window
		::AdjustWindowRectEx(&rDesk, GetStyle(), TRUE, GetExStyle());
		TRACE("rDesk after  adjuct: %d %d %d %d\n", rDesk.left,	rDesk.top, rDesk.right, rDesk.bottom);	
		// Remember this for OnGetMinMaxInfo()
		m_FullScreenWindowRect = rDesk;
		
		//		{
		//			CRect WindowRect;
		//			GetWindowRect(&WindowRect);
		//			CRect ClientRect;
		//			RepositionBars(0, 0xffff, AFX_IDW_PANE_FIRST, reposQuery, &ClientRect);
		//			ClientToScreen(&ClientRect);
		//			// ��ȡ��Ļ�ķֱ���
		//			int nFullWidth=GetSystemMetrics(SM_CXSCREEN);
		//			int nFullHeight=GetSystemMetrics(SM_CYSCREEN);
		//			// ������������Ŀͻ���ȫ����ʾ����(0,0)��(nFullWidth, nFullHeight)����, ��(0,0)��(nFullWidth, nFullHeight)������������ԭ���ںͳ�������֮��� �ͻ���λ�ü�Ĳ�ֵ, �͵õ�ȫ����ʾ�Ĵ���λ��
		//			m_FullScreenRect.left=WindowRect.left-ClientRect.left;
		//			m_FullScreenRect.top=WindowRect.top-ClientRect.top;
		//			m_FullScreenRect.right=WindowRect.right-ClientRect.right-nFullWidth;
		//			m_FullScreenRect.bottom=WindowRect.bottom-ClientRect.bottom-nFullHeight;
		//		}
		
		wpNew.length = sizeof m_wpPrev;
		wpNew = m_wpPrev;
		wpNew.showCmd =  SW_SHOWNORMAL;// ��ΪSW_SHOWMAXIMIZED���У��˵����ͱ������޷�����
		wpNew.rcNormalPosition = rDesk;
		
		
		bZoomed = IsZoomed();
		
		
		if (g_bFullScreenBar) {
			m_pwndFullScrnBar = new CToolBar;
			
			if (!m_pwndFullScrnBar->Create(this, CBRS_SIZE_DYNAMIC | CBRS_FLOATING) ||
				!m_pwndFullScrnBar->LoadToolBar(IDR_FULLSCREEN)) {
				//TRACE0(_T("Failed to create toolbar\n"));
				return;      // fail to create
			}
			
			//don't allow the toolbar to dock
			m_pwndFullScrnBar->EnableDocking(0);
			
			m_pwndFullScrnBar->SetWindowPos(0, 100, 100, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
			
			m_pwndFullScrnBar->SetWindowText(_T("Full Screen"));
			
			FloatControlBar(m_pwndFullScrnBar, CPoint(rDesk.right - 50, rDesk.top + 30));
		}
		
		//SetMenu(NULL);
		//ModifyStyle(WS_CAPTION,0);
		
		m_bFullScreen = TRUE;
	} else {
		//�˳�ȫ��
#if ENABLE_HIDEMENU
		if (!g_bMenuVisible) {
			ToggleMenu(false); // ����
		}
#endif//ENABLE_HIDEMENU
		
		if (m_pwndFullScrnBar) {
			g_bFullScreenBar = m_pwndFullScrnBar->IsWindowVisible(); //����ȫ��������״̬
			
			m_pwndFullScrnBar->DestroyWindow();
			delete m_pwndFullScrnBar;
			m_pwndFullScrnBar = NULL;
		}
		
		m_bFullScreen = FALSE;
		
		HideBars(true);
		
		//			WINDOWPLACEMENT wpNew1;
		//			GetWindowPlacement (&wpNew1);
		wpNew = m_wpPrev;
		
		if (bZoomed)
			ShowWindow(SW_SHOWMAXIMIZED);//û��䣬������С����
	}
	
	TRACE(_T("in CMainFrame::OnViewFullscreen 7\n"));
	
	SetWindowPlacement(&wpNew);
	
	TRACE(_T("out CMainFrame::OnViewFullscreen\n"));
}

void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI)
{
	if (IsFullScreen()) {
		lpMMI->ptMaxSize.x = m_FullScreenWindowRect.Width();
		lpMMI->ptMaxSize.y = m_FullScreenWindowRect.Height();
		lpMMI->ptMaxPosition.x = m_FullScreenWindowRect.Width();
		lpMMI->ptMaxPosition.y = m_FullScreenWindowRect.Height();
		lpMMI->ptMaxTrackSize.x = m_FullScreenWindowRect.Width();
		lpMMI->ptMaxTrackSize.y = m_FullScreenWindowRect.Height();
		
		//		lpMMI->ptMaxSize.y = m_FullScreenWindowRect.Height();
		//		lpMMI->ptMaxTrackSize.y = lpMMI->ptMaxSize.y;
		//		lpMMI->ptMaxSize.x = m_FullScreenWindowRect.Width();
		//		lpMMI->ptMaxTrackSize.x = lpMMI->ptMaxSize.x;
	}
	
	CMDIFrameWnd::OnGetMinMaxInfo(lpMMI);
}

BOOL CMainFrame::IsFullScreen()
{
	return m_bFullScreen;
}

void CMainFrame::OnUpdateViewFullScreen(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(IsFullScreen());
}

LRESULT CMainFrame::OnWindowEdge(WPARAM wParam, LPARAM lParam)
{
	static bool bShow = true;

	if (IsFullScreen()) {
		ShowControlBar(&m_wndToolBar, bShow, FALSE);
		bShow = !bShow;
	}

	return 1;
}

#endif//ENABLE_FULLSCRN

LRESULT CMainFrame::OnDisplayChange(WPARAM wParam, LPARAM lParam)
{
#if ENABLE_FULLSCRN
	if (IsFullScreen()) {
		WINDOWPLACEMENT wpPrevOld = m_wpPrev;
		SetFullscreen(true);
		m_wpPrev = wpPrevOld;
	}
#endif//ENABLE_FULLSCRN
	
	for (int i = 0; i < m_Child.nChild; i++) {
		if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView) {
			m_Child.pFrames[i]->m_pView->OnDisplayChange();
		}
	}
	
	return 1;
}

LRESULT CMainFrame::OnChildClosed(WPARAM wParam, LPARAM lParam)
{
	if (m_Child.nChild <= 0) {
		CString sTitle = _T("CTerm - [");
		if (g_nConnectionType == 2) {
			sTitle += GetShortFileName(g_LastFileName.LockBuffer());
			g_LastFileName.UnlockBuffer();
		}
		else {
			sTitle += g_LastSite.m_Login.m_szProfileName;
		}
		sTitle += _T("]");
		SetWindowText(sTitle);
		
		{
			SetMenuFav();
			
			CMenu *pMainMenu = GetMenu(); // ��ʱȡ��ȷʵ��IDR_MAINFRAME�˵�
			if (pMainMenu) {
#if ENABLE_MULTILANG
				g_SetMenuStrings(pMainMenu, _T(""));
#endif//ENABLE_MULTILANG
				DrawMenuBar();		// ˢ�²˵���ʾ
			}
		}
	}
	
#if ENABLE_HIDEMENU
	ToggleMenu(g_bMenuVisible);
#endif//ENABLE_HIDEMENU
	
	return 1;
}

void CMainFrame::OnTimer(UINT nIDEvent)
{
	//TRACEFINTS("CMainFrame::OnTimer\n", nIDEvent);
	//TRACE(_T("in CMainFrame::OnTimer nIDEvent:%d\n"), nIDEvent);
	if (nIDEvent == TIMER_FLASHWINDOW) {	//��˸���ڣ����磬�յ���Ϣʱ��
		//TRACEF("CMainFrame::OnTimer FLASHWINDOW");
		//TRACE(_T("flashing window\n"));
		FlashWindow(TRUE);
		static UINT icons[2] = {IDR_MAINFRAME, IDI_MESSAGE};
		static int index = 0;
		
		if (!IsWindowVisible()) {
			//			HICON hIcon = (HICON)::LoadImage(AfxGetInstanceHandle(),
			//				MAKEINTRESOURCE(icons[index++%2]),
			//				IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR);//SM_CXICON
			_tcscpy(m_nid.szTip, _T("you got message!"));
			m_nid.hIcon = AfxGetApp()->LoadIcon(icons[index++%2]);
			Shell_NotifyIcon(NIM_MODIFY, &m_nid);
			//			HICON hPrevIcon = (HICON)AfxGetMainWnd()->SendMessage(WM_SETICON,
			//				(WPARAM)ICON_SMALL,(LPARAM)hIcon);
		}
	}
	else if (nIDEvent == TIMER_GLOBLE_IDLE) {
		// ȫ��������ʱ��������ﵽһ��ʱ��������뿪״̬
		// ֻ�е����ڴ���ʱ�ż������������޴���ʱ�����뿪״̬��
		if (m_Child.nChild > 0)
			g_nGlobalIdleTime += g_nTimer;
		else
			g_nGlobalIdleTime = 0;
		
#if ENABLE_LOCK
		//#ifdef _DEBUG //for test
		//		g_nAutoProtectTime = 10;
		//#endif
		if (g_nAutoProtectTime > 0 && g_nGlobalIdleTime >= g_nAutoProtectTime && !g_bInLocking) {
			//�Զ�����CTerm
			LockSys(); // �Զ��뿪������Ҫ�Զ�����
		}
		
#endif ENABLE_LOCK
	}
	
	CMDIFrameWnd::OnTimer(nIDEvent);
}

#if ENABLE_SHOWIP
void CMainFrame::OnToolQueryIP()		// �ֹ���ѯIP
{
	CQueryIPDlg dlg;
	dlg.DoModal();
}

void CMainFrame::OnViewShowipauto()
{
#if ENABLE_REPLACEIP
	
	if (_taccess(g_sIPWryPath, 0) != 0) {
		// �����ļ�������,�����IP��ѯ
		MessageBox(_T("ָ����IP���ݿ��ļ������ڣ�����ϵͳѡ���н������á�"));
		g_bShowIPAuto = FALSE;
	} else {
		g_bShowIPAuto = !g_bShowIPAuto;
	}
	
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView) {
		if (!g_bShowIPAuto) {
			//pFrame->m_pView->Send ("\x0c", 1);		//^Lˢ�£�����ʾԭIP
			pFrame->m_pView->Refresh(2); //restore
		}
		else {
			pFrame->m_pView->Refresh(1);	//�ػ� (��ʾ�滻���IP)
		}
	}
	
#endif //ENABLE_REPLACEIP
}

void CMainFrame::OnUpdateViewShowipauto(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(g_bShowIPAuto);
}

#endif//ENABLE_SHOWIP

void CMainFrame::OnToolPicDownAuto()	//�Զ�����������ͼƬ
{
	g_bPicDownAuto=!g_bPicDownAuto;
}

void CMainFrame::OnUpdateToolPicDownAuto(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_bPicDownAuto);	
}


// WM_DISCONNECTED
// wParam: sessionID
LRESULT CMainFrame::OnDisConnected(WPARAM wParam, LPARAM lParam)
{
#if ENABLE_PYTHON
	int nSessionID = int (wParam);
	g_pMainWnd->PythonCallback(_T("OnSessionClose"), (long*) &nSessionID, 1);
#endif
	return 1;
}


void CMainFrame::OnViewShowcenter()
{
	g_bShowCenter = !g_bShowCenter;
	RefreshAll();
}

inline void CMainFrame::RefreshAll()
{
	for (int i = 0; i < m_Child.nChild; i++) {
		if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView) {
			m_Child.pFrames[i]->m_pView->Refresh();// OnEraseBkgnd &redraw &fixpostion
		}
	}
}

void CMainFrame::OnUpdateViewShowcenter(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(g_bShowCenter);
}

//void CMainFrame::OnViewShowleft()
//{
//	g_bShowCenter = FALSE;
//	RefreshAll();
//}

//void CMainFrame::OnUpdateViewShowleft(CCmdUI* pCmdUI)
//{
//	pCmdUI->SetCheck(!g_bShowCenter);
//}

void CMainFrame::OnViewStatusbar()
{
	ShowControlBar(&m_wndStatusBar, !m_wndStatusBar.IsVisible(), FALSE);
}

void CMainFrame::OnUpdateViewStatusbar(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_wndStatusBar.IsVisible());
}

void CMainFrame::GetMessageString(UINT nID, CString& rMessage) const
{
	CString strTipText;
	
	if (CMainFrame::GetToolText(nID, strTipText)) {
		rMessage = strTipText;
	} else {
		CFrameWnd::GetMessageString(nID, rMessage);
	}
}

BOOL CMainFrame::GetToolText(UINT nID, CString& strTipText) const
{
	//	switch(nID) {
	//	case ID_SETUP_KEY:
	//		strTipText.LoadString(ID_SETUP_KEY);
	//		return TRUE;
	//	default:
#if ENABLE_FUNKEY
	int i = nID - ID_FIRST_USERDEFCMD;
	
	if (0 <= i && i < MAX_USERDEFCMD_NUM) { //�Զ�������
		if (m_keyTable[i].nCmdID == 0) { // n/a
			strTipText = _T("");  //never reached
			return TRUE;
		}
		
		ASSERT(m_keyTable[i].nCmdID == nID);
		
		strTipText = m_keyTable[i].sTip;
		return TRUE;
	}
	
#endif//ENABLE_FUNKEY
	//	}
	return FALSE;
}

#define _countof(array) (sizeof(array)/sizeof(array[0]))

BOOL CMainFrame::OnToolTipText(UINT nID, NMHDR* pNMHDR,
                               LRESULT*pResult)
{
	//TRACEF("OnToolTipText\n");
	ASSERT(pNMHDR->code == TTN_NEEDTEXTA || pNMHDR->code == TTN_NEEDTEXTW);
	
	TOOLTIPTEXTA* pTTTA = (TOOLTIPTEXTA*) pNMHDR;
	TOOLTIPTEXTW* pTTTW = (TOOLTIPTEXTW*) pNMHDR;
	
	CString strTipText;
	
	if (GetToolText(pNMHDR->idFrom, strTipText)) {
#ifndef _UNICODE
		
		if (pNMHDR->code == TTN_NEEDTEXTA)
			lstrcpyn(pTTTA->szText, strTipText, _countof(pTTTA->szText));
		else
			_mbstowcsz(pTTTW->szText, strTipText, _countof(pTTTW->szText));
		
#else
		if (pNMHDR->code == TTN_NEEDTEXTA)
			_wcstombsz(pTTTA->szText, strTipText, _countof(pTTTA->szText));
		else
			lstrcpyn(pTTTW->szText, strTipText, _countof(pTTTW->szText));
		
#endif
		return TRUE;
	}
	
	return CMDIFrameWnd::OnToolTipText(nID, pNMHDR, pResult);
}

#if ENABLE_PICTURE
// ��ʾͼƬ��
void CMainFrame::OnToolPicbox()
{
	if (g_pPicShowDlg)
		g_pPicShowDlg->ShowPicture();
}
#endif//ENABLE_PICTURE

//���״̬�����ű���Ϣ��
void CMainFrame::OnPaneScript()
{
	CString s = g_szWorkDir + _T("temp\\pyerr.log");
	ShellExecute(NULL, _T("open"), s, NULL, NULL, SW_SHOWDEFAULT);
}

//#include "Shlwapi.h" //need Microsoft Platform SDK
// ���б���ѡ���ַ��ֱ������
void CMainFrame::OpenURL(CString url)
{
	ActivateView();
	CCTermApp *pApp = (CCTermApp *) AfxGetApp();
	
#if ENABLE_SEARCHBOX
	m_wndToolBar.SaveString();	// �����µ�ַ�����س�������ť������Ҫ�ȱ���
	
	if (url.IsEmpty()) {
		int idx = m_wndToolBar.m_wndUrl.GetCurSel();
		
		if (idx != CB_ERR)
			m_wndToolBar.m_wndUrl.GetLBText(idx, url);
		else
			m_wndToolBar.m_wndUrl.GetWindowText(url);
	}
#endif//ENABLE_SEARCHBOX
	if (g_sHomePage.IsEmpty())
		//g_sHomePage = _T("http://cterm.phy.ccnu.edu.cn/");
		//g_sHomePage = _T("https://anbangli.github.io/cterm/");
		//g_sHomePage = _T("http://devcpp.gitee.io/cterm/");
		g_sHomePage = _T("https://gitee.com/devcpp/cterm");
	
	if (url.IsEmpty())
		url = g_sHomePage;
	
	//{
	//	ShellExecute(m_hWnd, _T("open"), url, NULL, NULL, SW_SHOW);
	//verb���գ�the default verb is used if it is valid and available in the registry. If not, the _T("open") verb is used.
	//����IE��ȱʡ��������ԭ���ڣ�����ms�޷�����
	//	return;
	//}
	
	bool bShift = isdown(VK_SHIFT);
	
	bool dealed = false;
	if (!g_ipurl.IsEmpty() && IsIP((LPCSTR)url)) {
		// ��ͺͺ��IP
		CString s;
		s.Format(g_ipurl, url); //"http://ip.cn/?ip=%s"
		url = s;
	}
	else {
		CString proto, addr = url;
		
		GetPort(addr, proto);
		
		if (proto.IsEmpty()) {
			CString s;
			
			if (url.GetLength() >= 4 && url.Left(4).CompareNoCase(_T("bbs.")) == 0) {
				pApp->ConnectAddr(url);
				return;
			}
			else if (url.Find(_T(".")) != -1 && url.Find(_T(" ")) == -1) {
				if (g_bAutoURLHeader) {
					s = _T("http://");
					url = s + url;
				}
			}
			else {
#if ENABLE_ADDRBOOK
				if (pApp->ConnectSite(url)) { //����վ������
					return;
				}
#endif//ENABLE_ADDRBOOK
				{
					// todo: ��verb�Ĵ���Ӧ�������棬�����b http://baidu.com�������
					int repeatcount = 0;
					int verb = -1;//0: baidu, 1: google, 2: gotoboard, 3: repeat, default: google
					
					if (url.GetLength() > 2 && url[1] == ' ') { //verb
						switch (url[0]) {
							
						case 'b': //_T("b key")
							verb = 0;
							url = url.Right(url.GetLength() - 2);
							break;
							
						case 'g': //_T("g key")
							verb = 1;
							url = url.Right(url.GetLength() - 2);
							break;
							
						case 'j': //'j newsoftware'
							verb = 2;
							url = url.Right(url.GetLength() - 2);
							break;
							
						default:
							
							if (url[0] >= '0' && url[0] <= '9') { // _T("5 k")) =>_T("kkk") �ظ�����
								verb = 3;
								repeatcount = url[0] - '0';
								url = url.Right(url.GetLength() - 2);
							}
						}
					}//if(url[1]==' ')
					else if (url.GetLength() > 3 && url[2] == ' ') {
						if (url[0] >= '1' && url[0] <= '9' &&
							url[1] >= '0' && url[1] <= '9') { // _T("13 k")
							verb = 3;
							repeatcount = (url[0] - '0') * 10 + (url[1] - '0');
							url = url.Right(url.GetLength() - 3);
						}
					}
					
					
					if (verb == 2) {
#if ENABLE_PYTHON
						
						if (g_bEnablePython && g_bSysPythonScriptLoaded) {
							CString code;
							code.Format(_T("GotoBoard(\"%s\")"), url);
							RunPythonCode(code);
						}
						
						return;
						
#endif
					} 
					else if (verb == 3) { //�ظ�������ͬ�ַ��������磬_T("5 k")���൱�����б��������ƶ�5��
						s.Empty();
						
						for (int i = 0 ; i < repeatcount ; i++)
							s += url;
						
						s = TranslateString(s);
						
						CCTermView *pView = GetNthView();
						
						if (pView) {
							GetNthView()->Send(s.LockBuffer(), s.GetLength());
							s.UnlockBuffer();
						}
						
						return;
					}
					
#if ENABLE_URLENCODE
					//for searching
					CURLEncode g_urlEncoder;
					url = g_urlEncoder.URLEncode(url);
					
#endif//ENABLE_URLENCODE
					if ((verb == -1 && !g_bUseGoogle) || verb == 0) { // ��δָ���������棬��Ĭ�ϲ���Google�� �� ָ����Baidu
						//_T("http://www.baidu.com/s?tn=cleverterm&ct=&lm=&z=&rn=&word=");
						s = _T("http://www.baidu.com/baidu?tn=cleverterm&word=");
						url = s + url;
					} else {
						// ��δָ���������棬��Ĭ����Google�� �� ָ����Google
						s = _T("http://www.google.com/custom?q=");
						url = s + url + _T("&client=pub-9198310687703825&forid=1&ie=GB2312&oe=GB2312&cof=GALT%3A%23008000%3BGL%3A1%3BDIV%3A%23336699%3BVLC%3A663399%3BAH%3Acenter%3BBGC%3AFFFFFF%3BLBGC%3A336699%3BALC%3A0000FF%3BLC%3A0000FF%3BT%3A000000%3BGFNT%3A0000FF%3BGIMP%3A0000FF%3BFORID%3A1%3B&hl=zh-CN");
					}
				}
			}
			
			//LPTSTR pszCanonicalized=new TCHAR(6*url.GetLength());
			//DWORD dCanonicalized=6*url.GetLength();
			//UrlCanonicalize(url, pszCanonicalized, &dCanonicalized, URL_DONT_SIMPLIFY|URL_ESCAPE_PERCENT);
		}
		else {
			if (proto.CompareNoCase(_T("bbs")) == 0 || proto.CompareNoCase(_T("telnet")) == 0) {
				int idx = addr.Find(_T("/"));
				if (idx != -1) {
					addr = addr.Left(idx);
				}
				pApp->ConnectAddr(addr);
				dealed = true;
			}
			else if (proto.CompareNoCase(_T("ftp")) == 0) {
				OpenFtp(url);
				dealed = true;
			}
		}
	}
	
	if (!dealed) {
		if (bShift) {
			NewIEOpen(url);
		} else {
			OpenFile(url);
			//ShellExecute (m_hWnd, _T ("open"), url, NULL, NULL, SW_SHOW);
		}
	}
}

#if ENABLE_SEARCHBOX
void CMainFrame::OnFocusSearchbox()
{
	CWnd *fw = GetFocus();
	
	if (fw && fw->GetParent() == & (m_wndToolBar.m_wndUrl))
		ActivateView();
	
	//OnActivate(WA_ACTIVE, NULL, FALSE);
	else
		m_wndToolBar.m_wndUrl.SetFocus();
}

#endif//ENABLE_SEARCHBOX

/*
//ID��������
#define ID_FAVORITESITE1                32844
#define ID_FAVORITESITE2                32845
#define ID_FAVORITESITE3                32846
#define ID_FAVORITESITE4                32847
#define ID_FAVORITESITE5                32848
*/
/*
��ֵ����
g_bMenuFavTop	g_nFavoriteSite>0	del ID_MENU_SEPARATOR	del ID_FAVORITESITE		show top menu
0				0							1						1						0
0				1							1						1*						0
1				0							1						1						0
1				1							0						1						1
1*: ����ɾ��
*/
// ���⣺�ڴӵ�ַ����̬�ı�favoriatesʱ����α�˵���ҲҪ�����������ɾ��������ֻ��ɾ����������
void CMainFrame::SetMenuFav()
{
	//TRACE(_T("in SetMenuFav()\n"));
	CMenu *pMainMenu = GetMenu(); //m_Child.nChild>0ʱΪIDR_CTERMTYPE������ΪIDR_MAINFRAME
	CMenu *pFileMenu = NULL;
	
	if (pMainMenu)
		pFileMenu = pMainMenu->GetSubMenu(m_Child.nChild > 0 ? 1 : 0);  //"�ļ�"
	
	if (pFileMenu == NULL) return;
	
	// ��������˵���bug����ʱ�취
	// ��ִ�����¶������к�IDR_CTERMTYPE���ͼ�����һ��:
	// ���Ӵ���ʱAlt+M���ز˵�, �˳�Alt+M��ʾ�˵���������
	if (!::IsMenu(pFileMenu->m_hMenu)) {
		pFileMenu = pMainMenu->GetSubMenu(2);
	}
	if (!::IsMenu(pFileMenu->m_hMenu)) return;
	
	int idx;

	{
		// ɾ��ԭ����
		// �����Favorite���Ҳ���ʾ����˵���ֻɾ���������ȫɾ...��Ϊ���������ȫɾ�ˣ�ɾ��������
		int delstart = 0; //(!g_bMenuFavTop && g_nFavoriteSite>0) ? g_nFavoriteSite : 0;
		
		for (idx = delstart; idx < MAX_FAVORITE_NUM; idx++) {
#if ENABLE_COOLMENU
			{
				// ��ɾ���˵���(��SEPARATOR)֮ǰ, ���������Ƿ���δdelete���Զ�������
				MENUITEMINFO info;
				info.cbSize = sizeof(MENUITEMINFO);  // must fill up this field
				info.fMask = MIIM_DATA; //get dwItemData member
				info.dwItemData = NULL;
				//pFileMenu->GetMenuItemInfo (ID_FAVORITESITE1 + idx, &info);
				pMainMenu->GetMenuItemInfo(ID_FAVORITESITE1 + idx, &info);  //��pFileMenu��pMainMenu�õ��Ľ����һ����
				
				CMyItemData *pmd = (CMyItemData*) info.dwItemData;
				
				if (pmd && pmd->IsMyItemData()) {
					delete pmd;
				}
			}
#endif//ENABLE_COOLMENU

			// ɾ��ԭ����fav�˵���
			// ����ӣ�����ر����д��ڣ������Ӿͻ���һ��
			// ����ɾ������, pFileMenuҪ��pMainMenu֮ǰ;�������ζ���pMainMenu, ǰһ������ɾ���ļ��˵�����Ӧ����
			if (::IsMenu(pFileMenu->m_hMenu)) {
				pFileMenu->DeleteMenu(ID_FAVORITESITE1 + idx, MF_BYCOMMAND);
			}
			
			pMainMenu->DeleteMenu(ID_FAVORITESITE1 + idx, MF_BYCOMMAND);
		}
		
		// ɾ���ļ��˵��϶���ķָ���
		//static SEPARATOR_inserted=false;
		if (pFileMenu && ::IsMenu(pFileMenu->m_hMenu)) {
			// �����ID_SEPARATOR + 1 �ں���InsertMenu(ID_APP_EXIT, MF_BYCOMMAND | MF_SEPARATOR, ID_SEPARATOR + 1);��ָ��
			// ����ֱ����ID_SEPARATOR����Ϊ���ֵΪ0��������˵���Ĭ��ID��0�������зָ�������0

			//int idx = m_Child.nChild > 0 ? 10 : 5;  // վ��ȫɾ���󣬷ָ�����λ��; �����ǰ���Ӳ˵�������Ҫ�޸�...����λ��

			UINT state = pFileMenu->GetMenuState(ID_SEPARATOR + 1, MF_BYCOMMAND);
			if (state != 0xFFFFFFFF && state & MF_SEPARATOR) {
				pFileMenu->DeleteMenu(ID_SEPARATOR + 1, MF_BYCOMMAND);
			}
		}
	}

#if ENABLE_MENUFAVTOP
	ToggleFakeMenu(pMainMenu);
#endif//ENABLE_MENUFAVTOP
	
	// �ļ��˵��µ�վ������OnUpdateFavoritesites����ʾ��
	// �������޷�������Ŀ
	// �����ڴ�����
	if (g_nFavoriteSite > 0) {
		// ����Fav�˵���
		for (idx = 0; idx < g_nFavoriteSite; idx++) {
			//����վ���39
			CString sTitle(g_szFavoriteSite[idx]);
			int pos = sTitle.Find('-');
			
			if (pos != -1) {
				sTitle = sTitle.Right(sTitle.GetLength() - pos - 1);
			}
			
			CString s;
			
			s.Format(_T("%s(&%1d)"), sTitle, idx + 1);
			
#if ENABLE_MENUFAVTOP
			if (g_bMenuFavTop && pMainMenu)
				pMainMenu->AppendMenu(MF_STRING, ID_FAVORITESITE1 + idx, s);
#endif//ENABLE_MENUFAVTOP
			
			if (pFileMenu && ::IsMenu(pFileMenu->m_hMenu))
				pFileMenu->InsertMenu(ID_APP_EXIT, MF_BYCOMMAND, ID_FAVORITESITE1 + idx, s);
		}
		
		// ���ӷָ���
		if (pFileMenu && ::IsMenu(pFileMenu->m_hMenu)) {
			pFileMenu->InsertMenu(ID_APP_EXIT, MF_BYCOMMAND | MF_SEPARATOR, ID_SEPARATOR + 1);
			//SEPARATOR_inserted=true;
		}
	}
	
	DrawMenuBar();
}

#if ENABLE_MENUFAVTOP
// ����/ɾ����α�˵��������favoriate sites on top menu
// g_bMenuFavTopʱ���ӣ�����ɾ��
// m_Child.nChild > 0ʱ��ֻ����/ɾ��ID_MENU_SEPARATOR5
void CMainFrame::ToggleFakeMenu(CMenu *pMainMenu)
{
	bool ret;// temply
	// ɾ�������˵��ϵ�α�˵���
	// ����4��α�˵�����վ�㲻��ʾ�ڶ��������վ��ʱ��Ҫɾ��
	// ����֮ǰҲɾ���������Խ��Խ��
	if (m_Child.nChild <= 0) {
		ret = pMainMenu->DeleteMenu(ID_MENU_SEPARATOR1, MF_BYCOMMAND);
		ret = pMainMenu->DeleteMenu(ID_MENU_SEPARATOR2, MF_BYCOMMAND);
		ret = pMainMenu->DeleteMenu(ID_MENU_SEPARATOR3, MF_BYCOMMAND);
		ret = pMainMenu->DeleteMenu(ID_MENU_SEPARATOR4, MF_BYCOMMAND);
	}
	else {
		ret = pMainMenu->DeleteMenu(ID_MENU_SEPARATOR5, MF_BYCOMMAND);
	}
	
	// ��ɾ��������
	if (g_bMenuFavTop && g_nFavoriteSite > 0) {
		// ����α�˵������һ�
		if (m_Child.nChild <= 0) {
			ret = pMainMenu->InsertMenu(GetSubMenuPos(pMainMenu, 'I'),	MF_BYPOSITION | MF_DISABLED | MF_GRAYED, ID_MENU_SEPARATOR1, _T("�༭(&E)"));
			int pos = GetSubMenuPos(pMainMenu, g_bShowUserMenu ? 'U' : 'T');
			if (pos == 0) pos = GetSubMenuPos(pMainMenu, 'T');
			ret = pMainMenu->InsertMenu(pos, MF_BYPOSITION | MF_DISABLED | MF_GRAYED, ID_MENU_SEPARATOR2, _T("&BBS"));
			ret = pMainMenu->InsertMenu(GetSubMenuPos(pMainMenu, 'H'),	MF_BYPOSITION | MF_DISABLED | MF_GRAYED, ID_MENU_SEPARATOR3, _T("����(&W)"));
			ret = pMainMenu->AppendMenu(MF_STRING | MF_DISABLED | MF_GRAYED, ID_MENU_SEPARATOR4, _T("|"));
		}
		else {
			ret = pMainMenu->AppendMenu(MF_STRING | MF_DISABLED | MF_GRAYED, ID_MENU_SEPARATOR5, _T("|"));
		}
	}

}
#endif//ENABLE_MENUFAVTOP

#if ENABLE_FUNKEY
void CMainFrame::SetUserMenu()
{
	if (g_bShowUserMenu) {
		CMenu* pMainMenu = GetMenu();
		
		if (pMainMenu && m_UserMenu) {
			pMainMenu->RemoveMenu(GetSubMenuPos(pMainMenu, 'U'),
				MF_BYPOSITION);//�Զ���
			
			m_UserMenu->Detach();
			m_UserMenu->DestroyMenu();
			//delete m_UserMenu;
		}
		else {
			m_UserMenu = new CMenu(); //���ܵ�2��new
		}
		
		if (m_UserMenu) {
			m_UserMenu->CreatePopupMenu();
			
			CString sInfo;
			
			sInfo.LoadString(IDS_SETUP_KEY);
			
			m_UserMenu->AppendMenu(MF_STRING, ID_SETUP_KEY, sInfo);  // &C
		}
		
		if (pMainMenu && m_UserMenu) {
			pMainMenu->InsertMenu(GetSubMenuPos(pMainMenu, 'T'),
				MF_BYPOSITION | MF_POPUP | MF_STRING, (UINT) m_UserMenu->m_hMenu, g_LoadString(IDS_CUSTOMIZED));
		}
	}
}
#endif//ENABLE_FUNKEY

void CMainFrame::DockControlBarLeftOf(CControlBar* Bar, CControlBar* LeftOf)
{
	CRect rect;
	DWORD dw;
	UINT n;
	
	// get MFC to adjust the dimensions of all docked ToolBars
	// so that GetWindowRect will be accurate
	RecalcLayout(TRUE);
	
	LeftOf->GetWindowRect(&rect);
	rect.OffsetRect(1, 0);
	dw = LeftOf->GetBarStyle();
	n = 0;
	n = (dw &CBRS_ALIGN_TOP)				 ? AFX_IDW_DOCKBAR_TOP		: n;
	n = (dw &CBRS_ALIGN_BOTTOM	&& n == 0) ? AFX_IDW_DOCKBAR_BOTTOM	: n;
	n = (dw &CBRS_ALIGN_LEFT		&& n == 0) ? AFX_IDW_DOCKBAR_LEFT		: n;
	n = (dw &CBRS_ALIGN_RIGHT	&& n == 0) ? AFX_IDW_DOCKBAR_RIGHT	: n;
	
	// When we take the default parameters on rect, DockControlBar will dock
	// each Toolbar on a seperate line. By calculating a rectangle, we in effect
	// are simulating a Toolbar being dragged to that location and docked.
	DockControlBar(Bar, n, &rect);
}

#ifdef FOR_BYHH
void CMainFrame::OnBbsWeb() // ת�������µ�Webҳ for byhh
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (!pFrame || !pFrame->m_pView)
		return;
	
	if (!_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".byhh.")) && !_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".whnet.")))
		return;
	
	SITESTATUS nSta = pFrame->m_pView->GetStatus();
	
	SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
	
	if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {
		TCHAR buf[256];
		TCHAR board[20], ts[30];
		int  idx, sx, ex;
		
		pFrame->m_pView->m_Core.GetLineStr(buf, 0);	//����: SYSOP                    �� վ�������빫��                 ������ [sysop]
		ex = _tcslen(buf);
		
		while (ex > 0 && buf[ex] != ']') ex--;
		
		if (ex == 0) return;
		
		sx = ex;
		
		while (sx > 0 && buf[sx] != '[') sx--;
		
		if (sx == 0 || ex - sx > 18) return;
		
		sx++;
		
		_tcsncpy(board, buf + sx, ex - sx);
		
		board[ex-sx+1] = '\0';
		
		pFrame->m_pView->m_Core.GetLineStr(buf, pFrame->m_pView->m_Core.m_cursor.y);
		
		//>2216 + Anima        Nov 20  �� web����ͼƬ��ô�޷���ʾ��
		sx = 0;
		
		while (sx < 5 && !_tcschr(_T("123456789"), buf[sx])) sx++;
		
		ex = sx;
		
		while (ex < 10 && buf[ex] != ' ') ex++;
		
		_tcsncpy(ts, buf + sx, ex - sx);
		
		ts[ex-sx+1] = '\0';
		
		idx = _ttoi(ts);
		
		if (idx > 0)
			BYHHID2WEB(board, idx);
		
		//CWnd *pWndChild = GetWindow(GW_CHILD);
		//GetWindow(ID_BBS_WEB)->EnableWindow(0);
		//GetDlgItem(IDC_CHK_PYTHONSTATUS)->EnableWindow(m_bEnablePython);
	}
}

void CMainFrame::OnUpdateBbsWeb(CCmdUI* pCmdUI)		// ת�������µ�Webҳ for byhh �Ƿ����
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	
	if (pFrame && pFrame->m_pView && ((_tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".byhh."))) || _tcsstr(pFrame->m_pView->m_Site.m_Login.m_szAddr, _T(".whnet.")))) {
		SITESTATUS nSta = pFrame->m_pView->GetStatus();
		SITESTATUS nSub = pFrame->m_pView->m_Status.SubStatus();
		
		if (nSta == SST_LIST && nSub == SST_LIST_ARTICLE) {
			pCmdUI->Enable();
			return;
		}
	}
	
	pCmdUI->Enable(0);
}

#endif//FOR_BYHH

#if ENABLE_PYTHON
// ���³�ʼ��pythonִ�л���
void CMainFrame::OnReinitPython()
{
	g_bEnablePython = true;
	
	if (g_bPythonInited) {
		FinalizePython();
	}
	
	InitPython();
}

#endif//ENABLE_PYTHON

//////////////////////////////////////////////////////////////////////
//				CMainFrame ��Ϣ��������

#if defined(ENABLE_VBS) || defined(ENABLE_PYTHON)
void CMainFrame::OnRunScript()
{
	CFileDialogEx fd(TRUE, NULL, NULL, OFN_NOCHANGEDIR | OFN_HIDEREADONLY,
		_T("�ű��ļ�(.py;.vbs;.js;.txt)|*.py;*.vbs;*.js;*.txt|�����ļ�(*.*)|*.*||"));
	
	if (fd.DoModal() == IDOK) {
		CString s = fd.GetFileExt(); //������չ���жϽű�����
		
		if (!s.CompareNoCase(_T("py"))) {
#if ENABLE_PYTHON
			//extern void RunPythonScriptNoThread (const char *filename, int nSessionID);
			RunPythonScript(fd.GetPathName(), m_Child.nChild > 0 ? m_Child.nIDs[m_Child.nActive] : -1);  //pythonֱ�ӵ���execfile()
			//			RunPythonScriptNoThread (fd.GetPathName(), m_Child.nChild > 0 ? m_Child.nIDs[m_Child.nActive] : -1);
#endif
		} else {
#if ENABLE_VBS
			
			if (LoadScriptText(fd.GetPathName())) {
				if (!s.CompareNoCase(_T("js")))
					RunJavaScript();
				else //Ĭ��vbs�ű�
					RunVBScript();
			}
			
#endif// ENABLE_VBS
		}
	}
}
#endif

#if ENABLE_SYSCONFIG

extern void SysSetup();
void CMainFrame::OnSysSetup()
{
	SysSetup();
}

void CMainFrame::OnReloadconfig()
{
	LoadWindowConfig();
	
	SetStatus(ID_SEPARATOR, _T("configuration updated"));
	
	if (!g_bCaretBlink) {
		// �л����
		for (int i = 0; i < m_Child.nChild; i++) {
			if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView) {
				m_Child.pFrames[i]->m_pView->SwitchCaretBlink();
			}
		}
	}
}

void CMainFrame::OnAutosaveconfig()
{
	g_bAutoSaveConfig = !g_bAutoSaveConfig;
}

void CMainFrame::OnUpdateAutosaveconfig(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(g_bAutoSaveConfig);
}

void CMainFrame::OnSaveconfig()
{
	SaveWindowConfig();
}
#endif//ENABLE_SYSCONFIG

//void CMainFrame::OnBoldFont()
//{
//	g_bBold = !g_bBold;
//	RefreshAll();
//}

//void CMainFrame::OnUpdateBoldFont(CCmdUI* pCmdUI)
//{
//	pCmdUI->SetCheck(g_bBold);
//}

#if ENABLE_MULTILANG

//��iniװ����������,�������Բ˵�
void CMainFrame::LoadAllLanguage()
{
	bool bMatched = false;
	
	if (g_LangMenu) {
		g_LangMenu->DestroyMenu();
		g_LangMenu->Detach();
		delete g_LangMenu;
		g_LangMenu = NULL;
	}
	
	{
		g_LangMenu = new CMenu(); //���ܵ�2��new
		g_LangMenu->CreatePopupMenu();
		
		
		// �ڲ�Ĭ������(��������)
		g_LangMenu->AppendMenu(MF_STRING | MF_CHECKED, ID_LANG1, _T("Ĭ������(&D)"));
		int i = 1;
		
		CString szKey = _T("Language"), szSection = _T("Setting");
		
		DWORD dwSize = 1000;
		CString szLang;
		GetPrivateProfileString(szSection, szKey, DEFAULT_LANG, szLang.GetBuffer(dwSize), dwSize, g_szSettingPath);
		szLang.ReleaseBuffer();
		
		//m_cmbLang.SelectString(-1,szLang);
		
		CFileFind find;
		bool ret = find.FindFile(g_szWorkDir + _T("Language\\*.ini"));
		
		while (ret) {
			ret = find.FindNextFile();
			
			if (find.IsDots() || find.IsDirectory()) continue;
			
			CString szValue;
			
			DWORD dwSize = 100;
			
			CString file = find.GetFilePath();
			
			if (GetPrivateProfileString(szSection, szKey, _T(""),
				szValue.GetBuffer(dwSize), dwSize, file) != 0) {
				g_LangMenu->AppendMenu(MF_STRING | MF_CHECKED, ID_LANG1 + i, szValue);
				szValue.ReleaseBuffer();
				g_langStr[i] = szValue;
				
				if (!bMatched && szLang == szValue) {
					g_currLangID = ID_LANG1 + i;
					bMatched = true;
				}
				
				i++;
			} else
				szValue.ReleaseBuffer();
			
		}
		
		find.Close();
	}
	
	if (!bMatched) {
		g_currLangID = ID_LANG1;
	}
}

void CMainFrame::AddLangMenu(CMenu *pMainMenu)
{
	if (pMainMenu && g_LangMenu) {
	/*
				CString s;
				pMainMenu->GetMenuString(2, s, MF_BYPOSITION);
				g_LangMenu->GetMenuString(0, s, MF_BYPOSITION);
		*/
		CMenu* subMenu = pMainMenu->GetSubMenu(GetSubMenuPos(pMainMenu, 'I'));  //view
		subMenu->AppendMenu(MF_BYPOSITION | MF_POPUP | MF_STRING, (UINT) g_LangMenu->m_hMenu, _T("&Language"));
		DrawMenuBar();
	}
}

void CMainFrame::OnLang(UINT nID)
{
	if (nID != g_currLangID) {
		g_currLangID = nID;
		CString szValue = g_langStr[nID-ID_LANG1];
		//������������
		WritePrivateProfileString(_T("Setting"), _T("Language"), szValue, g_szSettingPath);
		
		//if (g_currLangID>ID_LANG1)
		{
			((CCTermApp*) AfxGetApp())->LoadLanguage(szValue); //?
			
			//�ı�˵�����
			//SetMenuStrings();
			CMenu *pMainMenu = g_pMainWnd->GetMenu();
			
			if (pMainMenu) {
				g_SetMenuStrings(pMainMenu, _T(""));
				
#if ENABLE_FUNKEY
				
				if (g_bShowUserMenu && m_UserMenu) {
					CString sInfo;
					sInfo.LoadString(m_bKeyUpdating ? IDS_SETUP_KEY : IDS_UPDATE_KEY); //������
					m_UserMenu->ModifyMenu(0, MF_BYPOSITION | MF_STRING, ID_SETUP_KEY, sInfo);
					
					pMainMenu->ModifyMenu(GetSubMenuPos(pMainMenu, 'U'), MF_BYPOSITION, 0, g_LoadString(IDS_CUSTOMIZED));
					//	g_LoadString(m_bKeyUpdating ? IDS_SETUP_KEY : IDS_UPDATE_KEY));
				}
				
#endif//ENABLE_FUNKEY
				
				DrawMenuBar();		//ˢ�²˵���ʾ
			}
		}
	}
}

void CMainFrame::OnUpdateLang(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(pCmdUI->m_nID == g_currLangID);
}

#endif// ENABLE_MULTILANG

//tray �Ҽ��˵�;����ͬOnTrayMenu(), WM_LBUTTONUP
void CMainFrame::OnMainRestore()
{
	PopupSelf();
}

// �ϴ������ļ����÷���
// �ȷ��ģ���U����༭״̬��Esc-Z����ʾ�ļ��ϴ���ַ
// Ȼ����python SendCommand(ID_UPONEFILE)����
// �˵��������ˣ���useless�˵���
void CMainFrame::OnUponefile()
{
#if ENABLE_PYTHON
	
	if (g_pMainWnd && g_bEnablePython && g_bSysPythonScriptLoaded) {
		CFileDialogEx fd(TRUE, _T(""), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("�����ļ�(*.*)|*.*||"));
		
		if (fd.DoModal() == IDOK) {
			CString s = fd.GetPathName();
			s.Replace(_T("\\"), _T("\\\\"));
			CString code;
			code.Format(_T("uponefile(r\"%s\")"), s);
			RunPythonCode(code);
		}
	}
	
#endif //ENABLE_PYTHON
}

void CMainFrame::SetStatus(UINT id, CString txt)
{
#if ENABLE_MMSTATUSBAR
	m_wndStatusBar.SetPaneText(id, txt);
#else
	m_wndStatusBar.SetPaneText(m_wndStatusBar.CommandToIndex(id), txt);
#endif//ENABLE_MMSTATUSBAR
}

#if ENABLE_UPDATE
#include "UpdateDlg.h"
extern TCHAR g_szUpdateBuf[];
extern int g_iUserSelection;
// �������¶Ի���
LRESULT CMainFrame::OnUpdateDlg(WPARAM wParam, LPARAM lParam)
{
	CUpdateDlg dlg;
	dlg.m_strVersionInfo = g_szUpdateBuf;
	
	if (dlg.DoModal() == IDOK)
		g_iUserSelection = 0;
	else
		g_iUserSelection = 1;
	
	return 1;
}

#endif//ENABLE_UPDATE

//void CMainFrame::ShowBallon(LPCTSTR title, LPCTSTR text, UINT type, UINT timeout)
//{
//TRACE("_WIN32_IE=%x\n", _WIN32_IE);
//TRACE("WINVER=%x\n", WINVER);
////
////	if(timeout < 0)return;
////	NOTIFYICONDATA data;
////	data.cbSize = sizeof(data);
////	data.hWnd = m_hWnd;
////	data.uID = 0;
////	data.uTimeoutOrVersion = timeout;
////	data.szInfoTitle = title;
////	data.szInfo = text;
////	data.dwInfoFlags = (DWORD)type; //Error=0x03, Info=0x01, None=0x00, Warning=0x02
////
////	Shell_NotifyIcon(0x01, &data); //Add=0x00,   Delete=0x02,   Modify=0x01
//}

LRESULT CMainFrame::OnTaskBarCreated(WPARAM wParam, LPARAM lParam)
{
	if (m_bTrayIconVisible) {
		BOOL bResult = Shell_NotifyIcon(NIM_ADD, &m_nid);
		
		if (!bResult)
			m_bTrayIconVisible = false;
	}
	
	return 0;
}

// view�����ʱcx, cy, flags��������������
bool CMainFrame::NeedAutoSize(int cx, int cy,
							  int &ncx, int &ncy,
							  int &ncx1, int &ncy1,
							  int &ncx2, int &ncy2,
							  int &maxsw, int &maxsh,
							  UINT flags)
{
	bool b = false;
	
	if (g_bAutoSize 
		&& !IsZoomed()
#if ENABLE_FULLSCRN
		&& !IsFullScreen()
#endif//ENABLE_FULLSCRN
		&& !IsIconic()
		&& (flags & SWP_NOSIZE) == 0)
	{
		BOOL bMaximized;
		CMDIChildWnd *pActive = MDIGetActive(&bMaximized);
		if (pActive && bMaximized && m_Child.nChild > 0) {
			CRect rect, rect1;
			GetWindowRect(&rect);
			m_Child.pFrames[0]->m_pView->GetClientRect(&rect1);
			int ncx0 = rect.Width() - rect1.Width(), ncy0 = rect.Height() - rect1.Height();
			//TRACE(_T("in CMainFrame::OnWindowPosChanging, ncx0=%d ncy0=%d\n"), ncx0, ncy0);
			
			pActive->GetWindowRect(&rect1);
			//GetClientRect(&rect1);// ���������nc������������
			ncx = rect.Width() - rect1.Width(), ncy = rect.Height() - rect1.Height();
			//			TRACE(_T("in CMainFrame::OnWindowPosChanging, ncx=%d ncy=%d\n"), ncx, ncy);
			
			pActive->GetWindowRect(&rect);
			pActive->GetClientRect(&rect1);
			ncx1 = rect.Width() - rect1.Width(), ncy1 = rect.Height() - rect1.Height();
			//			TRACE(_T("in CMainFrame::OnWindowPosChanging, ncx1=%d ncy1=%d\n"), ncx1, ncy1);
			
			//pActive->GetClientRect(&rect1) == pActive->m_pView->GetWindowRect(&rect)?
			
			m_Child.pFrames[0]->m_pView->GetWindowRect(&rect);
			//ASSERT(rect.Width() == rect1.Width());
			//ASSERT(rect.Height() == rect1.Height());
			m_Child.pFrames[0]->m_pView->GetClientRect(&rect1);
			ncx2 = rect.Width() - rect1.Width(), ncy2 = rect.Height() - rect1.Height();
			//			TRACE(_T("in CMainFrame::OnWindowPosChanging, ncx2=%d ncy2=%d\n"), ncx2, ncy2);
			
			int ncxall = ncx + ncx1 + ncx2;
			int ncyall = ncy + ncy1 + ncy2;
			
			if (ncxall > 0 && ncxall > 0) {
				int cw, ch, sw, sh;
				maxsw = 0, maxsh = 0;
				for (int i = 0; i < m_Child.nChild; i++) {
					if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView) {
						m_Child.pFrames[i]->m_pView->ComputeCharSize(cx - ncxall, cy - ncyall, cw, ch);
						sw = cw * m_Child.pFrames[i]->m_pView->TermW() / 2;
						sh = ch * m_Child.pFrames[i]->m_pView->TermH();
						if (sw > maxsw) maxsw = sw;
						if (sh > maxsh) maxsh = sh;
					}
				}
				//				TRACE(_T("in CMainFrame::OnWindowPosChanging, maxsw=%d maxsh=%d\n"), maxsw, maxsh);
				b = true;
			}//ncx > 0 && ncy > 0
		}//pActive
	}//g_bAutoSize
	
	return b;
}

void CMainFrame::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos)
{
	int ncx, ncy, maxsw, maxsh;
	int ncx1, ncy1, ncx2, ncy2;
	if (NeedAutoSize(lpwndpos->cx, lpwndpos->cy, ncx, ncy, ncx1, ncy1, ncx2, ncy2, maxsw, maxsh, lpwndpos->flags)) {
		lpwndpos->cx = ncx + ncx1 + ncx2 + maxsw; // 4���֣�(main.nc + child.nc + view.nc) + view.client, ����ǰ3���ֺ�����Ϊncx
		lpwndpos->cy = ncy + ncy1 + ncy2 + maxsh;
	}
	
	CMDIFrameWnd::OnWindowPosChanging(lpwndpos);
}

LRESULT CMainFrame::OnUnInitMenuPopup(WPARAM wParam, LPARAM lParam)
{
	extern bool g_bMenuPoping;
	g_bMenuPoping = false;
	//TRACE("CMainFrame::OnUnInitMenuPopup\n");
	
	return 1;
}


void CMainFrame::OnToggleansi() 
{
	DoCopy(g_bAnsiCP = !g_bAnsiCP);
}

void CMainFrame::OnUpdateToggleansi(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_bAnsiCP);	
}

#if ENABLE_CAPTIONBUTTON
LRESULT CMainFrame::OnCBLButtonClicked(WPARAM wParam, LPARAM lParam)
{
	CMDIChildWnd *pChild = MDIGetActive();
	if (pChild) {
		switch (wParam) {
		case CB_CLOSE:
			pChild->SendMessage(WM_CLOSE, 0, 0);
			break;
		case CB_MAX:
			//pChild->ShowWindow(pChild->IsZoomed() ? SW_RESTORE : SW_MAXIMIZE);
			pChild->SendMessage(WM_SYSCOMMAND, pChild->IsZoomed() ? SC_RESTORE : SC_MAXIMIZE);
			break;
		case CB_MIN:
			//pChild->ShowWindow(SW_MINIMIZE);
			pChild->SendMessage(WM_SYSCOMMAND, SC_MINIMIZE);
			break;
		}
	}
	
	return 1L;
}
#endif//ENABLE_CAPTIONBUTTON

#if ENABLE_SYSCONFIG
// �����޷���ֱ�Ӽ���Ч������Ҫ������Ч�Ĳ���
LRESULT CMainFrame::UpdateParam(WPARAM wParam, LPARAM lParam)
{
	if (m_Child.nChild > 0) {
		m_wndSwitchBar.tab()->SetMinTabWidth(g_nTabWidMin);
		CString title;
		for (int i = 0; i < m_Child.nChild; ++i) {
			CChildFrame *pChild = m_Child.pFrames[i];
			if (pChild) {
				title = pChild->GetTabTitle();
				TCITEM tcItem;
				tcItem.pszText = title.LockBuffer();
				tcItem.mask = TCIF_TEXT;
				m_wndSwitchBar.tab()->SetItem(i, &tcItem);
				title.UnlockBuffer();
			}
		}
	}
	
	if (g_bEnablePython)
		OnReinitPython();
	
#if ENABLE_PICTURE
	if (g_pPicShowDlg)
		g_pPicShowDlg->SetBgColor();
#endif//ENABLE_PICTURE
	
	for (int i = 0; i < m_Child.nChild; i++) {
		if (m_Child.pFrames[i] && m_Child.pFrames[i]->m_pView) {
			m_Child.pFrames[i]->m_pView->Send("\x0c", 1);    //^L
			m_Child.pFrames[i]->m_pView->Refresh();//OnEraseBkgnd &redraw &fixpostion
#if ENABLE_EDITBOX
			m_Child.pFrames[i]->m_pView->SetPopEditDlg(g_bPopEditDlg);
#endif//ENABLE_EDITBOX
			
			if (!g_bUseMouse) {
				m_Child.pFrames[i]->m_pView->ClearSelect();
				m_Child.pFrames[i]->m_pView->SetClickRect();
			}
		}
	}
	
	return 1L;
}
#endif//ENABLE_SYSCONFIG

void CMainFrame::FastAway(int i)
{
	CChildFrame *pFrame = GetNthFrame(i);
	
	if (pFrame && pFrame->m_pView) {
		SwitchView(i);
		pFrame->m_pView->FastAway();
	}
	
	ActivateView();
}

void CMainFrame::OnAlwaystop() 
{
	if (m_bTopMost) {
		SetWindowPos(&wndNoTopMost, 0, 0, 0, 0,
			SWP_NOMOVE | SWP_NOSIZE); 
	}
	else {
		SetWindowPos(&wndTopMost, 0, 0, 0, 0,
			SWP_NOMOVE | SWP_NOSIZE); 
	}
	m_bTopMost = !m_bTopMost;
	
	CMenu *pSys = GetSystemMenu(FALSE);
	pSys->CheckMenuItem(ID_ALWAYSTOP, (m_bTopMost ? MF_CHECKED : MF_UNCHECKED) | MF_BYCOMMAND);
}

void CMainFrame::OnWebGo() 
{
	OpenURL();
}

void CMainFrame::OnUpdateAlwaystop(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bTopMost);
}

void CMainFrame::OnViewMin() 
{
	ShowControlBar(&m_wndToolBar, FALSE, TRUE);
#if ENABLE_SWITCHBAR
	ShowControlBar(&m_wndSwitchBar,FALSE, TRUE);
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
	ShowControlBar(m_pKeyBar, FALSE, TRUE);
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
	ShowControlBar(&m_wndBbsBar, FALSE, TRUE);
#endif//ENABLE_BBSBAR
	ShowControlBar(&m_wndStatusBar, FALSE, TRUE);
#if ENABLE_ASCIIBAR
	ShowControlBar(&m_wndAsciiBar, FALSE, TRUE);
#endif//ENABLE_ASCIIBAR
	ShowControlBar(&m_wndScrollBar, FALSE, TRUE);
#if ENABLE_HIDEMENU
	ToggleMenu(false);
#endif//ENABLE_HIDEMENU
}

void CMainFrame::OnViewMax() 
{
	ShowControlBar(&m_wndToolBar, TRUE, TRUE);
#if ENABLE_SWITCHBAR
	ShowControlBar(&m_wndSwitchBar,TRUE, TRUE);
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
	ShowControlBar(m_pKeyBar, TRUE, TRUE);
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
	ShowControlBar(&m_wndBbsBar, TRUE, TRUE);
#endif//ENABLE_BBSBAR
	ShowControlBar(&m_wndStatusBar, TRUE, TRUE);
#if ENABLE_ASCIIBAR
	ShowControlBar(&m_wndAsciiBar, TRUE, TRUE);
#endif//ENABLE_ASCIIBAR
	ShowControlBar(&m_wndScrollBar, TRUE, TRUE);
#if ENABLE_HIDEMENU
	ToggleMenu(true);
#endif//ENABLE_HIDEMENU
}

void CMainFrame::OnViewSimple() 
{
	ShowControlBar(&m_wndToolBar, FALSE, TRUE);
#if ENABLE_SWITCHBAR
	ShowControlBar(&m_wndSwitchBar,FALSE, TRUE);
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
	ShowControlBar(m_pKeyBar, FALSE, TRUE);
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
	ShowControlBar(&m_wndBbsBar, FALSE, TRUE);
#endif//ENABLE_BBSBAR
	ShowControlBar(&m_wndStatusBar, TRUE, TRUE);
#if ENABLE_ASCIIBAR
	ShowControlBar(&m_wndAsciiBar, FALSE, TRUE);
#endif//ENABLE_ASCIIBAR
	ShowControlBar(&m_wndScrollBar, g_bCacheHistory, TRUE);
#if ENABLE_HIDEMENU
	ToggleMenu(true);
#endif//ENABLE_HIDEMENU
}

void CMainFrame::OnViewCompact() 
{
	ShowControlBar(&m_wndToolBar, TRUE, TRUE);
#if ENABLE_SWITCHBAR
	ShowControlBar(&m_wndSwitchBar,TRUE, TRUE);
#endif//ENABLE_SWITCHBAR
#if ENABLE_FUNKEY
	ShowControlBar(m_pKeyBar, FALSE, TRUE);
#endif//ENABLE_FUNKEY
#if ENABLE_BBSBAR
	ShowControlBar(&m_wndBbsBar, FALSE, TRUE);
#endif//ENABLE_BBSBAR
	ShowControlBar(&m_wndStatusBar, TRUE, TRUE);
#if ENABLE_ASCIIBAR
	ShowControlBar(&m_wndAsciiBar, FALSE, TRUE);
#endif//ENABLE_ASCIIBAR
	ShowControlBar(&m_wndScrollBar, g_bCacheHistory, TRUE);
#if ENABLE_HIDEMENU
	ToggleMenu(true);
#endif//ENABLE_HIDEMENU
}

void CMainFrame::OnShowPosts() 
{
	CString s = g_szWorkDir + _T("user\\mypost.txt");
	ShellExecute(NULL, _T("open"), s, NULL, NULL, SW_SHOWNORMAL);	
}

#if ENABLE_SCREENMAP
LRESULT CMainFrame::OnScrollBar(WPARAM wParam, LPARAM lParam)
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		int pos = (int)wParam;
		pFrame->m_pView->m_Core.ScreenJump(pos);
	}
	
	return 0L;
}
#endif//ENABLE_SCREENMAP

void CMainFrame::OnPaint()
{
	//TRACE("in CMainFrame::OnPaint()\n");
	CPaintDC dc(this); // device context for painting
	
#if ENABLE_SCROLLBAR
	CRect rclient;
	m_wndClient.GetWindowRect(&rclient);
	m_wndScrollBar.SetSize(rclient.Height());
#endif//ENABLE_SCROLLBAR
}

void CMainFrame::OnCloseall() 
{
	if (MessageBox(_T("��Ĺر����д�����"), _T("ȫ���ر�"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
		for (int i = 0; i < m_Child.nChild; i++) {
			if (m_Child.pFrames[i]) {
				m_Child.pFrames[i]->PostMessage(WM_CLOSE); // ��send���У���Ϊsend���1����pFrames�����Ѿ�����
			}
		}
	}
}

void CMainFrame::OnFontscale() 
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		int b = pFrame->m_pView->CharHWRatio();
		pFrame->m_pView->SetCharHWRatio(b ? 0 : 2);
		pFrame->m_pView->Refresh();
	}
}

void CMainFrame::OnConsole() 
{
	//#ifdef _DEBUG // �ݲ�release
	g_bOpenConsole = !g_bOpenConsole;
	//OpenConsole(); // �ݲ�֧�ֺ����򿪣�ֻ֧��������
	//#endif
}

void CMainFrame::OnUpdateConsole(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_bOpenConsole);	
}


BOOL HandlerRoutine(DWORD dwCtrlType) 
{ 
	if(dwCtrlType == CTRL_CLOSE_EVENT) 
	{
		printf("console closing\n");
		//g_bOpenConsole = false;
		
		//FreeConsole();//not work, ��ص�������
		//HWND hc = GetConsoleWindow();
		//HWND hc = ::FindWindow("ConsoleWindowClass", NULL);
		//HWND hc = ::FindWindow(NULL, "CTerm Console");
		
		//::CloseWindow(hc);//ͬ��
		//::DestroyWindow(hc);//ͬ��
		//::ShowWindow(hc, SW_HIDE);//ͬ��
		
		return TRUE;
	}
	else if (dwCtrlType == CTRL_C_EVENT || dwCtrlType == CTRL_BREAK_EVENT)
	{
		return TRUE;
	}
	return FALSE; 
}

bool g_bConsoleExist = false;
void CMainFrame::OpenConsole()
{
	if (g_bOpenConsole) {
		AllocConsole();
		SetConsoleTitle(_T("CTerm Console"));
		freopen("CONOUT$", "w+t", stdout);
		freopen("CONIN$", "r+t", stdin);// Ҳ��Ҫ�����߳�scanf
		freopen("CONIN$", "r+t", stderr);
		
		SetConsoleCtrlHandler((PHANDLER_ROUTINE)HandlerRoutine, TRUE);
		
		HWND hc = GetConsoleWindow(); // �ƺ��ᵼ�´Ӳ˵����ܹر�console������
		HMENU  hm = ::GetSystemMenu(hc, false);
		DeleteMenu(hm, SC_CLOSE, MF_BYCOMMAND);
		
		g_bConsoleExist = true;
		
		//		RunPythonCode("sys.stdout=open('CONOUT$', 'w', 0)\nsys.stderr=sys.stdout\n");//��Ч
		//
		//		LONG st = GetWindowLong(hc, GWL_EXSTYLE); // ����ȥ����������ť
		//		::SetWindowLong(hc, GWL_EXSTYLE, st | WS_EX_TOOLWINDOW); // �ܾ�����
		
		//printf("test on test\n");
	}
	//	else {
	//		FreeConsole();
	//	}
}

void CMainFrame::OnFileDup() 
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		PostMessage(WM_DUPSITE, (WPARAM)&pFrame->m_pView->m_Site, (LPARAM)0);
	}
}

void CMainFrame::OnUpdateFileDup(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_Child.nChild > 0);
}

void CMainFrame::OnFileReconnect() 
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		pFrame->m_pView->ReConnect();
	}
}

void CMainFrame::OnUpdateFileReconnect(CCmdUI* pCmdUI) 
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	pCmdUI->Enable(pFrame && pFrame->m_pView && !pFrame->m_pView->IsStarted());
}

void CMainFrame::RedrawCaptionButtons() {
	extern CCaptionButton g_cbExtra;
	if(m_Child.nChild > 1 && !g_bMenuVisible && g_bCaptionButtons)
		m_cbExtra.RedrawCaptions();
}

void CMainFrame::OnFileCopysite() 
{
	bool ret = false;
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();	
	if (pFrame && pFrame->m_pView) {
		ret = pFrame->m_pView->CopySite();
	}
	else {
		ret = g_LastSite.CopySite();
	}

	if (ret) {
//		CToolTipWnd BalloonToolWnd;
//		BalloonToolWnd.Create(this);
//		BalloonToolWnd.AddTool(NULL, "վ����Ϣ�ѿ���");
		SetStatus(ID_SEPARATOR, "վ����Ϣ�ѿ���");
	}
}

// ȡָ��վ�������
CString CMainFrame::AntiIdleString(const int nSessionID)
{
	CCTermView *pView = GetView(nSessionID);
	if (pView) {
		return pView->AntiIdleString();
	}
	else {
		return g_sAntiIdleStr;
	}
}

void CMainFrame::SetAntiIdleString(const int nSessionID, CString s)
{
	CCTermView *pView = GetView(nSessionID);
	if (pView) {
		pView->SetAntiIdleString(s);
	}
	else {
		g_sAntiIdleStr = s;
	}
}

void CMainFrame::OnUpdateFontscale(CCmdUI* pCmdUI) 
{
	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	if (pFrame && pFrame->m_pView) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(pFrame->m_pView->CharHWRatio());
	}
	else {
		pCmdUI->Enable(FALSE);
	}
}


void CMainFrame::OnBbsSignature() 
{
	g_bBbsSignature=!g_bBbsSignature;
	RefreshAll();
}

void CMainFrame::OnUpdateBbsSignature(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(g_bBbsSignature);	
}
