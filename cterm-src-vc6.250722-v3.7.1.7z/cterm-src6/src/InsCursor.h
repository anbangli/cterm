#if !defined(AFX_INSCURSOR_H__DE54C9C3_0D61_4473_A31C_B72DFC12DD5D__INCLUDED_)
#define AFX_INSCURSOR_H__DE54C9C3_0D61_4473_A31C_B72DFC12DD5D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InsCursor.h : header file
//

#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CInsCursor dialog

class CInsCursor : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CInsCursor)

// Construction
public:
	CInsCursor();
	~CInsCursor();

	CString GetStr();
// Dialog Data
	//{{AFX_DATA(CInsCursor)
	enum { IDD = IDD_INSCURSOR };
	CEdit	m_yctrl;
	CEdit	m_xctrl;
	int		m_x;
	int		m_y;
	int		m_type;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CInsCursor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CInsCursor)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSCURSOR_H__DE54C9C3_0D61_4473_A31C_B72DFC12DD5D__INCLUDED_)
