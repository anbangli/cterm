// MyPropertyPage.cpp : implementation file
//

#include "stdafx.h"
#include "MyPropertyPage.h"

extern CString g_szLanguagePath;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage property page

IMPLEMENT_DYNCREATE(CMyPropertyPage, CPropertyPage)

CMyPropertyPage::CMyPropertyPage(UINT nIDTemplate) : CPropertyPage(nIDTemplate)
{
	//{{AFX_DATA_INIT(CMyPropertyPage)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	//CString sTitle;
//	TCHAR sTitle[21] = _T( "fsssssssss" );
//	UINT IDD = GetIDD();
//	if ( IDD != 0 )
//	{
//		CString szKey;
//		szKey.Format ( _T ( "IDD%d_Title" ), GetIDD() );
//
//		if ( GetPrivateProfileString ( _T ( "Dialog" ), szKey, _T ( "" ),
//			sTitle, 20, g_szLanguagePath ) != 0 )
//		{
//			m_psp.pszTitle = sTitle; //m_strCaption;
//			m_psp.dwFlags |= PSP_USETITLE;
//			//sTitle.UnlockBuffer();
//		}
//	}
}

CMyPropertyPage::CMyPropertyPage() : CPropertyPage()
{
	//{{AFX_DATA_INIT(CMyPropertyPage)
	// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CMyPropertyPage::~CMyPropertyPage()
{
}

void CMyPropertyPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyPropertyPage)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyPropertyPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMyPropertyPage)
	// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyPropertyPage message handlers

UINT CMyPropertyPage::GetIDD()
{
	return 0;
}

CString CMyPropertyPage::GetStr()
{
	return CString(_T(""));
}
