// AutoRun.h: interface for the CAutoRun class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_AUTORUN_H__BB54D88F_E059_4B5D_B8BA_B35EDC1869CC__INCLUDED_)
#define AFX_AUTORUN_H__BB54D88F_E059_4B5D_B8BA_B35EDC1869CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

enum AutoRunStatus {AutoRun_NoWait, AutoRun_Wait, AutoRun_OK, AutoRun_Timeout, AutoRun_Unknown, AutoRun_PreExit};

#include "viewstatus.h"

class CCTermView;
class CAutoRun
{

public:
	clock_t m_nTime;
	void ChangeStatus(int nNextStatus);
	CCTermView *m_pView;
	AutoRunStatus QueryStatus();
	int m_bWait;
	int m_nStatus;
	SITESTATUS m_nWaitViewStatus;
	int m_nNextStatus;
	void Create(CCTermView *pView);
	void EnterNextStage(const TCHAR *buf, int nLen, SITESTATUS nViewStatus, int nNext, int nTimeOut = 30000);
	CAutoRun();
	virtual ~CAutoRun();

private:
	const static int m_nTimeOut;
	int m_nPastTime;
};

#endif // !defined(AFX_AUTORUN_H__BB54D88F_E059_4B5D_B8BA_B35EDC1869CC__INCLUDED_)
