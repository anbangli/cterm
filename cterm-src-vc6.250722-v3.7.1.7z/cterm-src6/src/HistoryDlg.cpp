// HistoryDlg.cpp : implementation file
//

#include "stdafx.h"

#if ENABLE_MESSAGE

#include "HistoryDlg.h"
#include "Ctermview.h"
#include "global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHistoryDlg dialog
void EncodePsw(TCHAR *psw);
void DecodePsw(TCHAR *psw);


CHistoryDlg::CHistoryDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CHistoryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHistoryDlg)
	m_input = _T("");
	m_info = _T("");
	m_pMes = NULL;
	m_nShowType = 2;//Show All
	//}}AFX_DATA_INIT
}


void CHistoryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHistoryDlg)
	DDX_Control(pDX, IDCANCEL, m_cancel);
	DDX_Control(pDX, IDC_SEARCHUP, m_sup);
	DDX_Control(pDX, IDC_SEARCHDOWN, m_sdown);
	DDX_Control(pDX, IDC_OUTFILE, m_output);
	DDX_Control(pDX, IDC_MESLIST, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_INFO, m_info);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHistoryDlg, CDialog)
	//{{AFX_MSG_MAP(CHistoryDlg)
	ON_BN_CLICKED(IDC_INMES, OnInmes)
	ON_BN_CLICKED(IDC_REPLYMES, OnReplymes)
	ON_BN_CLICKED(IDC_ALLMES, OnAllmes)
	ON_NOTIFY(NM_CLICK, IDC_MESLIST, OnClickMeslist)
	ON_BN_CLICKED(IDC_SEARCHUP, OnSearchup)
	ON_BN_CLICKED(IDC_SEARCHDOWN, OnSearchdown)
	ON_BN_CLICKED(IDC_OUTFILE, OnOutfile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistoryDlg message handlers

BOOL CHistoryDlg::OnInitDialog()
{
	CButton *pbut;
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG


#if ENABLE_BTNST
	m_cancel.SetFlat(0);
	m_sup.SetFlat(0);
	m_sdown.SetFlat(0);
	m_output.SetFlat(0);

	//m_cancel.SetIcon(IDI_DELETE);
	//m_sup.SetIcon(IDI_SEARCH);
	//m_sdown.SetIcon(IDI_SEARCH);
	//m_output.SetIcon(IDI_TOTXT);
#endif//ENABLE_BTNST

	m_list.InsertColumn(0, _T("ʱ��"), LVCFMT_LEFT, 120);
	m_list.InsertColumn(1, _T("����"), LVCFMT_LEFT, 350);
	pbut = (CButton *) GetDlgItem(IDC_ALLMES);
	pbut->SetCheck(1);

	if (!m_Image.Create(IDB_MESTYPE, 16, 2, RGB(0, 255, 0))) {
		ASSERT(0);
	}

	m_list.SetImageList(&m_Image, LVSIL_SMALL);

	InitMes();
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CHistoryDlg::InitMes()
{
	FILE *fp;
	TCHAR szFile[300];
	int  nSize, i, j;
	TCHAR ts[300];

	if (m_szPathName.IsEmpty())
		//if (�����ˡ���¼��Ϣ��  m_pwndView->m_bMsgRec = g_bMsgRec;)
		_stprintf(szFile, _T("%s%s-%s.msg"), m_pView->UserPath(), m_pView->m_Site.m_Login.m_szProfileName, m_pszUserName);

	//else
	//	return;
	else
		_tcscpy(szFile, m_szPathName);

	fp = _tfopen(szFile, _T("rb"));

	if (fp == NULL) {
		MessageBox(_T("���ܴ���Ϣ��¼�ļ�! ��������û�����á���¼��Ϣ�����ܣ��������ļ�����"), _T("��ʷ��¼"), MB_OK | MB_ICONERROR);
		OnOK();
		return;
	}

	fread(ts, 200, 1, fp);

	DecodePsw(ts);

	if (m_szPathName.IsEmpty()) {
		i = m_pView->UserPath().GetLength();
		j = _tcslen(ts);

		if (j > i || m_pView->UserPath().Right(j).Compare(ts)) {
			MessageBox(_T("��ʷ��¼�ļ���������!"), _T("��ʷ��¼"), MB_OK | MB_ICONERROR);
			OnOK();
		}
	} else {
		if (!InString(ts, szFile)) {
			MessageBox(_T("��ʷ��¼�ļ���������!"), _T("��ʷ��¼"), MB_OK | MB_ICONERROR);
			OnOK();
		}
	}

	fseek(fp, 0, SEEK_END);

	nSize = ftell(fp) - 200;
	m_pMes = (CMessage *) malloc(nSize);
	fseek(fp, 200, SEEK_SET);
	m_nMes = nSize / sizeof(CMessage);
	m_nMes = fread(m_pMes, sizeof(CMessage), m_nMes, fp);
	fclose(fp);
	UpdateList();
}

CHistoryDlg::~CHistoryDlg()
{
	if (m_pMes) free(m_pMes);
}

void CHistoryDlg::UpdateList()
{
	int i, at;
	TCHAR ts[12*MAX_TERM_WIDTH+1];
	m_list.DeleteAllItems();

	for (i = 0;i < m_nMes;i++) {
		if (m_nShowType == 2 ||
		        (m_nShowType == 0 && !m_pMes[i].bReply) ||
		        (m_nShowType == 1 && m_pMes[i].bReply)) {
			_stprintf(ts, _T("%d %d-%d %d:%d"), m_pMes[i].MesTime.GetYear(),
			          m_pMes[i].MesTime.GetMonth(),
			          m_pMes[i].MesTime.GetDay(),
			          m_pMes[i].MesTime.GetHour(),
			          m_pMes[i].MesTime.GetMinute());
			at = m_list.InsertItem(0, ts, m_pMes[i].bReply ? 1 : 0);
			_tcscpy(ts, m_pMes[i].szMes);
			DecodePsw(ts);
			m_list.SetItemText(at, 1, ts);
			m_list.SetItemData(at, (DWORD) m_pMes[i].szMes);
		}
	}
}

void CHistoryDlg::OnInmes()
{
	m_nShowType = 0;
	UpdateList();
}

void CHistoryDlg::OnReplymes()
{
	m_nShowType = 1;
	UpdateList();
}

void CHistoryDlg::OnAllmes()
{
	m_nShowType = 2;
	UpdateList();
}

void CHistoryDlg::OnClickMeslist(NMHDR* pNMHDR, LRESULT* pResult)
{
	TCHAR ts[MAX_TERM_WIDTH*12+1];
	int pos = (int) m_list.GetFirstSelectedItemPosition() - 1;

	if (pos >= 0) {
		_tcscpy(ts, (TCHAR *) m_list.GetItemData(pos));
		DecodePsw(ts);
		m_info = ts;
		UpdateData(FALSE);
		*pResult = 0;
	}
}

void CHistoryDlg::OnSearchdown()
{
	int pos = (int) m_list.GetNextItem(-1, LVNI_SELECTED);
	int i, n;
	TCHAR ts[MAX_TERM_WIDTH*12+1], szIndex[100];

	if (pos < 0) pos = 0;

	n = m_nMes - pos - 1;

	do { //for once
		if (n < 0 || n >= m_nMes) break;

		UpdateData();

		_tcscpy(szIndex, m_input);

		if (isempty(szIndex)) break;

		for (i = n + 1;i < m_nMes;i++) {
			_tcscpy(ts, m_pMes[i].szMes);
			DecodePsw(ts);

			if (InString(szIndex, ts))
				break;
		}

		if (i < m_nMes) {
			LVITEM  Item;
			Item.mask = LVIF_STATE;
			Item.state = 0xff;
			Item.stateMask = LVIS_SELECTED;
			Item.iItem = m_nMes - i - 1;
			m_list.SetItem(&Item);
			m_info = ts;
			UpdateData(FALSE);
			m_list.EnsureVisible(m_nMes - i - 1, FALSE);
		}
	} while (0);
}

void CHistoryDlg::OnSearchup()
{
	int pos = (int) m_list.GetNextItem(-1, LVNI_SELECTED);
	int i, n;
	TCHAR ts[MAX_TERM_WIDTH*12+1], szIndex[100];

	if (pos < 0) pos = m_nMes - 1;

	n = m_nMes - pos - 1;

	do { //for once
		if (n < 0 || n >= m_nMes) break;

		UpdateData();

		_tcscpy(szIndex, m_input);

		if (isempty(szIndex)) break;

		for (i = n - 1;i >= 0;i--) {
			_tcscpy(ts, m_pMes[i].szMes);
			DecodePsw(ts);

			if (InString(szIndex, ts))
				break;
		}

		if (i >= 0) {
			LVITEM  Item;
			Item.mask = LVIF_STATE;
			Item.state = 0xff;
			Item.stateMask = LVIS_SELECTED;
			Item.iItem = m_nMes - i - 1;
			m_list.SetItem(&Item);
			m_info = ts;
			UpdateData(FALSE);
			m_list.EnsureVisible(m_nMes - i - 1, FALSE);
		}
	} while (0);
}

void CHistoryDlg::OnOutfile()
{
	CFileDialogEx fd(FALSE, _T("txt"), _T("*.txt"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("�ı��ļ�(*.txt)|*.txt||"));
	FILE *fp;
	TCHAR ts[MAX_TERM_WIDTH*12+1];
	int i;

	if (fd.DoModal() == IDOK) {
		fp = _tfopen(fd.GetPathName(), _T("wt"));

		if (fp) {
			for (i = 0;i < m_nMes;i++) {
				_stprintf(ts, _T("%d %d-%d %d:%d %s: "), m_pMes[i].MesTime.GetYear(),
				          m_pMes[i].MesTime.GetMonth(),
				          m_pMes[i].MesTime.GetDay(),
				          m_pMes[i].MesTime.GetHour(),
				          m_pMes[i].MesTime.GetMinute(),
				          (m_pMes[i].bReply) ? _T("Reply") : m_pMes[i].szUserName);
				_fputts(ts, fp);
				_tcscpy(ts, m_pMes[i].szMes);
				DecodePsw(ts);
				_fputts(ts, fp);
				_fputts(_T("\n"), fp);
			}

			fclose(fp);
		}
	}
}

#endif//ENABLE_MESSAGE