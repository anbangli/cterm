#if !defined(AFX_INSCOLOR_H__78993DB7_F1A8_4A69_A113_5134DA06DEBB__INCLUDED_)
#define AFX_INSCOLOR_H__78993DB7_F1A8_4A69_A113_5134DA06DEBB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InsColor.h : header file
//

#include "MyPropertyPage.h"
#include "OneChar.h"

#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

/////////////////////////////////////////////////////////////////////////////
// CInsColor dialog

class CInsColor : public CMyPropertyPage
{
// Construction
public:
	CInsColor(CWnd* pParent = NULL);   // standard constructor

	UINT GetIDD();
	CString GetStr();

// Dialog Data
	//{{AFX_DATA(CInsColor)
	enum { IDD = IDD_INSCOLOR };
	CButtonST	m_preview;
	CComboBox	m_bc;
	CComboBox	m_fc;
	BOOL	m_blink;
	BOOL	m_hilight;
	BOOL	m_underline;
	BOOL	m_reverse;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInsColor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInsColor)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnSelchangeCombo2();
	afx_msg void OnCheck1();
	afx_msg void OnCheck2();
	afx_msg void OnCheck3();
	afx_msg void OnCheck4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	SOneChar m_cf;
	SOneChar m_c;

	void preview();
	void UpdateChar();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSCOLOR_H__78993DB7_F1A8_4A69_A113_5134DA06DEBB__INCLUDED_)
