// ShowIPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ShowIPDlg.h"
#include "ReadQQWry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#if ENABLE_SHOWIP

CShowIPDlg * g_pShowIPDlg = NULL; // only one

/////////////////////////////////////////////////////////////////////////////
// CShowIPDlg dialog

CShowIPDlg::CShowIPDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CShowIPDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShowIPDlg)
	m_sAddr = _T("");
	//}}AFX_DATA_INIT
}


void CShowIPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShowIPDlg)
	DDX_Control(pDX, IDC_SHOWIP, m_AddrCtrl);
	DDX_Text(pDX, IDC_SHOWIP, m_sAddr);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CShowIPDlg, CDialog)
	//{{AFX_MSG_MAP(CShowIPDlg)
	// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowIPDlg message handlers
extern CString g_sIPWryPath;
void CShowIPDlg::QueryIP(CString sURL)
{
	//	ASSERT(!g_szWorkDir.IsEmpty());
	//	CString strModulePath = g_szWorkDir + _T("qqwry.dat");
	CReadQQWry wry(g_sIPWryPath);
	//	CString sAddr=wry.QueryIP(sURL);
	//	if(sAddr==m_sAddr)
	//	{
	//		m_sAddr+=_T("."); //��.Ϊ�˽����ͬ��ַ������ʾ�����⣬��������
	//	}
	//	else
	m_sAddr = wry.QueryIP(sURL);

	if (m_sAddr.IsEmpty()) m_sAddr = _T("δ�ҵ���ؼ�¼");

	CRect rect;

	GetWindowRect(&rect);

	rect.right = rect.left + m_sAddr.GetLength() * 9; //9Ϊ�ֺţ��������ֺţ�����Ҳ�����

	MoveWindow(&rect);

	m_AddrCtrl.MoveWindow(0, 0, rect.Width() - 2, rect.Height() - 2);

	UpdateData(FALSE);
}

#endif//ENABLE_SHOWIP