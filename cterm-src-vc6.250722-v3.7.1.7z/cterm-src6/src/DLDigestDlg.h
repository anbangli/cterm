#if !defined(AFX_DLDIGESTDLG_H__58A79B45_E113_4206_9418_AAA659F5F090__INCLUDED_)
#define AFX_DLDIGESTDLG_H__58A79B45_E113_4206_9418_AAA659F5F090__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DLDigestDlg.h : header file
//

#include "autorun.h"

//ע�������ֵ��Ҫ��SiteSTatus.h���״ֵ̬SST_*��ͻ����
//��ΪEnternextStage���涼�����õ�
#define  DDS_SET				400
#define  DDS_UNKNOWN			401
#define  DDS_UNKNOWN_CONTINUE	402
#define  DDS_DONOTHING			403
#define  DDS_SEARCH_NEXT		404
#define  DDS_JUMPTOEND			405
#define  DDS_GETLASTINDEX		406
#define	 DDS_WAITEND			407
#define  DDS_COPY				408
#define  DDS_PGDOWN				409
#define  DDS_AUTO				410
#define  MAX_LEVEL				100

/////////////////////////////////////////////////////////////////////////////
// CDLDigestDlg dialog

class CHTMLConvert;

struct SDDStatus {
	int    nIndex[MAX_LEVEL];
	int m_iLastOfLevel[MAX_LEVEL];
	CHTMLConvert *pPage[MAX_LEVEL];
	TCHAR   szPath[300];
	TCHAR   szFile[300];
	TCHAR   szFirstFile[300];
	//FileName = szPath + (level?)nIndexStack
	int m_nLevel;
	TCHAR szFileName[300];

	SDDStatus();

public:
	void GetLastLevel(TCHAR *szLevel);
	void GetPrevFile(TCHAR *szPrev);
	void GetNextFile(TCHAR *sNext);
	void GetFirstFile(TCHAR *);
	CHTMLConvert *Pop(int &nNow);
	void Push(int &nNow, CHTMLConvert *p);
	void Create(TCHAR *szIndex);
	TCHAR *GetCurrFile();
};

struct SDDContinue {
	TCHAR szNowScreen[256];//��¼����
	int  m_nLevel;
	TCHAR szPath[300];
	TCHAR szFirstFile[300];
	TCHAR szPageFile[MAX_LEVEL][300];
	int  nIndex[MAX_LEVEL];
	int  nFileAt[MAX_LEVEL];
	int  nNowAt;
	int  nNowFileAt;

	SDDContinue();
};

class CDLDigestDlg : public CDialog
{
// Construction
	SDDStatus m_Status;
	int       m_nNow;
	CHTMLConvert *m_pNowPage;
	SDigestList m_Digest;
	BOOL m_bBusy;

public:
	CHTMLConvert *CreateNewPage(TCHAR *szFile, BOOL bList = TRUE);
	CAutoRun     m_Run;
	CDLDigestDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDLDigestDlg)
	enum { IDD = IDD_DL_DIGEST };
	CString	m_destfile;
	CString	m_info;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLDigestDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CDLDigestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBrowse();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnAdd();
	afx_msg void OnStop();
	afx_msg void OnRetry();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	TCHAR m_szWait[256];
	BOOL m_bWaitHead; //�Ƿ��ڵȴ������б���ͷ

	void WriteLink();
	void ProcessContinue();
	void AutoDeal(void);
	void DLEnd();
//	void CopyPicture();
	void AddList();
	void ProcessPgDown();
	void CopyArticle();
//	void ProcessUnKnown();
	void PopStatus(TCHAR *buf = _T("\x1b[D"));
	void PushStatus(TCHAR *buf, bool bFile);
	void SearchNext();
	void GetLastIndex();
	void JumpToEnd(void);
	void JumpToHead(const int next);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLDIGESTDLG_H__58A79B45_E113_4206_9418_AAA659F5F090__INCLUDED_)
