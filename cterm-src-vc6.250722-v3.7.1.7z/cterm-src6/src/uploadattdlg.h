#if !defined(AFX_UPLOADATTDLG_H__F2FE16A0_D038_4685_A150_0ADD58036B61__INCLUDED_)
#define AFX_UPLOADATTDLG_H__F2FE16A0_D038_4685_A150_0ADD58036B61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UploadAttDlg.h : header file
//
#include "webbrowser2.h"
/////////////////////////////////////////////////////////////////////////////
// CUploadAttDlg dialog

class CUploadAttDlg : public CDialog
{
// Construction

public:
	TCHAR sUrl[256];
	CUploadAttDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUploadAttDlg)
	enum { IDD = IDD_UPLOAD_ATT };
	CWebBrowser2	m_web;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUploadAttDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CUploadAttDlg)
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPLOADATTDLG_H__F2FE16A0_D038_4685_A150_0ADD58036B61__INCLUDED_)
