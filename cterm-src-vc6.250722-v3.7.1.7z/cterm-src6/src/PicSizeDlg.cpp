// PicSizeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "PicSizeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPicSizeDlg dialog


CPicSizeDlg::CPicSizeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPicSizeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPicSizeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPicSizeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPicSizeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPicSizeDlg, CDialog)
	//{{AFX_MSG_MAP(CPicSizeDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicSizeDlg message handlers

void CPicSizeDlg::OnOK() 
{
	SHELLEXECUTEINFO ShExecInfo;
	memset( &ShExecInfo, 0, sizeof( SHELLEXECUTEINFO ) );
	ShExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	ShExecInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	ShExecInfo.hwnd = m_hWnd;
	ShExecInfo.lpVerb = _T("Open");
	ShExecInfo.lpFile = _T("explorer.exe");
	ShExecInfo.lpParameters = m_szPicPath;
	ShExecInfo.lpDirectory = NULL;
	ShExecInfo.nShow = SW_SHOWNORMAL;
	ShExecInfo.hInstApp = NULL;
	ShellExecuteEx(&ShExecInfo);

	CDialog::OnOK();
}

int CPicSizeDlg::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DoModal();
}
