// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_)
#define AFX_MAINFRM_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"

#if ENABLE_SWITCHBAR
#include "SwitchBar.h"
#endif//ENABLE_SWITCHBAR

#include <Activscp.h>
#include "const.h"

#if ENABLE_BITMAPWND
#include "BitmapWnd.h"
#endif//ENABLE_BITMAPWND

#if ENABLE_COOLMENU
#include "coolmenu.h"
#endif//ENABLE_COOLMENU

#if ENABLE_MMSTATUSBAR
#include "MMStatusBar.h"
#else
typedef CStatusBar MMStatusBar;
#endif//ENABLE_MMSTATUSBAR

#if ENABLE_FUNKEY
#include "FuncKey.h"
#endif//ENABLE_FUNKEY

#if ENABLE_SEARCHBOX
#include "ToolBarEx.h"
#else
typedef CToolBar CToolBarEx;
#endif//ENABLE_SEARCHBOX

#if ENABLE_CAPTIONBUTTON
#include "CaptionButton.h"
#define CB_CLOSE 1
#define CB_MAX 2
#define CB_MIN 3
#endif//ENABLE_CAPTIONBUTTON

#if ENABLE_SCROLLBAR
#include "ViewScrollBar.h"
#endif//ENABLE_SCROLLBAR

//toolbar id
//֮������AFX_IDW_CONTROLBAR_LAST����Ϊ�˱���ͱ�׼bar���ͻ
#define ID_TOOLBAR_BBS		AFX_IDW_CONTROLBAR_LAST + 1 // 59648
#define ID_TOOLBAR_TAB		AFX_IDW_CONTROLBAR_LAST + 2 // 59649
#define ID_TOOLBAR_ASCII	AFX_IDW_CONTROLBAR_LAST + 3
#define ID_TOOLBAR_STATUS	AFX_IDW_CONTROLBAR_LAST + 4 // δ�ã�״̬���õ���AFX_IDW_STATUS_BAR
#define ID_TOOLBAR_KEY		AFX_IDW_CONTROLBAR_LAST + 5
#define ID_TOOLBAR_SCROLL	AFX_IDW_CONTROLBAR_LAST + 6

#define  FRAME_MAX 200
//#define EXEC_DLB    1111

class CChildFrame;
class CCTermView;

class CChildList
{
public:
	CChildList() {
		nActive = -1;
		nChild = 0;
		for (int i = 0; i < FRAME_MAX; ++i) pFrames[i] = NULL;
	}
	
	int Delete(CChildFrame *pChild);
	void Add(CChildFrame *pChild);
	void move(const int i, int offset);
	int GetChildIndex(CChildFrame *pChild);
	int GetChildIndex(CCTermView *pView);

	int nActive;
	int nChild;
	static int nMaxID;
	CChildFrame *pFrames[FRAME_MAX];
	int nIDs[FRAME_MAX];
	
private:
	int move(const int i, const bool forward);
};

class CLockDlg;
class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();
	~CMainFrame(); //virtual

public:
	bool m_bBossHided; //�Ƿ��ѱ��ϰ������
	bool m_bOwnHotkey;

public:
	// accessors
	void SetCreated()
	{
		m_bCreated = true;
	}
	
	int ChildCount() const
	{
		return m_Child.nChild;
	}

	void SetActiveChild(CChildFrame *pChild)
	{
		int n = m_Child.GetChildIndex(pChild);
#if ENABLE_SWITCHBAR
		//SetChildTab(this);
		if(::IsWindow(m_wndSwitchBar.GetSafeHwnd())) {
			m_wndSwitchBar.tab()->SetCurSel(n);
		}
#endif//ENABLE_SWITCHBAR
		if (0 <= n && n <= m_Child.nChild)
			m_Child.nActive = n;
	}

	bool isActive(int nSessionID) const
	{
		ASSERT(0 <= m_Child.nActive && m_Child.nActive <= m_Child.nChild);
		if (m_Child.nChild > 0 && 0 <= m_Child.nActive && m_Child.nActive <= m_Child.nChild) {
			return nSessionID == m_Child.nIDs[m_Child.nActive];
		}
		else {
			return false;
		}
	}

	int GetSessionID(int n) const
	{
		if (n == -1) 
			n = m_Child.nActive;
		ASSERT(0 <= n && n <= m_Child.nChild);
		if (0 <= n && n <= m_Child.nChild)
			return m_Child.nIDs[n];
		else
			return -1;
	}

	int ValidSessionID(int nID) const
	{
		int nSessionID = -1;
		if (m_Child.nChild > 0) {
			if (nID != -1 && 0 < nID && nID < m_Child.nMaxID) {
				// ע��sessionid��1��ʼ����
				// �������Χ�ڡ�����Ҳ��һ������ЧID��Ҳ���м���ɾ���ġ�����
				nSessionID = nID; //g_pMainWnd->m_Child.nIDs[i]; // ���Ǵ��ģ�i���Ǵ������
			}
			else {
				nSessionID = m_Child.nIDs[m_Child.nActive];
			}
		}
		return nSessionID;
	}

public:
	void FastAway(int i);
	void SetStatus(UINT id, CString txt);
	void ActivateView();
	void OpenURL(CString url = _T(""));
	CCTermView *GetView(const int nSessionID);
	void DeleteChild(CChildFrame *);
	void SetAutoReply(TCHAR *s = NULL);
	void RunViewPicVBS(CString url);
	void PopupSelf(bool bClick = false); // bClick�Ƿ�ģ�������
	void SetMenuFav();
#if ENABLE_MENUFAVTOP
	void ToggleFakeMenu(CMenu *pMainMenu);
#endif//ENABLE_MENUFAVTOP

#if ENABLE_SCROLLBAR
	void SetScrollSize(int nScrn, int nCur);
	void SetScrollBarPos(int pos)
	{
		m_wndScrollBar.SetPos(pos);
	}
#endif//ENABLE_SCROLLBAR

#if ENABLE_RAWCTD
	void ShowAsciiBar();
	void OpenCtdCsm();
#endif//ENABLE_RAWCTD

#if ENABLE_HOTKEY
public:
	void OnBossKey();
	void ReRegisterBossHotKey(bool bChange = false);
#endif//ENABLE_HOTKEY

	CString AntiIdleString(const int nSessionID);
	void SetAntiIdleString(const int nSessionID, CString s);

#if ENABLE_CAPTIONBUTTON
public:
	void RedrawCaptionButtons();

private:
	CCaptionButton m_cbExtra;
	void CreateCaptionButtons();
	void DeleteCaptionButtons();

#endif//ENABLE_CAPTIONBUTTON

#if ENABLE_FULLSCRN
public:
	BOOL IsFullScreen();
	CRect m_FullScreenWindowRect;
private:
	void SetFullscreen(bool bFull);

	bool m_bFullScreenBar;
	WINDOWPLACEMENT m_wpPrev;
	CToolBar *m_pwndFullScrnBar;
	BOOL m_bFullScreen;
#endif//ENABLE_FULLSCRN

#if ENABLE_PYTHON
public:
	bool PythonCallback(const TCHAR* func, const long* pnArgs, BYTE nArgc, void* pResult = NULL);
	//void RunPythonCode(CString sCode, int nSessionID = -1);
private:
	int RunPythonFile(const TCHAR *filename);
	void RunPythonScript(const TCHAR *filename, int nSessionID = -1);
#endif//ENABLE_PYTHON

#if ENABLE_FUNKEY
public:
	void InsertButton(int nCmdID, CString &sLabel, int nIndex = -1);
	const CMenu *getUserMenu() const
	{
		return m_UserMenu;
	}

	BOOL AppendToUserMenu(UINT nFlags, UINT nIDNewItem, LPCTSTR lpszNewItem) const
	{
		if (m_UserMenu) {
			return m_UserMenu->AppendMenu(nFlags, nIDNewItem, lpszNewItem);
		}
		return FALSE;
	}

public:
	SUserDefCmd m_keyTable[MAX_USERDEFCMD_NUM];
	BYTE m_nKeyButtonCount;
	CToolBar *m_pKeyBar;

private:
	bool m_bKeyBar;
	void SetUserMenu();
	void SetChildMenu();
	int CreateKeyBar();

	bool m_bKeyUpdating; // �Զ����������ڸ���
	CMenu *m_UserMenu;
#endif//ENABLE_FUNKEY

#if ENABLE_SWITCHBAR
private:
//	void SetChildTab(CChildFrame *pChild);
	void MoveChild(const int offset);
	void swapTab(const int i, const int j);
	void moveTab(const int i, const int offset);

	bool m_bDlgBar;
	CSwitchBar  m_wndSwitchBar;
	CImageList m_TabList;
#endif//ENABLE_SWITCHBAR

#if ENABLE_SCROLLBAR
	CViewScrollBar m_wndScrollBar;
#endif//ENABLE_SCROLLBAR

#ifdef _DEBUG
public:
	virtual void AssertValid() const;
private:
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// public data
	CToolBarEx	m_wndToolBar;

private:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual void GetMessageString(UINT nID, CString& rMessage) const; //override
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

private:
	// private functions
	bool NeedAutoSize(int cx, int cy,
					int &ncx, int &ncy,
					int &ncx1, int &ncy1,
					int &ncx2, int &ncy2,
					int &maxsw, int &maxsh,
					UINT flags);

	CChildFrame *GetNthFrame(const int i = -1) const;
	CCTermView *GetNthView(const int i = -1);
	CChildFrame* GetFrame(const int nSessionID);
	void AddChild(CChildFrame *);
	void SwitchView(UINT nIdx);

	BOOL GetToolText(UINT nID, CString& strTipText) const;

	void RefreshAll();
	void PopUpTrayMenu(int, int);
	void DoCopy(bool bANSI = false);
	void DoPaste(bool bANSI = false);

	int CreateBBSBar();
	void HideBars(bool bRestore = false, bool bOnlyFloating = false);

	void DockControlBarLeftOf(CControlBar* Bar, CControlBar* LeftOf);

#define SCRIPT_TYPE_VBS 1
#define SCRIPT_TYPE_JS 2
#define SCRIPT_TYPE_PY 3

#if ENABLE_VBS
// #####  BEGIN  ACTIVEX SCRIPTING SUPPORT #####
	bool LoadScriptText(CString &rFilename);
	BOOL RunMSScript(BYTE nType);
#define RunVBScript() RunMSScript(SCRIPT_TYPE_VBS)
#define RunJavaScript() RunMSScript(SCRIPT_TYPE_JS)
// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS

#if ENABLE_MULTILANG
	void LoadAllLanguage();
	void AddLangMenu(CMenu *pMainMenu);
#endif// ENABLE_MULTILANG

#if ENABLE_LOCK
	void UnlockScreen();
	void LockSys();
	void UnlockSys();
#endif//ENABLE_LOCK

#if ENABLE_HIDEMENU
	void ToggleMenu(bool bVisible);
#endif//ENABLE_HIDEMENU

#if ENABLE_SITECONFIG
	void ConfigSite(int nActive = -1);
#endif//ENABLE_SITECONFIG

#if ENABLE_HOTKEY
	void RegisterBossHotKey();
#endif//ENABLE_HOTKEY

	// Generated message map functions

private:
	//{{AFX_MSG(CMainFrame)
	afx_msg LRESULT OnScrollBar(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnChildClosed(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnDisplayChange(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg LRESULT OnTrayMenu(WPARAM , LPARAM);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg LRESULT OnStreamIn(WPARAM , LPARAM);
	afx_msg LRESULT OnDupSite(WPARAM , LPARAM);
	afx_msg void OnUpdateSelectRect(CCmdUI* pCmdUI);
	afx_msg void OnSelectRect();
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg LRESULT OnHaveMail(WPARAM, LPARAM);
	afx_msg void OnUpdateRightcode(CCmdUI* pCmdUI);
	afx_msg void OnRightcode();
	afx_msg void OnBbsDigest();
	afx_msg void OnBbsG();
	afx_msg void OnBbsClear();
	afx_msg void OnEditCopyANSI();
	afx_msg void OnEditPasteANSI();
	afx_msg void OnUpdateEditCopyANSI(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPasteANSI(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBbsClear(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBbsG(CCmdUI* pCmdUI);
	afx_msg void OnTest();
	afx_msg void OnF10();
	afx_msg void OnF1();
	afx_msg void OnUpdateAutocopy(CCmdUI* pCmdUI);
	afx_msg void OnAutocopy();
	afx_msg void OnUpdateBbsDigest(CCmdUI* pCmdUI);
	afx_msg void OnBbsSuperPaste();
	afx_msg void OnUpdateBbsSuperPaste(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LRESULT OnCreateNewChild(WPARAM , LPARAM);
	afx_msg LRESULT OnDisConnected(WPARAM, LPARAM);
	afx_msg void OnWindowNext();
	afx_msg void OnCtrlTab();
	afx_msg void OnCtrlShiftTab();
	afx_msg void OnUpdateViewShowcenter(CCmdUI* pCmdUI);
	afx_msg void OnViewStatusbar();
	afx_msg void OnUpdateViewStatusbar(CCmdUI* pCmdUI);
	afx_msg void OnBbsSametitle();
	afx_msg void OnUpdateBbsSametitle(CCmdUI* pCmdUI);
	afx_msg void OnPaneScript();
	afx_msg void OnViewShowcenter();
	afx_msg void OnViewShowleft();
	afx_msg void OnUpdateViewShowleft(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBbsH(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBbsBrowse(CCmdUI* pCmdUI);
	afx_msg void OnBbsH();
	afx_msg void OnBbsBrowse();
	afx_msg void OnBoldFont();
	afx_msg void OnUpdateBoldFont(CCmdUI* pCmdUI);
	afx_msg void OnMainRestore();
	afx_msg void OnUponefile();
	afx_msg LRESULT OnTaskBarCreated(WPARAM wParam, LPARAM lParam);
	afx_msg void OnToggleansi();
	afx_msg void OnUpdateToggleansi(CCmdUI* pCmdUI);
	afx_msg void OnAlwaystop();
	afx_msg void OnWebGo();
	afx_msg void OnUpdateAlwaystop(CCmdUI* pCmdUI);
	afx_msg void OnViewMin();
	afx_msg void OnViewMax();
	afx_msg void OnViewSimple();
	afx_msg void OnShowPosts();
	afx_msg void OnPaint();
	afx_msg void OnViewScrollbar();
	afx_msg void OnUpdateViewScrollbar(CCmdUI* pCmdUI);
	afx_msg void OnCloseall();
	afx_msg void OnFontscale();
	afx_msg void OnConsole();
	afx_msg void OnUpdateConsole(CCmdUI* pCmdUI);
	afx_msg void OnFileDup();
	afx_msg void OnUpdateFileDup(CCmdUI* pCmdUI);
	afx_msg void OnFileReconnect();
	afx_msg void OnUpdateFileReconnect(CCmdUI* pCmdUI);
	afx_msg void OnViewCompact();
	afx_msg void OnFileCopysite();
	afx_msg void OnUpdateFontscale(CCmdUI* pCmdUI);
	afx_msg void OnToolPicDownAuto();
	afx_msg void OnUpdateToolPicDownAuto(CCmdUI* pCmdUI);
	afx_msg void OnBbsPic();
	afx_msg void OnUpdateBbsPic(CCmdUI* pCmdUI);
	afx_msg void OnBbsSignature();
	afx_msg void OnUpdateBbsSignature(CCmdUI* pCmdUI);
	//}}AFX_MSG

#if ENABLE_CAPTIONBUTTON
	afx_msg LRESULT OnCBLButtonClicked(WPARAM wParam, LPARAM lParam);
#endif//ENABLE_CAPTIONBUTTON
	afx_msg LRESULT OnUnInitMenuPopup(WPARAM wParam, LPARAM lParam);
#if defined(ENABLE_VBS) || defined(ENABLE_PYTHON)
	afx_msg void OnRunScript();
#endif
#if ENABLE_PICTURE
	afx_msg void OnToolPicbox();
#endif//ENABLE_PICTURE
#if ENABLE_FULLSCRN
	afx_msg void OnViewFullscreen();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnUpdateViewFullScreen(CCmdUI* pCmdUI);
	afx_msg LRESULT OnWindowEdge(WPARAM wParam, LPARAM lParam);
#endif//ENABLE_FULLSCRN
#if ENABLE_HIDEMENU
	afx_msg void OnViewMenu();
	afx_msg void OnUpdateViewMenu(CCmdUI* pCmdUI);
#endif//ENABLE_HIDEMENU
#if ENABLE_ASCIIBAR
	afx_msg void OnViewAsciibar();
	afx_msg void OnUpdateViewAsciibar(CCmdUI* pCmdUI);
#endif//ENABLE_ASCIIBAR
#if ENABLE_BBSBAR
	afx_msg void OnViewBbsbar();
	afx_msg void OnUpdateViewBbsbar(CCmdUI* pCmdUI);
#endif//ENABLE_BBSBAR
#ifdef FOR_BYHH
	afx_msg void OnUpdateBbsWeb(CCmdUI* pCmdUI);
	afx_msg void OnBbsWeb();
#endif//FOR_BYHH
#if ENABLE_SEARCHBOX
	afx_msg void OnFocusSearchbox();
#endif//ENABLE_SEARCHBOX
#if ENABLE_SHOWIP
	afx_msg void OnToolQueryIP();
	afx_msg void OnViewShowipauto();
	afx_msg void OnUpdateViewShowipauto(CCmdUI* pCmdUI);
#endif//ENABLE_SHOWIP
#if ENABLE_SEARCHDLG
	afx_msg void OnBbsSearch();
	afx_msg void OnUpdateBbsSearch(CCmdUI* pCmdUI);
#endif//ENABLE_SEARCHDLG
#if ENABLE_FUNKEY
	afx_msg void OnCustomizeCommand();
	afx_msg void OnViewKeybar();
	afx_msg void OnUpdateViewKeybar(CCmdUI* pCmdUI);
#endif//ENABLE_FUNKEY
#if ENABLE_LOCK
	afx_msg void OnLeave();
	afx_msg void OnUpdateLeave(CCmdUI* pCmdUI);
#endif//ENABLE_LOCK
#if ENABLE_POSTDLG
	afx_msg void OnBbsPost();
	afx_msg void OnUpdateBbsPost(CCmdUI* pCmdUI);
#endif//ENABLE_POSTDLG
#if ENABLE_DOWNLOAD
	afx_msg void OnBbsFulltext();
	afx_msg void OnUpdateBbsFulltext(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDlmany(CCmdUI* pCmdUI);
	afx_msg void OnDlmany();
#endif//ENABLE_DOWNLOAD
#if ENABLE_EDITBOX
	afx_msg void OnUpdateEditDlg(CCmdUI* pCmdUI);
	afx_msg void OnEditDlg();
#endif//ENABLE_EDITBOX
#if ENABLE_MESSAGE
	afx_msg LRESULT OnPopMsg(WPARAM, LPARAM);
	afx_msg void OnShowMsgs();
#endif//ENABLE_MESSAGE
#if ENABLE_HOTKEY
	afx_msg LRESULT OnHotKey(WPARAM wParam, LPARAM lParam);// int idHotKey, UINT fuModifiers, UINT uVirtKey
#endif//ENABLE_HOTKEY
#if ENABLE_SYSCONFIG
	afx_msg LRESULT UpdateParam(WPARAM wParam, LPARAM lParam);
	afx_msg void OnAutosaveconfig();
	afx_msg void OnUpdateAutosaveconfig(CCmdUI* pCmdUI);
	afx_msg void OnSaveconfig();
	afx_msg void OnReloadconfig();
	afx_msg void OnSysSetup();
#endif//ENABLE_SYSCONFIG
#if ENABLE_UPDATE
	afx_msg LRESULT OnUpdateDlg(WPARAM wParam, LPARAM lParam);
#endif//ENABLE_UPDATE
#if ENABLE_COPYTCP
	afx_msg void OnCopytcp();
	afx_msg void OnUpdateCopytcp(CCmdUI* pCmdUI);
#endif//ENABLE_COPYTCP
#if ENABLE_BATCHDLG
	afx_msg void OnBat();
	afx_msg void OnUpdateBat(CCmdUI* pCmdUI);
#endif//ENABLE_BATCHDLG
#if ENABLE_SITECONFIG
	afx_msg void OnConfigSiteAutologin();
	afx_msg void OnConfigSiteFont();
	afx_msg void OnConfigSiteDecode();
	afx_msg void OnConfigSiteColor();
	afx_msg void OnUpdateConfigSite(CCmdUI* pCmdUI);
	afx_msg void OnConfigSite();
#endif//ENABLE_SITECONFIG
#if ENABLE_SWITCHBAR
	afx_msg void OnTabLeft();
	afx_msg void OnTabRight();
	afx_msg void OnViewTab();
	afx_msg void OnUpdateViewTab(CCmdUI* pCmdUI);
	afx_msg void OnClickSwitchTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclickSwitchTab(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeSwitchTab(NMHDR* pNMHDR, LRESULT* pResult);
#endif//ENABLE_SWITCHBAR
#if ENABLE_CTD
	afx_msg void OnOpenctd();
#endif//ENABLE_CTD
#if ENABLE_RAWCTD
	afx_msg void OnCtdrecord();
	afx_msg void OnUpdateCtdrecord(CCmdUI* pCmdUI);
#endif//ENABLE_RAWCTD
#if ENABLE_VBS
	afx_msg void OnDownloadTool();
	afx_msg void OnStopScript();
	afx_msg void OnUpdateStopScript(CCmdUI* pCmdUI);
#endif// ENABLE_VBS
#if ENABLE_PYTHON
	afx_msg void OnReinitPython();
	afx_msg LRESULT OnSetScriptInfo(WPARAM wParam, LPARAM lParam);
#endif//ENABLE_PYTHON

	afx_msg void OnUserDefCmd(UINT nID);
	afx_msg void OnSwitchView(UINT nID);
	afx_msg void OnUpdateKeyButton(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFakeMenu(CCmdUI* pCmdUI);
	afx_msg BOOL OnToolTipText(UINT nID, NMHDR* pNMHDR, LRESULT*pResult);
	afx_msg void OnLang(UINT nID);
	afx_msg void OnUpdateLang(CCmdUI* pCmdUI);

	afx_msg void OnLangCommand(UINT nID);
	afx_msg LRESULT OnSetLanguage(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()

#if ENABLE_TRANSPARENT
	afx_msg void OnTransparentInc();
	afx_msg void OnTransparentDec();
#endif // ENABLE_TRANSPARENT

#if ENABLE_VBS
// ##### BEGIN ACTIVEX SCRIPTING SUPPORT #####
	DECLARE_INTERFACE_MAP()

	BEGIN_INTERFACE_PART(ScriptSite, IActiveScriptSite)
	STDMETHOD(GetLCID)(LCID *plcid);
	STDMETHOD(GetItemInfo)(LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown **ppiunkItem, ITypeInfo **ppti);
	STDMETHOD(GetDocVersionString)(BSTR *pszVersion);
	STDMETHOD(RequestItems)(void);
	STDMETHOD(RequestTypeLibs)(void);
	STDMETHOD(OnScriptTerminate)(const VARIANT *pvarResult, const EXCEPINFO *pexcepinfo);
	STDMETHOD(OnStateChange)(SCRIPTSTATE ssScriptState);
	STDMETHOD(OnScriptError)(IActiveScriptError *pscripterror);
	STDMETHOD(OnEnterScript)(void);
	STDMETHOD(OnLeaveScript)(void);
	END_INTERFACE_PART(ScriptSite)

	BEGIN_INTERFACE_PART(ScriptSiteWindow, IActiveScriptSiteWindow)
	STDMETHOD(GetWindow)(HWND *phwnd);
	STDMETHOD(EnableModeless)(BOOL fEnable);
	END_INTERFACE_PART(ScriptSiteWindow)


	IActiveScript        *m_pIActiveScript;
	IActiveScriptParse   *m_pIActiveScriptParse;

	HRESULT CreateScriptEngine(LPCOLESTR pstrItemName);
// #####  END  ACTIVEX SCRIPTING SUPPORT #####
#endif// ENABLE_VBS

private:
	void OpenConsole(); // �򿪿���̨���ڵ������

private:
	
	
	// data
	NOTIFYICONDATA m_nid;
	CChildList m_Child;
	CLockDlg *m_pLockDlg; // ָ������(�뿪)�Ի���
	CString		m_strCode;

	BOOL m_bZoomed;
	BOOL m_bTopMost;
	bool m_bTrayIconVisible;
	bool m_bCreated; // ������ɲ�����ʾ
#if ENABLE_BITMAPWND
	CBitmapWnd  m_wndClient;
#endif//ENABLE_BITMAPWND

	MMStatusBar   m_wndStatusBar;	//extended statusbar

	//����ı�����������ر�������Hidebars()
	bool m_bToolBar;
	bool m_bStatusBar;

#if ENABLE_ASCIIBAR
	CToolBarEx  m_wndAsciiBar;
	bool m_bAsciiBar;
#endif//ENABLE_ASCIIBAR
	bool m_bScrollBar;

#if ENABLE_BBSBAR
	CToolBarEx	m_wndBbsBar;
	bool m_bBBSBar;
#endif//ENABLE_BBSBAR

#if ENABLE_COOLMENU
	// CJ��Ĳ˵�
	// ���ã��Զ���ʾ���ټ���������INS��ʾΪNUM0������
	CCoolMenuManager	m_pMenuMgr;
#endif//ENABLE_COOLMENU
};

extern CMainFrame *g_pMainWnd;
extern bool g_bSysPythonScriptLoaded;

#if ENABLE_PYTHON
void RunPythonCode(CString sCode, int nSessionID = -1);
#endif//ENABLE_PYTHON

inline void SetStatusBar(UINT nPaneID, UINT nStrID)
{
	CString g_LoadString(UINT id);
	if (g_pMainWnd)
		g_pMainWnd->SetStatus(nPaneID, g_LoadString(nStrID));
}

inline void SetStatusBar(UINT nPaneID, CString sInfo)
{
	if (g_pMainWnd)
		g_pMainWnd->SetStatus(nPaneID, sInfo);
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_)
