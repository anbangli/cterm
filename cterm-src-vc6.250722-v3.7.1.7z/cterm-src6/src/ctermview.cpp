// CTermView.cpp : implementation file
//

#include "stdafx.h"

#include <Shlwapi.h>
#define COMPILE_MULTIMON_STUBS // only once
#include <MULTIMON.H> // ����ʾ��֧��

#include "CTermView.h"
#include "paramconfig.h"
#include "global.h"
#include "forcode.h"
#include "MainFrm.h"
#include "usermsg.h"

#include "math.h"			// VC�ڲ���
#include "resource.h"		// ������Դ

#if ENABLE_MESSAGE
#include "messagedlg.h"		// �ظ���Ϣ
#endif//ENABLE_MESSAGE

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#if ENABLE_BASE64
#include "base64.h"			// ")CBase64" ��
#endif//ENABLE_BASE64

#if ENABLE_SHOWIP
#include "ShowIPDlg.h"
#endif//ENABLE_SHOWIP

#if ENABLE_PICTURE
#include "picshowdlg.h"
#endif//ENABLE_PICTURE

#if ENABLE_ATTACH
#include "UploadAttDlg.h"
#endif//ENABLE_ATTACH

#include "debugtool.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#ifdef _DEBUG
CCTermView *g_pView = NULL;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCTermView

IMPLEMENT_DYNCREATE(CCTermView, CView)

CCTermView::CCTermView() :
//m_nStartLine(m_Core.MaxStartLine()),
m_bClickRect(true),
m_pointDown(0, 0),
m_sTermType(_T("vt100")),
m_rectClick(0, 0, 0, 0),
m_rectSelect(0, 0, 0, 0),
m_CaretPos(-1, -1),
m_bCaretShow(false),
m_bBsIsDel(true),
m_bDelAsStop(false),
m_bBossColor(false),
m_bHaveFocus(false),
m_bViewInited(false),
m_nLastInputTime(0),
//		m_nSiteType(ST_FIREBIRD),
m_bSSHbbsLogin(false),
m_bCtdWait(true),
m_ctd_fp(NULL),
m_filesize(0),
m_bCtd_Loading(false)
{
	m_nCtdFile = 0;
	//	m_nStr = 0;
	m_bDbClick = FALSE;
	m_bLeftdown = FALSE;
	m_LastCursor = NULL;
	
	//	m_bIgnoreCtrlC = FALSE;		// �Ƿ�ʹ�� Ctrl-C�����ƣ����������ȷ�к����ǣ�^C����ַ��Ѿ��������ˣ�ִ�е�COPY�������ﲻ�ٴ����ˣ�else��֧������
	//	m_bIgnoreCtrlV = FALSE;		// �Ƿ�ʹ�� Ctrl-V��ճ��
	m_bClickRectURL = FALSE;
#if ENABLE_EDITBOX
	m_bPopEditDlg = g_bPopEditDlg;
	m_bEditVisible = false;
#endif//ENABLE_EDITBOX
	
	m_nSessionID = -1;
	m_nCharCellWidth = DEF_FONT_SIZE;
	m_nCharCellHeight = DEF_FONT_SIZE;
	m_nCARET_H = 2;
	m_nCARET_W = -5;
	m_blinkcount = 0;
	m_bMONOSPACE = true;
	m_bBold = false;

	m_nCharHWRatio = 2;
	m_bIPV6 = false;
	m_nMaxHistLine = DEFAULT_TERM_HEIGHT;
	
#if ENABLE_MESSAGE
	m_pMessageDlg = NULL;
#endif//ENABLE_MESSAGE
	
	m_nConnectionType = 0;
	
	m_szReturnChar[0] = '\r';
	m_szReturnChar[1] = '\0';
	
	m_szClick[0] = '\0';
	
	m_nTermWidth = DEFAULT_TERM_WIDTH;
	m_nTermHeight = DEFAULT_TERM_HEIGHT;
	m_nFixFontSize = DEF_FONT_SIZE;
	m_bFixFont = false;
	m_nStartLine = 0;
	
	m_bSleeping = false;
	m_bInited = false;
	
#if ENABLE_ATTACH
	m_bHttpUpload = false;
#endif//ENABLE_ATTACH
	
	m_bBlackList=false;		//�Ƿ����ú�����
	m_szBlackList="";		//������
	
#if ENABLE_PIPESSH
	m_bPipeOpen = false;
	m_hPipeReader = NULL;
	m_nPassTry = 0;
	m_bLogined = false;
	m_hChildStdoutRdDup = INVALID_HANDLE_VALUE;
	m_hChildStdinWrDup = INVALID_HANDLE_VALUE;
	m_plink_pinfo.dwProcessId = 0;
	m_plink_pinfo.dwThreadId = 0;
	m_plink_pinfo.hProcess = NULL;
	m_plink_pinfo.hThread = NULL;
#endif//ENABLE_PIPESSH
	
	m_nESCChar = 0;
	m_pESCChar = ESC_Char[0];
	
	m_pMemDC = NULL;
	m_pMemBitmap = NULL;
	
#if ENABLE_DRAG
	//	m_bDraging = FALSE;//δ��
#endif //ENABLE_DRAG
	
	m_Core.SetView(this);
	m_Sock.SetView(this);
}

CCTermView::~CCTermView()
{
#if ENABLE_PIPESSH
	if (m_plink_pinfo.hProcess != NULL) {
		KillPlinkProcess();
	}
	
	//	CloseHandle (m_hChildStdinWrDup);
	//	CloseHandle (m_hChildStdoutRdDup);
#endif//ENABLE_PIPESSH
	
#if ENABLE_MESSAGE
	m_pMessageDlg = NULL;
#endif//ENABLE_MESSAGE
	
#ifdef _DEBUG_STATUS
	//	m_wndStatusDlg.DestroyWindow();
#endif
	
#if ENABLE_EDITBOX
	m_EditDlg.DestroyWindow();
#endif//ENABLE_MESSAGE
}


BEGIN_MESSAGE_MAP(CCTermView, CView)
ON_WM_CONTEXTMENU()
//{{AFX_MSG_MAP(CCTermView)
ON_WM_ERASEBKGND()
ON_WM_SIZE()
ON_WM_CREATE()
ON_WM_TIMER()
ON_WM_SETCURSOR()
ON_WM_LBUTTONDOWN()
ON_WM_LBUTTONUP()
ON_WM_LBUTTONDBLCLK()
ON_WM_MOUSEMOVE()
ON_WM_RBUTTONDOWN()
ON_WM_RBUTTONUP()
ON_UPDATE_COMMAND_UI(ID_OPEN_URL, OnUpdateOpenUrl)
ON_COMMAND(ID_OPEN_URL, OnOpenUrl)
ON_UPDATE_COMMAND_UI(ID_SAVEAS, OnUpdateSaveAs)
ON_COMMAND(ID_SAVEAS, OnSaveAs)
ON_COMMAND(ID_ATTACHMENTS, OnAttachments)
ON_UPDATE_COMMAND_UI(ID_ATTACHMENTS, OnUpdateAttachments)
ON_WM_MOUSEWHEEL()
ON_WM_CHAR()
ON_WM_KEYDOWN()
ON_COMMAND(ID_OPEN_URL_NOW, OnOpenUrlNow)
ON_UPDATE_COMMAND_UI(ID_OPEN_URL_NOW, OnUpdateOpenUrlNow)
ON_COMMAND(ID_OPEN_URL_IE, OnOpenUrlIE)
ON_UPDATE_COMMAND_UI(ID_OPEN_URL_IE, OnUpdateOpenUrlIE)
ON_WM_MBUTTONUP()
ON_WM_DESTROY()
ON_WM_KILLFOCUS()
ON_COMMAND(ID_HIS_PGUP, OnHisPgup)
ON_COMMAND(ID_HIS_PGDN, OnHisPgdn)
ON_UPDATE_COMMAND_UI(ID_HIS_PGUP, OnUpdateHisPgup)
ON_UPDATE_COMMAND_UI(ID_HIS_PGDN, OnUpdateHisPgdn)
ON_COMMAND(ID_BOSSCOLOR, OnBosscolor)
ON_UPDATE_COMMAND_UI(ID_BOSSCOLOR, OnUpdateBosscolor)
ON_WM_SETFOCUS()
ON_MESSAGE(WM_DNSRESOLVED, OnDNSResolved)
ON_MESSAGE(WM_DATA_COME, OnDataCome)
ON_WM_CANCELMODE()
ON_WM_WINDOWPOSCHANGING()
ON_UPDATE_COMMAND_UI(ID_CTDLOAD, OnUpdateCtdload)
ON_UPDATE_COMMAND_UI(ID_CTDUP, OnUpdateCtdup)
ON_UPDATE_COMMAND_UI(ID_CTDDOWN, OnUpdateCtddown)
ON_COMMAND(ID_INSERTANSI, OnInsertansi)
ON_COMMAND(ID_CTDUP, OnCtdup)
ON_COMMAND(ID_CTDDOWN, OnCtddown)
ON_COMMAND(ID_CTDLOAD, OnCtdload)
//}}AFX_MSG_MAP
#if ENABLE_RAWCTD
ON_COMMAND(ID_CTDPLAY, OnCtdplay)
ON_UPDATE_COMMAND_UI(ID_CTDPLAY, OnUpdateCtdplay)
#endif//ENABLE_RAWCTD
#if ENABLE_VBS
ON_UPDATE_COMMAND_UI(ID_DOWNLOAD_TOOL, OnUpdateDownloadTool)
#endif//ENABLE_VBS
#if ENABLE_PICTURE
ON_UPDATE_COMMAND_UI(ID_OPEN_URL_PIC, OnUpdateOpenUrlPic)
ON_COMMAND(ID_OPEN_URL_PIC, OnOpenUrlPic)
#endif//ENABLE_PICTURE
#if ENABLE_DRAG
ON_MESSAGE(DROPM_DRAGOVER, OnDragOver)  //these 3 items for ENABLE_DRAG
ON_MESSAGE(DROPM_DROPEX, OnDropEx)
ON_MESSAGE(DROPM_DROP, OnDrop)
#endif//ENABLE_MESSAGE
#if ENABLE_PIPESSH
ON_MESSAGE(WM_PIPE_DATA, OnPipeData)
#endif//ENABLE_PIPESSH

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCTermView drawing


/////////////////////////////////////////////////////////////////////////////
// CCTermView diagnostics

#ifdef _DEBUG
void CCTermView::AssertValid() const
{
	CParentView::AssertValid();
}

void CCTermView::Dump(CDumpContext& dc) const
{
	CParentView::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCTermView message handlers

//�����˴����С֮��,���ݴ����С��ѡ�������С
void CCTermView::OnSize(UINT nType, int cx, int cy)
{
	//TRACEF("OnSize\n");
	//TRACE(_T("in CCTermView::OnSize\n"));
	
	// �̶������Сʱ����Ҫ�������壬����Ҫ SetScrollSizes()
	// ������OnPaint��ʱ��ͻ����������Ҳ�����:(
	Refresh();
	CParentView::OnSize(nType, cx, cy);
}

// ����ȫ���ַ������߶�
// ������֮
// m_bFixFont || m_font == _T("Fixedsys") ʱ��cx, cy������������
void CCTermView::ComputeCharSize(int cx, int cy, int &cw, int &ch)
{
#define MAX_HWRATIO 10
	// ע��������������ڲ��õĶ���Fixedsys����1��sСд
	bool bAutoRatio = false;
	if (m_font == _T("Fixedsys")) {
		// Ŀǰ�ĸ߿����ƺ��Թ̶��ֺŲ������ã��̶��ֺŻ�fixedsys�߿���Ҳ�̶�Ϊ2��
		m_nCharCellWidth = m_nCharCellHeight = m_bMONOSPACE ? DEF_FONT_SIZE : g_nFixedSysSize;
	} else if (m_bFixFont) {
		// Ŀǰ�ĸ߿����ƺ��Թ̶��ֺŲ������ã��̶��ֺŻ�fixedsys�߿���Ҳ�̶�Ϊ2��
		m_nCharCellWidth = m_nFixFontSize;
		m_nCharCellHeight = m_nFixFontSize;
	} else {
		if (0 < m_nCharHWRatio && m_nCharHWRatio < MAX_HWRATIO) {
			//�̶��߿���
			if(g_bMaxFullScreen) {
				int ch1 = (int)((double)cx / m_nTermWidth + 0.5) * m_nCharHWRatio;
				int ch2 = (int)((double)cy / m_nTermHeight + 0.5);
				m_nCharCellHeight = max(ch1, ch2); // ȡС����֤��������
				int deltaY1 = cy - ch1 * m_nTermHeight;
				double ry1 = (double)deltaY1 / ch1;
				
				int deltaY2 = cx - ch2 / m_nCharHWRatio *m_nTermWidth;
				double ry2 = (double)deltaY2 / ch2;
				
				if (fabs(ry1) > fabs(ry2)) {
					// ѡ�����������ٵ�
					m_nCharCellHeight = ch2;
				}
				else {
					m_nCharCellHeight = ch1;
				}
				
				m_nCharCellWidth = m_nCharCellHeight / m_nCharHWRatio;
			}
			else {
				int ch1 = cx / m_nTermWidth *m_nCharHWRatio;
				int ch2 = cy / m_nTermHeight;
				m_nCharCellHeight = min(ch1, ch2); // ȡС����֤��������
				m_nCharCellWidth = m_nCharCellHeight / m_nCharHWRatio;			
			}
		}
		else {
			// �Զ��߿���
			bAutoRatio = true;
			if(g_bMaxFullScreen) {
				m_nCharCellWidth = (int)((double)cx / m_nTermWidth + 0.5);
				m_nCharCellHeight = (int)((double)cy / m_nTermHeight + 0.5);
			}
			else {
				m_nCharCellWidth = cx / m_nTermWidth;
				m_nCharCellHeight = cy / m_nTermHeight;
			}
		}
		
		m_nCharCellWidth *= 2;
	}
	
	cw = m_nCharCellWidth; // ���������ر�������Ϊ0
	ch = m_nCharCellHeight;
	
	if (m_nCharCellWidth < 2) m_nCharCellWidth = 2;
	if (m_nCharCellHeight < 2) m_nCharCellHeight = 2;
	
	
	int nRowSpace = 0;
	if (g_nRowSpace == 0) {
		nRowSpace = 0;
	}
	if (g_nRowSpace < 0) {
		nRowSpace = (int)(m_nCharCellHeight * (-1 * g_nRowSpace) / 10.0);
	}
	else {
		// > 0
		nRowSpace = (g_nRowSpace > MAX_ROW_SPACE) ? MAX_ROW_SPACE : g_nRowSpace;
	}
	
	if (bAutoRatio) {
		m_nTrueFontHeight = m_nCharCellHeight - nRowSpace;
	}
	else {
		m_nTrueFontHeight = m_nCharCellHeight;
		m_nCharCellHeight += nRowSpace;
	}
	if (m_nTrueFontHeight < 2) m_nTrueFontHeight = 2;
}

// �����������壬�ַ����������ߴ��
void CCTermView::SetViewFont(int cx, int cy)
{
	//TRACE("in CCTermView::SetViewFont\n");
	
	// �п�����վ�㻹û�г�ʼ��(�� CMainFrame::OnCreateNewChild()��)ʱ����
	// ��ʱ�����������Ǵ���
	if (isempty(m_Site.m_Login.m_szProfileName))
		return;
	
	LOGFONT lf; //LOGFONT�ṹ�еı������ڶ�������ĸ�������
	
	memset(&lf, 0, sizeof(lf));
	
	int cw, ch; // ����������δ��
	ComputeCharSize(cx, cy, cw, ch); // ���� m_nCharCellWidth m_nCharCellHeight
	
	//	if (m_font == _T("Fixedsys")) {
	//		//		m_nFontSize=16;
	//		// Ŀǰ�ĸ߿����ƺ��Թ̶��ֺŲ������ã��̶��ֺŻ�fixedsys�߿���Ҳ�̶�Ϊ2��
	//		RedrawLine(m_nStartLine, m_nStartLine + m_nTermHeight - 1); //fixsys, resizeʱˢ�������⡣ԭ��maybe���ı����������ڴ�С�����������غϴ��ڡ�
	//	}
	
	// �����ֺ�
	if (m_font != _T("Fixedsys")) {
		// ������Щ�������fixedsys��������� ����
		
		if (m_font.IsEmpty()) // todo: ���������⣿
			m_font = _T("SimSun");
		
		lf.lfOutPrecision = OUT_TT_ONLY_PRECIS; //��fixedsys�������ø���
	}
	
#if ENABLE_CLEARTYPE
	lf.lfQuality = g_nFontQuality;
#else
	lf.lfQuality = 0;
#endif//ENABLE_CLEARTYPE
	
	//�����������С
	m_nCARET_H = (g_nCARET_H < 0) ? m_nTrueFontHeight * (-1 * g_nCARET_H) / 10 : g_nCARET_H;
	m_nCARET_W = (g_nCARET_W < 0) ? m_nCharCellWidth * (-1 * g_nCARET_W) / 10 : g_nCARET_W;
	
	// for scroll
#if ENABLE_SCROLL
	SetScrollSizes(MM_TEXT, CSize(m_nTermWidth * m_nCharCellWidth / 2, m_nTermHeight * m_nCharCellHeight));
#endif//ENABLE_SCROLL
	
	//m_nCharCellWidth=m_nFontSize, m_nCharCellHeight=m_nFontSize;
	double scale = (double) g_nCharScale / 10;
	int nTrueFontWidth = (int)((m_nCharCellWidth / 2) * scale);
	// û�б�Ҫ1:2
	
	//�����������VC�̳̣�http://www.vchelp.net/wyy/
	lf.lfWidth = nTrueFontWidth;
	lf.lfHeight = m_nTrueFontHeight;
	
	if (m_bBold)
		lf.lfWeight = FW_BOLD;	//g_nBoldWeight;
	else
		lf.lfWeight = FW_NORMAL;
	
	CDC *pDC = GetDC();
	FixPosition(pDC);
	
	// �����ַ���
	//	if (m_Site.iCode==0) {	// GB2312
	BYTE & cv = m_Site.m_Decode.m_nOutputCodeConvert;
	if (!m_Sock.m_bStarted
		|| cv == OUTPUT_NONE
		|| cv == OUTPUT_B2G
		|| cv == OUTPUT_U2G
		|| cv == OUTPUT_H2G) {
		
		//!m_bStarted����ʾ��ʾ��Ϣȫ��GB������ת�룬Ҳ���û�����
		
		if (m_font.CompareNoCase(_T("MingLiu")) == 0) {
			// ���MingLiu����תΪ���������
			// ��..�û�����־���ı���
			// ������Ӹ�ѡ�autofont
			lf.lfCharSet = DEFAULT_CHARSET;
		}
		else {
			lf.lfCharSet = g_gbCharSet;
		}
		
		if (FontExist(pDC->GetSafeHdc(), lf.lfCharSet, m_font))
			_tcscpy(lf.lfFaceName, m_font);  //������������
		else
			_tcscpy(lf.lfFaceName, _T("SimSun"));
	} else {
		// BIG5
		lf.lfCharSet = g_big5CharSet; //CHINESEBIG5_CHARSET; //�����ַ���Ϊ BIG5
		
		if (FontExist(pDC->GetSafeHdc(), lf.lfCharSet, m_font))
			_tcscpy(lf.lfFaceName, m_font);
		else
			_tcscpy(lf.lfFaceName, _T("MingLiu"));	// BIG5��ָ�����岻���ڣ���ʹ��MingLiu1
	}
	
	//	lf.lfPitchAndFamily = FIXED_PITCH; //�Էǵȿ����廹�ǲ�������
	
	//��������
	m_Font[0].DeleteObject(); //վ�����õ�����
	
	m_Font[1].DeleteObject();
	
	m_Font[2].DeleteObject();
	
	m_Font[3].DeleteObject();
	
	m_Font[4].DeleteObject();
	
	m_Font[0].CreateFontIndirect(&lf);
	
	//	TCHAR defaultfont[MAXFONTNAME]/* = _T("")*/;
	//	_stprintf(defaultfont, _T("%s"), lf.lfFaceName);
	
	
	//VARIABLE_PITCH=2
	if (!m_Font[1].CreateFont(m_nTrueFontHeight, nTrueFontWidth, 0, 0, lf.lfWeight, 0, 0, 0, 0x86, 3, 2, 1, 2, _T("SimSun")))
		m_Font[1].CreateFontIndirect(&lf);
	
	if (!m_Font[2].CreateFont(m_nTrueFontHeight, nTrueFontWidth, 0, 0, lf.lfWeight, 0, 0, 0, 0x86, 3, 2, 1, 2, _T("SimHei")))
		m_Font[2].CreateFontIndirect(&lf);
	
	if (!m_Font[3].CreateFont(m_nTrueFontHeight, nTrueFontWidth, 0, 0, lf.lfWeight, 0, 0, 0, 0x86, 3, 2, 1, 2, _T("Kaiti")))  //_T("Kaiti_GB2312");
		m_Font[3].CreateFontIndirect(&lf);
	
	CString eFont;
	
	if (m_eFont.IsEmpty() ||
		!FontExist(pDC->GetSafeHdc(), DEFAULT_CHARSET, m_eFont))
		eFont = m_font; // ����m_eFont
	else
		eFont = m_eFont;
	
	_tcscpy(lf.lfFaceName, eFont);
	
	lf.lfCharSet = DEFAULT_CHARSET;
	
	m_Font[4].CreateFontIndirect(&lf);
	
	
	ReleaseDC(pDC);
	
	//OnEraseBkgnd(pDC);
	//RedrawLine(0,(m_nTermHeight-1));
}

int CCTermView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	m_Sock.m_hWnd = this->m_hWnd;
	
	//	HWND hWnd = GetSafeHwnd();
	//	::SetWindowLong (hWnd, GWL_STYLE, GetWindowLong (hWnd, GWL_STYLE) & ~WS_VISIBLE);
	
	lpCreateStruct->style &= ~WS_VISIBLE;	// ��������ʾ...�ƺ���������?
	
	if (CParentView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	//SetTimer(TIMER_BLINK, g_nBlinkTimeOut, NULL);// �Ƶ�OnCreateNewChild
	
	if (g_nTimer > 0) {
		SetTimer(TIMER_CTERM, g_nTimer * 1000, NULL);
	}
	
#if ENABLE_EDITBOX
	m_EditDlg.m_pView = this;
	m_EditDlg.Create(IDD_EDIT, g_pMainWnd);
#endif//ENABLE_EDITBOX
	
#ifdef _DEBUG_STATUS
	m_wndStatusDlg.Create(IDD_SHOWSTATUS, this);
	
	m_wndStatusDlg.ShowWindow(SW_SHOW);
	
#endif
	
#if ENABLE_DRAG
#ifndef _DEBUG
	if (!m_dropEx.Register(this))
		TRACE(_T("register drop edit failed\n"));
	
#endif //_DEBUG
#endif //ENABLE_DRAG
	//for scroll
#if ENABLE_SCROLL
	SetScrollSizes(MM_TEXT, CSize(m_nTermWidth * m_nCharCellWidth / 2, m_nTermHeight * m_nCharCellHeight));
#endif//ENABLE_SCROLL
	
	CreateMemDC();
	
	return 0;
}

void CCTermView::CreateMemDC()
{
	CDC *pDC = GetDC();
	
	if (m_pMemDC) {
		m_pMemBitmap->DeleteObject();
		delete m_pMemBitmap;
		
		//		m_pMemDC->DeleteDC();
		//		delete m_pMemDC;
	}
	else {
		m_pMemDC = new CDC;
		m_pMemDC->CreateCompatibleDC(pDC);
	}
	
	//TRACE(_T("SystemMetrics: %d, %d\n"),
	//	  GetSystemMetrics(SM_CXVIRTUALSCREEN),
	//	  GetSystemMetrics(SM_CYVIRTUALSCREEN));
	
	m_pMemBitmap = new CBitmap;
	m_pMemBitmap->CreateCompatibleBitmap(pDC,
		GetSystemMetrics(SM_CXVIRTUALSCREEN),
		GetSystemMetrics(SM_CYVIRTUALSCREEN));
	m_pMemDC->SelectObject(m_pMemBitmap);
}

#if ENABLE_HIDECURSOR
void ToggleCursor(BOOL bShow)
{
	int r = 0;
	TRACE("in ToggleCursor\n");
	if (bShow) {
		// ��ʾ
		if (!g_bMouseVisible) {
			r = ::ShowCursor(bShow);
			g_nNoMouseMoveCount = 0;
			g_bMouseVisible = true;
			TRACE("in ToggleCursor bShow = %d, r = %d, Count = %d\n", bShow, r, g_nNoMouseMoveCount);
		}
	}
	else {
		// ����
		if (g_bMouseVisible) {
			r = ::ShowCursor(bShow);
			g_bMouseVisible = false;
		}
		TRACE("in ToggleCursor bShow = %d, r = %d, Count = %d\n", bShow, r, g_nNoMouseMoveCount);
	}
}
#endif//ENABLE_HIDECURSOR

// ��ʱ����������ͣ��ͼ�ͷ�ֹ�����ȵ�
void CCTermView::OnTimer(UINT nIDEvent)
{
	//TRACEFINTS (" OnTimer ", nIDEvent);
	
	switch (nIDEvent) {
#if ENABLE_PICTURE
		
	case TIMER_PICURLHOVER: {
		// ��ͣ��ͼ
		m_urlInfo.m_nHoverTime += TIMEOUT_PICURLHOVER;
		
		if (m_urlInfo.m_nHoverTime >= g_nPicHoverTime) {
			m_urlInfo.m_nHoverTime = 0;
			KillTimer(TIMER_PICURLHOVER);
			TRACE(_T("TIMER_PICURLHOVER killed 1\n"));
			TRACE(_T("call viewpicNOW 1\n"));
			ViewPicNow();
		}
							}
		break;
#endif //ENABLE_PICTURE
		
	case TIMER_BLINK: {
		// ��˸��300ms����һ��
#define CTD_LOAD_NO_DRAW true
		if (!Ctd_Loading() && CTD_LOAD_NO_DRAW) {
			ShowBlinkCore();
		}
		
		//TRACE("g_nNoMouseMoveCount: %d\n", g_nNoMouseMoveCount);
#if ENABLE_HIDECURSOR
		extern bool g_bMenuPoping;
		
		bool b = (g_bHideMouse && !g_bUseMouse && !g_bURLNoMouse
			&& !g_bMenuPoping
			&& g_bMouseVisible);
		//TRACE("g_bMenuPoping = %d b = %d, m_bHaveFocus = %d\n", g_bMenuPoping, b, m_bHaveFocus);
		if (g_bHideMouse && !g_bUseMouse && !g_bURLNoMouse
			&& !g_bMenuPoping
			&& ++g_nNoMouseMoveCount == 10
			&& g_bMouseVisible) {
			// 3����mousemove����֮
			// ��Ч���ˣ����ǻ�Ҫ�жϣ�1 cursor�Ƿ���view�ڣ�2 �Ƿ��жԻ��򣬼�view�Ƿ��н���
			if (m_bHaveFocus) {
				CRect r;
				GetWindowRect(&r);
				CPoint p;
				::GetCursorPos(&p);
				if (r.PtInRect(p)) {
					//AfxMessageBox(_T("hiding cursor\n"));
					//					int r = ::ShowCursor(FALSE);
					//					TRACE(_T("hided cursor, r = %d\n"));
					//					g_bMouseVisible = false;
					ToggleCursor(FALSE);
				}
			}
			if (g_bMouseVisible) {
				// δ����
				g_nNoMouseMoveCount = 0;
			}
		}
#endif//ENABLE_HIDECURSOR
		
		//
		//		if (m_nCtdFile == 2) // ������ʵ���ն��ļ��Ĳ鿴
		//		{
		//			m_Core.AddTxt(m_Core.m_pszSource, _tcslen (m_Core.m_pszSource));
		//			m_nCtdFile = 1;
		//			RedrawWindow();
		//		}//Add this because sometime there is animation
					  }
		
		break;
		
	case TIMER_CTERM: {
		// ϵͳTimer�¼���ÿ�봥��һ��
		if (!m_nCtdFile && m_Sock.m_bStarted) {
			// ��ֹ����
#if ENABLE_PYTHON
			g_pMainWnd->PythonCallback(_T("OnTimer"), (long*) &m_nSessionID, 1);
#endif
			//TRACE(_T("in CCTermView::OnTimer\n"));
			//DWORD tick=GetTickCount();
			//TRACE(_T(" \t tick %ld, elapse:%ld\n"), tick, tick-lasttick);
			//lasttick=tick;
			m_nLastInputTime += g_nTimer;
			
			if (g_bAntiIdle && m_bLogined && m_nLastInputTime >= g_nIdleTime) {
				// ��ֹ�����ҳ�����ֹ����ʱ��
				//TRACEF (" AntiIdle \n");
				// �������벻�����ڼ����ǰ��Sendʱ����g_nGlobalIdleTime������Ҫ�ָ�
				long oldGlobalIdleTime = g_nGlobalIdleTime; //backup
				
#if ENABLE_PYTHON
				if (g_bEnablePython && g_bSysPythonScriptLoaded) {
					g_pMainWnd->PythonCallback(_T("antiIdle"), (long*) &m_nSessionID, 1);
				}
				else
#endif//ENABLE_PYTHON
				{
					CString s = AntiIdleString();
					if (!s.IsEmpty()) {
						CString str = TranslateString(s);
						Send(str, str.GetLength());
					}
					
					//extern BOOL  g_bInLocking;
					//if(g_bInLocking) //���³��Է����������Ч
					//	Send(_T("\n"), 1);
				}
				
				g_nGlobalIdleTime = oldGlobalIdleTime; //restore
			}
		}
					  }
		
		break;
		
	case TIMER_SLEEP: // *[nM
		KillTimer(TIMER_SLEEP);
		m_Core.SetSleepEnd();
		m_Core.AddTxt(); // continue dealing
		break;
		
#if ENABLE_RAWCTD
	case TIMER_CTD_FILE:
		if (!m_bCtdWait) {
			if (m_nCtdFile == 3) {
				GetNextPacket(m_ctd_fp);
			}
			else {
				// .csm
				m_Core.ScreenDown();
			}
		}
		break;
#endif//ENABLE_RAWCTD
	}
	
	CParentView::OnTimer(nIDEvent);
}

#if ENABLE_GRAPH

#define getx(x) ((nx*m_nCharCellWidth+1)/2+((x)*m_nCharCellWidth+5)/10)
#define gety(y) (ny*m_nCharCellHeight+((y)*m_nCharCellHeight+5)/10)

void CCTermView::ShowGraph(CDC *pDC) const
{
	//TRACEF("ShowGraph\n");
	int nNum = m_Core.m_Graph.m_nNum;
	
	if (nNum <= 0) return;
	
	int i, j;
	
	int nx, ny;
	
	const SGraphSeq *pSeq;
	
	CFont *pFont;
	
	CPen *pPen, *pOld;
	
	int  nMode = 0;//nullsapce:C4701
	
	const SGCommand *pCommand;
	
	SGraphSet GSet;
	
	GSet.Init(&m_Site, m_nCharCellWidth, this);
	
	pFont = pDC->SelectObject(&GSet.Font);
	
	pPen = pDC->SelectObject(&GSet.Pen);
	
	pDC->SetTextColor(GSet.fc);
	
	pDC->SetBkColor(GSet.bc);
	
	pDC->SelectObject(&GSet.Brush);
	
	for (i = 0;i < nNum;i++) {
		pSeq = &m_Core.m_Graph.Seq[i];
		nx = pSeq->x;
		ny = pSeq->y;
		
		if (m_nStartLine > ny || ny > m_nStartLine + m_nTermHeight - 1)
			continue;
		
		ny -= m_nStartLine;
		
		for (j = 0;j < pSeq->nCommand;j++) {
			pCommand = &pSeq->Command[j];
			
			switch (pCommand->nType) {
				
			case GCT_LINE:
				pDC->MoveTo(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[1]));
				pDC->LineTo(getx(pCommand->snParam[2]),
					gety(pCommand->snParam[3]));
				break;
				
			case GCT_POINT:
				pDC->SetPixel(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[1]),
					GSet.fc);
				break;
				
			case GCT_ARC:
				pDC->Arc(getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[2]),
					getx(pCommand->snParam[0] + pCommand->snParam[2]),
					gety(pCommand->snParam[1] + pCommand->snParam[2]),
					getx(pCommand->snParam[0] + int (pCommand->snParam[2]*cos(3.1416*pCommand->snParam[3] / 180))),
					gety(pCommand->snParam[1] + int (pCommand->snParam[2]*sin(3.1416*pCommand->snParam[3] / 180))),
					getx(pCommand->snParam[0] + int (pCommand->snParam[2]*cos(3.1416*pCommand->snParam[4] / 180))),
					gety(pCommand->snParam[1] + int (pCommand->snParam[2]*sin(3.1416*pCommand->snParam[4] / 180))));
				break;
				
			case GCT_TEXT:
				
				if (GSet.bTextTrans) {
					nMode = pDC->GetBkMode();
					pDC->SetBkMode(TRANSPARENT);
				}
				
				pDC->TextOut(getx(pCommand->snParam[0]),
					
					gety(pCommand->snParam[1]),
					pCommand->szText);
				
				if (GSet.bTextTrans)
					pDC->SetBkMode(nMode);
				
				break;
				
			case GCT_ROUND:
				pDC->Arc(getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[3]),
					getx(pCommand->snParam[0] + pCommand->snParam[2]),
					gety(pCommand->snParam[1] + pCommand->snParam[3]),
					getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[3]),
					getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[3]));
				
				break;
				
			case GCT_RECT:
				pDC->MoveTo(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[1]));
				
				pDC->LineTo(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[3]));
				
				pDC->LineTo(getx(pCommand->snParam[2]),
					gety(pCommand->snParam[3]));
				
				pDC->LineTo(getx(pCommand->snParam[2]),
					gety(pCommand->snParam[1]));
				
				pDC->LineTo(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[1]));
				
				break;
				
			case GCT_F_RECT:
				pDC->FillSolidRect(getx(pCommand->snParam[0]),
					gety(pCommand->snParam[1]),
					getx(pCommand->snParam[2]) - getx(pCommand->snParam[0]),
					gety(pCommand->snParam[3]) - gety(pCommand->snParam[1]), GSet.bc);
				
				break;
				
			case GCT_F_ROUND:
				pDC->Ellipse(getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[3]),
					getx(pCommand->snParam[0] + pCommand->snParam[2]),
					gety(pCommand->snParam[1] + pCommand->snParam[3]));
				
				break;
				
			case GCT_F_ARC:
				pDC->Pie(getx(pCommand->snParam[0] - pCommand->snParam[2]),
					gety(pCommand->snParam[1] - pCommand->snParam[2]),
					getx(pCommand->snParam[0] + pCommand->snParam[2]),
					gety(pCommand->snParam[1] + pCommand->snParam[2]),
					getx(pCommand->snParam[0] + int (pCommand->snParam[2]*cos(3.1416*pCommand->snParam[3] / 180))),
					gety(pCommand->snParam[1] + int (pCommand->snParam[2]*sin(3.1416*pCommand->snParam[3] / 180))),
					getx(pCommand->snParam[0] + int (pCommand->snParam[2]*cos(3.1416*pCommand->snParam[4] / 180))),
					gety(pCommand->snParam[1] + int (pCommand->snParam[2]*sin(3.1416*pCommand->snParam[4] / 180))));
				
				break;
				
			case GCT_SFC:
				GSet.SetFColor(pCommand, pDC);
				
				break;
				
			case GCT_SBC:
				GSet.SetBkColor(pCommand, pDC);
				
				break;
				
			case GCT_SLW:
				GSet.Pen.DeleteObject();
				
				GSet.nWidth = pCommand->snParam[0];
				
				if (GSet.nWidth > 5) GSet.nWidth = 5;
				
				if (GSet.nWidth < 1) GSet.nWidth = 1;
				
				GSet.Pen.CreatePen(PS_SOLID, GSet.nWidth, GSet.fc);
				
				pOld = pDC->SelectObject(&GSet.Pen);
				
				if (pOld) pOld->DeleteObject();
				
				break;
				
				/*			case GCT_SM:GSet.bXOR=pCommand->snParam[0];
				if(pCommand->snParam[0])
				pDC->SetROP2(R2_XORPEN);
				else
				pDC->SetROP2(R2_COPYPEN);
				break;*/
				
			case GCT_ST:
				GSet.SetFont(pCommand, pDC, m_nCharCellWidth);
				
				break;
				
			case GCT_RESET:
				GSet.Reset(pDC, &m_Site, m_nCharCellWidth);
				
				break;
				
				
			}
		}
	}
	
	pDC->SelectObject(pFont);
	
	pDC->SelectObject(pPen);
}

#endif//ENABLE_GRAPH

void CCTermView::AddStart()
{
	Refresh();		// Ŀ���ǳ�ʼ������ //���е�����SetViewFont������ ������SetScrollSizes
	char *ts = "\x1b[2J\x1b[J\x1b[1m"
		"�q���������������������������r\r\n"
		"�� ������...                ��\r\n"
		"��                          ��\r\n"
		"�� ���Ժ�     �q�������r    ��\r\n"
		"��            �� \x1b[U<command=\"disconnect\" text=\"ȡ��\" color=14> ��    �� \r\n\x1b[1m"
		"��            �t�������s    ��\r\n"
		"�t���������������������������s\r\n";
	
	m_Core.AddTxt(ts, strlen(ts), true);
}

#if ENABLE_MESSAGE
void CCTermView::PopMessage(bool bAutoReply)
{
	//if(!m_Site.m_Login.m_bMes)		վ��ṹ�е�m_bMes ͣ��
	//	  return;
	
	AfxGetMainWnd()->PostMessage(WM_MSGPOP, WPARAM(this), 0);   // �Ա�viewָ��Ϊ����wParam
	//	((CMDIChildWnd*)GetParentFrame())->MDIActivate();// �л�Ϊ�����
	
	if (g_bMsgRec)		// ��¼�յ�����Ϣ
		m_Status.Mes.WriteToFile(&m_Site, (LPCTSTR) m_szUserPath);
	
	if (bAutoReply) {	// �Զ��ظ�, ���������ڣ����������������л���ǰ̨
		if (g_bIsAutoReply && !g_szReply.IsEmpty()) {
			//SendReplyString
			//		Send(_T("\x10"),1); //^P ����
			
			if (SiteType() == ST_MAPLE)
				Send(_T("\x12"), 1);  //^r
			else
				Send(_T("r"), 1);
			
			//		TCHAR msghead[]=_T("[CTerm]:");
			//		Send(msghead, _tcslen(msghead));
			Send(g_szReply, _tcslen(g_szReply));
			
			Send(_T("\n"), 1);
			
			if (SiteType() == ST_MAPLE)
				Send(_T("\n"), 1);
		}
	}
	else if (g_bMsgPopup) {
		// �����������
		//if(m_pMessageDlg!=NULL) //messaging with msgdlg
		//{
		//	WaitForSingleObject(m_pMessageDlg->m_hWnd, INFINITE); // Ҳ��û��Ҫ����Ϊ��Ϣ��˳�����ģ����Ტ�е�ͬʱ���뱾����
		//}
		if (SiteType() == ST_MAPLE)
			Send(_T("\x12"), 1);  //^r
		else
			Send(_T("r"), 1);
		
		CMessageDlg dlgMessage(this);
		m_pMessageDlg = &dlgMessage;
		dlgMessage.m_sender = m_Status.Mes.szUserName;
		dlgMessage.m_inmes = m_Status.Mes.szMes;
		CTime Now = CTime::GetCurrentTime();
		dlgMessage.m_time = Now.Format(_T("%H:%M"));
		dlgMessage.m_bMultiLine = m_Status.m_bMesMultiLine;		// ������Ϣ��SMTH, YTHT, �Ľ���FB�� ������Ϣ
		
		//int ret=dlgMessage.DoModal();������Ƿ�����
		dlgMessage.DoModal(); // �˺�Ҫ��ִ���κβ�����ֱ�ӷ���
	}	// if m_bMsgPopup
}

void CCTermView::SendMsg()
{
	CMessageDlg dlgMessage(this, true);	
	m_pMessageDlg = &dlgMessage;
	CTime Now = CTime::GetCurrentTime();
	dlgMessage.m_time = Now.Format(_T("%H:%M"));
	dlgMessage.DoModal();
}

// ����msgdlg����
void CCTermView::DealMsgDlg(bool bOK)
{
	ASSERT(m_pMessageDlg);
	
	if (!m_pMessageDlg)
		return;
	
	if (bOK) {
		if (m_Sock.m_bStarted) {
			// �п��ܵ���
			int len = m_pMessageDlg->m_replystr.GetLength();
			
			if (len > 960) { // 12*m_nTermWidth
				m_pMessageDlg->m_replystr = m_pMessageDlg->m_replystr.Left(960);
				len = 960;
			}
			
			Send(m_pMessageDlg->m_replystr, len);
			
			Send(_T("\n"), 1);
			
			if (SiteType() == ST_MAPLE)
				Send(_T("\n"), 1);
			
			m_Status.Mes.bReply = TRUE;
			
			_tcscpy(m_Status.Mes.szMes, m_pMessageDlg->m_replystr);
			
			if (g_bMsgRec) {
				// ��¼
				m_Status.Mes.WriteToFile(&m_Site, m_szUserPath);
			}
		}
	}
	else {
		if (m_Sock.m_bStarted) {
			// �п��ܵ���
			if (SiteType() == ST_MAPLE)
				Send(_T("\n\n\n"), 3);
			else
				Send(_T("\r"), 1);
		}
	}
	
	m_pMessageDlg = NULL;
}

#endif//ENABLE_MESSAGE

void CCTermView::ShowStream(int nStream) const
{
	CWnd *pMainWnd = AfxGetMainWnd();
	if (pMainWnd)
		pMainWnd->SendMessage(WM_STEAMIN, nStream, (DWORD) m_Sock.m_pBuf);
}

//y: ��������
bool CCTermView::InClickRect(int y, int x) const
{
	y -= m_nStartLine;
	
	if (m_bClickRect) {
		return (m_rectClick.top <= y && y <= m_rectClick.bottom
			&& m_rectClick.left <= x && x < m_rectClick.right); //����ҿ�
	} else {
		if (y == m_rectClick.top)
			return (m_rectClick.left <= x && x < m_nTermWidth);
		else if (y == m_rectClick.bottom)
			return (0 <= x && x < m_rectClick.right);
		else if (m_rectClick.top < y && y < m_rectClick.bottom)
			return (0 <= 0 && x < m_nTermWidth);
		else
			return false;
	}
}

//��һ������(�ַ�)����ӻ��ȥĳ������
inline void CCTermView::AddAttribute(const CRect &rect)  //, const bool bTrue)
{
	if (rect.Width() == 0 && rect.Height() == 0) return;
	
	//TRACE(_T("in AddAttribute \t rect:%d,%d,%d,%d\n"),rect.left,rect.top,rect.right,rect.bottom);
	
	int s = m_nStartLine + rect.top;
	
	int e = m_nStartLine + rect.bottom;
	
	m_Core.SetChange(s, e);
	
	RedrawLine(s, e);
}

inline void CCTermView::AddAttribute(const int start, const int end)
{
	ASSERT(0 <= start && start <= m_nTermHeight * m_nTermWidth - 1);
	ASSERT(0 <= end && end <= m_nTermHeight * m_nTermWidth && start <= end);
	
	int s = m_nStartLine + start / m_nTermWidth, e = m_nStartLine + end / m_nTermWidth;
	m_Core.SetChange(s, e);
	
	RedrawLine(s, e);
}

void CCTermView::SetClickRect(const CRect &rect1, const bool bURL, const bool bRect)
{
	//bURLָֻʾ����������Ƿ�URL
	//�������ָ���ַ����ֶ�ѡ��״̬ʱ����Ӧ����bURL=true����
	ASSERT(0 <= rect1.top && rect1.top <= m_nTermHeight && 0 <= rect1.left && rect1.left <= (m_nTermWidth + 1));
	ASSERT(0 <= rect1.bottom && rect1.bottom <= m_nTermHeight && 0 <= rect1.right && rect1.right <= (m_nTermWidth + 1));
	
	//TRACE("SetClickRect 0 bu:%d mr:%d bR: %d ch:%d\n", bURL, m_bClickRect, bRect, m_Core.m_bChanged);
	//TRACE(_T("\told %d:%d;%d:%d\n"), m_rectClick.left, m_rectClick.right, m_rectClick.top, m_rectClick.bottom);
	//TRACE(_T("\tnew %d:%d;%d:%d\n"), rect1.left, rect1.right, rect1.top, rect1.bottom);
	
	if (rect1 == m_rectClick && m_bClickRect == bRect) return;
	
#if ENABLE_SHOWIP
	if (g_pShowIPDlg->IsWindowVisible()) // IP
		g_pShowIPDlg->ShowWindow(SW_HIDE);
	
#endif//ENABLE_SHOWIP
	
#if ENABLE_PICTURE
	// && (g_pPicShowDlg->m_nState != PIC_SUCCESS || bURL)
	if (g_pPicShowDlg && g_pPicShowDlg->IsWindowVisible()
		&& g_pPicShowDlg->GetDisplaySize() == 0
		)
		g_pPicShowDlg->OnCancel();
	
#endif//ENABLE_PICTURE
	
	//TRACE("SetClickRect 1\n");
	// ȥ��ԭ����
	CRect rect = m_rectClick;
	
	m_rectClick = rect1;
	
	m_bClickRectURL = bURL;
	
	m_bClickRect = bRect;
	
	//m_Core.m_bChanged��ʾ���ڸ��£���updatestatus���ã������ƣ��������һ����ǰ��ʾ��
	if (!m_Core.Changed()) AddAttribute(rect);
	
	///TRACE("SetClickRect 2\n");
	
	if (rect1.Width() == 0 && rect1.Height() == 0) {
		return;
	}
	
	//���µ�
	if (!m_Core.Changed()) AddAttribute(m_rectClick);
}

// ������վ
void CCTermView::FastAway()
{
	if (m_nCtdFile) {
		GetParentFrame()->SendMessage(WM_CLOSE);
		return;
	}
	
	if (!m_Sock.m_bStarted) return;
	
	if (g_bEnablePython && g_bSysPythonScriptLoaded) {
#if ENABLE_PYTHON
		CString code;
		code.Format(_T("QuickAway(%d, %s)"), m_nSessionID, g_bAutoMailBack ? _T("True") : _T("False"));
		RunPythonCode(code, m_nSessionID);
#endif
	} else {
		TCHAR ts[100], str[100];
		
		if (SiteType() != ST_MAPLE) {	// FB/smth/ytht/lily
			if (g_bAutoMailBack)
				_tcscpy(str, _T("\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\n\nM\n\n\n"));   //��M��Ϊ����Ϣ�Ļ�����
			else
				_tcscpy(str, _T("\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\n\n\n\n\n"));   //���Ļ�����
		}
		else {
			//maple
			_tcscpy(str, _T("\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\x1b[D\ry\r\r\r\r"));   //���Ļ����� ���Ľ���\r �� \n
		}
		
		//TRACE(_T("in void CCTermView::FastAway() m_nStatus:%d"), m_Status.Status());
		SITESTATUS st = m_Status.Status();
		switch (st) {
			
		case SST_UNKNOWN:
			
		case SST_MENU:
			
		case SST_LIST:
			
		case SST_ARTICLE:
			
		case SST_END:
			
		case SST_ENTER:
			_tcscpy(ts, str);
			break;
			
		case SST_CHATROOM:
			
			if (SiteType() == ST_MAPLE)
				_stprintf(ts, _T("/bye\n\n%s"), str);
			else
				_stprintf(ts, _T("\4%s"), str);
			
			break;
			
		case SST_TALK:
			if (SiteType() == ST_MAPLE)
				_stprintf(ts, _T("\3\3\n\n%s"), str);
			else
				_stprintf(ts, _T("\4%s"), str);
			
			break;
			
		case SST_WRITE:
			_stprintf(ts, _T("\x18%c\n\n%s"), 'a', str);
			
			break;
			
		default:
			_tcscpy(ts, str);
			
			break;
		}
		
		Send(ts, _tcslen(ts));
	}
}

//=============================================================================

void CCTermView::OnContextMenu(CWnd*, CPoint point)
{
	// CG: This block was added by the Pop-up Menu component
	{
#if ENABLE_HIDECURSOR
		if (g_bHideMouse && !g_bUseMouse && !g_bURLNoMouse && !g_bMouseVisible) {
			//			::ShowCursor(TRUE);
			//			g_bMouseVisible = true;
			ToggleCursor(TRUE);
		}
#endif//ENABLE_HIDEMENU
		
		if (point.x == -1 && point.y == -1) {
			//keystroke invocation
			CRect rect;
			GetClientRect(rect);
			ClientToScreen(rect);
			
			point = rect.TopLeft();
			point.Offset(5, 5);
		}
		
		CMenu menu;
		
		VERIFY(menu.LoadMenu(CG_IDR_POPUP_CTERM_VIEW));
		
#if ENABLE_MULTILANG
		
		if (g_currLangID != ID_LANG1) {
			g_OutMenuStrings(&menu, _T(""));  //����Ĭ��
			g_SetMenuStrings(&menu, _T(""));
		}
		
#endif// ENABLE_MULTILANG
		
		CMenu* pPopup = menu.GetSubMenu(0);
		
		ASSERT(pPopup != NULL);
		
		CWnd* pWndPopupOwner = AfxGetMainWnd();
		
		while (pWndPopupOwner->GetStyle() & WS_CHILD)
			pWndPopupOwner = pWndPopupOwner->GetParent();
		
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
			pWndPopupOwner);
		
		//		if (g_bHideMouse && !g_bUseMouse && !g_bURLNoMouse && !g_bMouseVisible) {
		//			ToggleCursor(TRUE);
		//			g_bMouseVisible = true;
		//		}
	}
}

void CCTermView::FixPosition(CDC *pDC)
{
	if (g_bShowCenter) {					//������ʾ
		CRect r;
		GetClientRect(&r);
		m_ptOri.cx = (r.Width() - m_nCharCellWidth * m_nTermWidth / 2) / 2; // ǰ���2ȷʵӦ����2
		m_ptOri.cy = (r.Height() - m_nCharCellHeight * m_nTermHeight) / 2;
	} else {
		m_ptOri.cx = 0;
		m_ptOri.cy = 0;
	}
	
	::SetViewportOrgEx(pDC->m_hDC, m_ptOri.cx, m_ptOri.cy, NULL);
}

BOOL CCTermView::FixPoint(POINT &pt) const
{
	pt.x -= m_ptOri.cx;
	pt.y -= m_ptOri.cy;
	return (pt.x >= 0 && pt.y >= 0
		&& pt.x <= m_nTermWidth * m_nCharCellWidth / 2
		&& pt.y <= (m_nTermHeight + 1) * m_nCharCellHeight);
}

CPoint CCTermView::UndoFixPoint(const CPoint& point) const
{
	return point + m_ptOri;
}

BOOL CCTermView::GetCursorPos(LPPOINT pt) const
{
	BOOL bRet = ::GetCursorPos(pt);
	//TRACE(_T("in CCTermView::GetCursorPos \t pt:%d, %d\n"), pt->x, pt->y);
	FixPoint(*pt);
	return bRet;
}

void CCTermView::OnUpdateAttachments(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_Status.Status() == SST_WRITE);
}

void CCTermView::OnAttachments()	//�ϴ�����	(��֣���֪����������������Bat 2011-9-22)
{
	CFileDialogEx dlg(TRUE, _T(""), _T("*.*"), OFN_ENABLESIZING | OFN_READONLY | OFN_EXPLORER |
		OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, _T("�����ļ� (*.*)|*.*||"), this);
	
	if (dlg.DoModal() == IDOK) {
		PostAttachments(dlg.GetPathName());
	}
}

void CCTermView::PostAttachments(const CString &strFileName)	//�����ϴ��ı��ļ���
{
	CFile f;
	CFileException e;
	
	if (!f.Open(strFileName, CFile::modeRead | CFile::shareDenyWrite | CFile::typeBinary, &e)) {
		const int BUF_SIZE = 1024;
		TCHAR szMsg[BUF_SIZE];
		e.GetErrorMessage(szMsg, BUF_SIZE);
		MessageBox(szMsg, _T("�޷����ļ�"), MB_ICONWARNING | MB_OK);
		return;
	}
	
	CString strMsg;
	
	const unsigned nBufSize = f.GetLength();
	
	if (nBufSize == 0) {
		MessageBox(_T("����ճ������Ϊ0���ļ�"), _T("�ļ�����"), MB_ICONWARNING | MB_OK);
		
		return;
	}
	
	TCHAR *szBuf = new TCHAR[nBufSize];
	
	if (f.Read(szBuf, f.GetLength()) != nBufSize) {
		delete[] szBuf;
		
		strMsg = _T("�޷�������ȡ�ļ� ");
		strMsg += f.GetFilePath();
		MessageBox(strMsg, _T("��ȡ�ļ�����"), MB_ICONERROR | MB_OK);
		
		return;
	}
	
	f.Close();
	
	strMsg = _T("Content-Type: application/octet-stream; name=\"");
	strMsg += ::PathFindFileName(strFileName);
	strMsg += _T("\"\r\n");
	Send(strMsg, strMsg.GetLength());
	
	strMsg = _T("Content-Transfer-Encoding: base64\r\n");
	Send(strMsg, strMsg.GetLength());
	
	strMsg = _T("Content-Disposition: attachment; filename=\"");
	strMsg += ::PathFindFileName(strFileName);
	strMsg += _T("\"\r\n\r\n");
	Send(strMsg, strMsg.GetLength());
	
#if ENABLE_BASE64
	TCHAR *szEncoded = Base64Encode(szBuf, nBufSize);
	const int LINE_WIDTH = 76, nEncodedLen = _tcslen(szEncoded);
	
	delete[] szBuf;
	
	int i;
	const TCHAR *pch;
	
	for (i = 0, pch = szEncoded; i < nEncodedLen / LINE_WIDTH; i++, pch += LINE_WIDTH) {
		Send(pch, LINE_WIDTH);
		Send(_T("\r\n"), 2);
	}
	
	Send(pch, nEncodedLen % LINE_WIDTH);
	
	Send(_T("\r\n\r\n"), 4);
	
	free(szEncoded);
#endif//ENABLE_BASE64
}

void CCTermView::OnInitialUpdate()
{
	//TRACEF(" OnInitialUpdate \n");
	CParentView::OnInitialUpdate();
	
	CRect rect; // ���Ӵ˺�����Ϊ���ڴ��ڴ����������С(����childframe::onwindowposchanging)
	GetParentFrame()->GetWindowRect(&rect);
	//	rect.bottom+=1;//���!�޴ˣ���Ҳ�ı�ߴ�
	GetParentFrame()->MoveWindow(&rect);
	
	if (!g_bUseMouse) {
		// ��ֹ������ꡢ�����Զ�����ʱ����걣��æ״̬
		//TRACEF("IDC_ARROW 1\r\n");
		SetCursor(::LoadCursor(NULL, IDC_ARROW));
	}
	
	m_bViewInited = true;
}


//----------------- IME ----------------------------------------
// thanks to kxn (author of Fterm) for his PASCAL code

BOOL CCTermView::PreTranslateMessage(MSG* pMsg)
{
	static CString s;
	
	if (pMsg->message == WM_KEYDOWN) {
		if (isdown(VK_CONTROL) && pMsg->lParam >= 0) {
			if (pMsg->wParam == 'C') {
				// ^C
				if (g_bCtrlCCopy && (IsCopySelected() || m_bClickRectURL)) {
					g_pMainWnd->PostMessage(WM_COMMAND, ID_EDIT_COPY, NULL);
					return TRUE;
				}
			}
			else if (pMsg->wParam == 'V') {
				// ^V
				if (g_bCtrlVPaste && SiteType() != ST_SMTH && IsWriteStatus()) {
					// �༭״̬�£�Ctrl+V �ض���Ϊ ճ��
					// ��smth��^V�ǲ��ֵ��ȼ�����Ч
					g_pMainWnd->PostMessage(WM_COMMAND, ID_EDIT_PASTE, NULL);
					return TRUE;
				}
			}
		}
	}
	else if (pMsg->message == WM_IME_STARTCOMPOSITION) {
		//	TRACEF (_T ("WM_IME_STARTCOMPOSITION\n"));
		HIMC hIMC;
		COMPOSITIONFORM comp;
		
		if (m_Sock.m_bStarted) {
			//		pt=GetCaretPos();
			DoSetIMEWindow(m_Core.cursorX(), m_Core.cursorY());
			//  ����Լ�д�ĺ������� IME ����λ��
		} else {
			hIMC = ImmGetContext(this->m_hWnd);
			comp.dwStyle = CFS_DEFAULT;
			ImmSetCompositionWindow(hIMC, &comp);
			ImmReleaseContext(this->m_hWnd, hIMC);
		}
		
		//    Message.Result := DefWindowProc(handle,Message.Msg,Message.WParam,Message.LParam);
	} else if (pMsg->message == WM_IME_COMPOSITION) { //������������ת��
		//		TRACEF (_T ("WM_IME_COMPOSITION\n"));
		//		if (true) // m_Site.m_Decode.m_nInputCodeConvert
		{
			HIMC hIMC;
			DWORD dwSize;
			
			if (m_Sock.m_bStarted && (pMsg->lParam &GCS_RESULTSTR) != 0) {
				hIMC = ImmGetContext(this->m_hWnd);
				dwSize = ImmGetCompositionString(hIMC, GCS_RESULTSTR, NULL, 0);
				
				if (dwSize > 0) {
					//SetLength(s,dwSize);
					TCHAR *buf = s.GetBuffer(dwSize + 1);
					ImmGetCompositionString(hIMC, GCS_RESULTSTR, buf, dwSize);
					buf[dwSize] = '\0';
					//TnCnx.SendStr(s);
					
					// ����ת��
					// ��ʱʹ��ȫ�ֱ������ɹ�������ť�л����Ժ����Ϊ,m_Site�ı���
					
					if (m_Site.m_Decode.m_nInputCodeConvert == INPUT_B2G) {
						BIG52GB((BYTE *) buf);
					} else if (m_Site.m_Decode.m_nInputCodeConvert == INPUT_G2B) {
						GB2BIG5((BYTE *) buf);
					} else if (m_Site.m_Decode.m_nInputCodeConvert == INPUT_G2U) {
						s.ReleaseBuffer();
						GBKToUtf8(s);
					}
					
					if (m_Site.m_Decode.m_nInputCodeConvert != 3) s.ReleaseBuffer();
					
					Send(s, s.GetLength()); // ����������
					
					s.Empty();
				}
				
				ImmReleaseContext(this->m_hWnd, hIMC);
				
				return TRUE;
			} else if (g_bIMEChar) {
				hIMC = ImmGetContext(this->m_hWnd);
				dwSize = ImmGetCompositionString(hIMC, GCS_COMPSTR, NULL, 0);
				// ����ȸ�ƴ�����ԣ�����5.1���У�����6.1����
				
				if (dwSize > 0) {
					TCHAR *buf = s.GetBuffer(dwSize + 1);
					ImmGetCompositionString(hIMC, GCS_COMPSTR, buf, dwSize);
					buf[dwSize] = '\0';
					s.ReleaseBuffer();
				}
				
				ImmReleaseContext(this->m_hWnd, hIMC);
			}
		}
	} else if (g_bIMEChar && pMsg->message == WM_IME_ENDCOMPOSITION) {
		//        TRACEF (_T ("WM_IME_COMPOSITION\n"));
		if (!s.IsEmpty()) {
			// s�ǿ�˵�����ϴε����뷨����û�����־ͽ�����
			// ��Ϊ���ֻ�ִ��s.empty()
			// s�б����ƴ����
			// ֱ�ӷ���
			Send(s, s.GetLength()); // ����������
			s.Empty();
		}
	}
	
	
	return CParentView::PreTranslateMessage(pMsg);
}

// �������뷨����λ�ã�ʵ�ֹ�����
// y ��������
void CCTermView::DoSetIMEWindow(int X, int Y) const
{
	HIMC hIMC;
	COMPOSITIONFORM comp;
	LOGFONT LFont;
	CFont theFont;
	//	CANDIDATEFORM cand;
	
	//	if (false) // not canfocus then exit;
	//		return;
	
	Y -= m_nStartLine;
	
	//	CPoint pt=CharToPtPos(CPoint(m_Core.cursorX(), m_Core.cursorY()));
	//	SetCaretPos(pt);
	
	hIMC = ImmGetContext(this->m_hWnd);
	comp.dwStyle = CFS_POINT;// CFS_FORCE_POSITION;
	CPoint pt = CharToPtPos(CPoint(X, Y));
	comp.ptCurrentPos.x = pt.x;
	comp.ptCurrentPos.y = pt.y;
	//	comp.rcArea=CRect(100,100,180,120);
	
	//     theFont = Font;
	memset(&LFont, 0, sizeof(LFont));
	LFont.lfHeight = m_nCharCellHeight; //theFont.Height; // todo: ��ΪTrueFontHeight, TrueFontHeight
	LFont.lfWidth = m_nCharCellWidth / 2;
	LFont.lfCharSet = 0x83;//?
	//     case theFont.Pitch of
	//        fpDefault : LFont.lfPitchAndFamily = DEFAULT_PITCH;
	//        fpFixed : LFont.lfPitchAndFamily = FIXED_PITCH;
	//        fpVariable : LFont.lfPitchAndFamily = VARIABLE_PITCH;
	//     end;
	LFont.lfPitchAndFamily = VARIABLE_PITCH; //2
	_tcscpy(LFont.lfFaceName, m_font);
	ImmSetCompositionFont(hIMC, &LFont);
	
	ImmSetCompositionWindow(hIMC, &comp);
	
	/*cand.dwIndex = 0;
	cand.dwStyle = CFS_CANDIDATEPOS;
	cand.ptCurrentPos.x = pt.x;
	cand.ptCurrentPos.y = pt.y+m_nFontSize;
	ImmSetCandidateWindow(hIMC,&cand);*/
	
	ImmReleaseContext(this->m_hWnd, hIMC);
}

void CCTermView::OnDestroy()
{
#if ENABLE_MESSAGE
	if (m_pMessageDlg) {
		//m_pMessageDlg->m_pView = NULL;// ȥ����䲻֪���᲻�������
		//m_pMessageDlg->SendMessage(WM_CLOSE);// �����ز���
		m_pMessageDlg->EndDialog(-1);
	}
#endif//ENABLE_MESSAGE	if (m_pMessageDlg) // ��Ϣ��������ʾ
	
	if (m_pMemDC) {
		m_pMemDC->DeleteDC();
		m_pMemBitmap->DeleteObject();
		delete m_pMemBitmap;
		delete m_pMemDC;
	}
	
	if (!g_bHaveModalDlg)
		CParentView::OnDestroy();
	
#if ENABLE_RAWCTD
	if (m_ctd_fp) {
		KillTimer(TIMER_CTD_FILE);
		fclose(m_ctd_fp);
		m_ctd_fp = NULL;
	}
#endif//ENABLE_RAWCTD
}

void CCTermView::OnKillFocus(CWnd* pNewWnd)
{
	//TRACEF(" CCTermView::OnKillFocus \n");
	//TRACEFINTS(" CCTermView::OnKillFocus ", (int)this);
	//TRACEFINTS(" CCTermView::OnKillFocus ", (int)pNewWnd);
	m_bHaveFocus = false;
	if (g_bCaptureMouse)
		::ReleaseCapture();
	
#if ENABLE_HIDECURSOR
	if (!g_bMouseVisible) {
		//		::ShowCursor(TRUE);
		//		g_bMouseVisible = true;
		//		g_nNoMouseMoveCount = 0;
		ToggleCursor(TRUE);
	}
#endif//ENABLE_HIDECURSOR
	CParentView::OnKillFocus(pNewWnd);
}

/////////////////////////////////////////////////////////////////////////////
// drag and drop message handlers
#if ENABLE_DRAG
LRESULT CCTermView::OnDragOver(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo*) pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));
	
	if (pInfo->m_pDataObject->IsDataAvailable(CF_TEXT))
		return DROPEFFECT_COPY;
	else
		return DROPEFFECT_NONE;
}

LRESULT CCTermView::OnDropEx(WPARAM pDropInfoClass, LPARAM lParm)
{
	return (DROPEFFECT) - 1;
}

LRESULT CCTermView::OnDrop(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo*) pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));
	
	//����������
	::SendMessage(g_pMainWnd->m_wndToolBar.GetSafeHwnd(), DROPM_DROP, (WPARAM) pDropInfoClass, lParm);
	return TRUE;
}

#endif //ENABLE_DRAG

#if ENABLE_ATTACH
// KBS��2006��5�¿�ʼ����Telnet�з���ʱ��u�ϴ���������ʾ��һ��URL��ַ���ϴ�������
// SiteStatus�м�����״̬��CCTermCore::AddTxt �м�⣬���������ڴ򿪸�URL��ַ
void CCTermView::UploadAtt()	//�ϴ�����  ������ͼ֮���������
{
	TCHAR  sLine[256];
	m_Core.GetLineStr(sLine, 1);	//�ϴ���ַ
	
/*	�Ƶ�������ͼ��
	CString sFileName;
	CString sFileNameBak;
	//�������������ͼƬ������������
	//�μ�������ҳ�еġ�ճ�����͡�ת����ʽ�����֣� http://blog.csdn.net/mp5li/article/details/6255776
	HANDLE hBitmap=NULL;  
	CxImage *image = new CxImage();  
	CTime time;
	if (OpenClipboard()) hBitmap=GetClipboardData(CF_DIB);  
	if (hBitmap)	image->CreateFromHANDLE(hBitmap);  
	CloseClipboard(); 
	if (image->IsValid()){  //
		time = CTime::GetCurrentTime() ;
		sFileName.Format("%s-%4d%02i%02i-%02i%02i%02i%s",g_PicPath + _T("\\CTerm"),	//ͼƬ�ļ���
			time.GetYear(),time.GetMonth(),time.GetDay(), time.GetHour(), time.GetMinute(),time.GetSecond(),".png");
		sFileNameBak = sFileName;
		image->Save(sFileName.LockBuffer(), CXIMAGE_FORMAT_PNG);	//����ͼƬ��ͼƬ�ļ���
		MessageBox(sFileName, _T("ͼƬ�ļ�"), MB_ICONINFORMATIONG | MB_OK);
		
		// Ȼ���������գ����ļ����ַ��������������(�Ա���һ����ͼ����ʱ�����ظ�����)
		HGLOBAL hmem;
		TCHAR * p = startcopy(sFileName.GetLength() + 1, hmem);
		if (p) memcpy(p, (LPCSTR)sFileName, sFileName.GetLength() + 1);
		endcopy(hmem);
	}
*/	

	CUploadAttDlg Dlg;
	_tcscpy(Dlg.sUrl, sLine);
	if (Dlg.DoModal() == IDOK) {
		Send("\n", 1);
		return;
	}
	
	return;		//���������Python�ϴ�����

/*
	if (sFileName.IsEmpty())	{	//�������������ͼƬ���ļ���Ϊ�գ������һ���ļ�
		CFileDialogEx dlg(TRUE, _T(""), _T("*.*"), OFN_ENABLESIZING | OFN_READONLY | OFN_EXPLORER |
			OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST, _T("�����ļ� (*.*)|*.*||"), this);
		if (dlg.DoModal() != IDOK) {
			Send("\n", 1);	//���ͻس�����ʹ��Ļ���£�������β���
			return;
		}
		sFileName = dlg.GetPathName();
	}
	
	CFile f;
	CFileException e;
	if (!f.Open(sFileName, CFile::modeRead | CFile::shareDenyWrite | CFile::typeBinary, &e)) {
		const int BUF_SIZE = 1024;
		TCHAR szMsg[BUF_SIZE];
		e.GetErrorMessage(szMsg, BUF_SIZE);
		MessageBox(szMsg, _T("�޷����ļ�"), MB_ICONWARNING | MB_OK);
		Send("\n", 1);	//���ͻس�����ʹ��Ļ���£�������β���
		return;
	}
	
	bool done = false;
#if ENABLE_PYTHON
	if (g_pMainWnd && g_bEnablePython && g_bSysPythonScriptLoaded) {
		sFileName.Replace(_T("\\"), _T("\\\\"));
		CString code;
		code.Format(_T("uponefile(r\"%s\")"), sFileName);
		RunPythonCode(code);
		done = true;
	}
#endif
	
	if (!done) 
		AfxMessageBox(_T("�ϴ�����ʧ�ܡ�ԭ��δ����Python֧�֣���Pythonδ������ʼ����������Python֧�֣������³�ʼ��Python"));
	else if (image->IsValid()) {
		image->Destroy();
		CString ss;
		ss.Format("�������е�ͼƬ�ѱ���Ϊ %s ������Ϊ�����ϴ���", sFileNameBak);
		AfxMessageBox(ss);
	}

	Send("\n", 1);	//���ͻس�����ʹ��Ļ���£�������β���
*/
}

#endif//ENABLE_ATTACH

#include "debugtool.h"

// ��ʾ��ʷ��Ļ��һ��
void CCTermView::OnHisPgup()
{
	//	TRACEFINTS("in OnHisPgup: m_nStartLine= ", m_nStartLine);
	
	int minLine = m_Core.MaxLine() - m_nMaxHistLine + 1;
	
	//	TRACEFINTS("in OnHisPgup: minLine= ", minLine);
	//	TRACEFINTS("in OnHisPgup: m_nMaxLine= ", m_Core.MaxLine());
	//	TRACEFINTS("in OnHisPgup: m_nMaxHistLine= ", m_nMaxHistLine);
	
	if (minLine < 0) minLine = 0;
	
	if (m_nStartLine <= minLine) return;
	
	SetClickRect(); //clear
	
	m_nStartLine -= m_nTermHeight;
	
	if (m_nStartLine < minLine) m_nStartLine = minLine;
	
	//	TRACEFINTS("in OnHisPgup: m_nStartLine= ", m_nStartLine);
	
	RedrawLine();
	
	//�����Ƿ���Ҫ�޸�m_Core.m_bChanged��
	//�Ƿ���Ҫ��SendMessage (WM_SETCURSOR);�ᵽǰ��ȥ
	SendMessage(WM_SETCURSOR, (WPARAM) GetSafeHwnd(), (LPARAM) MAKELONG(HTCLIENT, 0));
}

void CCTermView::OnHisPgdn()
{
	if (m_nStartLine == m_Core.MaxStartLine())
		return;
	
	SetClickRect(); //clear
	
	m_nStartLine += m_nTermHeight;
	
	if (m_nStartLine > m_Core.MaxStartLine()) m_nStartLine = m_Core.MaxStartLine();
	
	RedrawLine();
	
	SendMessage(WM_SETCURSOR, (WPARAM) GetSafeHwnd(), (LPARAM) MAKELONG(HTCLIENT, 0));
}

void CCTermView::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView)
{
	//TRACEF(" OnActivateView \n");
	if (m_bInited && bActivate && !m_nCtdFile) {
		//TRACE(_T(" OnActivateView pAV=%p pDV=%p this=%p\n"));
		//m_Core.m_bChanged = true; //����ʶ��url�ȣ���ʹ�����url��Χ��//�����url��Χ��,������ʶ��
		SendMessage(WM_SETCURSOR, (WPARAM) GetSafeHwnd(), (LPARAM) MAKELONG(HTCLIENT, 0));
		//m_Core.m_bChanged = false;
	}
	
	CView ::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

void CCTermView::OnUpdateHisPgup(CCmdUI* pCmdUI)
{
	int minLine = m_Core.MaxLine() - m_nMaxHistLine + 1;
	
	//	TRACEFINTS(_T("m_nMaxHistLine="), m_nMaxHistLine);
	//	TRACEFINTS(_T("minLine="), minLine);
	//	TRACEFINTS(_T("m_nTermHeight="), m_nTermHeight);
	//	TRACEFINTS(_T("m_nStartLine="), m_nStartLine);
	
	if (minLine < 0) minLine = 0;
	
	pCmdUI->Enable(m_nMaxHistLine > m_nTermHeight && m_nStartLine > minLine);
}

void CCTermView::OnUpdateHisPgdn(CCmdUI* pCmdUI)
{
	int minLine = m_Core.MaxLine() - m_nMaxHistLine + 1;
	
	if (minLine < 0) minLine = 0;
	
	pCmdUI->Enable(m_nMaxHistLine > m_nTermHeight && m_nStartLine < m_Core.MaxStartLine());
}

void CCTermView::OnBosscolor() 
{
	// ChangeColor(8);
	
	if (m_bBossColor) {
		for (int i = 0;i <= 15;i++) {
			m_Site.m_Decode.m_ColorSet[i] = m_ColorSet[i];
		}
	}
	else {
		BYTE *pColor;
		int R, G, B;
		int gray, i;
		
		for (i = 0;i <= 15;i++) {
			pColor = (BYTE *) & m_Site.m_Decode.m_ColorSet[i];
			R = pColor[0];
			G = pColor[1];
			B = pColor[2];
			gray = 255 - (R * 3 + G * 6 + B) / 10;
			
			if (gray < 0) gray = 0;
			
			if (gray > 255) gray = 255;
			
			m_ColorSet[i] = m_Site.m_Decode.m_ColorSet[i]; // �����Ա��л�
			m_Site.m_Decode.m_ColorSet[i] = RGB(gray, gray, gray);
		}
	}
	
	// m_Site.m_Decode.m_nColorSetNum = 8; ���޸ģ�����ԭ���ķ����ţ��ϰ�ɫ����ʱ��
	
	//for (i = 0;i <= 15;i++)
	//	m_Site.m_Decode.m_ColorSet[i] = MyColor[i];
	
	m_Site.m_Decode.m_BackColor = m_Site.m_Decode.m_ColorSet[0];
	m_bBossColor = !m_bBossColor;
	
	Refresh();
}

void CCTermView::OnUpdateBosscolor(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(m_bBossColor);
}

// �ƺ�����
//void CCTermView::ChangeColor(int n)
//{
//	ASSERT(0 <= n && n <= 9);
//	if (0 <= n && n <= 9) {
//		m_Site.m_Decode.m_nColorSetNum = n;
//
////		for (int i = 0;i <= 15;i++)
////			m_Site.m_Decode.m_ColorSet[i] = MyColor[i];
////		
////		m_Site.m_Decode.m_BackColor = m_Site.m_Decode.m_ColorSet[0];
//	}
//	Refresh();
//}

void CCTermView::OnCancelMode() 
{
	TRACE("CCTermView::OnCancelMode\n");
	CView::OnCancelMode();
	
#if ENABLE_HIDECURSOR
	if (!g_bMouseVisible) {
		//		::ShowCursor(TRUE);
		//		g_bMouseVisible = true;
		ToggleCursor(TRUE);
	}
#endif//ENABLE_HIDECURSOR
}

void CCTermView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	m_bHaveFocus = true;
}

void CCTermView::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	//	GetParentFrame()->RecalcLayout();
	
	//	int ncx, ncy, maxsw, maxsh;
	//	if (g_pMainWnd
	//		&& (m_bFixFont || m_font == _T("Fixedsys")))
	//	{
	//		int ncx, ncy, maxsw, maxsh;
	//		int ncx1, ncy1, ncx2, ncy2;
	//		if (g_pMainWnd->NeedAutoSize(0, 0, ncx, ncy, ncx1, ncy1, ncx2, ncy2, maxsw, maxsh, lpwndpos->flags)) {
	//			//lpwndpos->x = ncx;
	//			//lpwndpos->y = ncy;
	//			lpwndpos->cx = ncx2 + maxsw;
	//			lpwndpos->cy = ncy2 + maxsh;
	//		}
	////TRACE(_T("in CCTermView::OnWindowPosChanging, ncx=%d ncy=%d\n"), ncx, ncy);
	////TRACE(_T("in CCTermView::OnWindowPosChanging, maxsw=%d maxsh=%d\n"), maxsw, maxsh);
	//	}
	
	CView::OnWindowPosChanging(lpwndpos);
}

void CCTermView::ClearLastInputTime()
{
	m_nLastInputTime = 0;
	g_nGlobalIdleTime = 0;
}

void CCTermView::OnUpdateCtdload(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nCtdFile == 3 || (m_nCtdFile == 0 && m_Core.HisScreenNum() > 0));
	pCmdUI->SetCheck(!m_bCtdWait && m_bCtd_Loading);
}

void CCTermView::OnInsertansi() 
{
	ShowInsertDlg(this);
}

CString CCTermView::AntiIdleString()
{
	// m_sAntiIdleStr�����壺���Ϊ�գ�����g_sAntiIdleStr
	// ���g_sAntiIdleStrҲΪ�գ��򲻷���
	// ���ΪNO�������
	if (!m_sAntiIdleStr.IsEmpty()) {
		if (m_sAntiIdleStr.CompareNoCase("NO") != 0) {
			return m_sAntiIdleStr;
		}
		else {
			return CString("");
		}
	}
	else {
		return g_sAntiIdleStr;
	}
}


