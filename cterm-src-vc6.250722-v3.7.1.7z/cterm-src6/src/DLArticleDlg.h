#if !defined(AFX_DLARTICLEDLG_H__27C1BB15_D8E5_41C6_BEA4_7A3C4A760C7D__INCLUDED_)
#define AFX_DLARTICLEDLG_H__27C1BB15_D8E5_41C6_BEA4_7A3C4A760C7D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DLArticleDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDLArticleDlg dialog

#define _UNICODE

class CCTermView;
class CHTMLConvert;
class CDLArticleDlg : public CDialog
{
// Construction
public:
	CCTermView *m_pView;
	CDLArticleDlg(CWnd* pParent = NULL);   // standard constructor
	~CDLArticleDlg();

	CString m_title;
	CString m_article_txt;
	CString m_article_ansi;

// Dialog Data
	//{{AFX_DATA(CDLArticleDlg)
	enum { IDD = IDD_DLARTICLE };
	CEdit	m_ctrl_keyword;
	CEdit	m_edit;
	CProgressCtrl	m_prog;
	CString	m_article;
	BOOL	m_bShowEdit;
	int		m_read;
	BOOL	m_bDLByLine;
	int		m_npos;
	CString	m_keyword;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDLArticleDlg)

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	void InitDL();
	void DLByScreen(void);
	void DLByLine(void);
//	void CDLArticleDlg::(*m_pfDLFunc)(void);

	// Generated message map functions
	//{{AFX_MSG(CDLArticleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnClose();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDlnext();
	afx_msg void OnDlprev();
	afx_msg void OnCheckToggleedit();
	afx_msg void OnReadText();
	afx_msg void OnReadAnsi();
	afx_msg void OnCheckDlbyline();
	afx_msg void OnChangeKeyword();
	afx_msg void OnKillfocusKeyword();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool m_bNew;
	//CString m_filename;
	CString m_ts;
	CFont m_Font;
	BOOL m_bOK;
	clock_t m_nLastTime;
	bool m_bFirstScr;

	CString m_lastKeyword;

#if ENABLE_HTMLDOWN
	CHTMLConvert *m_pConvert;
#endif//ENABLE_HTMLDOWN
	BOOL bInMes;

	void Toggleedit();
};

#undef _UNICODE
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLARTICLEDLG_H__27C1BB15_D8E5_41C6_BEA4_7A3C4A760C7D__INCLUDED_)
