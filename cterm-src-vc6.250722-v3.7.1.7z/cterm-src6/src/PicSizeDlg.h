#if !defined(AFX_PICSIZEDLG_H__7513B1CD_3E97_4D81_AE18_3FF5E858E1B3__INCLUDED_)
#define AFX_PICSIZEDLG_H__7513B1CD_3E97_4D81_AE18_3FF5E858E1B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PicSizeDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPicSizeDlg dialog

class CPicSizeDlg : public CDialog
{
// Construction
public:
	CString m_szPicPath;
	CPicSizeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPicSizeDlg)
	enum { IDD = IDD_PIC_SIZE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicSizeDlg)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPicSizeDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICSIZEDLG_H__7513B1CD_3E97_4D81_AE18_3FF5E858E1B3__INCLUDED_)
