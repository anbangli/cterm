//global.h
#if !defined(GLOBAL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_)
#define GLOBAL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_

struct WaitStruct {
	HANDLE h; //Ҫ�ȴ���handle
	//bool (*DealFunc)(HANDLE h); //����ʱ�Ĵ�������
	UINT Message;//����ʱ������Ϣ
};

int GetSafeStr(TCHAR dest[], char s[], int len = -1);
CString GetSafeStr(char s[], int len = -1);

#if defined(_UNICODE) || defined(UNICODE)
char *GetANSIStr(TCHAR *s, char *& result, int len = -1);
char *GetANSIStr(CString str, char *& result);
#endif

void safeCopy(char *dest, LPCTSTR src, int len = -1);

BOOL WritePrivateProfileInt(
    IN LPCTSTR lpAppName,
    IN LPCTSTR lpKeyName,
    IN INT nValue,
    IN LPCTSTR lpFileName
);

extern int g_Ver[4];
extern CString g_szUserPath;
extern const char g_szUser[];
extern bool g_bHaveModalDlg;

void GetWorkDir();
void PrependWorkDir(TCHAR *path);
TCHAR* StripWorkDir(TCHAR *path);
CString StripWorkDir(CString& path);
void PrependWorkDir(CString& path);
TCHAR* GetShortFileName(TCHAR* s);
BOOL NewProgOpen(CString url, CString prog);
BOOL NewIEOpen(CString url);
void OpenFile(const CString &url);
void OpenTelnet(const CString &url);
void OpenFtp(const CString &url);

void logerr(TCHAR *errinfo);
int IsInDir(CString sFile, CString sDir);
bool isAbsPath(const CString &s);

int GetSubMenuPos(CMenu *pMenu, TCHAR key);

int IsIP(TCHAR *pchURL, TCHAR cIP[17]);
bool IsIP(const TCHAR *s);

#if ENABLE_IPV6
bool IsIPv6(TCHAR *s);
bool IsIPv6(CString &str);
#endif//ENABLE_IPV6

bool FontExist(HDC hdc, long charset, CString strFontName);
int GetPort(CString &sAddr, CString &proto);
bool GetFileVersion(LPTSTR FileName, int ver[]);
CString GetBuildTime();

inline BYTE CharType(TCHAR c);
BYTE GetCharType(int x, CString str);

CString g_LoadString(UINT id);

bool AnsiToTxt(TCHAR* szTxt);
CString AnsiToTxt(CString s);

void EncodePsw(TCHAR *psw);
void DecodePsw(TCHAR *psw);

CString TranslateString(const TCHAR *s);
CString TranslateString(CString &s);

int InString(TCHAR *Index, TCHAR *s);
int rStrip(TCHAR *const s);

int CountLine(TCHAR *szTxt, int maxCount = -1, bool bCountNullLine = true);
bool CopyFromFILE(FILE * src_fp, FILE * dest_fp);

bool ValidateWH(int &w, int &h);
void ValidateWinSize(int &x, int &y, int &cx, int &cy);
void ValidateWinSize(CRect &r);
CString getSheng(const CString & is_str);

void ShowInsertDlg(CWnd *pParent, int nActive = -1);

void vec2str(const vector<CString> & m_StartSites, CString & m_szStartSite, char sep = ';');
void str2vec(vector<CString> & vec, const CString & str, char sep = ';');
TCHAR * startcopy(const int maxlen, HGLOBAL &hmem);
void endcopy(HGLOBAL &hmem);
#endif //GLOBAL_H__5C990D04_2B60_11D2_BE77_006097AC8D00__INCLUDED_
