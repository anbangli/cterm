// CToolBarEx.cpp : implementation file
//

#include "stdafx.h"
#include "ToolBarEx.h"
#include "MainFrm.h"
#include "paramconfig.h"

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolBarEx
#if ENABLE_SEARCHBOX

CToolBarEx::CToolBarEx()
{
}

CToolBarEx::~CToolBarEx()
{
}

BEGIN_MESSAGE_MAP(CToolBarEx, CToolBar)
	//{{AFX_MSG_MAP(CToolBarEx)
	ON_WM_SIZE()
	ON_COMMAND(IDOK, OnPressEnter)
	ON_COMMAND(IDCANCEL, OnCancel)
	ON_MESSAGE(DROPM_DRAGOVER, OnDragOver)
	ON_MESSAGE(DROPM_DROPEX, OnDropEx)
	ON_MESSAGE(DROPM_DROP, OnDrop)
	ON_WM_CONTEXTMENU()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CToolBarEx message handlers

BOOL CToolBarEx::CreateCombo()
{
	CRect rect;
	//������Ͽ�ؼ�Ϊsnapģʽ��Ͽ�
	//����ȡ����Ͽ��ڹ������е�λ��
	int index = 0;

	while (GetItemID(index) != ID_WEB_URL)
		index++;

	//Ȼ�������ť��Ϊ����ģ���ȡ������λ��
	SetButtonInfo(index, ID_WEB_URL, TBBS_SEPARATOR, (120 + 110*g_bWebLong) * g_bSearchBox);

	GetItemRect(index, &rect);

	//��չ��������ʹ������������Ͽ���������������ʾ
	rect.top += 1;

	rect.bottom += 200;

	//������Ͽ򣬲�����ʾ��
	BOOL Ret = m_wndUrl.Create(WS_CHILD | WS_VISIBLE | CBS_AUTOHSCROLL | CBS_DROPDOWN, rect, this, ID_WEB_URL);

	m_wndUrl.AddString(g_sHomePage);

	// m_wndUrl.SetCurSel(0);	//û�б�Ҫֱ����ʾ��


	m_pFont.CreateFont(-11,   // nHeight
	                   0, // nWidth
	                   0, // nEscapement
	                   0, // nOrientation
	                   0,	//FW_BOLD, // nWeight
	                   FALSE, // bItalic
	                   FALSE, // bUnderline
	                   0, // cStrikeOut
	                   ANSI_CHARSET, // nCharSet
	                   OUT_DEFAULT_PRECIS, // nOutPrecision
	                   CLIP_DEFAULT_PRECIS, // nClipPrecision
	                   DEFAULT_QUALITY, // nQuality
	                   DEFAULT_PITCH | FF_SWISS, // nPitchAndFamily
	                   _T("Tahoma"));     // lpszFac

	m_wndUrl.SetFont(&m_pFont);

	if (Ret)
		return TRUE;
	else
		return FALSE;
}

void CToolBarEx::OnSize(UINT nType, int cx, int cy)
{
	CToolBar::OnSize(nType, cx, cy);
}


void CToolBarEx::SaveString()
{
	CString url; //,it;
	m_wndUrl.GetWindowText(url);	// ע�⣬�˴��ǻ�õ�ǰ�༭���е�����
	int jj = -1;//ii=0,

	if (!url.IsEmpty()) {	//���գ������Ƿ��ظ������ظ���������
		jj = m_wndUrl.FindString(-1, url);    // ʹ��ϵͳ���� ����Ч�ɿ�
		//for (ii=0; ii<=m_wndUrl.GetCount()-1; ii++) {
		//	m_wndUrl.GetLBText(ii,it);
		//	if (url == it) jj=ii;
		//}

		if (jj >= 0) {
			m_wndUrl.SetCurSel(jj);
		} else {
			m_wndUrl.InsertString(0, url);	// �����ڶ���
			m_wndUrl.SetCurSel(0);
		}
	}
}

void CToolBarEx::OnPressEnter()		//���»س���
{
	if (g_pMainWnd != NULL)
		g_pMainWnd->OpenURL();

	//return true;
}

LRESULT CToolBarEx::OnDrop(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo*) pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));

	try {
		if (pInfo->m_pDataObject->IsDataAvailable(CF_TEXT)) {
			HGLOBAL hMem = pInfo->m_pDataObject->GetGlobalData(CF_TEXT);
			TCHAR* lp = (TCHAR *) GlobalLock((HGLOBAL) hMem);       //lock source

			if (lp != NULL) {
				m_wndUrl.SetWindowText(lp);
				g_pMainWnd->OpenURL();
				//g_pMainWnd->SendMessage(WM_COMMAND, ID_WEB_GO, 0);
			}

			GlobalUnlock(hMem);   //unlock source

			return TRUE;
		} else
			return FALSE;
	} catch (...) {
		return FALSE;
	}
}

BOOL CToolBarEx::Init()
{
	if (! CreateCombo())
		return FALSE;

#ifndef _DEBUG
	if (!m_dropEx.Register(this))
		TRACE(_T("register drop edit failed\n"));

#endif// _DEBUG

	return TRUE;
}

LRESULT CToolBarEx::OnDragOver(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo*) pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));

	if (pInfo->m_pDataObject->IsDataAvailable(CF_TEXT))
		return DROPEFFECT_COPY;
	else
		return DROPEFFECT_NONE;
}

LRESULT CToolBarEx::OnDropEx(WPARAM pDropInfoClass, LPARAM lParm)
{
	return (DROPEFFECT) - 1;
}

void CToolBarEx::OnCancel()
{
	g_pMainWnd->ActivateView();
	//return TRUE;
}

//�޷��ڳ�ʼ��ʱ���ش˰�ť������ֻ���������������
void CToolBarEx::ShowCombo()
{
	CWnd *pWnd;
	pWnd = GetDlgItem(ID_WEB_URL);

	if (!g_bSearchBox)
		pWnd->ShowWindow(SW_HIDE);
}

void CToolBarEx::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	if (point.x == -1 && point.y == -1) {
		//keystroke invocation
		CRect rect;
		GetClientRect(rect);
		ClientToScreen(rect);
		
		point = rect.TopLeft();
		point.Offset(5, 5);
	}
	
	CMenu menu;
	VERIFY(menu.LoadMenu(IDR_BAR_MENU));
	
#if ENABLE_MULTILANG
	if (g_currLangID != ID_LANG1) {
		g_OutMenuStrings(&menu, _T(""));  //����Ĭ��
		g_SetMenuStrings(&menu, _T(""));
	}
#endif// ENABLE_MULTILANG
	CMenu* pPopup = menu.GetSubMenu(0);
	ASSERT(pPopup != NULL);
	CWnd* pWndPopupOwner = AfxGetMainWnd();
	while (pWndPopupOwner->GetStyle() & WS_CHILD)
		pWndPopupOwner = pWndPopupOwner->GetParent();
	pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
		pWndPopupOwner);
}

#endif//ENABLE_SEARCHBOX
