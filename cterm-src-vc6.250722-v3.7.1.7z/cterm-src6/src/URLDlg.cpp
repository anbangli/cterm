// URLDlg.cpp : implementation file
// ȷ��URL

#include "stdafx.h"

#include "URLDlg.h"

#include "paramconfig.h"
#include "global.h"
#include "mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString g_szFtpProg;	//FTP����

/////////////////////////////////////////////////////////////////////////////
// CURLDlg dialog

CURLDlg::CURLDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CURLDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CURLDlg)
	m_url = _T("");
	m_noask = FALSE;
	//}}AFX_DATA_INIT
}


void CURLDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CURLDlg)
	DDX_Text(pDX, IDC_EDIT1, m_url);
	DDX_Check(pDX, IDC_NOASK, m_noask);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CURLDlg, CDialog)
	//{{AFX_MSG_MAP(CURLDlg)
	ON_BN_CLICKED(IDC_OPENFTP, OnOpenFtp)
	ON_BN_CLICKED(IDC_OPENHTTP, OnOpenHttp)
	ON_BN_CLICKED(IDC_OPEN_FLASHGET, OnOpenFlashget)
	ON_BN_CLICKED(IDC_OPENIE, OnOpenIE)
	ON_BN_CLICKED(IDC_NOASK, OnNoask)
	ON_BN_CLICKED(IDC_OPENTELNET, OnOpentelnet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CURLDlg message handlers

void CURLDlg::OnOpenIE()
{
	UpdateData();

	if (!_tcsnicmp(m_url, _T("telnet://"), 9) || !_tcsnicmp(m_url, _T("ftp://"), 6)
	        || !_tcsnicmp(m_url, _T("mailto:"), 7))		//��������HTTP
		return;

	NewIEOpen(m_url);

	CDialog::OnOK();
}

void CURLDlg::OnOpenHttp()
{
	UpdateData();

	if (!_tcsnicmp(m_url, _T("telnet://"), 9) || !_tcsnicmp(m_url, _T("ftp://"), 6)
	        || !_tcsnicmp(m_url, _T("mailto:"), 7))		//��������HTTP
		return;

	if (g_bAutoURLHeader && m_url.Find(_T("://")) == -1 && m_url.Find(_T(".")) != -1 && m_url.Find(_T(" ")) == -1) {
		CString s(_T("http://"));
		m_url = s + m_url;
	}

	int progid = 0;

	if (!g_sUrlProg.IsEmpty()) {
		NewProgOpen(m_url, g_sUrlProg);
	}
	else {
		OpenFile(m_url);
		//ShellExecute(m_hWnd, _T("open"), m_url, NULL, NULL, SW_SHOW);       //��Ĭ�������
	}

	CDialog::OnOK();
}

void CURLDlg::OnOpenFtp()
{
	UpdateData();
	OpenFtp(m_url);
	CDialog::OnOK();
}

void CURLDlg::OnOpentelnet()
{
	UpdateData();
	bool b =(!_tcsnicmp(m_url, _T("http://"), 7)
		|| !_tcsnicmp(m_url, _T("ftp://"), 6)
	    || !_tcsnicmp(m_url, _T("mailto:"), 7));		//��������BBSվ��

	if (!b)
		OpenTelnet(m_url);

	CDialog::OnOK();
}

void CURLDlg::OnOK()
{
	UpdateData();
	g_pMainWnd->OpenURL(m_url);
	CDialog::OnOK();
}

void CURLDlg::OnOpenFlashget()
{
	CWnd *pMainFrm = AfxGetMainWnd();
	pMainFrm->SendMessage(WM_COMMAND, ID_DOWNLOAD_TOOL, NULL);
	CDialog::OnOK();
}

BOOL CURLDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	m_noask = !g_bUrlWithConfirm;
	UpdateData(FALSE);

	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_NOASK), _T("�´β�����ʾ"));
	}
	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

//DEL void CURLDlg::OnUserprog()
//DEL {
//DEL 	int progid = 0;
//DEL 	if ( !g_sUrlProg.IsEmpty() )
//DEL 		NewProgOpen( m_url, g_sUrlProg );
//DEL }

void CURLDlg::OnNoask() 
{
	UpdateData();
	g_bUrlWithConfirm = !m_noask;
}

BOOL CURLDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	return CDialog::PreTranslateMessage(pMsg);	// CG: This was added by the ToolTips component.
}
