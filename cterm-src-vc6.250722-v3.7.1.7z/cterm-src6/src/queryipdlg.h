#if !defined(AFX_QUERYIPDLG_H__AE5297AC_5854_4F0A_9C5C_EAA365215AB2__INCLUDED_)
#define AFX_QUERYIPDLG_H__AE5297AC_5854_4F0A_9C5C_EAA365215AB2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// QueryIPDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CQueryIPDlg dialog

class CQueryIPDlg : public CDialog
{
// Construction

public:
	CQueryIPDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CQueryIPDlg)
	enum { IDD = IDD_QUERY_IP };
	CString	m_strIP;
	CString	m_strAddr;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQueryIPDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CQueryIPDlg)
	afx_msg void OnQuery();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUERYIPDLG_H__AE5297AC_5854_4F0A_9C5C_EAA365215AB2__INCLUDED_)
