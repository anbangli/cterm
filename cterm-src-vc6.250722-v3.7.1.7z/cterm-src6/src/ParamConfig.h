#if !defined(AFX_PARAMCONFIG_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_)
#define AFX_PARAMCONFIG_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_

// ParamConfig.h: �������ã��ⲿ����
// ֻ�ɰ���һ��

#if ENABLE_HOTKEY
#include "HotKey.h"
#endif//ENABLE_HOTKEY

//////////// ȫ�ֱ������� /////////////////////////////////

//////////// ϵͳ���ò������� /////////////////////////////////

//-------- ��ʵ���������� --------
extern bool g_bAllowMulti;
extern int  g_nInstanceNumber;

#if ENABLE_HOTKEY
#define MAX_HOTKEY_NAME 50
extern char g_BossHotKeyStr[];
extern char g_HotKeyStr[];
extern bool g_bBossKeyActive;	//�Ƿ�ʹ���ϰ��
extern CHotKey g_BossHotkey;
extern CHotKey g_Hotkey;
extern TCHAR g_CurBossHotkey;
extern bool g_bHotKeyRegistered;
#endif//ENABLE_HOTKEY

#define ORIGIN_CONTROL_PORT 47503
extern int g_nControlPort;


// --------- ԭ����CMultiUser�����ݣ�д��cterm2.ini�� ----------
extern CString g_sAddressBook;
extern BOOL g_bDblClkTab;
extern BOOL g_bLastSite;
extern int g_nConnectType;
//#define MAX_SITE_NAME 100
extern CString g_szLastSiteName;
extern CString g_szStartSite;
extern CString g_szFavoriteSite[];
extern int g_nFavoriteSite;	
// --------- CMultiUser end ----------

// auto
extern bool g_bAntiIdle;
extern int g_nIdleTime;
extern CString g_sAntiIdleStr;
extern CString g_szReply; //��ǰʹ�õ���Ϣ��
extern CString g_szInitReply; //ԭʼ�Ļظ���Ϣ��
extern int g_nTimer;

#if ENABLE_LOCK
extern long g_nGlobalIdleTime;
extern int  g_nAutoProtectTime;
extern bool g_bAutoLockBBS;
extern bool g_bMinWhenLeave;		//�뿪ʱ��С����tray(���ǵ����Ի���)
#endif//ENABLE_LOCK

#if ENABLE_MESSAGE
extern bool g_bPopupOnMsg;
extern bool g_bBeepWhenMsg;
extern CString g_szWavFile;
extern bool g_bPlayWav;
#endif//ENABLE_MESSAGE
extern CString g_szMailWavFile;

extern bool g_bRepeatUserName;
#define DEFAULT_RECV_BUF_LEN 40961
extern int g_nRecvBufLen;

// normal
//extern bool g_nPlaneNum;
extern bool g_bUseMouse;
extern bool g_bURLNoMouse;
#if ENABLE_HIDECURSOR
extern bool g_bHideMouse;
extern UINT g_nNoMouseMoveCount;
extern bool g_bMouseVisible;
#endif//ENABLE_HIDECURSOR
extern bool g_bSiteStatus;
extern bool g_bCaptureMouse;
extern bool g_bMinToTray;
extern bool g_bRefreshTitle;
extern bool g_bChildDefaultMax;
extern bool g_bSiteReport;
extern bool g_bMaxFullScreen;
extern bool g_bOpenConsole;
extern bool g_bAutoSize;
extern bool g_bAutoMailBack;
extern bool g_bMsgPopup;	// ������Ϣ��
extern bool g_bMsgRec;		// �Ƿ��¼��Ϣ
extern bool g_bIsAutoReply;

extern bool g_bAutoUpdate;
extern bool g_bNoAskWhenClose;
extern bool g_bNoAskClose;
extern bool g_bAutoLast;
extern bool g_bReportSimple;
extern bool g_bAnsiLog;

//#if ENABLE_PYTHON
//#endif//ENABLE_PYTHON
extern bool g_bEnablePython;
extern bool g_bPythonLog;
extern bool g_bEnablePythonStatus;
extern bool g_bPythonRunning;	//�Ƿ�����ִ��Python


//#if ENABLE_VBS
extern bool g_bEnableVBS;
extern bool g_bVBSInited;
//#endif//ENABLE_VBS

//View
extern bool g_bMenuVisible;
#if ENABLE_HIDEMENU
extern bool g_bAltShowMenu;
extern bool g_bCaptionButtons;
#endif//ENABLE_HIDEMENU
#if ENABLE_FUNKEY
extern bool g_bShowUserMenu;
#endif//ENABLE_FUNKEY
#if ENABLE_MENUFAVTOP
extern bool g_bMenuFavTop;
#endif//ENABLE_MENUFAVTOP
extern bool g_bShowCenter;
extern bool g_bForceHiLight;
extern bool g_bReadflag;
extern int  g_nMouseMenu;
extern bool g_bClickUser;


#if ENABLE_SWITCHBAR
extern int  g_nTabWidMin;
extern bool g_bTabFullName;
extern bool g_bTabUserName;
#endif//ENABLE_SWITCHBAR

extern int g_nKeybarWidth;
extern int g_nKeybarHeight;

//term window size
extern int g_nTermWidth;
extern int g_nTermHeight;
extern int g_nFixedSysSize;
extern int g_nCharScale;
extern int g_nRowSpace;
extern int g_nCharHWRatio;
extern bool g_TA_CENTER;
extern CString g_sEFont;
extern CString g_sFont;// ȫ�����壬��siteinfo.ini��δ�������壬����g_sFont������g_sFont���õ�ַ����
extern bool g_bMONOSPACE;
extern bool g_bFixFont;
extern int g_nFixFontSize;
#if ENABLE_CLEARTYPE
extern int g_nFontQuality;
#endif//ENABLE_CLEARTYPE
//extern bool g_bBold;
extern int g_nBoldWeight;
extern bool g_bSelectStay;
extern bool g_bSelBackHi;
extern bool g_bSelAntiHalf;
extern bool g_bEnableM;

extern bool g_bFullScreenBar;
extern bool g_bCursorPos;

extern bool g_bTransparent;
extern int g_nAlpha;

//Edit
extern bool g_bCtrlCCopy;
extern bool g_bCtrlVPaste;

#if ENABLE_EDITBOX
extern bool g_bPopEditDlg;
#endif//ENABLE_EDITBOX

extern bool g_bAutoWarp;			// �Ƿ������Զ�����
extern int  g_nWarpNumber;			// ÿ���������
extern bool g_bWarpAutoPara;		// ����ʶ��
extern bool g_bWarpPlusSpace;		// ÿ���Ƿ����ӿ���

extern bool g_bWarpAlwaysAsk;		// �Ƿ�ÿ�ζ�ѯ�ʡ��Ƿ��Զ����С�

extern bool g_bAutoCopy;
extern bool g_bAnsiCP;
extern bool g_bCopyUni;
extern bool g_bPasteUni;
extern bool g_bSelectRect;

extern bool g_bCopyNoReturn;
extern int g_nWrapLen;
extern bool g_bCopyRectNoReturn;

extern bool g_bAutoSaveEdit;
extern bool g_bEditIME;
extern int g_nEditFontSize;
//extern int	g_nCloseIME;
extern bool g_bIMEChar;
extern int g_gbCharSet;
extern int g_big5CharSet;
extern bool g_bPasteConfirm;

#if ENABLE_HOTKEY
// boss
extern bool g_bBossKeyActive;
extern bool g_bOldBossKey;
extern bool g_bNewBossKey;
extern int g_nBossKeyStyle;
//extern BOOL g_bBossMinimize;
extern bool g_bBossExecute;
extern CString g_szBossPrograme;
#endif//ENABLE_HOTKEY

//Web
extern bool g_bSearchBox;			// �Ƿ���ʾ��ַ��
extern bool g_bWebLong;			// ��ַ���Ŀ���(խ/��)
extern CString g_sHomePage;		// �û�Ĭ����ҳ
extern bool g_bUseGoogle;			// �Ƿ�ʹ��Google������0-Baidu, 1-Google

extern CString g_ipurl;
extern bool g_bFilterQueryIP;
#if ENABLE_SHOWIP
extern bool g_bShowIP;
extern bool g_bShowIPAuto;
//extern bool g_bAutoFromIP;
extern bool g_bBakAutoIP;
extern CString g_sIPWryPath;
#endif//ENABLE_SHOWIP

extern bool g_bBbsSignature;
#if ENABLE_PICTURE
extern bool g_bShowPic;
extern bool g_bPicDownAuto;
extern int  g_nPicFolderSize;
extern bool g_bVBSViewPic;
extern bool g_bCtrlViewPic;
extern int  g_nPicHoverTime;
extern bool g_bEmptyPicCache;
extern bool g_bPicDlgInfo;
extern CString g_PicPath;
extern int  g_nPicLoadTimeOut;
extern bool g_bPicDrag;
extern bool g_bLoadPicThread;
extern CString g_sPicDlgColor;
extern bool g_bGetPicInfo;
extern int  g_nPicTimeOut;
extern bool g_bPicTip;
extern bool g_bPicBorder;
extern bool g_bPicHide;
extern bool g_bAutoRetryPic;
extern bool g_bDelPicAsk;
#endif//ENABLE_PICTURE

extern CString g_szFtpProg;	//FTP����
#if ENABLE_PIPESSH
extern CString g_sPlink;
#endif//ENABLE_PIPESSH
extern CString g_sLoginFlag;
extern CString g_sLoginFlag1;

extern bool g_bUrlWithConfirm;
extern bool g_bURLStrip;
extern CString g_sUrlProg;
extern bool g_bPythonOpenFile;
extern bool g_bViewDrag;
extern int g_nDownTool;
extern bool g_bAutoURLHeader;

extern int g_nBlinkTimeOut;
extern int g_nCARET_H;
extern int g_nCARET_W;
//extern bool g_bCaretEditOnly;
extern bool g_bCaretCenter;
extern bool g_bCaretBlink;

extern bool g_bUploadAttAuto;

#if ENABLE_FUNKEY
extern CString g_sKeyTableFile;
#endif//ENABLE_FUNKEY

extern CString g_sScriptDir;

extern bool g_bAllowSameSiteName;
extern bool g_bAddrFullName;

//extern bool	g_bUploadAllow;	// �Ƿ���ʾ���ϴ��ļ�����

extern CString g_sArticleSaveExt;
extern int g_nDLDlgWidth, g_nDLDlgHeight;

extern bool g_bAutoSaveConfig;

extern int g_iAskDlg;
extern int g_nDownTimeout;

extern bool g_bCtdDraw;
extern bool g_bDrawByString;

extern bool g_bDownloadWithHTML;

extern bool g_bRegBBSProto;
extern bool g_bNoFocusNoCursor;

extern bool g_bCacheHistory;

//extern bool g_bRecordTxt;

//////////// ϵͳ���ò����������� /////////////////////////////////

//#define MAX_VAR_NAME 100
//#define MAX_STR_VAR 1024
//
//struct ConfigIntVar {
//	tstring sVarName;
//	int nDefaultVal;
//	int *pVar;
//	tstring sNote; // ˵��
//	tstring sSection;
//
//	ConfigIntVar() {}
//	ConfigIntVar(TCHAR *name, int val, int *p, TCHAR *note, TCHAR *sec)
//		:sSection(sec),
//		sVarName(name),
//		nDefaultVal(val),
//		pVar(p),
//		sNote(note)
//	{
//	}
//};
//
//struct ConfigVar {
//	tstring sVarName;
//	void *pDefaultVal;
//	void *pVar;
//	tstring sNote; // ˵��
//	tstring sSection;
//	int type;
//};
//
//struct ConfigStrVar {
//	tstring sVarName;
//	tstring sDefaultVal;
//	tstring *pVar;
//	tstring sSection;
//};

void LoadWindowConfig(); // ��ȡ����
void SaveWindowConfig(); // д�����

#endif // !defined(AFX_PARAMCONFIG_H__2AC2BA96_FE64_11D3_B1BC_000080013F30__INCLUDED_)
