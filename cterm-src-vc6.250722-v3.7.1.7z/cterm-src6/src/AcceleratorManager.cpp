////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Thierry Maurel
// All rights reserved
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc., and
// I'll try to keep a version up to date.  I can be reached as follows:
//    tmaurel@caramail.com   (or tmaurel@hol.fr)
//
////////////////////////////////////////////////////////////////////////////////
// File    : AcceleratorManager.cpp
// Project : AccelsEditor
////////////////////////////////////////////////////////////////////////////////
// Version : 1.0                       * Author : T.Maurel
// Date    : 17.08.98
//
// Remarks : implementation of the CAcceleratorManager class.
//
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "AcceleratorManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//��ݼ�����

//////////////////////////////////////////////////////////////////////
// Constructor/Destructor
//////////////////////////////////////////////////////////////////////
//
//
CAcceleratorManager::CAcceleratorManager()
{
//	m_hRegKey = HKEY_CURRENT_USER;
//	m_szRegKey = _T("");
	m_bAutoSave = FALSE;
	m_pWndConnected = NULL;

	m_bDefaultTable = false;

	m_sDataFileName = _T("user\\myaccel.dat");
}


//////////////////////////////////////////////////////////////////////
//
//
CAcceleratorManager::~CAcceleratorManager()
{
	if ((m_bAutoSave == true) && (m_sDataFileName.IsEmpty() == FALSE)) {
		bool bRet = Write();
#ifdef _DEBUG
		if (!bRet)
			AfxMessageBox(_T("CAcceleratorManager::~CAcceleratorManager\nError in CAcceleratorManager::Write..."));
#endif//_DEBUG
	}

	Reset();
}

//////////////////////////////////////////////////////////////////////
// Internal fcts
//////////////////////////////////////////////////////////////////////
//
//
void CAcceleratorManager::Reset()
{
	CCmdAccelOb* pCmdAccel;
	WORD wKey;
	POSITION pos = m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
		delete pCmdAccel;
	}

	m_mapAccelTable.RemoveAll();

	m_mapAccelString.RemoveAll();

	pos = m_mapAccelTableSaved.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTableSaved.GetNextAssoc(pos, wKey, pCmdAccel);
		delete pCmdAccel;
	}

	m_mapAccelTableSaved.RemoveAll();
}


//////////////////////////////////////////////////////////////////////
//
// ����szCommandΪNULL����ʱ����m_mapAccelString������ڣ��Ӷ����������ʾ
bool CAcceleratorManager::AddAccel(BYTE cVirt, WORD wIDCommand, WORD wKey, LPCTSTR szCommand, bool bLocked)
{
//	ASSERT(szCommand != NULL);

	WORD wIDCmd;

	if (szCommand != NULL && m_mapAccelString.Lookup(szCommand, wIDCmd) == TRUE) {
		if (wIDCmd != wIDCommand)
			return false;
	}

	CCmdAccelOb* pCmdAccel = NULL;

	if (m_mapAccelTable.Lookup(wIDCommand, pCmdAccel) == TRUE) {
		if (pCmdAccel->m_szCommand != szCommand) {   //����ΪNULL
			return false;
		}

		CAccelsOb* pAccel;

		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();

		while (pos != NULL) {
			pAccel = pCmdAccel->m_Accels.GetNext(pos);

			if (pAccel->m_cVirt == cVirt &&
			        pAccel->m_wKey == wKey)
				return FALSE;
		}

		// Adding the accelerator
		pCmdAccel->Add(cVirt, wKey, bLocked);

	} else {
		pCmdAccel = new CCmdAccelOb(cVirt, wIDCommand, wKey, szCommand, bLocked);
		ASSERT(pCmdAccel != NULL);
		m_mapAccelTable.SetAt(wIDCommand, pCmdAccel);
	}

	// 2nd table
	if (szCommand != NULL)
		m_mapAccelString.SetAt(szCommand, wIDCommand);

	return true;
}


//////////////////////////////////////////////////////////////////////
// Debug fcts
//////////////////////////////////////////////////////////////////////
//
//
#ifdef _DEBUG
void CAcceleratorManager::AssertValid() const
{
}

//////////////////////////////////////////////////////////////////////
//
//
void CAcceleratorManager::Dump(CDumpContext& dc) const
{
	CCmdAccelOb* pCmdAccel;
	WORD wKey;
	//dc << _T("CAcceleratorManager::Dump :\n");
	//dc << _T("m_mapAccelTable :\n");
	POSITION pos = m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
		dc << _T("a CCmdAccelOb at 0x")  << (void*) pCmdAccel << _T(" = {\n");
		dc << pCmdAccel;
		dc << _T("}\n");
	}

	//dc << _T("\nm_mapAccelTableSaved\n");

	pos = m_mapAccelTableSaved.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTableSaved.GetNextAssoc(pos, wKey, pCmdAccel);
		dc << _T("a CCmdAccelOb at 0x") << (void*) pCmdAccel << _T(" = {\n");
		dc << pCmdAccel;
		dc << _T("}\n");
	}
}

#endif


//////////////////////////////////////////////////////////////////////
//
//////////////////////////////////////////////////////////////////////
//
//
void CAcceleratorManager::Connect(CFrameWnd* pWnd, bool bAutoSave)
{
	ASSERT(m_pWndConnected == NULL);
	m_pWndConnected = pWnd;
	m_bAutoSave = bAutoSave;
}


//////////////////////////////////////////////////////////////////////
//
//
/*bool CAcceleratorManager::GetRegKey(HKEY& hRegKey, CString& szRegKey)
{
	if (m_szRegKey.IsEmpty())
		return false;

	hRegKey = m_hRegKey;
	szRegKey = m_szRegKey;
	return true;
}
*/

//////////////////////////////////////////////////////////////////////
//
//
/*bool CAcceleratorManager::SetRegKey(HKEY hRegKey, LPCTSTR szRegKey)
{
	ASSERT(hRegKey != NULL);
	ASSERT(szRegKey != NULL);

	m_szRegKey = szRegKey;
	m_hRegKey = hRegKey;
	return true;
}*/


//////////////////////////////////////////////////////////////////////
// Update the application's ACCELs table
//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::UpdateWndTable()
{
	int iLoop = 0;
	CTypedPtrArray<CPtrArray, LPACCEL> arrayACCEL;

	CCmdAccelOb* pCmdAccel;
	WORD wKey;
	LPACCEL pACCEL;
	CAccelsOb* pAccelOb;
	POSITION pos = m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();

		while (pos != NULL) {
			pAccelOb = pCmdAccel->m_Accels.GetNext(pos);

			pACCEL = new ACCEL;
			ASSERT(pACCEL != NULL);
			pACCEL->fVirt = pAccelOb->m_cVirt;
			pACCEL->key = pAccelOb->m_wKey;
			pACCEL->cmd = pCmdAccel->m_wIDCommand;
			arrayACCEL.Add(pACCEL);
		}
	}

	int nAccel = arrayACCEL.GetSize();

	LPACCEL lpAccel = (LPACCEL) LocalAlloc(LPTR, nAccel *sizeof(ACCEL));

	if (!lpAccel) {
		for (iLoop = 0; iLoop < nAccel; iLoop++)
			delete arrayACCEL.GetAt(iLoop);

		arrayACCEL.RemoveAll();

		return false;
	}

	for (iLoop = 0; iLoop < nAccel; iLoop++) {

		pACCEL = arrayACCEL.GetAt(iLoop);
		lpAccel[iLoop].fVirt = pACCEL->fVirt;
		lpAccel[iLoop].key = pACCEL->key;
		lpAccel[iLoop].cmd = pACCEL->cmd;

		delete pACCEL;
	}

	arrayACCEL.RemoveAll();

	HACCEL hNewTable = CreateAcceleratorTable(lpAccel, nAccel);

	if (!hNewTable) {
		::LocalFree(lpAccel);
		return false;
	}

	HACCEL hOldTable = m_pWndConnected->m_hAccelTable;

	if (!::DestroyAcceleratorTable(hOldTable)) {
		::LocalFree(lpAccel);
		return false;
	}

	m_pWndConnected->m_hAccelTable = hNewTable;

	::LocalFree(lpAccel);
	return true;
}


//////////////////////////////////////////////////////////////////////
// Create/Destroy accelerators
//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::DeleteAccel(BYTE cVirt, WORD wIDCommand, WORD wKey)
{
	CCmdAccelOb* pCmdAccel = NULL;

	if (m_mapAccelTable.Lookup(wIDCommand, pCmdAccel) == TRUE) {
		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();
		POSITION PrevPos;
		CAccelsOb* pAccel = NULL;

		while (pos != NULL) {
			PrevPos = pos;
			pAccel = pCmdAccel->m_Accels.GetNext(pos);

			if (pAccel->m_bLocked == true)
				return false;

			if (pAccel->m_cVirt == cVirt && pAccel->m_wKey == wKey) {
				pCmdAccel->m_Accels.RemoveAt(PrevPos);
				delete pAccel;
				return true;
			}
		}
	}

	return false;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::DeleteEntry(WORD wIDCommand)
{
	CCmdAccelOb* pCmdAccel = NULL;

	if (m_mapAccelTable.Lookup(wIDCommand, pCmdAccel) == TRUE) {      //�����Ҳ���
		CAccelsOb* pAccel;
		POSITION pos = pCmdAccel->m_Accels.GetHeadPosition();

		while (pos != NULL) {
			pAccel = pCmdAccel->m_Accels.GetNext(pos);

			if (pAccel->m_bLocked == true)
				return false;
		}

		m_mapAccelString.RemoveKey(pCmdAccel->m_szCommand);

		m_mapAccelTable.RemoveKey(wIDCommand);
		delete pCmdAccel;
		return true;
	} else
		return false;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::DeleteEntry(LPCTSTR szCommand)
{
	ASSERT(szCommand != NULL);

	WORD wIDCommand;

	if (m_mapAccelString.Lookup(szCommand, wIDCommand) == TRUE) {
		return DeleteEntry(wIDCommand);
	}

	return true;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::SetAccel(BYTE cVirt, WORD wIDCommand, WORD wKey, LPCTSTR szCommand, bool bLocked)
{
//	ASSERT(szCommand != NULL);

	return AddAccel(cVirt, wIDCommand, wKey, szCommand, bLocked);
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::AddCommandAccel(WORD wIDCommand, LPCTSTR szCommand, bool bLocked)
{
//	ASSERT(szCommand != NULL);

	ASSERT(m_pWndConnected != NULL);
	HACCEL hOriginalTable = m_pWndConnected->m_hAccelTable;

	int nAccel = ::CopyAcceleratorTable(hOriginalTable, NULL, 0);
	LPACCEL lpAccel = (LPACCEL) LocalAlloc(LPTR, (nAccel) * sizeof(ACCEL));

	if (!lpAccel)
		return false;

	::CopyAcceleratorTable(hOriginalTable, lpAccel, nAccel);

	bool bRet = false;

	for (int i = 0; i < nAccel; i++) {
		if (lpAccel[i].cmd == wIDCommand)
			bRet = AddAccel(lpAccel[i].fVirt, wIDCommand, lpAccel[i].key, szCommand, bLocked);
	}

	::LocalFree(lpAccel);

	return bRet;
}


//////////////////////////////////////////////////////////////////////
//
//
/*bool CAcceleratorManager::CreateEntry(WORD wIDCommand, LPCTSTR szCommand)
{
	ASSERT(szCommand != NULL);

	WORD wIDDummy;
	if (m_mapAccelString.Lookup(szCommand, wIDDummy) == TRUE)
		return false;

	CCmdAccelOb* pCmdAccel = new CCmdAccelOb(wIDCommand, szCommand);
	ASSERT(pCmdAccel != NULL);
	m_mapAccelTable.SetAt(wIDCommand, pCmdAccel);
	m_mapAccelString.SetAt(szCommand, wIDCommand);

	return false;
}
*/

//////////////////////////////////////////////////////////////////////
// Get a string from the ACCEL definition
//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::GetStringFromACCEL(ACCEL* pACCEL, CString& szAccel)
{
	ASSERT(pACCEL != NULL);

	CAccelsOb accel(pACCEL);
	accel.GetString(szAccel);

	if (szAccel.IsEmpty())
		return false;
	else
		return true;
}


//////////////////////////////////////////////////////////////////////
//
//
bool CAcceleratorManager::GetStringFromACCEL(BYTE cVirt, WORD nCode, CString& szAccel)
{
	CAccelsOb accel(cVirt, nCode);
	accel.GetString(szAccel);

	if (szAccel.IsEmpty())
		return false;
	else
		return true;
}


//////////////////////////////////////////////////////////////////////
// Copy function
//
CAcceleratorManager& CAcceleratorManager::operator= (const CAcceleratorManager &accelmgr)
{
	Reset();

	CCmdAccelOb* pCmdAccel;
	CCmdAccelOb* pNewCmdAccel;
	WORD wKey;
	// Copy the 2 tables : normal accel table...
	POSITION pos = accelmgr.m_mapAccelTable.GetStartPosition();

	while (pos != NULL) {
		accelmgr.m_mapAccelTable.GetNextAssoc(pos, wKey, pCmdAccel);
		pNewCmdAccel = new CCmdAccelOb;
		ASSERT(pNewCmdAccel != NULL);
		*pNewCmdAccel = *pCmdAccel;
		m_mapAccelTable.SetAt(wKey, pNewCmdAccel);
	}

	// ... and saved accel table.
	pos = accelmgr.m_mapAccelTableSaved.GetStartPosition();

	while (pos != NULL) {
		accelmgr.m_mapAccelTableSaved.GetNextAssoc(pos, wKey, pCmdAccel);
		pNewCmdAccel = new CCmdAccelOb;
		ASSERT(pNewCmdAccel != NULL);
		*pNewCmdAccel = *pCmdAccel;
		m_mapAccelTableSaved.SetAt(wKey, pNewCmdAccel);
	}

	// The Strings-ID table
	CString szKey;

	pos = accelmgr.m_mapAccelString.GetStartPosition();

	while (pos != NULL) {
		accelmgr.m_mapAccelString.GetNextAssoc(pos, szKey, wKey);
		m_mapAccelString.SetAt(szKey, wKey);
	}

	m_bDefaultTable = accelmgr.m_bDefaultTable;

	return *this;
}



//////////////////////////////////
//////		Originally posted by: Joachim Friedhoff
// I have written a routine to fill the accelerator manager automatically with the menu items. I'm using the
// function in my applications InitInstance after the connection of the accelerator manager to the MainFrame
// Window

//The necessary functions:
//------------------------

//If you have the situation, that a menu command can be reached by more than one menu, e.g.
//Menu1/Submenu1/MyItem AND Menu2/Submenu1/MyItem you get a memory leak. In this situation use the
//CreateEntry-function below instead of the original CreateEntry.
//�����ͬһ�˵����ڶ���Ӳ˵��г��ֵ����(�Ӷ��в�ͬ�����ִ�)�������ڴ�й©

bool CAcceleratorManager::CreateEntry(WORD wIDCommand, LPCTSTR szCommand)
{
	ASSERT(szCommand != NULL);

	WORD wIDDummy;

	if (m_mapAccelString.Lookup(szCommand, wIDDummy) == TRUE)
		return false;

	CCmdAccelOb* pCmdAccel = NULL;

	if (!m_mapAccelTable.Lookup(wIDCommand, pCmdAccel))
		pCmdAccel = new CCmdAccelOb(wIDCommand, szCommand);

	if (!pCmdAccel)   // ������û�ҵ���������ID�ҵ��ˣ�ֱ�ӷ��أ���ôͬһ����Ĳ�ͬ��ھͱ�������
		return FALSE;

	m_mapAccelTable.SetAt(wIDCommand, pCmdAccel);

	m_mapAccelString.SetAt(szCommand, wIDCommand);

	return false;
}
