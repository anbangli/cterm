#if !defined(AFX_URLDLG_H__73ADF3B0_85FE_455A_8504_45A2AF7C59A9__INCLUDED_)
#define AFX_URLDLG_H__73ADF3B0_85FE_455A_8504_45A2AF7C59A9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// URLDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CURLDlg dialog

class CURLDlg : public CDialog
{
// Construction

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CURLDlg(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CURLDlg)
	enum { IDD = IDD_URLOK };
	CString	m_url;
	BOOL	m_noask;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	CToolTipCtrl m_tooltip;
	// Generated message map functions
	//{{AFX_MSG(CURLDlg)
	afx_msg void OnOpenFtp();
	afx_msg void OnOpenHttp();
	virtual void OnOK();
	afx_msg void OnOpenFlashget();
	afx_msg void OnOpenIE();
	virtual BOOL OnInitDialog();
	afx_msg void OnNoask();
	afx_msg void OnOpentelnet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLDLG_H__73ADF3B0_85FE_455A_8504_45A2AF7C59A9__INCLUDED_)
