// TermLine.h: interface for the CTermLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TERMLINE_H__F7D0B407_A473_4757_B810_1FDAEB4C33ED__INCLUDED_)
#define AFX_TERMLINE_H__F7D0B407_A473_4757_B810_1FDAEB4C33ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "onechar.h"

class CTermLine
{

public:
	CTermLine();
	virtual ~CTermLine();

	CTermLine(CString s);
	CTermLine(int len);

// Attributes

public:	
	bool m_bChanged;
	int m_nLineNum; //�к�
	int m_nLineLen;
//	int m_bLong;

	inline SOneChar * const buf() const
	{
		return m_buf;
	}

public:
	void ClearLine(int startx = 0, int endx = -1);

protected:
	inline void NewLine(int len);
	SOneChar * m_buf;
};

#endif // !defined(AFX_TERMLINE_H__F7D0B407_A473_4757_B810_1FDAEB4C33ED__INCLUDED_)
