// UserPassDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UserPassDlg.h"
#include "telnetsite.h"
#include "addrbookdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUserPassDlg dialog


CUserPassDlg::CUserPassDlg(CWnd* pParent /*=NULL*/, CTelnetSite * pSite)
		: CDialog(CUserPassDlg::IDD, pParent),
		m_pSite(pSite)
{
	//{{AFX_DATA_INIT(CUserPassDlg)
	m_user = _T("");
	m_pass = _T("");
	m_bSave = FALSE;
	//}}AFX_DATA_INIT
	m_nPassTry = 0;
}


void CUserPassDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUserPassDlg)
	DDX_Control(pDX, IDOK, m_okctrl);
	DDX_Control(pDX, IDC_PASS, m_passctrl);
	DDX_Control(pDX, IDC_USER, m_userctrl);
	DDX_Text(pDX, IDC_USER, m_user);
	DDX_Text(pDX, IDC_PASS, m_pass);
	DDX_Check(pDX, IDC_SAVE, m_bSave);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUserPassDlg, CDialog)
	//{{AFX_MSG_MAP(CUserPassDlg)
	ON_BN_CLICKED(ID_NOTASK, OnNotask)
	ON_EN_CHANGE(IDC_USER, OnChangeUser)
	ON_EN_CHANGE(IDC_PASS, OnChangePass)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUserPassDlg message handlers

void CUserPassDlg::OnOK()
{
	UpdateData();
	CDialog::OnOK();
}

BOOL CUserPassDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	GetDlgItem(IDC_USER)->SetFocus();

	if (!m_user.IsEmpty()) {
		m_userctrl.EnableWindow(FALSE);
		m_passctrl.SetFocus();
		m_passctrl.SetSel(0, -1, TRUE);
	}

	if (m_user.IsEmpty() || m_pass.IsEmpty()) {
		m_okctrl.EnableWindow(FALSE);
	}

	{
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_SAVE), _T("���浽��ַ��"));
	}
	return FALSE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CUserPassDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	if (pMsg->message == WM_KEYDOWN) {
		if (pMsg->wParam == VK_RETURN && GetFocus() == GetDlgItem(IDC_USER)) {
			GetDlgItem(IDC_PASS)->SetFocus();
			return TRUE;
		}
	}

	return CDialog::PreTranslateMessage(pMsg);
}

void CUserPassDlg::OnNotask()
{
	//m_nPassTry>=100�Ͳ���ʾ�ˣ���������m_nPassTry=100���Խ�ֹ����ʾ
	m_nPassTry = 100;
	OnCancel();
}

void CUserPassDlg::OnChangeUser() 
{
	// ��������Ϊ��... ppt && !m_pass.IsEmpty()
	UpdateData();
	m_okctrl.EnableWindow(!m_user.IsEmpty());
}

void CUserPassDlg::OnChangePass() 
{
	UpdateData();
	m_okctrl.EnableWindow(!m_user.IsEmpty());
}

void CUserPassDlg::OnSave() 
{
	if (m_pSite) {
		UpdateData();
		if (m_bSave) {
			m_pSite->SetAutoLogin(m_user, m_pass);
			BYTE b = m_pSite->m_Login.m_bAutoLogin;
			m_pSite->m_Login.m_bAutoLogin = true;
			CAddrBookDlg AddrBook;
			AddrBook.SaveSite(m_pSite);
			m_pSite->m_Login.m_bAutoLogin = b; // �ָ�
		}
	}
}
