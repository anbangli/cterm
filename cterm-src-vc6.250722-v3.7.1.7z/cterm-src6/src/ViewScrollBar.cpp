// ViewScrollBar.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "ViewScrollBar.h"
#include "usermsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewScrollBar dialog


CViewScrollBar::CViewScrollBar(CWnd* pParent /*=NULL*/)
	: CDialogBar()
{
	//{{AFX_DATA_INIT(CViewScrollBar)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

void CViewScrollBar::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CViewScrollBar)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CViewScrollBar, CDialogBar)
	//{{AFX_MSG_MAP(CViewScrollBar)
	ON_WM_VSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewScrollBar message handlers

void CViewScrollBar::SetScrollSize(int nScrn, int nCur)
{
	CScrollBar * pBar = (CScrollBar *)GetDlgItem(IDC_SCROLLBAR1);
	if (pBar) {
		pBar->SetScrollRange(0, nScrn - 1);
		pBar->SetScrollPos(nCur);

		SCROLLINFO info;
		info.cbSize = sizeof(info);
		info.nPage = 1;
		info.fMask = SIF_PAGE;
		pBar->SetScrollInfo(&info);
	}
}

void CViewScrollBar::SetSize(int sz)
{
	//TRACE("CViewScrollBar::SetSize %d\n", sz);
	
	CRect rdlg;
	GetWindowRect(&rdlg);
	rdlg.bottom = rdlg.top + sz;
	GetParent()->ScreenToClient(rdlg);
	MoveWindow(&rdlg);
	CScrollBar * pBar = (CScrollBar *)GetDlgItem(IDC_SCROLLBAR1);
	if (pBar) {
		CRect rbar;
		pBar->GetWindowRect(&rbar);
		rbar.bottom = rbar.top + sz;
		ScreenToClient(rbar);
		pBar->MoveWindow(&rbar);
	}
	RedrawWindow();
}

void CViewScrollBar::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar * pScrollBar) 
{
	const int pageNum = 3;
	int TempPos = pScrollBar->GetScrollPos();
	int minPos, maxPos;
	bool bDefault = false;
	pScrollBar->GetScrollRange(&minPos, &maxPos);
	switch(nSBCode)
	{
	case SB_THUMBPOSITION:
		TempPos = nPos;
		break;
	case SB_LINEUP:
		if(TempPos > minPos)
		{
			TempPos--;
		}
		break;
	case SB_LINEDOWN:
		if(TempPos < maxPos)
		{
			TempPos++;
		}
		break;
	case SB_PAGEUP:
		if(TempPos > minPos)
		{
			TempPos -= pageNum;
			if (TempPos < minPos)
				TempPos = minPos;
		}
		break;
	case SB_PAGEDOWN:
		if(TempPos < maxPos)
		{
			TempPos += pageNum;
			if (TempPos > maxPos)
				TempPos = maxPos;
		}
		break;
	default:
		bDefault = true;	
	}

	if (!bDefault) {
		pScrollBar->SetScrollPos(TempPos);
		AfxGetMainWnd()->SendMessage(WM_SCROLLBAR, (WPARAM)TempPos, 0);
	}

	CDialogBar::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CViewScrollBar::SetPos(int pos)
{
	CScrollBar * pBar = (CScrollBar *)GetDlgItem(IDC_SCROLLBAR1);
	if (pBar) {
		pBar->SetScrollPos(pos);
	}
}
