// MoreLine.h: interface for the CMoreLine class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MORELINE_H__0F60510E_0715_4F4F_AD4E_F46A41205FB5__INCLUDED_)
#define AFX_MORELINE_H__0F60510E_0715_4F4F_AD4E_F46A41205FB5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "OneChar.h"
class CCTermCore;
class CCTermView;
//������ʾ�����У��۵���һ����ʾ
//�����кž�����ڵ�ǰ��

class CMoreLine
{

public:
	CMoreLine();
	virtual ~CMoreLine();

	BOOL SetLine(CCTermCore *pCore, int nStart);

	const CCTermCore *m_pCore;
	const CCTermView *m_pView;
	BOOL m_bHaveChange;

protected:
	void RemoveChange();

	int m_nThisLine;
	int m_nLine;
	int m_nStart;
	SOneChar m_BakLine[3][256];

	void ChangeLine(int n, TCHAR *ts);
};

#endif // !defined(AFX_MORELINE_H__0F60510E_0715_4F4F_AD4E_F46A41205FB5__INCLUDED_)
