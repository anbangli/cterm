// PicShowDlg.cpp : implementation file
//

#include "stdafx.h"
#include <winsock.h>
#include <io.h>
#include <process.h>
#include <MULTIMON.H>

#include "mainfrm.h"
#include "global.h"

#if ENABLE_MULTILANG
#include "multilang.h"
#endif//ENABLE_MULTILANG

#include "paramconfig.h"
#include "debugtool.h"

#include "PicShowDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define ID_PICTURE_0			0x100		// ��̬����ͼƬ�ؼ�ID

#define PICDLG_INITHEIGHT 25	//��ͼƬʱ�������С
#define PICDLG_INITWIDTH 350
#define PICDLG_MINWIDTH 350

#define PIC_MOVE_STEP 20 //��һ�¼�ͷ��, ͼƬ�ƶ��ľ���

extern piclist g_PicList;
#if ENABLE_PYTHON
extern bool g_bSysPythonScriptLoaded;
#endif


CPicShowDlg *g_pPicShowDlg = NULL; // only one

TCHAR *GetShortFileName(TCHAR *s);

/////////////////////////////////////////////////////////////////////////////
// CPicShowDlg dialog

#if ENABLE_PICTURE

CPicShowDlg::CPicShowDlg(CWnd* pParent /*=NULL*/)
: CDialog(CPicShowDlg::IDD, pParent),
m_picex(NULL),
//m_bFullScreen ( FALSE ),
m_nState(PIC_UNKNOWN),
//		m_bFixed(false),
m_hLoadPicThread(NULL),
m_pic(NULL),
//		m_picit(NULL),
m_lastmovept(0, 0),
m_lasttiped(false),
m_firsttiped(false)
{
	//{{AFX_DATA_INIT(CPicShowDlg)
	//}}AFX_DATA_INIT
	m_bDrawing = false;
	m_bLoading = false;
	m_LoadingPic = NULL;
	m_nDisplaySize = 0;
	m_bPicMoving = false;
	m_bLeftDown = false;
}

void CPicShowDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPicShowDlg)
	DDX_Control(pDX, IDC_PIC_INFO, m_btInfo);
	DDX_Control(pDX, IDC_PIC_CLOSE, m_btClose);
	DDX_Control(pDX, IDC_PIC_SAVE, m_btSave);
	DDX_Control(pDX, IDC_PIC_OPEN, m_btOpen);
	DDX_Control(pDX, IDC_PIC_NEXT, m_btNext);
	DDX_Control(pDX, IDC_PIC_PREV, m_btPrev);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPicShowDlg, CDialog)
//{{AFX_MSG_MAP(CPicShowDlg)
ON_WM_SHOWWINDOW()
ON_BN_CLICKED(IDC_PIC_PREV, OnPicPrev)
ON_BN_CLICKED(IDC_PIC_NEXT, OnPicNext)
ON_BN_CLICKED(IDC_PIC_SAVE, OnPicSave)
ON_MESSAGE(WM_PICTURE, OnPicEvent)
ON_BN_CLICKED(IDC_PIC_CLOSE, OnPicClose)
ON_MESSAGE(WM_SETSTATUSCOUNT, OnSetStatusCount)
ON_WM_CTLCOLOR()
ON_WM_MOUSEWHEEL()
ON_BN_CLICKED(IDC_PIC_OPEN, OnPicOpen)
ON_WM_NCHITTEST()
ON_WM_NCLBUTTONDOWN()
ON_WM_TIMER()
ON_COMMAND(ID_PIC_ZOOM, OnPicZoom)
ON_WM_NCLBUTTONUP()
ON_WM_MOUSEMOVE()
ON_WM_NCRBUTTONDOWN()
ON_WM_SETCURSOR()
ON_BN_CLICKED(IDC_PIC_INFO, OnPicExif)
ON_COMMAND(ID_PICEXIF, OnPicExif)
ON_COMMAND(ID_PIC_MAX, OnPicMax)
ON_COMMAND(ID_PIC_PREV, OnPicPrev)
ON_COMMAND(ID_PIC_NEXT, OnPicNext)
ON_COMMAND(ID_PIC_SAVE, OnPicSave)
ON_COMMAND(ID_PIC_OPEN, OnPicOpen)
ON_COMMAND(ID_PIC_CLOSE, OnPicClose)
	ON_COMMAND(ID_PIC_OPENPATH, OnPicOpenpath)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPicShowDlg message handlers

BOOL CPicShowDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG
	
	
	m_picex = new CPictureEx(this);
	
	if (m_picex->Create(NULL, WS_VISIBLE | WS_CHILD | SS_BLACKFRAME,
		CRect(0, 25, 150, 150), this, ID_PICTURE_0) == FALSE) {
		AfxMessageBox(_T(" Fail to create control"));
		delete m_picex;
		m_picex = NULL;
		//TRACE(_T("Create Pciture Control Failed\n"));
	}
	
	SetBgColor();
	
#if ENABLE_BTNST
	CButtonST *buttons[] = { &m_btPrev, &m_btNext, &m_btSave, &m_btOpen, &m_btClose, &m_btInfo };
	int count = sizeof(buttons) / sizeof(CButtonST *);
	
	for (int i = 0; i < count; ++i) {
		// ���ø���ť����ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_BK_OUT, RGB(100, 100, 100));	// ��ͨ״̬ʱ�ı���ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_FG_OUT, RGB(255, 255, 255));	// ��ͨ״̬ʱ��ǰ��ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_BK_IN, RGB(150, 150, 150));	    // �����ڰ�ť��ʱ�ı���ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_FG_IN, RGB(255, 255, 255));	    // �����ڰ�ť��ʱ��ǰ��ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_BK_FOCUS, RGB(100, 100, 100));  // ��ť��ý���ʱ�ı���ɫ
		buttons[i]->SetColor(CButtonST::BTNST_COLOR_FG_FOCUS, RGB(255, 255, 255));  // ��ť��ý���ʱ��ǰ��ɫ
		buttons[i]->EnableWindow(FALSE);   // ��ʼ��ʱ���ã���������һ��ͼƬ��ſ���
	}
	
#endif//ENABLE_BTNST
	
	m_btClose.EnableWindow(TRUE);
	
	m_btInfo.EnableWindow(TRUE);
	
	ShowDlgInfo(CString(_T("û��ͼƬ")));
	
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);
		
		m_tooltip.AddTool(GetDlgItem(IDC_PIC_INFO), "info...");
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CPicShowDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
	//m_bFullScreen=FALSE;
	//DrawPicture(true);
}

// ͼƬ������Ϣ
// wParam: ����
LRESULT CPicShowDlg::OnSetStatusCount(WPARAM wParam, LPARAM lParam)
{
	CString sInfo;
	int nPicDownNum = (int) wParam;
	
	if (nPicDownNum > 0)
		sInfo.Format(ID_INDICATOR_PIC_FORMAT, nPicDownNum);
	else
		sInfo.Format(IDS_PIC_DOWNLOADED, g_PicList.size());
	
	SetStatusBar(ID_INDICATOR_PIC, sInfo);
	
	return 1;
}

//#ifdef _DEBUG
//	DWORD g_piclasttick = 0;
//#endif //_DEBUG
HRESULT CPicShowDlg::OnPicEvent(WPARAM wParam, LPARAM lParam)
{
	//	TRACEFINTS(_T("CPicShowDlg::OnPicEvent wParam="), wParam);
	//#ifdef _DEBUG
	//	g_piclasttick = GetTickCount();
	//	TRACE(_T("CPicShowDlg::OnPicEvent wParam=%x, lParam=%x\n, g_nPicTimeout=%d, g_piclasttick=%ld\n"),
	//		wParam, lParam, g_nPicTimeOut, g_piclasttick);
	//	TRACE(_T("CPicShowDlg::OnPicEvent wParam=%x, lParam=%x\n, g_nPicTimeout=%d, g_piclasttick=%ld\n"),
	//#endif //_DEBUG
	
	m_csDraw.Lock();
	
	PicState nState = PIC_DOWNLOAD;
	
	if (!m_picex) goto retlabel;
	
	if (lParam == FLAG_PIC_NEW) {
		PICSTRUCT *pic = (PICSTRUCT *) wParam;
		
		if (!pic)  goto retlabel;
		
		// ��ctrl��û��shiftʱ��������
		// shift���ж���Ϊ�˱����ctrl+shift+p��ͻ
		bool bRedown = (isdown(VK_CONTROL) && !isdown(VK_SHIFT) && !isdown(VK_MENU));
		
		nState = DownloadPic(pic, m_picit, bRedown);	//picdown.cpp
		
		if (m_picit == g_PicList.end()) {
			//m_picit������Ч��iterator: ����ҵ�, ����֮; ���򷵻��¼����
			//�����Ӧ�øı䵱ǰpic
			//			m_pic = pic = NULL;
			//			m_szPicFile.Empty(); // todo: �⼸������Ӧд����������
			goto retlabel;
		} else {
			m_pic = *m_picit;
		}
		
		//if ( pic && !pic->strURL.IsEmpty() )
		m_szPicFile = GetLocalFile(m_pic->strURL);
	} else {
		m_pic = (PICSTRUCT*) wParam;
		
		if (!m_pic)  goto retlabel;
		
		nState = m_pic->State();
		
#ifdef _DEBUG
		if (m_szPicFile.IsEmpty()) m_szPicFile = _T("null");
		
#endif
		//if ( !m_pic->strURL.IsEmpty() )
		m_szPicFile = GetLocalFile(m_pic->strURL);
		
		// from loading thread
		if (lParam == FLAG_PIC_LOAD) {
			ASSERT(m_pic == m_LoadingPic);
			m_bLoading = false;
			m_LoadingPic = NULL;
			KillTimer(TIMER_LOADPIC);
			m_hLoadPicThread = NULL;
		}
	}
	
	if (lParam != FLAG_PIC_LOAD && nState == PIC_LOADED) {
		// reload, ��Ϊ��ͼƬ��loaded��ͼƬ���ܲ���һ��
		// todo: ���Ҫ����ͬһͼƬ�����ظ�load, �ɼ�¼��loadedpic���Ƚ�
		nState = PIC_SUCCESS; // todo: �Ƿ�һ��
		
		if (m_pic) m_pic->Setstate(PIC_SUCCESS);
	}
	
	m_nState = nState;
	
	//TRACE( _T("OnPicEvent wP=%d lP=%d st=%d\n"), wParam, lParam, m_nState );
	//TRACE(_T("OnPicEvent m_nState = %d \n"), m_nState);
	if (!g_bPicDlgInfo && (nState == PIC_START || nState == PIC_DOWNLOAD)) {
		ASSERT(g_pMainWnd);
		SetStatusBar(ID_INDICATOR_PIC, GetStatusStr(nState));
	} else {
		bool bFixed = true;
		
		if (!IsWindowVisible()) {
			// && g_pPicShowDlg->m_nState!=PIC_SUCCESS
			//m_bFullScreen = FALSE;
			m_nDisplaySize = 0;
			bFixed = false;
			//ShowWindow(SW_SHOWNORMAL);
		}
		
		//DrawPicture1();
		DrawPicture(nState, bFixed);   //��ʾ״̬���ͼ
	}
	
retlabel:
	
	m_csDraw.Unlock();
	
	return 1;
}

unsigned __stdcall CPicShowDlg::LoadPicThread(void *pParam)
{
	//	TRACE(_T("LoadPicThread loading ...\n"));
	CPicShowDlg *pPicDlg = (CPicShowDlg *) pParam;
	
	ASSERT(pPicDlg->m_LoadingPic != NULL);
	ASSERT(!pPicDlg->m_LoadingPic->strLocal.IsEmpty());
	ASSERT(pPicDlg->m_LoadingPic->State() == PIC_SUCCESS);
	
	CString sfilename = pPicDlg->m_LoadingPic->strLocal;
	
	if (pPicDlg->m_picex->Load(sfilename)) {
		pPicDlg->m_LoadingPic->Setstate(PIC_LOADED);
	} else {
		pPicDlg->m_LoadingPic->Setstate(PIC_FAILURE, 5);
		//TRACEF( _T( "PIC_FAILURE 5\n" ) );
	}
	
	//TRACE( _T( "WM_PICTURE 13\n" ) );
	pPicDlg->PostMessage(WM_PICTURE, (WPARAM)pPicDlg->m_LoadingPic, (LPARAM)FLAG_PIC_LOAD);
	
	//pPicDlg->m_bDrawing = false;
	//pPicDlg->DrawPicture();//m_bFixed not changed;
	return 0;
}

void CPicShowDlg::LoadPicture()
{
	if (g_bLoadPicThread) {
		if (m_bLoading) return;   //��������
		
		m_bLoading = true;
		
		ASSERT(m_pic != NULL);
		
		if (m_nState == PIC_SUCCESS && !m_szPicFile.IsEmpty() && m_pic != NULL) {
			//if (!m_picex->Load(m_szPicFile))//���߳�����������ͼƬ�ر���ͼƬ�������⣬��Ӱ����������Ӧ
			//	break;
			//m_sLoadFile = m_szPicFile;
			m_LoadingPic = m_pic;
			
			unsigned threadid = 0;
			m_hLoadPicThread = (HANDLE) _beginthreadex(NULL,
				0,
				CPicShowDlg::LoadPicThread,
				(LPVOID) this,
				0,
				&threadid);
			KillTimer(TIMER_LOADPIC);
			SetTimer(TIMER_LOADPIC, g_nPicLoadTimeOut, NULL);
			
			//		m_bDrawing = false; //����������pic����, ��Ϊ loadpicthread Ҫʹ�� m_pictex
			return;
		}
	} else {
		if (!m_szPicFile.IsEmpty()) {
			if (m_picex->Load(m_szPicFile)) {
				m_nState = PIC_LOADED;
				
				if (m_pic) m_pic->Setstate(PIC_LOADED);
				
			} else {
				m_nState = PIC_FAILURE;
				
				if (m_pic) m_pic->Setstate(m_nState, 6);
			}
			
			
		}
	}
}

void CPicShowDlg::ShowDlgInfo(const CString &info) const
{
	m_picex->ShowWindow(SW_HIDE);
	
	// һֱ��ʾ��
	//	GetDlgItem(IDC_PIC_INFO)->ShowWindow(SW_SHOW);
	//	GetDlgItem(IDC_PIC_CLOSE)->ShowWindow(SW_SHOW); // ԭ����hide, Ϊʲô
	//	GetDlgItem(IDC_PIC_PREV)->ShowWindow(SW_SHOW);
	//	GetDlgItem(IDC_PIC_NEXT)->ShowWindow(SW_SHOW);
	//	GetDlgItem(IDC_NUM)->ShowWindow(SW_SHOW);
	
	GetDlgItem(IDC_DOWNLOAD)->ShowWindow(SW_SHOWNORMAL);
	GetDlgItem(IDC_DOWNLOAD)->SetWindowText(info);
	
	GetDlgItem(IDC_PIC_SAVE)->ShowWindow(SW_HIDE);
	GetDlgItem(IDC_PIC_OPEN)->ShowWindow(SW_HIDE);
}

void CPicShowDlg::ShowDlgInfo1(const CString &filename) const
{
	if (!filename.IsEmpty()) {
		GetDlgItem(IDC_NUM)->SetWindowText(filename);
	} else if (m_pic && !m_pic->strURL.IsEmpty()) {
		// ���url�ĺ�벿��
		ASSERT(m_pic->strLocal.IsEmpty());
		ASSERT(!m_pic->strURL.IsEmpty());
		
		tstring s = (LPCTSTR)m_pic->strURL;
		const int maxlen = 24;
		
		if (maxlen < s.size())
			s = s.substr(s.size() - maxlen, maxlen);
		
		GetDlgItem(IDC_NUM)->SetWindowText(s.c_str());
	} else {
		GetDlgItem(IDC_NUM)->SetWindowText(_T(""));
	}
}

CString CPicShowDlg::GetStatusStr(PicState nState) const
{
	CString r;
	
	switch (nState) {
		
	case PIC_START:
		
	case PIC_DOWNLOAD:
		//ShowDlgInfo(_T(""));
		r = _T("��������...");
		break;
		
	case PIC_WRONG:
		
	case PIC_FAILURE: {
		r.Format(_T("�޷���ʾ(%d)"), m_pic ? m_pic->errcode : 0);
					  }
		
		break;
#ifdef _DEBUG
		
	default:
		r = _T("");
#endif
	}
	
	return r;
}

void CPicShowDlg::ShowButtons(bool bShow)
{
	m_btPrev.ShowWindow(bShow);
	m_btNext.ShowWindow(bShow);
	m_btSave.ShowWindow(bShow);
	m_btOpen.ShowWindow(bShow);
	m_btClose.ShowWindow(bShow);
	m_btInfo.ShowWindow(bShow);
	GetDlgItem(IDC_DOWNLOAD)->ShowWindow(bShow);
	GetDlgItem(IDC_NUM)->ShowWindow(bShow);
}

// ȫ��ʱ��
static const int winoffset = 20;// scnRect.top == -20

// bFixed = true: �̶�����λ�ã������ı�λ��(����Խ��)������������ͼƬ��С�ı�
// ����: ����
void CPicShowDlg::DrawPicture(PicState nState, bool bFixed)
{
	if (m_bDrawing) return;   // ��������
	
	m_bDrawing = true;
	
	//	if ( isdown ( VK_SHIFT ) ) nState = PIC_SUCCESS; //shift���¼���
	m_lasttiped = m_firsttiped = false;
	
	if (!m_bLoading && m_pic && nState == PIC_SUCCESS && !m_szPicFile.IsEmpty()) {
		LoadPicture();
		
		if (g_bLoadPicThread) {
			m_bDrawing = false;
			return;
		} else {
			nState = m_nState;
		}
	}
	
	CRect mainrect; //rect1
	
	AfxGetMainWnd()->GetWindowRect(&mainrect);
	
	CRect rw;
	GetWindowRect(&rw);
	
	POINT LTpt;//���Ͻ�����
	GetCursorPos(&LTpt);
	
	//  && LTpt.y - rw.top <= PICDLG_INITHEIGHT
	if (m_nDisplaySize == 0 && IsWindowVisible() && rw.PtInRect(LTpt)) {
		// �����ͼƬ�������ʱ������
		bFixed = true;
	}
	
	if (bFixed) {
		LTpt.x = rw.left;
		LTpt.y = rw.top;
	}
	
	//else
	//	::GetCursorPos(&LTpt);
	
	int width = PICDLG_INITWIDTH, height = PICDLG_INITHEIGHT;
	
	//	GetParent()->ScreenToClient(&LTpt);���Ҫ���ã�����
	
	if (m_nDisplaySize > 0) {
		if (nState == PIC_WRONG) {
			// ��ͼƬ ���߼�����
			m_nDisplaySize = 0; // ��ͼƬ�˳�ȫ��
		} else if (nState != PIC_LOADED) {
			// �����ȫ��״̬����״̬���Ǽ��سɹ���ʲô������
			m_bDrawing = false;
			return;
		}
	}
	
	if (m_pic &&
		!(nState == PIC_LOADED && !g_bPicBorder)) {
		// ��������ް�ť
		m_tooltip.AddTool(GetDlgItem(IDC_PIC_INFO), m_pic->sExtInfo);
	}
	
	CString filename;
	
	if (!m_szPicFile.IsEmpty()) {
		ASSERT(m_szPicFile == m_pic->strLocal);
		filename = GetShortFileName(m_szPicFile.LockBuffer());
		m_szPicFile.UnlockBuffer();
	}
	
	m_picex->SetPicText(_T(""));
	
	m_tooltip.Pop();
	m_tooltip.Update();
	
	if (g_bPicTip && m_pic && nState == PIC_LOADED) {
		CString tip;		//CString tip(filename);
		tip=m_pic->sExtInfo;
//		if (true) {
//			//g_bPicBorder //��Ч�������о�ѡ��			// �ް�ť
//			int nPos = m_pic->sExtInfo.Find(':');
//			if (nPos != -1 && m_pic->sExtInfo.GetLength() > nPos + 1) {
//				tip += _T("@");
//				tip += m_pic->sExtInfo.Mid(nPos + 1) + _T("");
//			}
//			m_picex->UpdateTooltip();
//		}
		m_picex->UpdateTooltip(tip);
	}
	
	if (m_pic == NULL) {
		nState = PIC_WRONG;
		m_szPicFile.Empty();
	}
	
	// ͼƬ������1����
	BOOL b = g_PicList.size() > 1;
	
	GetDlgItem(IDC_PIC_PREV)->EnableWindow(b);
	
	GetDlgItem(IDC_PIC_NEXT)->EnableWindow(b);
	
	b = nState == PIC_LOADED;
	
	if (b && g_bPicBorder) {
		GetDlgItem(IDC_PIC_SAVE)->ShowWindow(SW_SHOWNORMAL);
		GetDlgItem(IDC_PIC_OPEN)->ShowWindow(SW_SHOWNORMAL);
		GetDlgItem(IDC_PIC_SAVE)->EnableWindow(b);
		GetDlgItem(IDC_PIC_OPEN)->EnableWindow(b);
	}
	
	//bool bPosFixed = false; // �ѵ���
	switch (nState) {
		// PIC_START��ʼ���أ�PIC_DOWNLOAD�����У�PIC_FAILURE����ʧ��
	case PIC_LOADED: {
		m_bLoading = false;
		
		GetDlgItem(IDC_DOWNLOAD)->ShowWindow(SW_HIDE);
		
		
		//300,300*szPic.cy /szPic.cx );// ʹ��ͼƬ�ĳ�����
		CSize szPic = m_picex->GetSize();
		int picWid = szPic.cx;
		int picHigh = szPic.cy;
		
		ASSERT(!m_szPicFile.IsEmpty());
		
		if (m_nDisplaySize == 0) {
			if (!g_bPicBorder) {
				ShowButtons(false); // hide all
			}
			else {
				ShowButtons();
				GetDlgItem(IDC_DOWNLOAD)->ShowWindow(SW_HIDE);
			}
			
			if (!filename.IsEmpty()) {
				GetDlgItem(IDC_NUM)->SetWindowText(filename);
			} else {
				//never here
				ASSERT(FALSE);
				GetDlgItem(IDC_NUM)->SetWindowText(_T(""));
			}
			
			// ���� rc λ��ʱ��ҪС�ģ��ڸı�right, bottomʱ�������� cx, cy ����Ҫ�ı仯
			// ���´��벻Ҫ��ͼ��
			if (picWid > PICDLG_MINWIDTH) {
				picWid = PICDLG_MINWIDTH;
				picHigh = (int)(picWid *szPic.cy / szPic.cx);
			}
			
			if (picHigh > mainrect.Height() - PICDLG_INITHEIGHT * 2) {
				picHigh = mainrect.Height() - PICDLG_INITHEIGHT * 2;
				picWid = (int)(picHigh *szPic.cx / szPic.cy);
			}
			
			m_rcPic = CRect(0, 0, picWid, picHigh);		//x0=2,�������һ����϶ //������Ϊʲô
			
			m_rcPic.bottom = m_rcPic.bottom + PICDLG_INITHEIGHT;
			m_rcPic.top = m_rcPic.top + PICDLG_INITHEIGHT;
			
			if (g_bPicBorder) {
				width = m_rcPic.Width() < PICDLG_MINWIDTH ? PICDLG_MINWIDTH : m_rcPic.Width(); //195����ʾ4����ť����Ŀ���
				height = PICDLG_INITHEIGHT + picHigh; //PICDLG_INITHEIGHT�ǰ�ť�߶�,������Ҫ���Ӹ߶Ȳ�����ʾ���ƺ��Ǵ��ڱ߿�����ġ�
			} else {
				width = m_rcPic.Width();
				height = m_rcPic.Height();
			}
			
			//�µĴ���rect
			//���ܼ�������
			//rect.right = rect.left + width;
			//rect.bottom = rect.top + height;
		} else if (m_nDisplaySize == 1) {
			// ȫ��
			CRect scnRect;
			GetWindowRect(&scnRect);	//ȫ���ߴ�
			
			// ��static����ô?
			// �����Ǳ߿��ԭ�������С�ᳬ����Ļ�ߴ�һЩ
			// ��Сһ�����ʾ���� ��Ϊ�����и�ƫ��
			//const int winoffset = 20;// scnRect.top == -20
			int frameWidth = scnRect.Width(), frameHeight = scnRect.Height() - winoffset;
			// ����ǻ���ߴ�, �����ǵ�����Ļ�ߴ�, ������Ҫ��С��ʾ��ʱ��, ��������
			
			m_rcPic = CRect(0, 0, szPic.cx, szPic.cy);
			double ratiox = ((double) frameWidth) / szPic.cx, ratioy = ((double) frameHeight) / szPic.cy;
			
			if (ratiox < 1.0 || ratioy < 1.0) {
				// ͼƬ����ȫ��
				//��С: �����ҡ��±߽�
				ratiox = min(ratiox, ratioy);
				m_rcPic.right = (long)(ratiox *szPic.cx);
				m_rcPic.bottom = (long)(ratiox *szPic.cy);
			}
			
			//ͼƬ����
			int W = m_rcPic.Width();
			
			int H = m_rcPic.Height();
			
			m_rcPic.left = (frameWidth - W) / 2;
			
			m_rcPic.right = m_rcPic.left + W;
			
			m_rcPic.top = (frameHeight - H) / 2;
			
			m_rcPic.top += winoffset; //��Ϊ��һ��ƫ��, ����Ҫ������һ��
			
			m_rcPic.bottom = m_rcPic.top + H;
			
		} else {
			// m_nDisplaySize == 2 ԭ�ߴ�
			CRect scnRect;
			GetWindowRect(&scnRect);	//ȫ���ߴ�
			int frameWidth = scnRect.Width(), frameHeight = scnRect.Height() - winoffset;	// ��Сһ�����ʾ����
			
			if (!m_bPicMoving) {
				//ִ��"ԭ�ߴ�����"
				m_rcPic = CRect(0, 0, szPic.cx, szPic.cy);
				
				//ͼƬ����
				int W = m_rcPic.Width();
				int H = m_rcPic.Height();
				m_rcPic.left = (int)(frameWidth - W) / 2;
				m_rcPic.right = m_rcPic.left + W;
				m_rcPic.top = (int)(frameHeight - H) / 2;
				m_rcPic.top += winoffset;
				m_rcPic.bottom = m_rcPic.top + H;
			}
			
			//else // m_bPicMoving
		}
		
		// ǰ��������ͼƬ��С��λ�ã�������ʾͼƬ
		// ���ƶ�λ�ã�Ȼ����ʾΪNORMAL�������ơ����򲻿ɵߵ���
		if (m_nDisplaySize == 0 && !g_bPicBorder) {
			m_rcPic.top -= PICDLG_INITHEIGHT;
			m_rcPic.bottom -= PICDLG_INITHEIGHT;
		}
		
//		if (m_nDisplaySize == 0) {
//			bPosFixed = true;
//			fixWinPos(LTpt, mainrect, bFixed, width, height);
//			MoveWindow(LTpt.x, LTpt.y, width, height, TRUE);

//			ShowWindow(SW_SHOWNORMAL);
//		}

		m_picex->MoveWindow(&m_rcPic);
		m_picex->ShowWindow(SW_SHOWNORMAL);
		m_picex->SetPaintRect(&m_rcPic);
		m_picex->Draw();
	}//PIC_LOADED
	
	break;
	
	default: {
		// PIC_START PIC_DOWNLOAD / PIC_WRONG PIC_FAILURE ��������״̬
		ShowDlgInfo(GetStatusStr(nState));
		ShowDlgInfo1(filename);
			 }//default
		
	}//switch
	
	if (true) {
		//!bPosFixed
		if (m_nDisplaySize == 0) {
			fixWinPos(LTpt, mainrect, bFixed, width, height);
			// Ҫ��move, ��show
			// ����Ҳ��������˸
			MoveWindow(LTpt.x, LTpt.y, width, height, TRUE);

			CPoint pcur;
			CRect rt(LTpt.x, LTpt.y, LTpt.x + width, LTpt.y + height);
			GetCursorPos(&pcur);
			if (!rt.PtInRect(pcur)) {
				::SetCursorPos(LTpt.x + width - 1, LTpt.y + height - 1);
			}
		}
		//TRACE(_T("CPicShowDlg::DrawPicture ... ShowWindow1\n"));
		ShowWindow(SW_SHOWNORMAL);
	}

	m_bDrawing = false;
}

// �س�
void CPicShowDlg::OnOK()
{
	OnPicMax();
}

void CPicShowDlg::OnPicMax()
{
	TogglePic(1);
}

// mode=1: ȫ��
// mode=2: ԭ�ߴ�
void CPicShowDlg::TogglePic(int mode)
{
	if (m_nState != PIC_LOADED)
		return;
	
	ASSERT(mode != 0);
	
	if (mode == 0) return;   //never
	
	//m_csDraw.Lock();
	
	CRect rw;
	
	GetWindowRect(&rw);
	
	WINDOWPLACEMENT wpNew;
	
	// size	mode	result
	// 0	1		1
	// 1	1		0
	// 2	1		1
	// 0	2		2
	// 1	2		2
	// 2	2		0
	// x	0		0	never
	
	int lastsize = m_nDisplaySize; //save
	
	//bool bFixed = true;
	if (m_nDisplaySize == mode) {	// ȫ��->����
		//ShowWindow ( SW_HIDE ); //������, ������ܹ���ڼ�϶��ָ��url
		m_nDisplaySize = 0;
		wpNew = m_wpPrev; //restore
		//bFixed = true; //��Ҫ���� �����п����ܵ����Ͻ�
		
		//ShowWindow(SW_HIDE); //���������ڴ���...������
	} else { // 1->2, 2->1, 0->1, 0->2
		m_nDisplaySize = mode;
		
		// ����->ȫ��
		
		if (lastsize == 0) {
			GetWindowPlacement(&m_wpPrev);
			m_wpPrev.length = sizeof m_wpPrev;
		}
		
		{
			//Adjust RECT to new size of window			
			// ����ʾ��֧��
			MONITORINFO mi;
			mi.cbSize = sizeof(MONITORINFO);
			RECT &rDesk = mi.rcMonitor;
			HMONITOR hm = MonitorFromWindow(GetSafeHwnd(), MONITOR_DEFAULTTONEAREST);
			if (!GetMonitorInfo(hm, &mi)) {
				// ������
				::GetWindowRect(GetDesktopWindow()->GetSafeHwnd(), &rDesk);
			}
			::AdjustWindowRectEx(&rDesk, GetStyle(), TRUE, GetExStyle());
			// Remember this for OnGetMinMaxInfo()
			//	    m_FullScreenWindowRect = rectDesktop;
			wpNew = m_wpPrev;
			wpNew.showCmd =  SW_SHOWNORMAL;
			
			wpNew.rcNormalPosition = rDesk;
			m_picex->ShowWindow(SW_HIDE);	//ͼƬ���أ����ⴰ�ڷŴ�ʱ���Դ˳ߴ��ػ�
		}
		
		//m_bFixed = true;
	}
	
	SetWindowPlacement(&wpNew);
	
	DrawPicture(PIC_LOADED, false);// ����
	
	//m_csDraw.Unlock();
}

// ǰһ��ͼƬ
void CPicShowDlg::OnPicPrev()
{
	if (g_PicList.size() <= 1)
		return;
	
	ASSERT(m_picit != g_PicList.end());
	
	if (m_picit == g_PicList.end()) return; //wrong
	
	PicIt theit  = m_picit; //�ñ����������ѭ��
	
	PicIt it = m_picit;
	
	if (it <= g_PicList.begin()) {
		if (!m_firsttiped) {
			// ��ʾ, ����
			const TCHAR s[] = _T("�Ѿ����˿�ʼ, �ٰ�һ���������");
			
			if (m_nState == PIC_LOADED)
				m_picex->SetPicText(s);
			else {
				GetDlgItem(IDC_NUM)->SetWindowText(s);
			}
			
			//				m_picex->UpdateTooltip(_T("�Ѿ����˿�ʼ, �ٰ�һ���������"));
			//				m_tooltip.AddTool(this, _T("�Ѿ�����ͷ��, �ٰ�һ���������"));
			//				m_tooltip.Pop();
			//				m_tooltip.Update();
			m_firsttiped = true;
			
			return;
		} else {
			m_firsttiped = false;
			// ����
		}
		
		it = g_PicList.end() - 1;
	} else
		it--;
	
	PICSTRUCT *pic = *it;
	
	if (m_nDisplaySize > 0) {
		// ȫ��/�Ŵ�ģʽ�£�����ʾδ���سɹ���
		while (pic) {
			if (pic->State() == PIC_LOADED || pic->State() == PIC_SUCCESS)
				break;
			else {
				if (it <= g_PicList.begin()) {
					it = g_PicList.end() - 1;
				} else
					it--;
			}
			
			pic = *it;
			
			if (it == theit) {
				// ������ѭ��...û���ҵ�һ�����سɹ���
				// �������ᵽ����, ��Ϊ��ǰͼƬһ���ǳɹ�, ���ɹ�Prev, Next��ť������
				if (pic->State() != PIC_LOADED && pic->State() != PIC_SUCCESS)
					pic = NULL;
				
				break;
			}
		}
	}
	
	if (pic) {
		//m_csDraw.Lock();
		m_pic = pic;
		m_picit = it;
		m_szPicFile = pic->strLocal;
		m_nState = m_pic->State();
		
		if (m_pic->State() == PIC_LOADED) {
			m_nState = m_pic->Setstate(PIC_SUCCESS);    //reload
		}
		
		//		m_bFixed = true;
		DrawPicture(m_nState);
		
		//m_csDraw.Unlock();
	}
	
	//#ifdef _DEBUG
	//	PICSTRUCT *pic1 = NULL;
	//	while ( pos )
	//	{
	//		if ( pos ) pic1 = g_PicList.GetAt( pos );
	//		if ( pos ) pic1 = g_PicList.GetNext ( pos );
	//	}
	//	pos =  g_PicList.GetHeadPosition();
	//		if ( pos2 ) pic1 = g_PicList.GetAt( pos2 );
	//		if ( pos ) pic1 = g_PicList.GetAt( pos );
	//#endif//_DEBUG
}

// ��һ��ͼƬ
void CPicShowDlg::OnPicNext()		// ǰһ��ͼƬ
{
	if (g_PicList.size() <= 1)
		return;
	
	ASSERT(m_picit != g_PicList.end());
	
	if (m_picit == g_PicList.end()) return;
	
	PicIt theit  = m_picit; //�ñ����������ѭ��
	
	PicIt it = m_picit;
	
	if (++it == g_PicList.end()) {
		TRACE(_T("CPicShowDlg::OnPicNext(), m_lasttiped=%d (1)\n"), m_lasttiped);
		
		if (!m_lasttiped) {
			
			const TCHAR s[] = _T("�Ѿ��������, �ٰ�һ��������ʼ");
			
			if (m_nState == PIC_LOADED)
				m_picex->SetPicText(s);
			else {
				GetDlgItem(IDC_NUM)->SetWindowText(s);
			}
			
			//			m_picex->UpdateTooltip(_T("�Ѿ��������, �ٰ�һ��������ʼ"));
			//			m_tooltip.AddTool(this, _T("�Ѿ��������, �ٰ�һ��������ʼ"));
			//			m_tooltip.Pop();
			//			m_tooltip.Update();
			m_lasttiped = true;
			
			TRACE(_T("CPicShowDlg::OnPicNext(), m_lasttiped=%d (2)\n"), m_lasttiped);
			
			return;
		} else {
			m_lasttiped = false;
		}
		
		TRACE(_T("CPicShowDlg::OnPicNext(), m_lasttiped=%d (3)\n"), m_lasttiped);
		
		it = g_PicList.begin();
	}
	
	PICSTRUCT *pic = *it;
	
	if (m_nDisplaySize > 0) {
		// ȫ��/�Ŵ�ģʽ�£�����ʾδ���سɹ���
		while (pic) {
			if (pic->State() == PIC_LOADED || pic->State() == PIC_SUCCESS)
				break;
			else {
				if (++it == g_PicList.end()) it = g_PicList.begin();
			}
			
			pic = *it;
			
			if (it == theit) {
				// ������ѭ��...û���ҵ�һ�����سɹ���
				// �������ᵽ����, ��Ϊ��ǰͼƬһ���ǳɹ�, ���ɹ�Prev, Next��ť������
				if (pic->State() != PIC_LOADED && pic->State() != PIC_SUCCESS)
					pic = NULL;
				
				break;
			}
		}
	}
	
	if (pic) {
		m_pic = pic;
		m_picit = it;
		m_szPicFile = pic->strLocal;
		m_nState = m_pic->State();
		
		if (m_pic->State() == PIC_LOADED) {
			m_nState = m_pic->Setstate(PIC_SUCCESS);    //reload
		}
		
		//		m_bFixed = true;
		DrawPicture(m_nState);
	}
}

void CPicShowDlg::OnPicSave()		// ����ͼƬ
{
	if (m_nState != PIC_LOADED)
		return;
	
	CString strFileName = m_szPicFile;
	CString strExt;
	int nPos = strFileName.ReverseFind('\\');
	
	//if(_access(m_szPicFile, 0) != -1)
	strFileName = strFileName.Right(strFileName.GetLength() - nPos - 1);
	
	nPos = strFileName.ReverseFind('.');
	
	if (nPos)
		strExt = strFileName.Right(strFileName.GetLength() - nPos);
	
	CFileDialogEx dlg(FALSE, NULL, strFileName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, _T("ͼƬ�ļ� (*.*)|*.*||"));
	
	if (dlg.DoModal() == IDOK) {
		strFileName = dlg.GetFileName();
		
		if (!_tcsstr(strFileName, strExt))	// ���û���������ᶪʧ��չ�������Դ˴������¸�����չ��
			strFileName = strFileName + strExt;
		
		if (_taccess(m_szPicFile, 0) != -1)
			CopyFile(m_szPicFile, strFileName, TRUE);
	}
	
}

// ���ⲿ�����ͼƬ
void CPicShowDlg::OnPicOpen()
{
	//	if (m_nState != PIC_LOADED) // ȥ�������������load failure��ʱ��Ҳ���Բ鿴
	//		return;
	
	//code.Format(_T("import os\\r\\nos.startfile(r\"%s\")"), m_szPicFile);
	// code�ﲻ�ܼӻ��У������������
	// exec "import os
	// os.startfile(...)"
	// code.Format(_T("import os\\r\\nos.startfile(r\"%s\")"), m_szPicFile); // ��������
	// code.Format(_T("import os\r\nos.startfile(r\"%s\")"), m_szPicFile); // ����Ҳ����
	
	if (m_nState != PIC_START && m_nState != PIC_DOWNLOAD && !m_szPicFile.IsEmpty()) {
		OpenFile(m_szPicFile);
		ShowWindow(SW_HIDE);
	}
}

void CPicShowDlg::OnPicClose()
{
	ShowWindow(SW_HIDE);
	
	if (m_nDisplaySize == 1 || m_nDisplaySize == 2) {	// ȫ��->����
		m_nDisplaySize = 0;
		//		m_bFixed = false;
		UINT oldshowCmd = m_wpPrev.showCmd;
		m_wpPrev.showCmd = SW_HIDE;
		SetWindowPlacement(&m_wpPrev);
		m_wpPrev.showCmd = oldshowCmd;
	}
}

void CPicShowDlg::DelPic(void)
{
	// ɾ����ǰͼƬ Ŀǰֻ���б���ɾ����Ӳ���ļ���ɾ
	if (m_picit != g_PicList.end() && g_PicList.size() >= 1) {
		m_nState = m_pic->State();
		
		if (m_nState != PIC_START && m_nState != PIC_DOWNLOAD) {
			extern CCriticalSection g_csPicture;
			g_csPicture.Lock();
			delete m_pic;
			m_picit = g_PicList.erase(m_picit);
			{
				if (m_picit == g_PicList.end()) {
					if (g_PicList.size() > 0) {
						// �ǿ�
						m_picit = g_PicList.begin();
						
						if (m_nDisplaySize != 0) {
							// ȫ��, Ҫ�ҵ�һ������ʾ��
							PicState st = PIC_FAILURE;
							
							for (PicIt it = g_PicList.begin(); it != g_PicList.end(); ++it) {
								st = (*it)->State();
								
								if (st == PIC_SUCCESS || st == PIC_LOADED) {
									m_picit = it;
									break;
								}
							}
							
							if (st != PIC_SUCCESS && st != PIC_LOADED) {
								// û�п���ʾ��
								m_nDisplaySize = 0;
							}
						}
					} else {
						// ��
						m_picit = g_PicList.end();
					}
				}
				
				// else valid
			}
			
			if (m_picit != g_PicList.end()) {
				m_pic = *m_picit;
				m_nState = m_pic->State();
				
				if (m_nState == PIC_LOADED) m_nState = m_pic->Setstate(PIC_SUCCESS); // reload
				
				m_szPicFile = m_pic->strLocal;
			} else {
				m_pic = NULL;
				m_nState = PIC_WRONG;
				m_szPicFile.Empty();
				//m_pic
			}
			
			g_csPicture.Unlock();
			
			DrawPicture(m_nState);
		}
	}
}

//***********************************************************************
//DEL void CPicShowDlg::OnRButtonUp(UINT nFlags, CPoint point)
//DEL {
//DEL 	CDialog::OnRButtonUp(nFlags, point);
//DEL }

BOOL CPicShowDlg::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	if (zDelta > 0)
		OnPicPrev();
	else
		OnPicNext();
	
	return CDialog::OnMouseWheel(nFlags, zDelta, pt);
}

HBRUSH CPicShowDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	switch (nCtlColor) {
		
	case CTLCOLOR_STATIC:
		
	case CTLCOLOR_MSGBOX:
		
	case CTLCOLOR_DLG :
		
	case CTLCOLOR_EDIT: {
		pDC->SetBkMode(TRANSPARENT);
		pDC->SetTextColor(RGB(255, 255, 255));	//���壺��ɫ
		return m_hbrush;
		break;
						}
		
	default:
		return m_hbrush;
	}
	
	// ���Ϸ����������ڰ�ť
}

BOOL CPicShowDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}

	// �޸�Ϊʹ�����¼�ͷ��ҳ�����Ҽ�ͷ�ر�
	if (pMsg->message == WM_KEYDOWN) {
		switch (pMsg->wParam) {
			
		case 'L': // last
		case 'P': // previous
		case VK_BACK:
		case VK_PRIOR: // PGUP
		case VK_NUMPAD9:
		case VK_UP:
			OnPicPrev();
			break;
			
		case 'N': // next
		case VK_SPACE:
		case VK_NEXT: // PGDN
		case VK_NUMPAD3:
		case VK_DOWN:
			OnPicNext();
			break;
			
		case 'S': // save
		case VK_NUMPAD0:
		case VK_INSERT:
			OnPicSave();
			break;
			
		case 'O': // open
		case '8': // *
		case VK_MULTIPLY:
			OnPicOpen();
			break;
			
		case 191: // '/'
		case VK_DIVIDE:
			OnPicZoom();
			break;
			
		case VK_RETURN:
		case VK_ADD:
		case 187: // ������+
			OnPicMax();
			break;
			
		case 'R': // redownload
			
		case 'I': // info
			OnPicExif();
			break;
			
		case VK_HOME: // home
			if (isdown(VK_CONTROL)) {
				MovePicture(m_rcPic.Width(), 0);
			} else {
				MovePicture(0, m_rcPic.Height());
			}
			
			break;
			
		case VK_END: // end
			
			if (isdown(VK_CONTROL)) {
				MovePicture(-m_rcPic.Width(), 0);
			} else {
				MovePicture(0, -m_rcPic.Height());
			}
			
			break;
			
/*		case VK_UP:
			if (isdown(VK_CONTROL)) {
				MovePicture(0, 5 * PIC_MOVE_STEP);
			} else {
				MovePicture(0, PIC_MOVE_STEP);   // *  ( HIWORD( pMsg->lParam ) ) count,  ������
			}
			
			break;
			
		case VK_DOWN:
			
			if (isdown(VK_CONTROL)) {
				MovePicture(0, -5 * PIC_MOVE_STEP);
			} else {
				MovePicture(0, -PIC_MOVE_STEP);
			}
			
			break;
			
		case VK_LEFT:
			
			if (isdown(VK_CONTROL)) {
				MovePicture(5 * PIC_MOVE_STEP, 0);
			} else {
				MovePicture(PIC_MOVE_STEP, 0);
			}
			
			break;
			
		case VK_RIGHT:
			if (isdown(VK_CONTROL)) {
				MovePicture(-5 * PIC_MOVE_STEP, 0);
			} else {
				MovePicture(-PIC_MOVE_STEP, 0);
			}
			break;
*/			
		case 'C':
			CopyURL();
			break;

		case VK_LEFT:
		case VK_RIGHT:
		case 'X': // exit
		case 220: // ������|\:
			OnCancel();
			break;
			
		case 'D': // delete
		case VK_DELETE:
			DelPic();
			break;
			
		default:
			return CDialog::PreTranslateMessage(pMsg);
		}
		
		m_bPicMoving = false;
		
		return TRUE; //translated
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CPicShowDlg::ShowPicture(void)
{
	// ��Ҫ�����, ��ǰ��������ؽϴ�ʱ, ������˸
	//	ShowWindow(SW_SHOWNORMAL);
	
	//	m_bFixed = false;
	DrawPicture(m_nState, false);
}

LRESULT CPicShowDlg::OnNcHitTest(CPoint point)
{
	UINT ret = CDialog::OnNcHitTest(point);
	
	if (ret == HTCLIENT)   //Ϊ���϶����ڵ���Ҫ�����ĳ���HTCAPTION���˺���Ӧ�����Ϣ����Ҫ����NC
		ret = HTCAPTION;
	
	return ret;
}

//DEL void CPicShowDlg::OnLButtonDown(UINT nFlags, CPoint point)
//DEL {
//DEL 	CDialog::OnLButtonDown(nFlags, point);
//DEL //TRACE(_T("enter CPicShowDlg::OnLButtonDown"));
//DEL 	//ȷ��Ҫ�϶�,�����������
//DEL 	//�������250ms����ΪҪ�϶�
//DEL /*	Sleep(250);
//DEL 	MSG msg;
//DEL 	::PeekMessage(
//DEL 		&msg,
//DEL 		GetSafeHwnd(),
//DEL 		WM_LBUTTONUP,
//DEL 		WM_LBUTTONUP,
//DEL 		PM_NOREMOVE
//DEL 		);
//DEL
//DEL TRACE(_T("in CPicShowDlg::OnLButtonDown: message: %d\n"), msg.message);
//DEL 	//click,���
//DEL 	if( msg.message==WM_LBUTTONUP )
//DEL 	{
//DEL 		m_bDraging=false;
//DEL 		OnPicMax();
//DEL 	}
//DEL 	else
//DEL 	{
//DEL 		m_bDraging=true;
//DEL 		CDialog::OnLButtonDown(nFlags, point);
//DEL 	}
//DEL TRACE(_T("leave CPicShowDlg::OnLButtonDown"));*/
//DEL }

void CPicShowDlg::OnNcLButtonDown(UINT nHitTest, CPoint point)
{
	//ȷ��Ҫ�϶�,�����������
	//�������250ms����ΪҪ�϶�
	//	Sleep ( 250 );
	//	MSG msg;
	//	::PeekMessage (
	//		&msg,
	//		GetSafeHwnd(),
	//		WM_NCLBUTTONUP,
	//		WM_LBUTTONUP,
	//		PM_NOREMOVE
	//		);
	//	//click,���
	//	if ( msg.message == WM_NCLBUTTONUP )
	//	{
	//		OnPicMax();
	//	}
	//	else
	{
		//SetCursor ( AfxGetApp()->LoadCursor ( IDC_MYHAND ) );
		m_lastmovept = point;
		m_bLeftDown = true;
		//TRACE(_T(" CPicShowDlg::OnNcLButtonDown() m_bLeftDown %d\n"), m_bLeftDown);
		CDialog::OnNcLButtonDown(nHitTest, point);
	}
	
	CDialog::OnNcLButtonDown(nHitTest, point);
}

void CPicShowDlg::OnTimer(UINT nIDEvent)
{
	// TIMER_LOADPIC
	
	//	MessageBox("picture loading timeout!");
	// kill the loading thread
	if (m_hLoadPicThread) {
		TerminateThread(m_hLoadPicThread, -1);
		m_hLoadPicThread = NULL;
		m_bLoading = false;
		m_nState = m_LoadingPic->Setstate(PIC_FAILURE, 7);
		//TRACEF("PIC_FAILURE 6\n");
		PostMessage(WM_PICTURE, (WPARAM)m_LoadingPic, (LPARAM) FLAG_PIC_LOAD);
	}
	
	KillTimer(TIMER_LOADPIC);
	
	CDialog::OnTimer(nIDEvent);
}

void CPicShowDlg::OnCancel()
{
	OnPicClose();
	CDialog::OnCancel();
}

void CPicShowDlg::OnPicZoom()
{
	TogglePic(2);
}

void CPicShowDlg::MovePicture(int offsetx, int offsety)
{
	if (m_nDisplaySize != 2 || m_nState != PIC_LOADED) return;
	
	CRect scnRect;
	
	GetWindowRect(&scnRect);
	
	// ����������static�Ļ�, ��Ļ�ֱ��ʸı�����ô��?
	int frameWidth = scnRect.Width(), frameHeight = scnRect.Height() - winoffset;
	
	CRect oldrc = m_rcPic;
	
	if (m_rcPic.Width() > frameWidth && offsetx != 0) {
		if (offsetx > 0) {   //left
			if (m_rcPic.left < 0) {
				m_rcPic.left += offsetx;
				m_rcPic.right += offsetx;
				
				if (m_rcPic.left > 0) {
					m_rcPic.right -= m_rcPic.left;
					m_rcPic.left = 0;
				}
			}
		}
		else {
			//right
			if (m_rcPic.right > frameWidth) {
				m_rcPic.left += offsetx;
				m_rcPic.right += offsetx;
				
				if (m_rcPic.right < frameWidth) {
					m_rcPic.left += frameWidth - m_rcPic.right;
					m_rcPic.right = frameWidth;
				}
			}
		}
	}
	
	if (m_rcPic.Height() > frameHeight && offsety != 0) {
		int H = m_rcPic.Height();
		
		if (offsety > 0) {   //up
			if (m_rcPic.top < winoffset) {
				m_rcPic.top += offsety;
				//				m_rcPic.bottom += offsety;
				
				if (m_rcPic.top > winoffset) {
					m_rcPic.top = winoffset;
					//m_rcPic.bottom -= m_rcPic.top;
				}
				
				m_rcPic.bottom = m_rcPic.top + H;
			}
		} else { //down
			if (m_rcPic.bottom > frameHeight + winoffset) {
				//m_rcPic.top += offsety;
				m_rcPic.bottom += offsety;
				
				if (m_rcPic.bottom < frameHeight + winoffset) {
					m_rcPic.bottom = frameHeight + winoffset;
					//m_rcPic.top += frameHeight  + winoffset - m_rcPic.bottom;
				}
				
				m_rcPic.top = m_rcPic.bottom - H;
			}
		}
	}
	
	// ����һ��
	//	m_rcPic.top += winoffset;
	//	m_rcPic.bottom += winoffset;
	
	if (m_rcPic != oldrc) {
		m_bPicMoving = true;
		DrawPicture(PIC_LOADED, false);
	}
}

void CPicShowDlg::OnNcLButtonUp(UINT nHitTest, CPoint point)
{
	SetCursor(AfxGetApp()->LoadCursor(IDC_ARROW));
//	TRACEF("IDC_ARROW 6\r\n");
	
	m_bLeftDown = false;
	//TRACE(_T(" CPicShowDlg::OnNcLButtonUp() m_bLeftDown %d \n"), m_bLeftDown);
	
	if (m_bPicMoving) {
		if (! g_bPicDrag) {
			CPoint offset = point - m_lastmovept;
			MovePicture(offset.x, offset.y);
		}
		
		m_bPicMoving = false;
	}
	else {
		OnPicMax();
	}
	
	CDialog ::OnNcLButtonUp(nHitTest, point);
}

void CPicShowDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	//TRACE( _T( " CPicShowDlg::OnMouseMove() m_bLeftDown %d \n" ), m_bLeftDown);
	if (m_bLeftDown && point != m_lastmovept && m_nDisplaySize == 2 && m_nState == PIC_LOADED) {   //draging
		SetCursor(AfxGetApp()->LoadCursor(IDC_MYHAND));
		m_bPicMoving = true;
		
		if (g_bPicDrag) {
			CPoint offset = point - m_lastmovept;
			MovePicture(offset.x, offset.y);
			m_lastmovept = point;
		}
	}
	else {
		//m_lastmovept = point;
		CDialog ::OnMouseMove(nFlags, point);
	}
}

void CPicShowDlg::OnNcRButtonDown(UINT nHitTest, CPoint point)
{
	CMenu menu, *pmenu = NULL;
	menu.LoadMenu(IDR_PICDLG_MENU);
#if ENABLE_MULTILANG
	
	if (g_currLangID != ID_LANG1) {
		g_OutMenuStrings(&menu, _T(""));      //����Ĭ��
		g_SetMenuStrings(&menu, _T(""));
	}
	
#endif// ENABLE_MULTILANG
	pmenu = (CMenu *) menu.GetSubMenu(0);
	
	//point: ��Ļ����
	//ClientToScreen( &point );//��䲻��Ҫ
	CPoint pt;
	GetCursorPos(&pt);
	
	//pmenu->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	pmenu->TrackPopupMenu(TPM_LEFTALIGN, pt.x, pt.y, this); // �ⷽ����򵥣�
	
	pmenu->DestroyMenu();
	
	CDialog::OnNcRButtonDown(nHitTest, point);
}

BOOL CPicShowDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	//	TRACE( _T( "m_bPicMoving=%d\n" ), m_bPicMoving );
	if (!m_bPicMoving)
		return CDialog ::OnSetCursor(pWnd, nHitTest, message);
	else
		return FALSE;
}

void CPicShowDlg::OnPicExif()
{
	if (m_pic == NULL) {
		return; //wrong
	}
	
	// m_nState == m_pic->State()���ܲ�����
	m_nState = m_pic->State();
	
#if ENABLE_PYTHON
	if (g_bEnablePython && g_bSysPythonScriptLoaded &&
		(m_nState == PIC_SUCCESS || m_nState == PIC_LOADED)) {
		ASSERT(!m_szPicFile.IsEmpty());
		CString code;
		code.Format(_T("ImgExif(r\"%s\")"), m_szPicFile);
		code.Replace("\\", "\\\\");
		RunPythonCode(code);
	} else
#endif //ENABLE_PYTHON
		if (m_nState == PIC_FAILURE) {
			//m_szPicFile.IsEmpty() ���ܲ��գ�����load����
			//������ֵġ���ʱ���󣡡�
			ReDownloadPic(m_pic);//��������
			m_nState = m_pic->State();
			DrawPicture(m_nState, false);
		}
}

void CPicShowDlg::CopyURL(void)
{
#define MAX_URL 300
	bool b = false;
	
	if (m_pic != NULL && !m_pic->strURL.IsEmpty()) {
		
		if (HGLOBAL hmem = GlobalAlloc(GMEM_FIXED,  MAX_URL + 2)) {
			if (TCHAR *p = (TCHAR *) GlobalLock(hmem)) {
				_tcsncpy(p, m_pic->strURL.LockBuffer(), MAX_URL);
				m_pic->strURL.UnlockBuffer();
				
				if (OpenClipboard()) {
					EmptyClipboard();
#ifdef _UNICODE
#define CF CF_UNICODETEXT
#else
#define CF CF_TEXT
#endif
					SetClipboardData(CF, hmem);
					CloseClipboard();
					b = true;
				} else {
					TRACE(_T("ERROR: Cannot open the Clipboard!"));
				}
			}
			
			GlobalUnlock(hmem);
		} else {
			CloseClipboard();
			TRACE(_T("ERROR: Cannot open the Clipboard!"));
		}
	}
	
	if (m_picex && m_nState == PIC_LOADED)
		m_picex->SetPicText(b ? _T("url copied") : _T("copy url failed"));
	else {
		GetDlgItem(IDC_NUM)->SetWindowText(b ? _T("url copied") : _T("copy url failed"));
	}
}

void CPicShowDlg::SetBgColor()
{
	int r = 0, g = 0, b = 0;//RGB(100, 100, 100);
	sscanf(g_sPicDlgColor.LockBuffer(), "%2x%2x%2x", &r, &g, &b);
	m_bg = RGB(r, g, b);
	g_sPicDlgColor.UnlockBuffer();
	m_hbrush = CreateSolidBrush(m_bg);
}

void CPicShowDlg::fixWinPos(POINT &LTpt, const CRect &mainrect, const bool bFixed
							, const int width, const int height) const
{
	if (m_nDisplaySize == 0) {
		if (!bFixed) {   //������
			if (LTpt.x > mainrect.Width() / 2) {
				//������Ұ�ߣ��ұ߽��������
				LTpt.x -= width - 1;// -1ʹ���λ��ͼƬ�ڲ�
			}
			
			if (LTpt.y > mainrect.Height() / 2) {
				//������²����±߽��������
				LTpt.y -= height - 5 - 1;// -1ʹ���λ��ͼƬ�ڲ�
			}
		}
		
		//Խ�����
		if (m_nState == PIC_LOADED) {
			//TRACE(_T("in DrawPicture \t before adjust: %d,%d,%d,%d\n"),rw.left,rw.top,rw.right,rw.bottom);
			//TRACE(_T("\t before adjust main: %d,%d,%d,%d\n"),mainrect.left,mainrect.top,mainrect.right,mainrect.bottom);
			int delta = LTpt.y + height - mainrect.bottom;
			
			if (delta > 0) {
				//TRACE(_T("\t 1: %d\n"), delta);
				LTpt.y -= delta + 10;
			}
			
			delta = mainrect.top - LTpt.y;
			
			if (delta > 0) {
				//TRACE(_T("\t 2: %d\n"), delta);
				LTpt.y += delta + 10;
			}
			
			delta = LTpt.x + width - mainrect.right;
			
			if (delta > 0) {
				//TRACE(_T("\t 3: %d\n"), delta);
				LTpt.x -= delta + 10;
			}
			
			delta = mainrect.left - LTpt.x;
			
			if (delta > 0) {
				//TRACE(_T("\t 4: %d\n"), delta);
				LTpt.x += delta + 10;
			}
			
			//TRACE(_T("in DrawPicture \t after adjust: %d,%d,%d,%d\n"),rw.left,rw.top,rw.right,rw.bottom);
			//		GetParent()->ScreenToClient(&LTpt);
		}
	}
}

void CPicShowDlg::OnPicOpenpath() 
{
	OpenFile(g_PicPath);
}
#endif //ENABLE_PICTURE


