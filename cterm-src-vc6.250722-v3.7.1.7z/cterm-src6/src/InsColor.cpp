// InsColor.cpp : implementation file
//

#include "stdafx.h"
#include "cterm.h"
#include "InsColor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

void AddEscByAttr(SOneChar &CF, const SOneChar &Char, TCHAR *buf, int &nLen, const TCHAR *pESCChar);
/////////////////////////////////////////////////////////////////////////////
// CInsColor dialog


CInsColor::CInsColor(CWnd* pParent /*=NULL*/)
	: CMyPropertyPage(GetIDD())
{
	//{{AFX_DATA_INIT(CInsColor)
	m_blink = FALSE;
	m_hilight = FALSE;
	m_underline = FALSE;
	m_reverse = FALSE;
	//}}AFX_DATA_INIT
}


void CInsColor::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInsColor)
	DDX_Control(pDX, IDC_PREVIEW, m_preview);
	DDX_Control(pDX, IDC_COMBO2, m_bc);
	DDX_Control(pDX, IDC_COMBO1, m_fc);
	DDX_Check(pDX, IDC_CHECK1, m_blink);
	DDX_Check(pDX, IDC_CHECK2, m_hilight);
	DDX_Check(pDX, IDC_CHECK3, m_underline);
	DDX_Check(pDX, IDC_CHECK4, m_reverse);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInsColor, CMyPropertyPage)
	//{{AFX_MSG_MAP(CInsColor)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO2, OnSelchangeCombo2)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1)
	ON_BN_CLICKED(IDC_CHECK2, OnCheck2)
	ON_BN_CLICKED(IDC_CHECK3, OnCheck3)
	ON_BN_CLICKED(IDC_CHECK4, OnCheck4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInsColor message handlers
UINT CInsColor::GetIDD()
{
	return IDD;
}

CString CInsColor::GetStr()
{
	UpdateChar();
	TCHAR buf[100];
	int len = 0;
	AddEscByAttr(m_cf, m_c, buf, len, _T("\x1b"));// ӦΪm_pEscChar
	buf[len] = '\0';
	m_cf = m_c;
	return CString(buf);
}

void CInsColor::UpdateChar()
{
	UpdateData();
	int bc = m_bc.GetCurSel();
	int fc = m_fc.GetCurSel();
	m_c.SetBC(bc);
	m_c.SetFC(fc);
	m_c.SetBlink(m_blink);
	m_c.SetHilight(m_hilight);
	m_c.SetUnderline(m_hilight);
	m_c.SetReverse(m_reverse);
}

BOOL CInsColor::OnInitDialog() 
{
	CMyPropertyPage::OnInitDialog();
	
	m_fc.SetCurSel(7);
	m_bc.SetCurSel(0);
	preview();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

COLORREF  colorset[16] = {
		RGB(0, 0, 0),
		RGB(128, 0, 0),
		RGB(0, 128, 0),
		RGB(128, 128, 0),
		RGB(0, 0, 128),
		RGB(128, 0, 128),
		RGB(0, 128, 128),
		RGB(192, 192, 192),
		RGB(128, 128, 128),
		RGB(255, 0, 0),
		RGB(0, 255, 0),
		RGB(255, 255, 0),
		RGB(0, 0, 255),
		RGB(255, 0, 255),
		RGB(0, 255, 255),
		RGB(255, 255, 255)
};

void CInsColor::preview()
{
//	CDC *pDC = m_preview.GetDC();
//	CRect rect;
//	m_preview.GetClientRect(&rect);
//	pDC->FillSolidRect(&rect, colorset[bc]);
//	m_preview.ReleaseDC(pDC);
	UpdateChar();

	int bc, fc;
	m_c.GetColor(fc, bc);
	m_preview.SetColor(CButtonST::BTNST_COLOR_BK_OUT, colorset[bc]);
	m_preview.SetColor(CButtonST::BTNST_COLOR_FG_OUT, colorset[fc]);	  // ��ͨ״̬ʱ��ǰ��ɫ
	m_preview.SetColor(CButtonST::BTNST_COLOR_BK_IN, colorset[bc]);	  // �����ڰ�ť��ʱ�ı���ɫ
	m_preview.SetColor(CButtonST::BTNST_COLOR_FG_IN, colorset[fc]);	  // �����ڰ�ť��ʱ��ǰ��ɫ
	m_preview.SetColor(CButtonST::BTNST_COLOR_BK_FOCUS, colorset[bc]);  // ��ť��ý���ʱ�ı���ɫ
	m_preview.SetColor(CButtonST::BTNST_COLOR_FG_FOCUS, colorset[fc]);  // ��ť��ý���ʱ��ǰ��ɫ
}

void CInsColor::OnSelchangeCombo1() 
{
	preview();
}

void CInsColor::OnSelchangeCombo2() 
{
	preview();
}

void CInsColor::OnCheck1() 
{
	preview();
}

void CInsColor::OnCheck2() 
{
	preview();	
}

void CInsColor::OnCheck3() 
{
	preview();	
}

void CInsColor::OnCheck4() 
{
	preview();	
}
