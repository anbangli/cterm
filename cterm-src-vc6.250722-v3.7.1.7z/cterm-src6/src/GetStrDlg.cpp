// GetStrDlg.cpp : implementation file
// ������ʱ����һ�仰������ ChatDlg���á�

#include "stdafx.h"
#include "GetStrDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGetStrDlg dialog


CGetStrDlg::CGetStrDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CGetStrDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetStrDlg)
	m_input = _T("");
	//}}AFX_DATA_INIT
}


void CGetStrDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetStrDlg)
	DDX_Text(pDX, IDC_INPUT, m_input);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetStrDlg, CDialog)
	//{{AFX_MSG_MAP(CGetStrDlg)
	ON_EN_CHANGE(IDC_INPUT, OnChangeInput)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetStrDlg message handlers

void CGetStrDlg::OnChangeInput()
{
	UpdateData();
}
