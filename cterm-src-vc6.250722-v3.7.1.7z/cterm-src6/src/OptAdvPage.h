#if !defined(AFX_OPTADVPAGE_H__B1FA4D3B_C72A_4851_9C30_1FA36BB13DA4__INCLUDED_)
#define AFX_OPTADVPAGE_H__B1FA4D3B_C72A_4851_9C30_1FA36BB13DA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptAdvPage.h : header file
//

#include "MyPropertyPage.h"
#include "TreeOptionsCtrlEx.h"
/////////////////////////////////////////////////////////////////////////////
// COptAdvPage dialog

class COptAdvPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptAdvPage)

// Construction
public:
	COptAdvPage();
	~COptAdvPage();
	virtual UINT GetIDD();

	// Dialog Data
	//{{AFX_DATA(COptAdvPage)
	enum { IDD = IDD_OPT_ADV };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

	bool m_bRepeatUserName;
	bool m_bURLNoMouse;
	bool m_bHideMouse;
	bool m_bSiteStatus;
	bool m_bCaptureMouse;
	bool m_bRefreshTitle;
	bool m_bChildDefaultMax;
	bool m_bAutoSize;
	bool m_bCacheHistory;
	bool m_bIsAutoReply;
	bool m_bNoAskClose;
	bool m_bPythonLog;
	bool m_bAnsiLog;
	bool m_bReportSimple;
	BOOL m_bEnableVBS;
	bool m_bAltShowMenu;
	bool m_bCaptionButtons;
	bool m_bClickUser;
	int m_nKeybarWidth;
	int m_nKeybarHeight;
	int m_nFixedSysSize;
	int m_nCharScale;
	int m_nRowSpace;
	bool m_TA_CENTER;
	CString m_sEFont;
	CString m_sFont;
	bool m_bMONOSPACE;
	bool m_bFixFont;
	int m_nFixFontSize;
	int m_nBoldWeight;
	bool m_bSelectStay;
	bool m_bSelBackHi;
	bool m_bSelAntiHalf;
	bool m_bEnableM;
	bool m_bFullScreenBar;
	bool m_bCursorPos;
	bool m_bTransparent;
	int m_nAlpha;
//	bool m_bCtrlVPaste;
//	bool m_bCopyUni;
//	bool m_bPasteUni;
	bool m_bCopyNoReturn;
	int m_nWrapLen;
	bool m_bCopyRectNoReturn;
	bool m_bAutoSaveEdit;
	bool m_bEditIME;
	int m_nEditFontSize;
//	int	m_nCloseIME;
	bool m_bIMEChar;
	int m_gbCharSet;
	int m_big5CharSet;
	bool m_bPasteConfirm;
	bool m_bFilterQueryIP;
	bool m_bAutoFromIP;
	bool m_bBakAutoIP;
	int  m_nPicHoverTime;
	int  m_nPicLoadTimeOut;
	bool m_bPicDrag;
	bool m_bLoadPicThread;
	CString m_sPicDlgColor;
	CString m_PicPath;
	bool m_bGetPicInfo;
	bool m_bDelPicAsk;
	int	 m_nPicTimeOut;
	bool m_bPicTip;
	bool m_bPicNoBorder;
	bool m_bPicHide;
	bool m_bAutoRetryPic;
	CString m_sUrlProg;
	CString m_sFtpProg;
	int  m_nDownProg;
	bool m_bPythonOpenFile;
	CString m_sPlink;
	CString m_sLoginFlag;
	CString m_sLoginFlag1;
	bool m_bUrlWithConfirm;
	bool m_bURLStrip;
	bool m_bViewDrag;
	bool m_bAutoURLHeader;
	int m_nBlinkTimeOut;
	int m_nCaretStyle;
	int m_nCARET_H;
	int m_nCARET_W;
	bool m_bCaretCenter;
	bool m_bCaretBlink;
	bool m_bUploadAttAuto;
	CString m_sKeyTableFile;
	CString m_sScriptDir;
	CString m_sMailWavFile;
	bool m_bAllowSameSiteName;
	bool m_bAddrFullName;
	CString m_sArticleSaveExt;
	int m_iAskDlg;
	int m_nDownTimeout;
	bool m_bCtdDraw;
//	bool m_bDrawByString;
	int m_nRecvBufLen;
	int m_nBossKeyStyle;
	int m_nControlPort;
	bool m_bNoFocusNoCursor;
	bool m_bDownloadWithHTML;
	bool m_bRegBBSProto;
	int m_nTimer;
//	CString m_sHotKey;
	bool m_bPicDlgInfo;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptAdvPage)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(COptAdvPage)
	afx_msg LRESULT OnTreeOptsCtrlNotify(WPARAM wParam, LPARAM lParam);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void Init();
	void UnInit();

	CTreeOptionsCtrlEx m_ctrlTreeOptions;
	bool m_bInitializedTreeOpts;

	// groups
	HTREEITEM	m_htiFontGrp;
	HTREEITEM	m_htiPicGrp;
	HTREEITEM	m_htiCaretGrp;
	HTREEITEM	m_htiTxtGrp;
	HTREEITEM	m_htiUrlGrp;
	HTREEITEM	m_htiViewGrp;
	HTREEITEM	m_hTermGrp;
	
	HTREEITEM	m_htiRepeatUserName;
	HTREEITEM	m_htiURLNoMouse;
	HTREEITEM	m_htiHideMouse;
	HTREEITEM	m_htiSiteStatus;
	HTREEITEM	m_htiCaptureMouse;
	HTREEITEM	m_htiRefreshTitle;
	HTREEITEM	m_htiChildDefaultMax;
	HTREEITEM	m_htiAutoSize;
	HTREEITEM	m_htiCacheHistory;
	HTREEITEM	m_htiIsAutoReply;
	HTREEITEM	m_htiNoAskClose;
	HTREEITEM	m_htiPythonLog;
	HTREEITEM	m_htiAnsiLog;
	HTREEITEM	m_htiReportSimple;
	HTREEITEM	m_htiEnableVBS;
	HTREEITEM	m_htiAltShowMenu;
	HTREEITEM	m_htiCaptionButtons;
	HTREEITEM	m_htiClickUser;
	HTREEITEM	m_htiKeybarWidth;
	HTREEITEM	m_htiKeybarHeight;
	HTREEITEM	m_htiFixedSysSize;
	HTREEITEM	m_htiCharScale;
	HTREEITEM	m_htiRowSpace;
	HTREEITEM	m_htiTA_CENTER;
	HTREEITEM	m_htiEFont;
	HTREEITEM	m_htiFont;
	HTREEITEM	m_htiMONOSPACE;
	HTREEITEM	m_htiFixFont;
	HTREEITEM	m_htiFixFontSize;

	HTREEITEM	m_htiBoldWeight;
	HTREEITEM	m_htiBoldWeight0;
	HTREEITEM	m_htiBoldWeight1;
	HTREEITEM	m_htiBoldWeight2;
	HTREEITEM	m_htiBoldWeight3;
	HTREEITEM	m_htiBoldWeight4;
	HTREEITEM	m_htiBoldWeight5;
	HTREEITEM	m_htiBoldWeight6;
	HTREEITEM	m_htiBoldWeight7;
	HTREEITEM	m_htiBoldWeight8;
	HTREEITEM	m_htiBoldWeight9;

	HTREEITEM	m_htiSelectStay;
	HTREEITEM	m_htiSelBackHi;
	HTREEITEM	m_htiSelAntiHalf;
	HTREEITEM	m_htiEnableM;
	HTREEITEM	m_htiFullScreenBar;
	HTREEITEM	m_htiCursorPos;
	HTREEITEM	m_htiTransparent;
	HTREEITEM	m_htiAlpha;
	HTREEITEM	m_htiCtrlVPaste;
//	HTREEITEM	m_htiCopyUni;
//	HTREEITEM	m_htiPasteUni;
	HTREEITEM	m_htiCopyNoReturn;
	HTREEITEM	m_htiWrapLen;
	HTREEITEM	m_htiCopyRectNoReturn;
	HTREEITEM	m_htiAutoSaveEdit;
	HTREEITEM	m_htiEditIME;
	HTREEITEM	m_htiEditFontSize;
//	HTREEITEM	m_htiCloseIME;
	HTREEITEM	m_htiIMEChar;

	HTREEITEM	m_htigbCharSet;
	HTREEITEM	m_htigbCharSet0;
	HTREEITEM	m_htigbCharSet1;
	HTREEITEM	m_htigbCharSet2;
	HTREEITEM	m_htigbCharSet6;
	HTREEITEM	m_htigbCharSet7;

	HTREEITEM	m_htibig5CharSet;
	HTREEITEM	m_htibig5CharSet0;
	HTREEITEM	m_htibig5CharSet1;
	HTREEITEM	m_htibig5CharSet2;
	HTREEITEM	m_htibig5CharSet6;
	HTREEITEM	m_htibig5CharSet7;

	HTREEITEM	m_htiPasteConfirm;
	HTREEITEM	m_htiFilterQueryIP;
	HTREEITEM	m_htiAutoFromIP;
	HTREEITEM	m_htiBakAutoIP;
	HTREEITEM	m_htiPicHoverTime;
	HTREEITEM	m_htiPicLoadTimeOut;
	HTREEITEM	m_htiPicDrag;
	HTREEITEM	m_htiLoadPicThread;
	HTREEITEM	m_htiPicDlgColor;
	HTREEITEM	m_htiPicPath;
	HTREEITEM	m_htiGetPicInfo;
	HTREEITEM	m_htiDelPicAsk;
	HTREEITEM	m_htiPicTimeOut;
	HTREEITEM	m_htiPicTip;
	HTREEITEM	m_htiPicNoBorder;
	HTREEITEM	m_htiPicHide;
	HTREEITEM	m_htiAutoRetryPic;
	HTREEITEM	m_htiUrlProg;
	HTREEITEM	m_htiFtpProg;
	HTREEITEM	m_htiDownProg;
	HTREEITEM	m_htiPythonOpenFile;
	HTREEITEM	m_htiPlink;
	HTREEITEM	m_htiLoginFlag;
	HTREEITEM	m_htiLoginFlag1;
	HTREEITEM	m_htiUrlWithConfirm;
	HTREEITEM	m_htiURLStrip;
	HTREEITEM	m_htiViewDrag;
	HTREEITEM	m_htiAutoURLHeader;
	HTREEITEM	m_htiBlinkTimeOut;

	HTREEITEM	m_htiCaretStyle;
	HTREEITEM	m_htiCaretStyle0;
	HTREEITEM	m_htiCaretStyle1;
	HTREEITEM	m_htiCaretStyle2;
	HTREEITEM	m_htiCaretStyle3;
	HTREEITEM	m_htiCaretStyle4;

	HTREEITEM	m_htiCARET_H;
	HTREEITEM	m_htiCARET_W;
	HTREEITEM	m_htiCaretCenter;
	HTREEITEM	m_htiCaretBlink;
	HTREEITEM	m_htiHttpUploadDlg;
	HTREEITEM	m_htiKeyTableFile;
	HTREEITEM	m_htiScriptDir;
	//HTREEITEM	m_htiMailWavFile;
	HTREEITEM	m_htiAllowSameSiteName;
	HTREEITEM	m_htiAddrFullName;
	HTREEITEM	m_htiArticleSaveExt;

	HTREEITEM	m_htiAskDlg;
	HTREEITEM	m_htiAskDlg0;
	HTREEITEM	m_htiAskDlg1;
	HTREEITEM	m_htiAskDlg2;
	HTREEITEM	m_htiAskDlg3;
	HTREEITEM	m_htiAskDlg4;
	HTREEITEM	m_htiAskDlg5;
	
	HTREEITEM	m_htiDownTimeout;
	HTREEITEM	m_htiCtdDraw;
	HTREEITEM	m_htiDrawByString;
	HTREEITEM	m_htiRecvBufLen;
	HTREEITEM	m_htiBossKeyStyle;
	HTREEITEM	m_htiBossKeyStyle0;
	HTREEITEM	m_htiBossKeyStyle1;
	HTREEITEM	m_htiControlPort;
	HTREEITEM	m_htiNoFocusNoCursor;
	HTREEITEM	m_htiDownloadWithHTML;
	HTREEITEM	m_htiRegBBSProto;
	HTREEITEM	m_htiTimer;
	HTREEITEM	m_htiHotKey;
	HTREEITEM	m_htiPicDlgInfo;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTADVPAGE_H__B1FA4D3B_C72A_4851_9C30_1FA36BB13DA4__INCLUDED_)
