#if !defined(AFX_ASKDLG_H__EAA65DB0_2E1C_4EB0_ABA3_9691D518F5F5__INCLUDED_)
#define AFX_ASKDLG_H__EAA65DB0_2E1C_4EB0_ABA3_9691D518F5F5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AskDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAskDlg dialog

class CAskDlg : public CDialog
{
// Construction

public:
	BOOL m_bDigest;
	CAskDlg(CWnd* pParent = NULL);   // standard constructor

	// m_nType=0 PopStatus
	// m_nType=1 m_Run.EnterNextStage(_T(" "),1,SST_ARTICLE,DDS_COPY);
	// m_nType=2 m_Run.ChangeStatus(DDS_SEARCH_NEXT);
	//����Ϊ��CDLDigestDlg��ĺ���
	//��CDLListDlg���������У���֣���
// Dialog Data
	//{{AFX_DATA(CAskDlg)
	enum { IDD = IDD_ASKDLG };
	CComboBox	m_list;
	int		m_nType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAskDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CAskDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASKDLG_H__EAA65DB0_2E1C_4EB0_ABA3_9691D518F5F5__INCLUDED_)
