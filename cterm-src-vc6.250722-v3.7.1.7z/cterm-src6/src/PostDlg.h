#if !defined(AFX_INPUTDLG_H__9565394A_BD3A_48CD_B640_238E1E304BE3__INCLUDED_)
#define AFX_INPUTDLG_H__9565394A_BD3A_48CD_B640_238E1E304BE3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InputDlg.h : header file
//

#include <afxmt.h>
#include "webbrowser2.h"	// Added by ClassView

#define WM_STATUS_CHANGED		WM_USER + 5		// �ϴ�״̬֪ͨ��Ϣ
#define WM_TRAYICON_MESSAGE		WM_USER + 6		// ������Ϣ

/////////////////////////////////////////////////////////////////////////////
// CPostDlg dialog

class CPostDlg : public CDialog
{
// Construction

public:
	TCHAR sUrl[256];
	CPostDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPostDlg)
	enum { IDD = IDD_EDIT_POST };
	CListBox	m_listStatus;
	CString	m_inputline;
	int		m_quote;
	int		m_qmd;
	BOOL	m_reply;
	int		m_nLiveTime;
	BOOL	m_bContinuously;
	CString	m_strBoardName;
	CString	m_strSiteName;
	CString	m_strLocalFile;
	CString	m_strUserName;
	CString	m_strPassWord;
	CString	m_strDescription;
	BOOL	m_bUploadAtt;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPostDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	int m_nMaxWidth;
	void AddStringToListBox(CString &strItem);
	// Generated message map functions
	//{{AFX_MSG(CPostDlg)
	virtual void OnOK();
	afx_msg void OnBrowse();
	afx_msg LRESULT OnStatusChanged(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT OnNotifyFunc(WPARAM wParam, LPARAM lParam);
	afx_msg void OnOneByOne();
	virtual BOOL OnInitDialog();
	afx_msg void OnUpload();
	afx_msg void OnClose();
	virtual void OnCancel();
	afx_msg void OnUploadAllow();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	BOOL m_bUploadAllow;
	CString m_strUploadURLs;
	BOOL			m_bThreadExit;					// �˳���־
	CWinThread 		*m_thdUpload;					// �����߳�ID
	CEvent			m_eventExit;					// �߳��˳��¼�
	CString			m_strInfo;						// �ϴ���״̬��Ϣ
	BOOL			m_bSucceed;						// �ϴ��Ƿ�ɹ�
	CStringArray	m_astrFilesUpload;				// ��Ҫ�ϴ����ļ��б�
	CStringArray	m_astrFilesDelete;				// ��Ҫɾ�����ļ��б�
	BOOL			m_bUpload;						// ���ϴ��ļ�����ɾ���ļ�
	void			ThreadExit();					// �߳��˳���

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INPUTDLG_H__9565394A_BD3A_48CD_B640_238E1E304BE3__INCLUDED_)
