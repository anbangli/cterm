// HTMLConvert.h: interface for the CHTMLConvert class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_HTMLCONVERT_H__D7CF29F1_BD1D_40CF_8BC2_B760CCF7D76A__INCLUDED_)
#define AFX_HTMLCONVERT_H__D7CF29F1_BD1D_40CF_8BC2_B760CCF7D76A__INCLUDED_
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "onechar.h"

class CCTermCore;
class CCTermView;
class AFX_CLASS_EXPORT CHTMLConvert
{

public:
	//ע�ⲻҪֱ�Ӷ���CHTMLConvert����Ϊ��ʹ�ÿ�ָ��m_pCore��Σ�գ�Ҫ��new CHTMLConvert(pCore)����ʽ
	//CHTMLConvert();
	CHTMLConvert(CCTermCore *pCore);
	virtual ~CHTMLConvert();

	BOOL Create(TCHAR *szFile, int nFileAt, CCTermCore *pCore);
	BOOL Create(const CString & szPath, TCHAR *szSite, TCHAR *szProfile, TCHAR *szTitle, BOOL bTemp = TRUE, BOOL bIndex = TRUE);

	TCHAR *GetTitle();
	int GetFileAt();
	void AddLine(TCHAR *szLine);
	int ScreenToHTML(TCHAR *buf, int nStart = 0, int nEnd = -1);
	void AddScreen(BOOL bLast = FALSE);
	void AddLines(int start, int end = -1);

	CString m_szFile;
	const CCTermCore *m_pCore;
	const CCTermView *m_pView;
	SOneChar m_CF;

	static  COLORREF  colorset[16];

private:
	BOOL m_bTemp;
	TCHAR(*m_LastScreen)[40];
	BOOL ChangeBkColor(const SOneChar &now, const SOneChar &New, TCHAR *buf);
	BOOL IsSameAttr(const SOneChar &a, const SOneChar &b);
	BOOL ChangeAttr(const SOneChar &old, const SOneChar &New, TCHAR *buf);
	void WriteEnd(FILE *);
	TCHAR m_szProfile[100];
	TCHAR m_szTitle[100];
	int  m_nFileAt;
	void WriteHead(FILE *, BOOL);
	TCHAR m_szSite[100];
};

#endif // !defined(AFX_HTMLCONVERT_H__D7CF29F1_BD1D_40CF_8BC2_B760CCF7D76A__INCLUDED_)
