// MultiLang.h : main header file for the MULTILANGUAGE application
//

#if !defined(AFX_MULTILANG_H__1FA8EA4E_14F0_43D6_905B_882C8922AD22__INCLUDED_)
#define AFX_MULTILANGUAGE_H__1FA8EA4E_14F0_43D6_905B_882C8922AD22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

extern CString g_szLanguagePath;
extern CString g_defaultLangPath;
extern CString g_szSettingPath;
extern CString g_langStr[];
extern int g_currLangID;

TCHAR ExtractName(CString& str);
void AddMenuAccessKey(CString& menuName, TCHAR key);
CString g_LoadString(UINT id);

#ifdef _DEBUG
void g_OutDialogStrings(CDialog *pDlg, UINT uDlgID);
#endif

BOOL g_OutMenuStrings(CMenu* pMenu, CString subKey);
BOOL g_SetMenuStrings(CMenu* pMenu, CString subKey);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MULTILANG_H__1FA8EA4E_14F0_43D6_905B_882C8922AD22__INCLUDED_)
