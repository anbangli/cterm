// Graph.cpp: implementation of the CGraph class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#if ENABLE_GRAPH

#include "Graph.h"
#include "const.h"
#include "ctermview.h"
#include "telnetsite.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraph::CGraph()
{
	Reset();
}

CGraph::~CGraph()
{

}

void CGraph::Reset()
{
	m_nNum = 0;
}

void CGraph::AddSeq(const TCHAR *szSeq, int x, int y)
{
	SGCommand Command;
	int nAt = 0;

	if (m_nNum >= 10) return;  //Full

	/* //��������������term�йأ������ʳ�Ա������û�а취�����Է�Χ�������ɵ����߸���
		//���ô��룺m_Graph.AddSeq(Seq.m_szExtend,m_cursor.x,m_cursor.y);
		//Ӧ�ò��ᳬ��term size��
	  if(x>(MAX_TERM_WIDTH-1))
		  x=(MAX_TERM_WIDTH-1);
	  if(y>(MAX_TERM_HEIGHT-1))
		  y=(MAX_TERM_HEIGHT-1);
		  */
	Seq[m_nNum].x = x;

	Seq[m_nNum].y = y;

	Seq[m_nNum].nCommand = 0;

	while (GetCommand(szSeq, nAt, Command) && Seq[m_nNum].nCommand < 30) {
		memcpy(&Seq[m_nNum].Command[Seq[m_nNum].nCommand], &Command, sizeof(SGCommand));
		Seq[m_nNum].nCommand++;
	}

	if (Seq[m_nNum].nCommand)
		m_nNum++;
}

void CGraph::DeleteSeq(int x0, int y0, int x1, int y1)
{
	int i, j;

	for (i = 0;i < m_nNum;i++) {
		if (Seq[i].x >= x0 && Seq[i].x <= x1
		        && Seq[i].y >= y0 && Seq[i].y <= y1) {
			for (j = i;j < m_nNum - 1;j++) {
				memcpy(&Seq[j], &Seq[j+1], sizeof(SGraphSeq));
			}

			m_nNum--;

			i--;
		}
	}
}

BOOL CGraph::GetCommand(const TCHAR *szSeq, int &nAt, SGCommand &Command)
{
	const TCHAR *p = szSeq + nAt;
#define MAX_COMMAND 256

	if (_tcslen(p) < 6) return FALSE;

	//�ҵ���1���ǿո��ַ�
	while (*p && (*p == ' ' || *p == '\r' || *p == '\n')) {
		p++;
		nAt++;
	}

	if (!*p) return FALSE;   //ȫ�ո�

	int  n = 0;
	TCHAR szCom[MAX_COMMAND] = _T("");

	BOOL bInStr = FALSE;

	while (*p && n < MAX_COMMAND - 1 && *p != '\r' && *p != '\n' && (*p != ' ' || (*p == ' ' && bInStr))) {
		szCom[n] = *p;

		if (*p == '\"')   //�ַ�����Ŀո�
			bInStr = !bInStr;

		n++;

		p++;

		nAt++;
	}

	szCom[n] = 0;

	if (n < 4) return FALSE;

	return GetParam(szCom, Command);
}


BOOL CGraph::GetParam(TCHAR *szCom, SGCommand &Com)
{
	TCHAR szHead[10], ts[80+3];//DEFAULT_TERM_WIDTH?
	int  n = 0;
	TCHAR *p = szCom;

	while (*p && *p != '(' && n < 9) {
		szHead[n] = *p;
		p++;
		n++;
	}

	BOOL ret = TRUE;

	do { //once
		if (n >= 9) {
			ret = FALSE;
			break;
		}

		if (!*p) {
			ret = FALSE;
			break;
		}

		szHead[n] = 0;

		n = 0;
		Com.nType = 255;

		if (!_tcsicmp(szHead, _T("L")))
			Com.nType = GCT_LINE;

		if (!_tcsicmp(szHead, _T("P")))
			Com.nType = GCT_POINT;

		if (!_tcsicmp(szHead, _T("O")))
			Com.nType = GCT_ROUND;

		if (!_tcsicmp(szHead, _T("R")))
			Com.nType = GCT_RECT;

		if (!_tcsicmp(szHead, _T("A")))
			Com.nType = GCT_ARC;

		if (!_tcsicmp(szHead, _T("FO")))
			Com.nType = GCT_F_ROUND;

		if (!_tcsicmp(szHead, _T("FR")))
			Com.nType = GCT_F_RECT;

		if (!_tcsicmp(szHead, _T("FA")))
			Com.nType = GCT_F_ARC;

		if (!_tcsicmp(szHead, _T("T")))
			Com.nType = GCT_TEXT;

		if (!_tcsicmp(szHead, _T("SFC")))
			Com.nType = GCT_SFC;

		if (!_tcsicmp(szHead, _T("SBC")))
			Com.nType = GCT_SBC;

		if (!_tcsicmp(szHead, _T("SLW")))
			Com.nType = GCT_SLW;

		if (!_tcsicmp(szHead, _T("ST")))
			Com.nType = GCT_ST;

		if (!_tcsicmp(szHead, _T("SM")))
			Com.nType = GCT_SM;

		if (!_tcsicmp(szHead, _T("RS")))
			Com.nType = GCT_RESET;

		if (Com.nType == 255) {
			ret = FALSE;
			break;
		}

		p++;

		if (_tcslen(p) < 2 && Com.nType != GCT_RESET) {
			ret = FALSE;
			break;
		}

		Com.nParam = 0;

		Com.szText[0] = 0;

		do {
			n = 0;

			while (*p && *p != ',' && *p != ')' && n < 82) {
				ts[n] = *p;
				n++;
				p++;
			}

			ts[n] = 0;

			if (n >= (80 + 2)) {
				ret = FALSE;  //DEFAULT_TERM_WIDTH?
				break;
			}

			if (ts[0] != '\"') {
				if (_tcslen(ts) > 5) {
					ret = FALSE;
					break;
				}

				Com.snParam[Com.nParam] = _ttoi(ts);

				Com.nParam++;

				if (Com.nParam >= 6) {
					ret = FALSE;
					break;
				}
			} else {
				//Text
				if (ts[n-1] == '\"') ts[n-1] = 0;

				_tcscpy(Com.szText, ts + 1);
			}

			if (*p == ',') *p++;
		} while (*p && *p != ')');

		switch (Com.nType) {

		case GCT_LINE:

			if (Com.nParam < 4) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_POINT:

			if (Com.nParam < 2) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_F_ROUND:

		case GCT_ROUND:

			if (Com.nParam < 4) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_ARC:

		case GCT_F_ARC:

			if (Com.nParam < 5) {
				ret = FALSE;
				break;
			}

			Com.snParam[3] = 360 - Com.snParam[3];

			Com.snParam[4] = 360 - Com.snParam[4];
			break;

		case GCT_RECT:

		case GCT_F_RECT:

			if (Com.nParam < 4) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_TEXT:

			if (Com.nParam < 2 || !_tcslen(Com.szText)) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_SBC:

		case GCT_SFC:

			if (Com.nParam < 3) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_SLW:

		case GCT_SM:

			if (!Com.nParam) {
				ret = FALSE;
				break;
			}

			break;

		case GCT_ST:

			if (Com.nParam < 2 || !_tcslen(Com.szText)) {
				ret = FALSE;
				break;
			}

			break;
		}
	} while (0);

	return ret;
}

void CGraph::Scroll(int nLine)
{
	// -nline
	int i;

	for (i = 0;i < m_nNum;i++) {
		Seq[i].y -= nLine;
	}

	DeleteSeq(0, -100, 255, -1);

	DeleteSeq(0, MAX_TERM_HEIGHT, 255, 100);    //��MAX_TERM_HEIGHT����������
}


/******************************************************************************
Graph ͼ�λ���
******************************************************************************/
void SGraphSet::Init(const CTelnetSite *pSite, int nFontSize, const CCTermView *pView)
{
	m_pView = pView;
	fc = pSite->m_Decode.m_ColorSet[15];
	bc = pSite->m_Decode.m_ColorSet[0];
	m_font = m_pView->Font();
	bXOR = FALSE;
	bTextTrans = FALSE;
	nWidth = 1;
	Pen.CreatePen(PS_SOLID, nWidth, fc);
	Font.CreateFont(nFontSize, 0, 0, 0, 0x190, 0, 0, 0, 0x86, 3, 2, 1, 2, m_font);
	Brush.CreateSolidBrush(bc);
}

SGraphSet::~SGraphSet()
{
	Pen.DeleteObject();
	Font.DeleteObject();
	Brush.DeleteObject();
}

void SGraphSet::SetFColor(const SGCommand *pCommand, CDC *pDC)		// ǰ��ɫ
{
	CPen *pOld;
	fc = RGB(pCommand->snParam[0],
	         pCommand->snParam[1],
	         pCommand->snParam[2]);
	pDC->SetTextColor(fc);
	Pen.DeleteObject();
	Pen.CreatePen(PS_SOLID, nWidth, fc);
	pOld = pDC->SelectObject(&Pen);

	if (pOld) pOld->DeleteObject();
}

void SGraphSet::SetBkColor(const SGCommand *pCommand, CDC *pDC)		// ����ɫ
{
	CBrush *pOld;
	bc = RGB(pCommand->snParam[0],
	         pCommand->snParam[1],
	         pCommand->snParam[2]);
	pDC->SetBkColor(bc);
	Brush.DeleteObject();
	Brush.CreateSolidBrush(bc);
	pOld = pDC->SelectObject(&Brush);

	if (pOld) pOld->DeleteObject();
}

void SGraphSet::SetFont(const SGCommand *pCommand, CDC *pDC, int nSize)	// ��������
{
	int nFontSize;
	CFont *pOld;
	Font.DeleteObject();
	m_font = pCommand->szText;
	nFontSize = pCommand->snParam[0] * nSize / 10;

	if (nFontSize > m_pView->TermW())
		nFontSize = m_pView->TermW();

	if (!nFontSize) nFontSize = 4;

	bTextTrans = pCommand->snParam[1];

	Font.CreateFont(nFontSize, 0, 0, 0, 0x190, 0, 0, 0, (m_font[0] < 0) ? 0x86 : 0, 3, 2, 1, 2, m_font);

	pOld = pDC->SelectObject(&Font);

	if (pOld) pOld->DeleteObject();
}

void SGraphSet::Reset(CDC *pDC, const CTelnetSite *pSite, int nSize)
{
	fc = pSite->m_Decode.m_ColorSet[15];
	bc = pSite->m_Decode.m_ColorSet[0];
	m_font = m_pView->Font();
	bXOR = FALSE;
	bTextTrans = FALSE;
	nWidth = 1;
	Pen.DeleteObject();
	Pen.CreatePen(PS_SOLID, nWidth, fc);
	Font.DeleteObject();
	Font.CreateFont(nSize, 0, 0, 0, 0x190, 0, 0, 0, (m_font[0] < 0) ? 0x86 : 0, 3, 2, 1, 2, m_font);
	Brush.DeleteObject();
	Brush.CreateSolidBrush(bc);

	CPen *pOldPen = pDC->SelectObject(&Pen);

	if (pOldPen) pOldPen->DeleteObject();

	pDC->SetTextColor(fc);

	pDC->SetBkColor(bc);

	CBrush *pOldBrush = pDC->SelectObject(&Brush);

	if (pOldBrush) pOldBrush->DeleteObject();

	CFont *pOldFont = pDC->SelectObject(&Font);

	if (pOldFont) pOldFont->DeleteObject();
}

#endif//ENABLE_GRAPH
