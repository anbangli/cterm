#if !defined(AFX_GETSTRDLG_H__C94445D8_95E0_439D_8668_BA2F239AA9A0__INCLUDED_)
#define AFX_GETSTRDLG_H__C94445D8_95E0_439D_8668_BA2F239AA9A0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GetStrDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGetStrDlg dialog

class CGetStrDlg : public CDialog
{
// Construction

public:
	CGetStrDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGetStrDlg)
	enum { IDD = IDD_GETSTRDLG };
	CString	m_input;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGetStrDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CGetStrDlg)
	afx_msg void OnChangeInput();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GETSTRDLG_H__C94445D8_95E0_439D_8668_BA2F239AA9A0__INCLUDED_)
