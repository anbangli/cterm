// CTermView.cpp : implementation file
// ������غ���

#include "stdafx.h"
#include "ctermview.h"
#include "paramconfig.h"
#include "usermsg.h"
#include "global.h"
#include "debugtool.h"
#include "mainfrm.h"
#include "forcode.h"

#ifdef _DEBUG
#include "global.h"
extern CCTermView *g_pView;
#endif

extern int g_nConnectionType;

void CCTermView::ReConnect()
{
	if (m_Sock.m_bStarted) {
		return;
	}

	m_nStartLine = 0;

	if (isdown(VK_SHIFT)) {
		m_Site.m_Login.m_bAutoLogin = !m_Site.m_Login.m_bAutoLogin;
	}

	if (isdown(VK_CONTROL)) {
		m_Site.m_Login.m_bSSH = !m_Site.m_Login.m_bSSH;

		if (isSSH())
			m_Site.m_Login.m_nPort = SSH_PORT;
		else
			m_Site.m_Login.m_nPort = TELNET_PORT;
	}

#if ENABLE_FILTER
	m_Site.m_Login.m_AutoLogin.Restore(); // �������������Ӻ��ǻᶯ̬�ı�ģ���Ҫrestore
#endif//ENABLE_FILTER

	if (isSSH()) {
#if ENABLE_PIPESSH
		KillPlinkProcess();
#endif//ENABLE_PIPESSH
	}

	//ASSERT(m_Sock.m_hSocket == INVALID_SOCKET);
	if (m_Sock.m_hSocket != INVALID_SOCKET) return; //have created

	InitConnect();
}

void CCTermView::InitConnect()
{
	m_Core.Init();
	m_More.m_pCore = &m_Core;
	m_Status.Init(&m_Core, &m_Site);

	AddStart(); // ���ӿ��ܱȽϷ�ʱ�䣬����AddStart��ǰ�棬�����Եÿ�
	m_Core.SetTermType(m_Site.m_Decode.m_nType);// Ҫ��AddStart()֮�󣬷���������նˣ�link��ʾ����

	if (isSSH()) {
#if ENABLE_PIPESSH
		ConnectTheSiteSSH(); // ssh���ӣ��������̣��ܵ��ȣ�
#endif//ENABLE_PIPESSH
	}
	else {
		ConnectTheSite();
	}
}

// ��ʼ����վ��
void CCTermView::Navigator()
{
	//TRACEF(_T ("%d: connecting ...\r\n"), m_nSessionID);

	//	TRACE(_T("%d: connecting ...\r\n"), m_nSessionID);

	LoadSiteInfo();

	m_Sock.m_nHostPort = m_Site.m_Login.m_nPort;
	m_Sock.m_strHostAddress = m_Site.m_Login.m_szAddr;

	m_Sock.m_nTermWidth = m_nTermWidth;
	m_Sock.m_nTermHeight = m_nTermHeight;
	m_Sock.m_sTermType = m_sTermType;

#if ENABLE_PROXY
	m_Sock.SetProxy(&m_Site.m_Login);
#endif//ENABLE_PROXY

	InitConnect();

	m_bInited = true;

#if ENABLE_EDITBOX
	m_EditDlg.SetWindowText(m_Site.m_Login.m_szProfileName);
#endif//ENABLE_EDITBOX

#ifdef _DEBUG
	g_pView = this;
#endif//_DEBUG
}

void CCTermView::ConnectTheSite()
{
	bool bSockCreated = false;

	if (m_bIPV6) {
#if ENABLE_IPV6

		if (m_Sock.CreateV6(m_Sock.m_strHostAddress, m_Sock.m_nHostPort,
		                    SOCK_STREAM, FD_READ | FD_WRITE | FD_CLOSE | FD_CONNECT | FD_OOB)) {
			bSockCreated = true;
//			CString info;
//			info.Format(_T("Network initialization Error%d!"), GetLastError());
//			AfxMessageBox(info);
			//MessageBox (_T ("Network initialization Error!"), _T ("Error!"));	// ��ʼ���������!
//			return;
		}

#endif//ENABLE_IPV6
	}
	else if (m_Sock.Create()) {
		bSockCreated = true;
	}
	
	if (!bSockCreated) {
		m_Sock.OnConnectError(GetLastError());
		return;
	}

	if (m_Sock.m_bProxy) {
#if ENABLE_PROXY
		m_Sock.ConnectTo();
#endif//ENABLE_PROXY
	}
	else {
		if (m_bIPV6) {
#if ENABLE_IPV6
			m_Sock.ConnectEx(m_Sock.m_pAI);
#endif//ENABLE_IPV6
		}
		else {
			m_Sock.AsyncSelect(FD_READ | FD_WRITE | FD_CLOSE | FD_CONNECT | FD_OOB);
			//m_Sock.Connect(m_Site.m_Login.m_szAddr,m_Site.m_Login.m_nPort);
			m_Sock.StartConnect2();
		}
	}
}

TCHAR ESC_Char[3][3] = { _T("\x1b"), _T("\x1b\x1b"), _T("\x15") };

// �������ĵ�ַ����
// ��Щ������Ϊ���ࣺ���Զ�̬�ı�ģ��Ͳ����Զ�̬�ı��
void CCTermView::LoadSiteInfo(bool bAll)
{
	if (bAll) {
		m_nTermWidth = m_Site.GetVarInt(_T("TermWidth"), g_nTermWidth);
		m_nTermHeight = m_Site.GetVarInt(_T("TermHeight"), g_nTermHeight);

		ValidateWH(m_nTermWidth, m_nTermHeight);

		m_Site.GetVarString(_T("TermType"), _T("vt100"), m_sTermType, 20);

		m_bIPV6 = m_Site.GetVarInt(_T("IsIPv6"), 0);

		m_nMaxHistLine = m_Site.GetVarInt(_T("MaxHistLine"),
		                                  (SiteType() == ST_NORMAL) ? MAX_HIST_LINE : m_nTermHeight);

		if (m_nMaxHistLine < m_nTermHeight) m_nMaxHistLine = m_nTermHeight;

		m_nESCChar = m_Site.GetVarInt(_T("ESCChar"), 0);

		if (m_nESCChar > 2 || m_nESCChar < 0) m_nESCChar = 0;

		m_pESCChar = ESC_Char[m_nESCChar];

#if ENABLE_FILTER
	m_Site.m_Login.m_AutoLogin.Restore();
	m_Site.m_Login.m_AutoLogin.pLoginSet = &m_Site.m_Login;
#endif//ENABLE_FILTER
	}

	//���ϲ��ܶ�̬�ı�
	////////////////////////////////////////////////////

	// ������Щ���Զ�̬�ı�(bAll=true/false)����Ҫ��Ч��Ҫִ���ض��Ĳ���������SetViewFont()
	m_Site.GetVarString(_T("EFont"), "Courier New", m_eFont, MAXFONTNAME);

	m_Site.GetVarString(_T("Font"),
	                    g_sFont.IsEmpty() ? m_Site.m_Decode.m_szFont : g_sFont,
	                    m_font, MAXFONTNAME);

	if (m_font.IsEmpty()) m_font = _T("SimSun");

	//m_nCharHWRatio = m_Site.GetVarInt(_T("CharHWRatio"), g_nCharHWRatio);
	m_nCharHWRatio = 2; // ����������߱ȵ���

	m_bMONOSPACE = m_Site.GetVarInt(_T("MONOSPACE"), g_bMONOSPACE);
	m_bBold = m_Site.GetVarInt (_T("BOLD"), 0);

	m_nFixFontSize = m_Site.GetVarInt(_T("FixFontSize"), g_nFixFontSize);

	m_bFixFont = m_Site.GetVarInt(_T("FixFont"), g_bFixFont);

	m_bBsIsDel = m_Site.GetVarInt(_T("BsIsDel"), SiteType() == ST_NORMAL);
	m_bDelAsStop = m_Site.GetVarInt(_T("DelAsStop"), FALSE);

#if ENABLE_ATTACH
	m_bHttpUpload = m_Site.GetVarInt(_T("HttpUpload"), 0);
#endif//ENABLE_ATTACH
	
	m_bBlackList = m_Site.GetVarInt(_T("bBlackList"), 0);	// �Ƿ����ú�����
	m_Site.GetVarString(_T("BlackList"), _T(""), m_szBlackList, 1024);	// ������
	
	//ǰ������пո񣬲���ʵ���û�����ǰ�󶼴��ո񣩵ľ�ȷƥ��
	if (!m_szBlackList.IsEmpty()) {
		if (m_szBlackList[0] != ' ') {
			CString s = ' ';
			m_szBlackList = s + m_szBlackList;
		}
		
		if (m_szBlackList[m_szBlackList.GetLength() - 1] != ' ') {
			m_szBlackList += ' ';
		}
	}

	// ��ַ���ڲ�����
	//m_nSiteType = SiteType();
	m_szReturnChar[0] = m_Site.m_Decode.m_bEnterAsReturn ? '\r' : '\n'; //���²���
	m_bSSHbbsLogin = m_Site.GetVarInt(_T("SSHbbs"), false);
	m_Site.GetVarString(_T("AntiIdleStr"), _T(""), m_sAntiIdleStr, 1024);
}

// WM_DNSRESOLVED
// DNS�����ɹ����
// ִ�����Ӷ���
LRESULT CCTermView::OnDNSResolved(WPARAM wParam, LPARAM lParam)
{
//TRACEFINTS(_T ("%d: DNS resolved ...\r\n"), m_nSessionID);
	//TRACE(_T("%d: DNS resolved ...\r\n"), m_nSessionID);

	if (wParam) {
		m_Sock.OnConnectError(wParam, "��ַ����ʧ��");
		return 0;
	} else {
		return m_Sock.ConnectNow2();
	}
}

#if ENABLE_COPYTCP
// ����TCP��
void CCTermView::CopyTcpPack(BOOL bTRUE, CString szFile)
{
	if (m_nCtdFile) return;

	m_Sock.CopyTcpPack(bTRUE, szFile);

	return;
}
#endif//ENABLE_COPYTCP

#if ENABLE_PIPESSH
#define ErrorExit(s) \
	do {\
	TRACE(s); return;\
	} while (0)

void CCTermView::KillPlinkProcess()
{
	if (m_plink_pinfo.hProcess != NULL) {
		m_bPipeOpen = false;

		if (m_hPipeReader != NULL) {
			DWORD threadExitCode = 0;
			GetExitCodeThread(m_hPipeReader, &threadExitCode);

			if (threadExitCode == STILL_ACTIVE) {
				TerminateThread(m_hPipeReader, 0);
			}

			CloseHandle(m_hPipeReader);

			m_hPipeReader = NULL;
		}

		DWORD exitcode;

		GetExitCodeProcess(m_plink_pinfo.hProcess, &exitcode);

		if (exitcode == STILL_ACTIVE) {
			TerminateProcess(m_plink_pinfo.hProcess, 0);
		}

		if (m_plink_pinfo.hProcess != NULL) CloseHandle(m_plink_pinfo.hProcess);

		if (m_plink_pinfo.hThread != NULL) CloseHandle(m_plink_pinfo.hThread);

		m_plink_pinfo.hProcess = NULL;

		m_plink_pinfo.dwProcessId = 0;

		m_plink_pinfo.dwThreadId = 0;

		m_plink_pinfo.hThread = NULL;
	}
}

//�̺߳���
unsigned __stdcall PipeReaderFunc(void *arg)
{
	CCTermView *pto = (CCTermView *) arg;
	
	ASSERT(pto);
	
	pto->DoPipeRead();

	return 0;
}

// ��PipeReaderFunc�е��ã���ʵ�ʵĹ���
void CCTermView::DoPipeRead()
{
	const int &dwRead = m_Sock.m_nLen;
	const int &buflen = m_Sock.m_nRecvBufLen - 1;
	DWORD exitcode = -386;
	
	//TRACE(_T("in PipeReaderFunc 1\n"));
	
	while (m_bPipeOpen) {
		//TRACE(_T("in PipeReaderFunc 2\n"));
		if (m_plink_pinfo.hProcess != NULL) {
			GetExitCodeProcess(m_plink_pinfo.hProcess, &exitcode);
			//TRACE(_T("in PipeReaderFunc 3\n"));
			
			if (exitcode != STILL_ACTIVE) {
				//TRACE(_T("in PipeReaderFunc 4\n"));
				
				break;
			}
			
			ASSERT(m_hChildStdoutRdDup != INVALID_HANDLE_VALUE
				&& m_hChildStdinWrDup != INVALID_HANDLE_VALUE);
			
			if (m_Sock.buf_in == NULL) {
#if ENABLE_BUF_QUEUE
				m_Sock.buf_in = m_Sock.m_bufpool.getBuf();
#else
				m_Sock.buf_in = new BYTE[m_Sock.m_nRecvBufLen];
#endif//ENABLE_BUF_QUEUE
			}
			
			m_Sock.m_pBuf = m_Sock.buf_in;
			BYTE *buf = m_Sock.m_pBuf;
			ASSERT(buf);
			
			if (buf) {
				//TRACE(_T("in PipeReaderFunc 5\n"));
				if (ReadFile(m_hChildStdoutRdDup, buf, buflen, (DWORD *)&dwRead, NULL) == 0
					|| dwRead == 0) {
					//TRACE(_T("in PipeReaderFunc 6\n"));
					break;
				}
				
				buf[dwRead] = '\0';
				//TRACE(_T("in PipeReaderFunc 7\n"));
				
				SendMessage(WM_PIPE_DATA, WPARAM(0), LPARAM(0));
			}//if (buf)
		}
	}//while
	
	//TRACE(_T("in PipeReaderFunc 8\n"));
	
	SendMessage(WM_PIPE_DATA, WPARAM(1), LPARAM(0));
}

// ���plink����
// ��while������״̬�Ƿ�STILL_ACTIVE��Ч�������ǵ����ٶȱ�ü���
// �� WaitForSingleObject
unsigned __stdcall PlinkWatcherFunc(void *arg)
{
        CCTermView *pto = (CCTermView *) arg;
        ASSERT(pto);

        if (pto) {
			if (!pto->PipeOpen() || pto->PlinkProcess() == NULL) {
                Sleep(2000);
			}
			
			if (pto->PipeOpen() || pto->PlinkProcess() != NULL) {
                WaitForSingleObject(pto->PlinkProcess(), INFINITE);
                SendMessage(pto->GetSafeHwnd(), WM_PIPE_DATA, WPARAM(1), LPARAM(0));
			}
		}

        return 0;
}

#include <process.h>

BOOL CCTermView::StartPipeReader()
{
        unsigned tid;
        m_hPipeReader = (HANDLE) _beginthreadex(NULL,
                                                0,
                                                PipeReaderFunc,
                                                (LPVOID) this,
                                                0,
                                                &tid);
        return TRUE;
}

#include "UserPassDlg.h"
extern CTelnetSite g_LastSite;
int GetSSHUserPass(CTelnetSite *pSite, CString &user, CString &pass, int &nPassTry)
{
//	if (pSite->m_Login.m_bAutoLogin) {
//		user = pSite->m_Login.m_szLoginName;
//		pass = pSite->m_Login.m_szLoginPSW;
//	}

	int ret = 0; // 0: OK, 1: Cancel, 2: Abort
	// ����� ��������Ч
	if ((nPassTry > 0 && nPassTry < 100)
	|| (nPassTry == 0 && (user.IsEmpty() || pass.IsEmpty()))) {
		CUserPassDlg dlg(NULL, pSite);
		dlg.m_user = user;
		dlg.m_pass = pass;
		dlg.m_nPassTry = nPassTry;

		if (dlg.DoModal() == IDOK) {
			user = dlg.m_user;
			pass = dlg.m_pass;

			// ���Զ���ssh��˵�������¼��һ��
			// �����Ƿ�ѡ��savesite
			// ������ȡ��user/pass�浽g_lastsite�������augologin
			pSite->SetAutoLogin(user, pass);
			g_LastSite.SetAutoLogin(user, pass);
		}
		else {
			if (dlg.m_nPassTry >= 100) {
				ret = 2;
			} else {
				ret = 1;
			}
		}

		if (dlg.m_nPassTry >= 100) {
			nPassTry = dlg.m_nPassTry;
		}
	} else if (nPassTry >= 100) {
		ret = 2;
	}

	return ret;
}

static int puttyProxyType(ProxyType t)
{
	int r = 0; //PT_NONE
	switch(t) {
	case PT_TELNET:
		r = 4;
		break;
	case PT_SOCK4:
		r = 1;
		break;
	case PT_SOCK5:
		r = 2;
		break;
	case PT_HTTP:
		r = 3;
		break;
	}

	return r;
}

bool CCTermView::CreatePlinkProcess(LPSTARTUPINFO si)
{
#define CTERM_PLINK_SESSION _T("CTermSession")
	do {
		// HKEY_CURRENT_USER\Software\SimonTatham\PuTTY\Sessions\Default%20Settings
//		LONG Ret = 0;
		HKEY hKey, hKey1, hKey2, hKey3, hKey4;

		if (RegCreateKey(HKEY_CURRENT_USER, _T("Software"), &hKey) != ERROR_SUCCESS)
			break;

		if (RegCreateKey(hKey, _T("SimonTatham"), &hKey1) != ERROR_SUCCESS)
			break;

		if (RegCreateKey(hKey1, _T("PuTTY"), &hKey2) != ERROR_SUCCESS)
			break;

		if (RegCreateKey(hKey2, _T("Sessions"), &hKey3) != ERROR_SUCCESS)
			break;

		if (RegCreateKey(hKey3, CTERM_PLINK_SESSION, &hKey4) != ERROR_SUCCESS)  //CTERM_PLINK_SESSION
			break;

		RegSetValueEx(hKey4,
		              _T("HostName"),
		              0,
		              REG_SZ,
		              (LPBYTE) m_Site.m_Login.m_szAddr,
		              strlen(m_Site.m_Login.m_szAddr));

		char prot[] = "ssh";

		RegSetValueEx(hKey4,
		              _T("Protocol"),
		              0,
		              REG_SZ,
		              (LPBYTE) prot,
		              sizeof(prot));

		RegSetValueEx(hKey4,
		              _T("PortNumber"),
		              0,
		              REG_DWORD,
		              (LPBYTE) &m_Site.m_Login.m_nPort,
		              sizeof(m_Site.m_Login.m_nPort));

		RegSetValueEx(hKey4,
		              _T("TerminalType"),
		              0,
		              REG_SZ,
		              (LPBYTE) m_sTermType.LockBuffer(),
		              m_sTermType.GetLength());

		m_sTermType.UnlockBuffer();

		// ��������ʱ����Ҫ�û���...
		// ��ע����������û��������Ա������"login as"����ʾ
		if (m_Site.m_Login.m_bAutoLogin) {
			if (m_bSSHbbsLogin) {
				m_user = m_pass = _T("bbs"); // ptt��sshҪ��bbs:bbs��¼
			}
			else {
				// �����������m_user/pass��Ϊ�գ�����Ҫ��ȡ��
				if (m_user.IsEmpty()) m_user = m_Site.m_Login.m_szLoginName;
				if (m_pass.IsEmpty()) m_pass = m_Site.m_Login.m_szLoginPSW;
			}
		}

		if (!m_user.IsEmpty()) {
			//m_Site.m_Login.m_bAutoLogin
			RegSetValueEx(hKey4,
			              _T("UserName"),
			              0,
			              REG_SZ,
			              (LPBYTE) m_user.LockBuffer(),
			              m_user.GetLength());
			m_user.UnlockBuffer();
		}
		else {
			RegDeleteValue(hKey4, _T("UserName"));
		}

		DWORD TermHeight = m_nTermHeight, TermWidth = m_nTermWidth;

		if (RegSetValueEx(hKey4,
		                  _T("TermWidth"),
		                  0,
		                  REG_DWORD,
		                  (LPBYTE) &TermWidth,
		                  sizeof(TermHeight)) != ERROR_SUCCESS ||
		        RegSetValueEx(hKey4,
		                      _T("TermHeight"),
		                      0,
		                      REG_DWORD,
		                      (LPBYTE) &TermHeight,
		                      sizeof(TermHeight)) != ERROR_SUCCESS) {
			m_nTermWidth = DEFAULT_TERM_WIDTH;
			m_nTermHeight = DEFAULT_TERM_HEIGHT;
		}

#if ENABLE_PROXY
		// ���ô���
		if (m_Sock.m_bProxy && m_Sock.m_ProxyType != PT_NONE) {
			RegSetValueEx(hKey4,
				_T("ProxyHost"),
				0,
				REG_SZ,
				(LPBYTE) m_Sock.m_ProxyAddr,
				strlen(m_Sock.m_ProxyAddr));

			RegSetValueEx(hKey4,
		              _T("ProxyPort"),
		              0,
		              REG_DWORD,
		              (LPBYTE) &m_Sock.m_nProxyPort,
		              sizeof(m_Sock.m_nProxyPort));

			int ntype = puttyProxyType(m_Sock.m_ProxyType);
			RegSetValueEx(hKey4,
		              _T("ProxyMethod"),
		              0,
		              REG_DWORD,
		              (LPBYTE) &ntype,
		              sizeof(ntype));

			RegSetValueEx(hKey4,
				_T("ProxyUsername"),
				0,
				REG_SZ,
				(LPBYTE) m_Sock.m_szProxyUserName,
				strlen(m_Sock.m_szProxyUserName));
		
			RegSetValueEx(hKey4,
				_T("ProxyPassword"),
				0,
				REG_SZ,
				(LPBYTE) m_Sock.m_szProxyUserPass,
				strlen(m_Sock.m_szProxyUserPass));
		}
		else {
			// no proxy
			RegDeleteValue(hKey4, _T("ProxyHost"));
			RegDeleteValue(hKey4, _T("ProxyPort"));
			RegDeleteValue(hKey4, _T("ProxyMethod"));
			RegDeleteValue(hKey4, _T("ProxyUsername"));
			RegDeleteValue(hKey4, _T("ProxyPassword"));
		}
#endif//ENABLE_PROXY
		
		RegCloseKey(hKey);

		RegCloseKey(hKey1);
		RegCloseKey(hKey2);
		RegCloseKey(hKey3);
		RegCloseKey(hKey4);
	} while (false);

	CString m_host;

//	m_host.Format(_T("%s %s -P %d -l %s -pw %s"),
//		g_sPlink,
//		m_Site.m_Login.m_szAddr,
//		m_Site.m_Login.m_nPort,
//		m_Site.m_Login.m_szLoginName,
//		m_Site.m_Login.m_szLoginPSW
//		);

	m_host.Format(_T("%s -load %s"), g_sPlink, CTERM_PLINK_SESSION);

	//�����-pw����, ��������, ����������¼
	//�����������, plink��ֱ���˳�
//		if (!m_pass.IsEmpty())
//		{
//			m_host += _T(" -pw ");
//			m_host += m_pass;
//		}

#ifdef _DEBUG_RELEASE
//	TRACEF(m_host.LockBuffer());
//	m_host.UnlockBuffer();
//	AfxMessageBox(m_host);
#endif//_DEBUG_RELEASE

	m_Sock.AnsiLog(NULL, 0);

	bool bRet = true;

	if (!CreateProcess(NULL, m_host.LockBuffer(),
	                   NULL, NULL, TRUE, NULL, NULL, NULL, si, &m_plink_pinfo)) {
		bRet = false;
	}

	m_host.UnlockBuffer();

	return bRet;
}

// ��ʼ����վ��
// pipe��ʽ
void CCTermView::ConnectTheSiteSSH()
{
	m_Sock.OnConnect(0);

	m_bPipeOpen = false;
	m_nPassTry = 0;
	m_bLogined = false;
	m_plink_pinfo.dwProcessId = 0;
	m_plink_pinfo.dwThreadId = 0;
	m_plink_pinfo.hProcess = NULL;
	m_plink_pinfo.hThread = NULL;

	//////////////////////////pipe operations

	HANDLE hChildStdinRd, hChildStdinWr,
	hChildStdoutRd, hChildStdoutWr,
	hSaveStdin, hSaveStdout, hSaveStderr; //hInputFile,

	SECURITY_ATTRIBUTES saAttr;
	BOOL fSuccess;

	// Set the bInheritHandle flag so pipe handles are inherited.

	saAttr.nLength = sizeof(SECURITY_ATTRIBUTES);
	saAttr.bInheritHandle = TRUE;
	saAttr.lpSecurityDescriptor = NULL;

	// The steps for redirecting child process's STDOUT:
	//     1. Save current STDOUT, to be restored later.
	//     2. Create anonymous pipe to be STDOUT for child process.
	//     3. Set STDOUT of the parent process to be write handle to
	//        the pipe, so it is inherited by the child process.
	//     4. Create a noninheritable duplicate of the read handle and
	//        close the inheritable read handle.

	// Save the handle to the current STDOUT.

	hSaveStdout = GetStdHandle(STD_OUTPUT_HANDLE);

	hSaveStderr = GetStdHandle(STD_ERROR_HANDLE);
	// Create a pipe for the child process's STDOUT.

	if (!CreatePipe(&hChildStdoutRd, &hChildStdoutWr, &saAttr, 0))
		ErrorExit("Stdout pipe creation failed\n");

	// Set a write handle to the pipe to be STDOUT.
	if (!SetStdHandle(STD_OUTPUT_HANDLE, hChildStdoutWr))
		ErrorExit("Redirecting STDOUT failed");

//	TRACE(_T("hSaveStdout = %x \n hSaveStderr = %x \n hChildStdoutWr = %x\n"),
//		hSaveStdout, hSaveStderr, hChildStdoutWr);


	if (!SetStdHandle(STD_ERROR_HANDLE, hChildStdoutWr))
		ErrorExit("Redirecting STDERR failed");

	// Create noninheritable read handle and close the inheritable read
	// handle.

	fSuccess = DuplicateHandle(GetCurrentProcess(), hChildStdoutRd,
	                           GetCurrentProcess(), &m_hChildStdoutRdDup , 0,
	                           FALSE,
	                           DUPLICATE_SAME_ACCESS);

	if (!fSuccess)
		ErrorExit("DuplicateHandle failed");

	CloseHandle(hChildStdoutRd);

	// The steps for redirecting child process's STDIN:
	//     1.  Save current STDIN, to be restored later.
	//     2.  Create anonymous pipe to be STDIN for child process.
	//     3.  Set STDIN of the parent to be the read handle to the
	//         pipe, so it is inherited by the child process.
	//     4.  Create a noninheritable duplicate of the write handle,
	//         and close the inheritable write handle.

	// Save the handle to the current STDIN.

	hSaveStdin = GetStdHandle(STD_INPUT_HANDLE);

	// Create a pipe for the child process's STDIN.

	if (!CreatePipe(&hChildStdinRd, &hChildStdinWr, &saAttr, 0))
		ErrorExit("Stdin pipe creation failed\n");

//	TRACE(_T("hChildStdinRd = %x \n hChildStdinWr = %x\n"),
//		hChildStdinRd, hChildStdinWr);
	// Set a read handle to the pipe to be STDIN.

	if (!SetStdHandle(STD_INPUT_HANDLE, hChildStdinRd))
		ErrorExit("Redirecting Stdin failed");

	// Duplicate the write handle to the pipe so it is not inherited.

	fSuccess = DuplicateHandle(GetCurrentProcess(), hChildStdinWr,
	                           GetCurrentProcess(), &m_hChildStdinWrDup, 0,
	                           FALSE,                  // not inherited
	                           DUPLICATE_SAME_ACCESS);

	if (!fSuccess)
		ErrorExit("DuplicateHandle failed");

	CloseHandle(hChildStdinWr);

	STARTUPINFO   startupinfo;

	startupinfo.cb = sizeof(STARTUPINFO);

	GetStartupInfo(&startupinfo);

	startupinfo.hStdError = hChildStdoutWr;

	startupinfo.hStdOutput = hChildStdoutWr;

	startupinfo.hStdInput = hChildStdinRd;

	startupinfo.dwFlags = STARTF_USESHOWWINDOW   |   STARTF_USESTDHANDLES;

	startupinfo.wShowWindow = SW_HIDE;

	// Now create the child process.
	if (!CreatePlinkProcess(&startupinfo)) {
		MessageBox(_T("create plink process error!"));
		m_Sock.OnConnectError(0);
		return;
	}

//   if (!StartPipeReader())
//		ErrorExit("Create reader thread failed");

//   if (!CreateChildProcess(host))
//		ErrorExit("Create process failed");

	// ����ReadFile�ĳ�ʱ��ʧ��
//	COMMTIMEOUTS ct;

//	GetCommTimeouts(m_hChildStdoutRdDup, &ct);

//	ZeroMemory(&ct, sizeof(ct));
//	ct.ReadIntervalTimeout = MAXDWORD; // 3s
//	ct.ReadTotalTimeoutConstant = 2000;
//	ct.ReadTotalTimeoutMultiplier = MAXDWORD;
//	ct.WriteTotalTimeoutConstant = 0;
//	ct.WriteTotalTimeoutMultiplier = 0;
//	CString s;
//	s.Format("%u", ct.ReadTotalTimeoutConstant);
//	AfxMessageBox(s);
//	BOOL b = SetCommTimeouts(m_hChildStdoutRdDup, &ct);
	//DWORD e = GetLastError();
	
//	LPVOID lpMsgBuf;
//	FormatMessage( 
//		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
//		FORMAT_MESSAGE_FROM_SYSTEM | 
//		FORMAT_MESSAGE_IGNORE_INSERTS,
//		NULL,
//		GetLastError(), // ERROR_INVALID_FUNCTION
//		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
//		(LPTSTR) &lpMsgBuf,
//		0,
//		NULL 
//		);
	// Process any inserts in lpMsgBuf.
	// ...
	// Display the string.
	//AfxMessageBox((LPCTSTR)lpMsgBuf);
	// Free the buffer.
//	LocalFree( lpMsgBuf );
	
//the timeouts in the COMMTIMEOUTS structure set using SetCommTimeouts
//apply only to serial ports.

	if (!StartPipeReader())
		ErrorExit("Create reader thread failed");

//	BYTE   buffer[1024];
//	DWORD byteRead=0;
//	while(true)
//	{
//		RtlZeroMemory(buffer,1024);
//		if(ReadFile(m_hChildStdoutRdDup,buffer,1023,&byteRead,NULL)==NULL)
//			break;
//	}

	// After process creation, restore the saved STDIN and STDOUT.

	if (!SetStdHandle(STD_INPUT_HANDLE, hSaveStdin))
		ErrorExit("Re-redirecting Stdin failed\n");

	if (!SetStdHandle(STD_OUTPUT_HANDLE, hSaveStdout))
		ErrorExit("Re-redirecting Stdout failed\n");

	if (!SetStdHandle(STD_ERROR_HANDLE, hSaveStderr))
		ErrorExit("Re-redirecting Stdout failed\n");

	m_bPipeOpen = true;
	
	unsigned tid1;
	HANDLE h = (HANDLE) _beginthreadex(NULL,
		0,
		
		PlinkWatcherFunc,
		(LPVOID) this,
		0,
		&tid1);

	///////////////////////////////
}

//bool isSSHEndStr(const char *s, const int len, const BYTE sitetype);

//wParam: 1, �����ݳ�����ͬPipeReaderFunc����
// �൱��CCTermSock::OnReceive
LRESULT CCTermView::OnPipeData(WPARAM wParam, LPARAM lParam)
{
	switch (wParam) {

	case 0: {
#ifndef _DEBUG
		// releaseʱ�ã���������issshstr��ʶ������
		char s[50];
		sprintf(s, "                                        ");
#endif
		//��������������������printf��䣬������
		//ȥ������printf��䣬����
		//�����Լ��ζ������
		//���ֻ��һ��printf��䣬����
		//ȥ������printf��䣬����������
		//���ԣ�����
		//printf("%d\n", __LINE__);
		if (m_Sock.m_nLen <= 0) {
		//printf("%d\n", __LINE__);
			return 0;
		}
		//printf("%d\n", __LINE__);
		m_Sock.AnsiLog(m_Sock.m_pBuf, m_Sock.m_nLen);

//		m_Sock.TelnetNegotiate (m_nLen);

		if (!m_Sock.m_bStarted) {
		//printf("%d\n", __LINE__);
			m_Sock.OnConnectOK();
		}
		//printf("%d\n", __LINE__);

#if ENABLE_BUF_QUEUE
		const SBuf b = {m_Sock.m_pBuf, m_Sock.m_nLen};
		m_Sock.queueIn(b);
		//TRACE("push %p buf_queue size = %d\n", m_Sock.m_pBuf, m_Sock.m_buf_queue.size());
		
		BYTE *buf = m_Sock.m_bufpool.getBuf();
		if (m_Sock.m_pBuf == m_Sock.buf_in) {
		//printf("%d\n", __LINE__);
			m_Sock.buf_in = buf;
		}
		else {
		//printf("%d\n", __LINE__);
			m_Sock.buf_out = buf;
		}
		//printf("%d\n", __LINE__);
		
		if (m_bInited && m_bViewInited) {
		//printf("%d\n", __LINE__);
			PostMessage(WM_DATA_COME);
		}
#else
		//printf("%d\n", __LINE__);
		m_Sock.m_dataBuf = m_Sock.m_pBuf;
		m_Sock.m_dataLen = m_Sock.m_nLen;
		m_Sock.ProcessReceive();
#endif//ENABLE_BUF_QUEUE
		
		//printf("%d\n", __LINE__);
		// todo: �ⲿ��Ӧ��д��һ������, ��������
		bool bFound = false;

		CString loginflag = SiteType() == ST_NORMAL ? g_sLoginFlag1 : g_sLoginFlag;
		if (loginflag.IsEmpty()) {
		//printf("%d\n", __LINE__);
			loginflag = _T("�ϴ�����ʱ��");
		}
		//printf("%d\n", __LINE__);
		int minlen = loginflag.GetLength();
		// 8: �˴��Ƚϵ�3��������С����
		if (minlen > 8) {
		//printf("%d\n", __LINE__);
			minlen = 8;
		}

		//printf("%d\n", __LINE__);
		if (!m_bLogined && m_Sock.m_nLen >= minlen) {
		//printf("%d\n", __LINE__);
			int ret = 0;
			do {
				// dummy loop
		//printf("%d\n", __LINE__);
//TRACE("%d %s\n", __LINE__, m_Sock.m_pBuf);
				if (InString(_T("login as"), (char *)m_Sock.m_pBuf)) {
//TRACE("%d %s\n", __LINE__, m_Sock.m_pBuf);
					// only once
					bFound = true;
					ret = GetSSHUserPass(&m_Site, m_user, m_pass, m_nPassTry);
//TRACE("%d %s\n", __LINE__, m_user);
//TRACE("%d %s\n", __LINE__, m_pass);
					if (ret == 2) {
						break;
					}
					else if (ret == 0 && !m_user.IsEmpty()) {
//TRACE("%d sending %s\n", __LINE__, m_user);
						Send(m_user + _T("\r\n"), m_user.GetLength() + 2);
					}
				}
				else if (
					(m_Sock.m_nLen > 13 && strncmp((char *)m_Sock.m_pBuf + m_Sock.m_nLen - 13, _T("'s password: "), 13) == 0)
				 || (m_Sock.m_nLen >= 11 && strncmp((char *)m_Sock.m_pBuf + m_Sock.m_nLen - 10, _T("Password: "), 10) == 0)
					) {
//TRACE("%d got %s\n", __LINE__, m_Sock.m_pBuf);
		//printf("%d\n", __LINE__);
					bFound = true;
					ret = GetSSHUserPass(&m_Site, m_user, m_pass, m_nPassTry);
					m_nPassTry++;
					if (ret == 2) break;
					else if (ret == 0) {
		//printf("%d\n", __LINE__);
						//  && !m_pass.IsEmpty()���յ�Ҳ�����Ա���ʾ��һ�� 
						//TRACE("sending m_pass\n");
//TRACE("%d sending %s len=%d\n", __LINE__, m_pass, m_pass.GetLength());
						Send(m_pass + _T("\r\n"), m_pass.GetLength() + 2);
					}
				}
				else if (InString(loginflag.LockBuffer(), (char *)m_Sock.m_pBuf)) {
		//printf("%d\n", __LINE__);
					// �ϴ�����ʱ��
					// Last login:
					m_bLogined = true;
					loginflag.UnlockBuffer();
				}
				else {
		//printf("%d\n", __LINE__);
					loginflag.UnlockBuffer();
				}
			} while(0);
			
			if (ret == 2) {
		//printf("%d\n", __LINE__);
				bFound = true;
				m_Sock.OnClose(0);
			}
		}
		//printf("%d\n", __LINE__);

		//minlen = 8;
		// ����m_bLoginedΪ��Ϊ�棬ֻҪǰ��� InString û���֣���Ӧ��������Щ
		// ��Ϊδ�ɹ���¼ǰҲ���ܶ���

		// �����ssh��ssh/unix����ʱ����ǰ�Ͽ�����
		//(m_Sock.m_nLen == 8 && strncmp((char *)m_Sock.m_pBuf, "logout\r\n", 8) == 0)
		// ���Լ��� SiteType() != ST_NORMAL ������
		// ����linux�������Զ��Ͽ�

		//if (!bFound && m_Sock.m_nLen >= minlen) {
		//printf("%d\n", __LINE__);
			//isSSHEndStr("Sent username \"nullspace\"\r\nFATAL ERROR: Server unexpectedly closed network connection", 87, ST_NORMAL);
			//if (isSSHEndStr((char *)m_Sock.m_pBuf, m_Sock.m_nLen, SiteType())) {
		//printf("%d\n", __LINE__);
			//	bFound = true;
				//FATAL ERROR: Server unexpectedly closed network connection
			//	m_Sock.OnClose(0);
			//}
		//printf("%d\n", __LINE__);
		//}
		//printf("%d\n", __LINE__);
	}//case 0

	break;

	case 1: {
		//plink���̽����������PipeReaderFunc ���أ����Ͳ���Ϊ1��WM_PIPE_DATA��Ϣ

		m_bPipeOpen = false;

		//if (m_Sock.m_bStarted)
		m_Sock.OnClose(0);
	}

	break;
	}//switch

	return 1L;
}

/*#define STR_SIZE(s) (sizeof(s) / sizeof(TCHAR) - 1)
#define DISCONN_MSG0 _T("logout\r\n")
#define DISCONN_MSG1 _T("Sent username ")
#define DISCONN_MSG2 _T("FATAL ERROR: Server unexpectedly closed network connection")
#define DISCONN_MSG3 _T("FATAL ERROR: Network error")
#define DISCONN_MSG4 _T("Server sent disconnect")
#define DISCONN_MSG5 _T("Unable to open connection")

// �ж��Ƿ�Ͽ��ı�־
bool isSSHEndStr(const char *s, const int len, const BYTE sitetype)
{
	if ((sitetype != ST_NORMAL
		&& len == 8
		&& strncmp(s, DISCONN_MSG0, STR_SIZE(DISCONN_MSG0)) == 0)
		|| strncmp(s, DISCONN_MSG2, STR_SIZE(DISCONN_MSG2)) == 0
		|| strncmp(s, DISCONN_MSG3, STR_SIZE(DISCONN_MSG3)) == 0
		|| strncmp(s, DISCONN_MSG4, STR_SIZE(DISCONN_MSG4)) == 0
		|| strncmp(s, DISCONN_MSG4, STR_SIZE(DISCONN_MSG5)) == 0
		) {
		return true;
	}
	else if (_tcsnccmp(s, DISCONN_MSG1, STR_SIZE(DISCONN_MSG1)) == 0) {
		//Sent username "nullspace"
		//FATAL ERROR: Server unexpectedly closed network connection
		// �����û���
				
		const char *p = s + STR_SIZE(DISCONN_MSG1);
		if (*p == '\"') {
			++p;
			while(*p && *p != '\"')
				++p;
			if (*p == '\"') {
				if (*(++p) == '\r') {
					if (*(++p) == '\n') {
						++p;
						if (strncmp(p, DISCONN_MSG2, STR_SIZE(DISCONN_MSG2)) == 0
							|| strncmp(p, DISCONN_MSG3, STR_SIZE(DISCONN_MSG3)) == 0) {
							return true;
						}
					}
				}
			}
		}
	}

	return false;
}
*/
#endif//ENABLE_PIPESSH

LRESULT CCTermView::OnDataCome(WPARAM wParam, LPARAM lParam)
{
	m_Sock.ProcessReceive();
	return 0L;
}
