// SiteDecodePage.cpp : implementation file
//

#include "stdafx.h"

#include "SiteDecodePage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteDecodePage property page

IMPLEMENT_DYNCREATE(CSiteDecodePage, CMyPropertyPage)

CSiteDecodePage::CSiteDecodePage() : CMyPropertyPage(CSiteDecodePage::IDD)
{
	//{{AFX_DATA_INIT(CSiteDecodePage)
	m_bEnter = FALSE;
	m_nDecode = 0;
	m_nInputCodeInvert = -1;
	m_nOutputCodeInvert = -1;
	m_bBsIsDel = FALSE;
	m_bDelAsStop = FALSE;
	//}}AFX_DATA_INIT
}

CSiteDecodePage::~CSiteDecodePage()
{
}

void CSiteDecodePage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteDecodePage)
	DDX_Control(pDX, IDC_DECODE, m_nDecode_ctrl);
	DDX_Check(pDX, IDC_ENTERSET, m_bEnter);
	DDX_CBIndex(pDX, IDC_DECODE, m_nDecode);
	DDX_Radio(pDX, IDC_RADIO1, m_nInputCodeInvert);
	DDX_Radio(pDX, IDC_RADIO5, m_nOutputCodeInvert);
	DDX_Check(pDX, IDC_BSASDEL, m_bBsIsDel);
	DDX_Check(pDX, IDC_DELASSTOP, m_bDelAsStop);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteDecodePage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteDecodePage)
	ON_BN_CLICKED(IDC_DOUBLECODE_YES, OnDoublecodeYes)
	ON_BN_CLICKED(IDC_DOUBLECODE_NO, OnDoublecodeNo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteDecodePage message handlers

BOOL CSiteDecodePage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



//	m_nDecode	=m_pDecode->m_nType;
//	m_bEnter	=m_pDecode->m_bEnterAsReturn;
//	m_bDouble	=m_pDecode->m_bDoubleCode;		// ˫�ֽڴ���
//	UpdateData(FALSE);

	CButton *pBut;

	if (m_bDouble)
		pBut = (CButton *) GetDlgItem(IDC_DOUBLECODE_YES);
	else
		pBut = (CButton *) GetDlgItem(IDC_DOUBLECODE_NO);

	if (pBut)
		pBut->SetCheck(1);

	/*	if (m_pLogin->m_nSiteType==ST_FIREBIRD)
		{
		GetDlgItem(IDC_CLEAR_C)->EnableWindow(1);		//����FBվ����Ҫ�������δ����ǰ���
		GetDlgItem(IDC_CLEAR_F)->EnableWindow(1);
		}else
		{
		GetDlgItem(IDC_CLEAR_C)->EnableWindow(0);
		GetDlgItem(IDC_CLEAR_F)->EnableWindow(0);
		}
	*/
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control

	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSiteDecodePage::OnDoublecodeYes()
{
	m_bDouble	= true;
}

void CSiteDecodePage::OnDoublecodeNo()
{
	m_bDouble = false;
}

UINT CSiteDecodePage::GetIDD()
{
	return IDD;
}
