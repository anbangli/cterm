////////////////////////////////////////////////////////////////////
////////  ���Դ���
////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "MainFrm.h"

//#ifdef _DEBUG
//#include "exception\stdafx1.h"
//#include "exception\se_translator.h"
//#include "exception\exception_trap.h"
//#include "exception\unhandled_report.h"
//#include "exception\sym_engine.h"
//#include "exception\debug_stream.h"
//#include "exception\exception2.h"
//
//// std::cout or debugger's output depending on running under debugger or not
//std::ostream& get_ostream();
//std::ostream& g_os = get_ostream();	
//
//std::ostream& get_ostream()
//{
//	static dostream dos;
//	if (IsDebuggerPresent())
//		return dos;
//	else 
//		return std::cout;
//}
//
//// sets the trap for unhandled exceptions
//exception_trap<unhandled_report> trap(true, unhandled_report(g_os));
//
//// workaround of VCPP synchronous exception and se translator
//bool global_force_exception_flag = false;
//#define WORKAROUND_VCPP_SYNCHRONOUS_EXCEPTION  if (global_force_exception_flag) force_exception_frame();
//void force_exception_frame(...) {std::cout.flush();}
//
//#endif//_DEBUG

void CMainFrame::OnTest()
{
#ifdef _DEBUG
//#include "inscolor.h"
	//		CChildFrame *pFrame=(CChildFrame *)MDIGetActive();
	//		if(pFrame && pFrame->m_pView)
	//		{
	//		TCHAR s[]= _T("����������");
	//pFrame->m_pView->m_Core.AddTxt(s,_tcslen(s));
	//		pFrame->m_pView->RedrawRectDoubleColor(10, 10, s);
	//		}
	
	//crash test
	//	AfxMessageBox ("Crash Test");
	//	int *p = NULL;
	//	*p = 0;
	
	// char *pch1 = new char[20];
	// delete pch1;
	// delete pch1;//not crash!
	
	
	//extern void testRunPy();
	//	testRunPy();
	
	//	CTestDlg dlg;
	//	dlg.DoModal();
	
	//	CChildFrame *pFrame = (CChildFrame *) MDIGetActive();
	//	if (pFrame && pFrame->m_pView)
	//	{
	//		CDC *pDC = pFrame->m_pView->GetDC();
	//		bool b=FontExist (pDC->GetSafeHdc(), DEFAULT_CHARSET, "����");
	//	}
	
	//	CString szFileName
	//	ASSERT (szFileName);
	
	//#if ENABLE_PNG
	//	if (IsPicPNG (szFileName))
	//	{
	//		m_bIsPNG = TRUE;
	//		 return LoadPNG (szFileName);
	//	}
	//#endif
	
	//	CPictureEx pic;
	//	pic.Load("D:\\mine\\cterm\\null\\bad_1199689795-2577.gif");
	
	//	CPicShowDlg1 dlg;
	//	dlg.DoModal();
	
	//test unicode
	//	TCHAR *p = _T("mfcxxx.lib");
	//	char *pc = (char *) p;
	
	// ���ز˵���
	//	AfxGetMainWnd()->SetMenu(NULL);   
	//	AfxGetMainWnd()->DrawMenuBar();
	
	/*
	BOOL bMaximized;
	CChildFrame *pActive = (CChildFrame *)MDIGetActive(&bMaximized);
	if (pActive && bMaximized && m_Child.nChild > 0) {
	CRect rect1;
	pActive->GetWindowRect(&rect1);
	CString s;
	s.Format("child: %d %d %d %d", rect1.top, rect1.bottom, rect1.left, rect1.right);
	AfxMessageBox(s);
	
	  pActive->m_pView->GetWindowRect(&rect1);
	  s.Format("view: %d %d %d %d", rect1.top, rect1.bottom, rect1.left, rect1.right);
	  AfxMessageBox(s);
	  
		GetWindowRect(&rect1);
		s.Format("main: %d %d %d %d", rect1.top, rect1.bottom, rect1.left, rect1.right);
		AfxMessageBox(s);
		}
	*/
	
	//	MoveChild(1);
	//	static bool bTop = false;
	//	if (bTop) {
	//		SetWindowPos(&wndNoTopMost, 0, 0, 0, 0,
	//                              SWP_NOMOVE | SWP_NOSIZE); 
	//	}
	//	else {
	//		SetWindowPos(&wndTopMost, 0, 0, 0, 0,
	//                              SWP_NOMOVE | SWP_NOSIZE); 
	//	}
	//	bTop = !bTop;
	//	int a = 1;
	
	//	CMDIChildWnd *pChild = MDIGetActive();
	//	pChild->ShowWindow(SW_MINIMIZE);
	
//	CInsColor dlg;
//	dlg.DoModal();

	//	AfxDumpStack();
//	{
//		try
//		{		
//			//int *p = NULL;
//			//*p = 3; // ��exception���Գ����﹤�������ﲻ������ֱ�ӵ�����������
//			throw new exception2("sadf");
//		}
//		catch(se_translator::access_violation& ex)
//		{			
//			g_os	<< ex.name() << " at 0x" << std::hex << ex.address() 
//				<< ", thread attempts to " << (ex.is_read_op() ? "read" : "write") 
//				<< " at 0x" << std::right << ex.inaccessible_address() << std::endl
//				<< "stack trace : " << std::endl; // ��exception2�����ﱨ��
//			sym_engine::stack_trace(g_os, ex.info()->ContextRecord);		
//		}
//		catch(exception2& ex)
//		{
//			g_os << ex.what() << std::endl
//				<< "stack trace :" << std::endl
//				<< ex.stack_trace() << std::endl;
//		}
//	}
#endif //_DEBUG
}
