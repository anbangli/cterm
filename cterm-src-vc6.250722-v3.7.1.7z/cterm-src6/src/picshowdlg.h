#if !defined(AFX_PICSHOWDLG_H__BF553716_6FF5_4655_BE39_F6A7E3F7F1AD__INCLUDED_)
#define AFX_PICSHOWDLG_H__BF553716_6FF5_4655_BE39_F6A7E3F7F1AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PicShowDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPicShowDlg dialog
#include "PictureEx.h"
#include "picdown.h"
#include <afxmt.h>
#include "resource.h"

#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

enum MoveDir {MOVE_UP = VK_UP, MOVE_DOWN = VK_DOWN, MOVE_LEFT = VK_LEFT, MOVE_RIGHT = VK_RIGHT};

class CPicShowDlg : public CDialog
{
public:
// Construction
	CPicShowDlg(CWnd* pParent = NULL);
	~CPicShowDlg()
	{
		if (m_picex)
			delete m_picex;

		DeleteObject(m_hbrush);
	}

public:
	void ShowPicture(void);  // ��MainFrame�е���
	int GetDisplaySize() const
	{
		return m_nDisplaySize;
	}

	COLORREF getBg() const
	{
		return m_bg;
	}

	void SetBgColor();

private:
	void OnPicMax();
	void CopyURL(void);
	void ShowDlgInfo(const CString &info) const;
	void ShowDlgInfo1(const CString &info) const;
	CString GetStatusStr(PicState nState) const;
	void ShowButtons(bool bShow = true);
	void fixWinPos(POINT &LTpt, const CRect &mainrect, const bool bFixed
		, const int width, const int height) const;

	void DrawPicture(PicState nState = PIC_DOWNLOAD, bool bFixed = true);
	void LoadPicture();
	void TogglePic(int mode = 1);
	void MovePicture(int offsetx, int offsety);
	void DelPic(void);

	static unsigned __stdcall LoadPicThread(void *pParam);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPicShowDlg)
public:
	virtual void OnCancel();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

private:
	// Generated message map functions
	//{{AFX_MSG(CPicShowDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnPicPrev();
	afx_msg void OnPicNext();
	afx_msg void OnPicSave();
	afx_msg HRESULT OnPicEvent(WPARAM wParam, LPARAM lParam);
	afx_msg void OnPicClose();
	afx_msg LRESULT OnSetStatusCount(WPARAM wParam, LPARAM lParam);
	virtual void OnOK();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnPicOpen();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnPicZoom();
	afx_msg void OnNcLButtonUp(UINT nHitTest, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNcRButtonDown(UINT nHitTest, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnPicExif();
	afx_msg void OnPicOpenpath();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
// Dialog Data
	//{{AFX_DATA(CPicShowDlg)
	enum { IDD = IDD_PIC_SHOW };
	CButtonST	m_btInfo;
	CButtonST	m_btClose;
	CButtonST	m_btSave;
	CButtonST	m_btOpen;
	CButtonST	m_btNext;
	CButtonST	m_btPrev;
	//}}AFX_DATA

private:
	CToolTipCtrl m_tooltip;
	PicState m_nState;
	CString m_szPicFile;
	// �Ƿ���ʾ��Խ����Ϣ��Ϣ
	bool m_lasttiped;
	bool m_firsttiped;

// load thread��Ҫ��������Դ
	CPictureEx *m_picex;
	//CString m_sLoadFile;
	HANDLE m_hLoadPicThread;
	bool m_bLoading;
	PICSTRUCT *m_LoadingPic; // ָ������loading��ͼƬ
	PICSTRUCT *m_pic; // ָ��ǰ��draw��ͼƬ
	PicIt m_picit; // ָ���pic���б��е�λ��,
	//�����listִֻ��push_back����, ���Դ�posһ����Ч, һֱ����Ч, ֱ��clear()...��size_type���͵�pos��Ҫ�Ӵ�����, ��iterator����Ҫ��, ���Ժ��߸���ȫ

	CCriticalSection	m_csDraw;
	WINDOWPLACEMENT m_wpPrev;

	HBRUSH m_hbrush; //background
	COLORREF m_bg;
//	bool m_bFixed;
	bool m_bDrawing;
	bool m_bLeftDown;

//	BOOL m_bFullScreen;
	int m_nDisplaySize; //0: Сͼ, 1: ȫ��, 2: ԭ�ߴ�
	int m_bPicMoving;
	CPoint m_lastmovept;

	CRect m_rcPic; //ͼƬλ��
};

#include "usermsg.h"

extern CPicShowDlg *g_pPicShowDlg;
inline void PostPicMsg(const PICSTRUCT *const pic)
{
	ASSERT(g_pPicShowDlg && pic);
	g_pPicShowDlg->PostMessage(WM_PICTURE, (WPARAM) pic, (LPARAM) FLAG_PIC_GOT);
}

inline void PosPicCountMsg(int num)
{
	ASSERT(g_pPicShowDlg);
	g_pPicShowDlg->PostMessage(WM_SETSTATUSCOUNT, (WPARAM) num, (LPARAM) FLAG_PIC_GOT);
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICSHOWDLG_H__BF553716_6FF5_4655_BE39_F6A7E3F7F1AD__INCLUDED_)
