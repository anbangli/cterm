// HTMLConvert.cpp: implementation of the CHTMLConvert class.
// HTMLת��
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <direct.h>
#include "HTMLConvert.h"
#include "ctermview.h"
#include "paramconfig.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CHTMLConvert::~CHTMLConvert()
{
	if (m_LastScreen)
		delete[] m_LastScreen;
}

CHTMLConvert::CHTMLConvert(CCTermCore *pCore)
{
	m_pCore = pCore;
	if (pCore) m_pView = pCore->getView();
	m_LastScreen = new TCHAR[m_pView->TermH()][40];
	ASSERT(m_LastScreen != NULL);
	memset(m_LastScreen, 0, m_pView->TermH()*40*sizeof(TCHAR));

	const COLORREF *cs = m_pView->SiteColorSet();
	for (int i = 0; i < 16; i++)
		CHTMLConvert::colorset[i] = cs[i];

	m_szFile.Empty();
	//memset((void*)m_szFile, 0, sizeof(m_szFile));

	memset((void*)m_szProfile, 0, sizeof(m_szProfile));

	memset((void*)m_szTitle, 0, sizeof(m_szTitle));

	memset((void*)m_szSite, 0, sizeof(m_szSite));

	m_bTemp = FALSE;

	m_nFileAt = 0;;
}

BOOL CHTMLConvert::Create(const CString & szPath, TCHAR *szSite, TCHAR *szProfile, TCHAR *szTitle, BOOL bTemp, BOOL bIndex)
{
	CFileFind finder;

	if (bTemp)
		m_szFile = szPath + _T("temp\\temp.htm");
	else
		m_szFile = szPath;

	if (m_szFile.IsEmpty())
		return FALSE;

	m_bTemp = bTemp;

	_tcscpy(m_szSite, szSite);

	_tcscpy(m_szTitle, szTitle);

	_tcscpy(m_szProfile, szProfile);

	FILE *fp = _tfopen(m_szFile, _T("wt"));

	if (fp == NULL)
		return FALSE;

	ASSERT(m_pCore != NULL);    //must call CHTMLConvert::CHTMLConvert(CCTermCore *pCore)

	for (int i = 0;i < m_pView->TermH(); i++) m_LastScreen[i][0] = 0;

	//Here Need a Pattern of HTML File
	m_CF.Reset();

	WriteHead(fp, bIndex);

	WriteEnd(fp);

	fclose(fp);

	return TRUE;
}

void CHTMLConvert::WriteHead(FILE *fp, BOOL bIndex)
{
	_fputts(_T("<HTML>"), fp);
	_fputts(_T("<HEAD>"), fp);
	_ftprintf(fp, _T("<title>%s </title>"), m_szTitle);

	_tchdir(g_szWorkDir);
	/*
		FILE *fpcolor=_tfopen(_T("user\\htmlcolor.txt"), "r");
		if(fpcolor) {
			TCHAR line[256]=_T("");
			while( _fgetts(line, 255, fpcolor) )
				_fputts(line, fp);
			fclose(fpcolor);
		}
		else
	*/
	{
		_fputts(_T("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=gb2312\">\n"), fp);
		_fputts(_T("<STYLE type=text/css media=screen>\n"), fp);
		_fputts(_T("body {\n"), fp);
		_ftprintf(fp, _T("font-family: %s;\n"), m_pView->m_Site.m_Decode.m_szFont);
		_ftprintf(fp, _T("background-color:#%02x%02x%02x;\n"), (BYTE)(colorset[0]&0xff), (BYTE)((colorset[0]&0xff00) / 256), (BYTE)((colorset[0]&0xff0000) / 65536));
		_ftprintf(fp, _T("color: #%02x%02x%02x;\n"), (BYTE)(colorset[7]&0xff), (BYTE)((colorset[7]&0xff00) / 256), (BYTE)((colorset[7]&0xff0000) / 65536));
		_fputts(_T("}\n"), fp);
		_fputts(_T("</STYLE>\n"), fp);
		_fputts(_T("</HEAD>\n"), fp);
		_ftprintf(fp, _T("<BODY link=\"#0099CC\" vlink=\"#00CCCC\" alink=\"#CCFF00\">\n"));
	}

	//_fputts(_T("<FONT FACE=\"����\" LANG=\"ZH-CN\" SIZE=3></FONT>"),fp);

	//_fputts(_T("<table border=\"1\" bgcolor=\"#FFFFFF\" bordercolor=\"#FFFFFF\" width=\"100%\">"),fp);
	//_fputts(_T("<tr>\n<td bordercolor=\"#FFFFFF\" width=\"190\"><a href=\"mailto:cterm@mail.fanso.com\"><img src=\"logo.GIF\" width=\"190\" height=\"74\" border=\"0\"></a></td>\n<td width=\"850\" bordercolor=\"#FFFFFF\"><img src=\"adv.gif\" width=\"400\" height=\"80\"></td>\n</tr>"),fp);
	//_fputts(_T("<tr>\n<td bordercolor=\"#FFFFFF\" width=\"190\"><a href=\"mailto:cterm@mail.fanso.com\"><img src=\"logo.GIF\" width=\"190\" height=\"74\" border=\"0\"></a></td>\n<td width=\"850\" bordercolor=\"#FFFFFF\"></td>\n</tr>"),fp);
	//_fputts(_T("</table>"),fp);

	// 2004-4-6 1:20  ɾ��������Щ��������
	// 2021-4-23 ��Ϊ���������ļ���д��һЩ��Ϣ
	if (bIndex)	{	//�����ļ�������д��һЩ��Ϣ
		if(_tcslen(m_szProfile)&&_tcslen(m_szSite))
			_ftprintf(fp,_T("<P ALIGN=\"left\"><font lang=\"ZH-CN\" size=\"3\" color=\"#FFFFFF\">CTerm��������: <a href=\"http://%s\">%s</a></font><br></P>\n"), m_szSite, m_szProfile);

 		if(_tcslen(m_szTitle))
			_ftprintf(fp,_T("<P ALIGN=\"center\"><font face=\"����\" size=\"3\" color=\"#FFFFFF\">%s</font></P>\n"),m_szTitle);
		else
			_fputts(_T("<P></P>\n"),fp);
	}
	_fputts(_T("<span style=\"letter-spacing: 0pt;line-height: 1\">\n"),fp);

	m_nFileAt = ftell(fp);
}

void CHTMLConvert::WriteEnd(FILE *fp)
{
	fseek(fp, m_nFileAt, SEEK_SET);
	_fputts(_T("</span>"), fp);
	_fputts(_T("</BODY>\n</HTML>"), fp);       //length: 17 bytes
}

//��������
//start end �����ĩ��=��ǰ�����к�
void CHTMLConvert::AddLines(int start, int end)
{
#define MAX_LINE_LEN 2000

	if (end == -1) end = start;

	TCHAR *buf = (TCHAR *) malloc(MAX_LINE_LEN * (end - start + 1) + 1);

	if (!buf) {
//TRACE(_T("in CHTMLConvert::AddLines() memory failed!\n"));
		return;
	}

	FILE *fp;

	fp = _tfopen(m_szFile, _T("r+t"));

	if (!fp) {
		AfxMessageBox(_T("Cannot open temp file!"));
		return;
	}

	fseek(fp, m_nFileAt, SEEK_SET);

//	for(int i=start; i<=end;i++)
//	{
	int nLen = ScreenToHTML(buf, start, end + 1);
	ASSERT(nLen <= MAX_LINE_LEN*(end - start + 1));

	if (nLen) {
//TRACE(_T("nLen:%d\n"), nLen);
		fwrite(buf, nLen, 1, fp);
	}

	free(buf);

//	}
	m_nFileAt = ftell(fp);
	WriteEnd(fp);
	fclose(fp);
}

//�кž��������ĩ��(=��ǰ��)���к�
void CHTMLConvert::AddScreen(BOOL bLast)
{
//TRACE(_T("CHTMLConvert::AddScreen bLast:%d\n"), bLast);
	TCHAR buf[40000];
	int  nLen, i;
	FILE *fp;

	if (bLast) {
		//��һ�����ظ���
		i = m_pView->m_Status.DupLineNum();
	} else
		i = 0;

	nLen = ScreenToHTML(buf, i, m_pView->TermH() - (bLast ? 1 : 2));

	if (nLen) {
//TRACE(_T("2 nLen:%d\n"), nLen);
		fp = _tfopen(m_szFile, _T("r+t"));

		if (fp) {
			fseek(fp, m_nFileAt, SEEK_SET);
			fwrite(buf, nLen, 1, fp);
			m_nFileAt = ftell(fp);
			WriteEnd(fp);
			fclose(fp);
		}
	}
}

//nStart nEnd �����ĩ��(=��ǰ��)���к�
int CHTMLConvert::ScreenToHTML(TCHAR *buf, int nStart, int nEnd)
{
	if (nEnd == -1) nEnd = m_pView->TermH() - 2;

	if (nStart >= m_pView->TermH() || nStart < 0
	        || nEnd >= m_pView->TermH() || nEnd < 0 || nStart > nEnd)
		return 0;

	ASSERT(0 <= nEnd && nEnd < m_pView->TermH());

	ASSERT(0 <= nStart && nStart < m_pView->TermH());

	//תΪ�����к�
	nStart += m_pCore->MaxStartLine();

	nEnd += m_pCore->MaxStartLine();

	int nWrapLen = (g_nWrapLen <= 0 || g_nWrapLen > m_pView->TermW())
	               ? m_pView->TermW() : g_nWrapLen;

	TCHAR ts[30] = _T("");

	BOOL bFontChange = FALSE;

	BOOL bBkColorChange = FALSE;

	//m_CF.Reset();
	buf[0] = 0;

	//   _tcscat(buf,_T("<font size=\"3\" color=\"#FFFFFF\">\n")); //- <p>
//	if (nEnd == -1)
//		nEnd = m_pView->TermH() - 2;

	int i, j;

	for (i = nStart;i < nEnd;i++) {
		const SOneChar *pLine = m_pCore->line(i);

		for (j = MAX_LINE_CHAR - 1;j > 0;j--) {
			if (pLine[j].GetChar() != ' ' ||
			        (pLine[j].GetBC()) != 0) // ����0��ɫ, ǰ��7��ɫ...�Կո���˵��ǰ��û������
				break;
		}

		int nLen = j;

		m_CF.Reset();
		bFontChange = FALSE;
		bBkColorChange = FALSE;

		for (j = 0;j < nLen + 1;j++) {
			if (pLine[j].GetBC() != m_CF.GetBC()) {
				if (bBkColorChange)
					_tcscat(buf, _T("</span>"));

				bBkColorChange = ChangeBkColor(m_CF, pLine[j], buf);

				m_CF.SetBC(pLine[j].GetBC());
			}

			if (!IsSameAttr(pLine[j], m_CF)) {
				if (bFontChange)
					_tcscat(buf, _T("</font>"));      //to defult first

				bFontChange = ChangeAttr(m_CF, pLine[j], buf);

				m_CF = pLine[j];
			}

			switch (pLine[j].GetChar()) {

			case ' ':
				_stprintf(ts, _T("&nbsp;"));
				break;

			case '<':
				_stprintf(ts, _T("&lt;"));
				break;

			case '>':
				_stprintf(ts, _T("&gt;"));
				break;

			case '\"':
				_stprintf(ts, _T("&quot;"));
				break;

			case '&':
				_stprintf(ts, _T("&amp;"));
				break;

			default:
				_stprintf(ts, _T("%c"), pLine[j].GetChar());
			}

			_tcscat(buf, ts);
		}

		if (bFontChange)
			_tcscat(buf, _T("</font>"));

		if (bBkColorChange)
			_tcscat(buf, _T("</span>"));

		{
			bool bReturn = false;
//			if ( bRect )
//			{
//				if ( !g_bCopyRectNoReturn || nEnd < x1 - 1 ) bReturn = true;
//			}
//			else
			{
				if (!g_bCopyNoReturn || nLen < nWrapLen - 1) bReturn = true;
			}

			if (bReturn) {
				_tcscat(buf, _T("<br>\n"));
			}
		}
	}

	//_tcscat(buf,_T("</font>")); //- </p>
	return _tcslen(buf);
}

COLORREF  CHTMLConvert::colorset[16] = {
	RGB(0, 0, 0),
	RGB(128, 0, 0),
	RGB(0, 128, 0),
	RGB(128, 128, 0),
	RGB(0, 0, 128),
	RGB(128, 0, 128),
	RGB(0, 128, 128),
	RGB(192, 192, 192),
	RGB(128, 128, 128),
	RGB(255, 0, 0),
	RGB(0, 255, 0),
	RGB(255, 255, 0),
	RGB(0, 0, 255),
	RGB(255, 0, 255),
	RGB(0, 255, 255),
	RGB(255, 255, 255),
};

BOOL CHTMLConvert::ChangeAttr(const SOneChar &Old, const SOneChar &New, TCHAR *buf)
{
	SOneChar Char;
	TCHAR fc, font;
	TCHAR ts[100];
	Char.Reset();

	if (IsSameAttr(New, Char))
		return FALSE;//To defult

	fc = New.GetFC();

	if (!New.HasAttr(ATTR_HIGHLIGHT))
		fc -= (fc > 8) ? 8 : 0;
	else
		fc += (fc < 8) ? 8 : 0;

	//if(fc==0)fc=8;
	font = New.GetFont();

	_stprintf(ts, _T("<font color=\"#%02x%02x%02x\" "), (BYTE)(colorset[fc]&0xff),
	          (BYTE)((colorset[fc]&0xff00) / 256), (BYTE)((colorset[fc]&0xff0000) / 65536));               //,colorset[fc].G,colorset[fc].B);

	_tcscat(buf, ts);

	if (font) {
		switch (font) {

		case 1:
			_tcscat(buf, _T("face=\"����\""));
			break;

		case 2:
			_tcscat(buf, _T("face=\"����\""));
			break;

		case 3:
			_tcscat(buf, _T("face=\"����\""));  //"����_GB2312\"
			break;
		}
	}

	_tcscat(buf, _T(">"));

	return TRUE;
}

BOOL CHTMLConvert::IsSameAttr(const SOneChar &a, const SOneChar &b)
{
	if (a.HasAttr(ATTR_HIGHLIGHT) != b.HasAttr(ATTR_HIGHLIGHT) ||      //�������Բ�ͬ��ATTR_UNDERLINE��ATTR_REVERSE����
	        a.GetFont() != b.GetFont() ||     //���岻ͬ����˸����
	        a.GetFC() != b.GetFC())      //ǰ��ɫ��ͬ������ɫ����
		return FALSE;

	return TRUE;

//������Щ���ԣ���ܶ಻ͬ���Ե�������Ϊ��ͬһ����...���
}

BOOL CHTMLConvert::ChangeBkColor(const SOneChar &now, const SOneChar &New, TCHAR *buf)
{
	SOneChar Char;
	TCHAR bc;
	TCHAR ts[100];
	Char.Reset();

	if ((Char.GetBC()) == (New.GetBC()))
		return FALSE;//To defult

	bc = New.GetBC();

	bc /= 16;

	if (New.HasAttr(ATTR_BACKHI))
		bc += (bc < 8) ? 8 : 0;
	else
		bc -= (bc > 8) ? 8 : 0;

	_stprintf(ts, _T("<span style=\"background-color: #%02x%02x%02x\">"), (BYTE)(colorset[bc]&0xff),
	          (BYTE)((colorset[bc]&0xff00) / 256), (BYTE)((colorset[bc]&0xff0000) / 65536));               //,colorset[fc].G,colorset[fc].B);

	_tcscat(buf, ts);

	return TRUE;
}

void CHTMLConvert::AddLine(TCHAR *szLine)
{
	FILE *fp;
	fp = _tfopen(m_szFile, _T("r+t"));

	if (fp) {
		fseek(fp, m_nFileAt, SEEK_SET);
		_fputts(szLine, fp);
		m_nFileAt = ftell(fp);
		WriteEnd(fp);
		fclose(fp);
	}
}

int CHTMLConvert::GetFileAt()
{
	return m_nFileAt;
}

BOOL CHTMLConvert::Create(TCHAR *szFile, int nFileAt, CCTermCore *pCore)	//���� HTML �ļ�
{
	if (isempty(szFile))
		return FALSE;

	FILE *fp = _tfopen(szFile, _T("r+t"));
	if (!fp)
		return FALSE;

	m_szFile = szFile;
	m_pCore = pCore;
	m_CF.Reset();
	m_nFileAt = nFileAt;

	fclose(fp);
	return TRUE;
}

TCHAR *CHTMLConvert::GetTitle()
{
	return m_szTitle;
}
