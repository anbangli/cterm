// InputDlg.cpp : implementation file
//

#include <afxmt.h>
#include "stdafx.h"
#include "PostDlg.h"
#include "UploadAttDlg.h"

//#include <dispex.h> 
//#include <atlbase.h>//for atlcom.h   
//extern CComModule _Module;//for atlbase.h  
//#include <atlcom.h>//for OLE2T   

#include "UploadThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPostDlg dialog


CPostDlg::CPostDlg(CWnd* pParent /*=NULL*/)
		: CDialog(CPostDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPostDlg)
	//m_inputline = _T("");
	//m_quote = 0;
	//m_qmd = 0;
	//m_reply = TRUE;
	m_nLiveTime = 30;
	m_bContinuously = FALSE;
	m_strBoardName = _T("");
	m_strSiteName = _T("");
	m_strLocalFile = _T("");
	m_strUserName = _T("");
	m_strPassWord = _T("");
	m_strDescription = _T("");
	m_bUploadAtt = FALSE;
	//}}AFX_DATA_INIT
	m_bThreadExit = FALSE;
	m_thdUpload = NULL;
	m_bSucceed = FALSE;
	m_nMaxWidth = 0;
	m_bUpload = TRUE;
}


void CPostDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPostDlg)
	
	//DDX_Text(pDX, IDC_INPUT, m_inputline);
	//DDV_MaxChars(pDX, m_inputline, 45);
	//DDX_CBIndex(pDX, IDC_QUOTE, m_quote);
	//DDX_CBIndex(pDX, IDC_QMD, m_qmd);
	//DDX_Check(pDX, IDC_CHK_REPLY, m_reply);
	DDX_Check(pDX, IDC_ONE_BY_ONE, m_bContinuously);
	DDX_Text(pDX, IDC_SITE_NAME, m_strSiteName);
	DDX_Text(pDX, IDC_BOARD_NAME, m_strBoardName);
	DDX_Text(pDX, IDC_USER_NAME, m_strUserName);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassWord);
	DDX_Text(pDX, IDC_LOCAL_FILE, m_strLocalFile);
	DDX_Text(pDX, IDC_LIVE, m_nLiveTime);
	DDV_MinMaxInt(pDX, m_nLiveTime, 1, 999);
	DDX_Text(pDX, IDC_FILE_DESCRIPTION, m_strDescription);
	DDX_Control(pDX, IDC_STATUS_LIST, m_listStatus);
	//DDX_Check(pDX, IDC_CHK_UPLOADATT, m_bUploadAtt);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPostDlg, CDialog)
	//{{AFX_MSG_MAP(CPostDlg)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_MESSAGE(WM_STATUS_CHANGED, OnStatusChanged)
	ON_MESSAGE(WM_TRAYICON_MESSAGE, OnNotifyFunc)
	ON_BN_CLICKED(IDC_ONE_BY_ONE, OnOneByOne)
	ON_BN_CLICKED(IDC_UPLOAD, OnUpload)

	ON_WM_CLOSE()
	//ON_BN_CLICKED(IDC_UPLOAD_ALLOW, OnUploadAllow)
	ON_WM_SHOWWINDOW()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPostDlg message handlers

BOOL CPostDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	//SetIcon(m_hIcon, TRUE);			// Set big icon
	//SetIcon(m_hIcon, FALSE);		// Set small icon

	//GetModuleFileName(NULL, m_strModulePath.GetBuffer(MAX_PATH), MAX_PATH);
	//m_strModulePath.ReleaseBuffer();
	//int nPos = m_strModulePath.ReverseFind('\\');
	//m_strModulePath = m_strModulePath.Left(nPos + 1);


	//ReadSettings();
	SetIcon(AfxGetApp()->LoadIcon(IDI_NOTEPAD), FALSE);
	//m_listStatus.AddString(_T("����"));

	//if (m_stHendy.Load(MAKEINTRESOURCE(IDR_GIF_HENDY),_T("GIF")))
	//	m_stHendy.Draw();

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}


void CPostDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	//CRect rect;
	//GetWindowRect(&rect);
	CDialog::OnShowWindow(bShow, nStatus);
	if (!m_strLocalFile.IsEmpty())
		GetDlgItem(IDC_UPLOAD)->SetFocus();
}


void CPostDlg::OnBrowse()	// BYHH ���Ӹ���
{
	CFileDialogEx fd(TRUE, _T(""), m_strLocalFile, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
	               _T("ͼƬ�ļ�(*.jpg, *.gif, *.bmp, *.png)|*.*||"));

	if (fd.DoModal() == IDOK) {
		UpdateData();
		m_strLocalFile = fd.GetPathName();
		//m_astrFilesUpload.Add(m_strLocalFile);
		UpdateData(FALSE);
	}
	GetDlgItem(IDC_UPLOAD)->SetFocus();
}


void CPostDlg::AddStringToListBox(CString &strItem)
{
	int nMaxWidth = 0;
	CSize szText;
	CDC *pDC = GetDC();
	szText = pDC->GetTextExtent(strItem);

	if (szText.cx > m_nMaxWidth) {
		m_nMaxWidth = szText.cx;
	}

	m_listStatus.InsertString(-1, strItem);

	m_listStatus.SetCurSel(m_listStatus.GetCount() - 1);

	if (szText.cx > nMaxWidth) {	// ʹListBox��ˮƽ�������ܹ���
		m_listStatus.SendMessage(LB_SETHORIZONTALEXTENT, m_nMaxWidth);
	}
	ReleaseDC(pDC);
}


void CPostDlg::OnUpload()	// BYHH �ϴ�����
{
	if (!m_bUpload) {
		AfxMessageBox(_T("����ɾ���ļ������Ժ�..."));
		return;
	}

	if (m_thdUpload) {
		m_bThreadExit = TRUE;
		if (WaitForSingleObject(m_eventExit, 2000) == WAIT_TIMEOUT) {
			// ǿ�н����߳�
			TerminateThread(m_thdUpload->m_hThread, 0);
		}
		m_thdUpload = NULL;

		GetDlgItem(IDC_UPLOAD)->SetWindowText(_T("�ϴ�(&U)"));
		GetDlgItem(IDOK)->EnableWindow(TRUE);
		return;
	}

	if (!UpdateData()) {
		return;
	}

	// �����ʺ�
	/*	for(int i = 0; i < m_astrUseNames.GetSize(); i ++)		{
			if(m_strUserName == m_astrUseNames.GetAt(i)){	// �Ѿ����ڵ��û���
				break;
			}
		}
		if(i == m_astrUseNames.GetSize())	{
			((CComboBox*)GetDlgItem(IDC_USER_NAME))->InsertString(-1, m_strUserName);
			m_astrUseNames.Add(m_strUserName);
			m_astrPassword.Add(m_strPassWord);
		}
		SaveSettings();
	*/

	if (m_strUserName.IsEmpty()) {
		AfxMessageBox(_T("����д�û�����"));
		return;
	}

	if (m_strPassWord.IsEmpty()) {
		AfxMessageBox(_T("����д���룡"));
		return;
	}

	if (m_strBoardName.IsEmpty() )	{
		AfxMessageBox(_T("��û��ѡ���ϴ����棡"));
		return;
	}
	//m_strBoardName=_T("OurSoftware");

	if (m_astrFilesUpload.GetSize() == 0 && m_strLocalFile.IsEmpty()) {
		AfxMessageBox(_T("��ѡ��Ҫ�ϴ��ı����ļ���"));
		return;
	}

	if (m_strDescription.IsEmpty()) {
		m_strDescription = _T("CTerm");
	}

//	if(m_astrFiles.GetSize() == 0)
//	{
//		m_astrFiles.Add(m_strLocalFile);
//	}
	
	m_listStatus.ResetContent();
	m_nMaxWidth = 0;
	m_listStatus.AddString(_T("����"));
	GetDlgItem(IDC_UPLOAD)->EnableWindow(FALSE);
	m_thdUpload = AfxBeginThread(UploadThread, this);
}


void CPostDlg::OnClose()
{
	/*
		//SaveSettings();

		m_bThreadExit = TRUE;
		if(m_thdUpload)
		{
			if(WaitForSingleObject(m_eventExit, 2000) == WAIT_TIMEOUT)
			{
				// ǿ�н����߳�
				TerminateThread(m_thdUpload->m_hThread, 0);
			}
			m_thdUpload = NULL;
		}
		else
		{
			if(m_bContinuously)
			{
				// ȷ��HTTP������ر�
				AfxBeginThread(UploadThread, this);
				Sleep(200);
			}
		}
		CDialog::OnClose();
	*/
	if (m_strSiteName.Find(_T("whnet")) == -1 && m_strSiteName.Find(_T("byhh")) == -1) {	//����_T("whnet")
		CDialog::OnClose();
	}
}

void CPostDlg::ThreadExit()
{
	m_bThreadExit = FALSE;
	m_thdUpload = NULL;

	if (m_bUpload) {
		GetDlgItem(IDC_UPLOAD)->SetWindowText(_T("�ϴ�(&U)"));
		GetDlgItem(IDC_UPLOAD)->EnableWindow(TRUE);
		GetDlgItem(IDOK)->EnableWindow(TRUE);
	} else {
		m_bUpload = TRUE;
		GetDlgItem(IDC_DELETE)->EnableWindow(TRUE);
	}

	m_bSucceed = FALSE;
}

LRESULT CPostDlg::OnStatusChanged(WPARAM wParam, LPARAM lParam)
{
	CString strStatus((LPCTSTR) wParam);

	if (strStatus.Find(_T("�ϴ�����")) != -1) {
		// ��ʾ����
		int nLastMsg = m_listStatus.GetCount() - 1;
		CString strLastMsg;
		m_listStatus.GetText(nLastMsg, strLastMsg);

		if (strLastMsg.Find(_T("�ϴ�����")) != -1) {
			m_listStatus.DeleteString(nLastMsg);
		}

		//m_listStatus.InsertString(-1, strStatus);
		AddStringToListBox(strStatus);
	} else {
		//m_listStatus.InsertString(-1, strStatus);
		AddStringToListBox(strStatus);
	}

	if (!IsWindowVisible()) {
		NOTIFYICONDATA noticedata;
		noticedata.cbSize = sizeof(NOTIFYICONDATA);
		noticedata.uID = IDR_MAINFRAME;
		noticedata.hIcon = LoadIcon(AfxGetApp()->m_hInstance, MAKEINTRESOURCE(IDR_MAINFRAME));
		noticedata.hWnd = m_hWnd;
		lstrcpyn(noticedata.szTip, (LPCTSTR) wParam, sizeof(noticedata.szTip));
		noticedata.uCallbackMessage = WM_TRAYICON_MESSAGE;
		noticedata.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
		Shell_NotifyIcon(NIM_ADD, &noticedata);
	}

	if (!lParam) {
		// ���ƻƺײ���������
	}

	return 0L;
}

void CPostDlg::OnOneByOne()
{
	m_bContinuously = !m_bContinuously;

	if (!m_bContinuously) {
		m_bThreadExit = TRUE;
		// ȷ��HTTP������ر�
		AfxBeginThread(UploadThread, this);
	}
}


LRESULT CPostDlg::OnNotifyFunc(WPARAM wParam, LPARAM lParam)
{
	if (lParam == WM_LBUTTONDOWN) {
		ShowWindow(SW_SHOW);
		NOTIFYICONDATA noticedata;
		noticedata.cbSize = sizeof(NOTIFYICONDATA);
		noticedata.uID = IDR_MAINFRAME;
		noticedata.hWnd = m_hWnd;
		Shell_NotifyIcon(NIM_DELETE, &noticedata);
	}

	return 0L;
}

void CPostDlg::OnOK()
{
	CDialog::OnOK();
}

void CPostDlg::OnCancel()
{
	m_bThreadExit = TRUE;

	if (m_thdUpload) {
		if (WaitForSingleObject(m_eventExit, 2000) == WAIT_TIMEOUT) {
			TerminateThread(m_thdUpload->m_hThread, 0);		// ǿ�н����߳�
		}

		m_thdUpload = NULL;
	} else {
		if (m_bContinuously) {
			AfxBeginThread(UploadThread, this);	// ȷ��HTTP������ر�
			Sleep(200);
		}
	}
	CDialog::OnCancel();
}


	// ����ҳ����ѡ���ϴ������ַ����δ����Ǵ����Ͽ������ġ���Դ������
/*	CString mystr;
	LPDISPATCH mydoc;
	IPersistStreamInit * test_1;
	IStream *pstream =NULL;
	HGLOBAL hHtmlText;
	char temp_str[5000];
	char url_str[1000];
	//char unicode_str[5000];
	//char gbk_str[5000];

	mydoc = m_web.GetDocument() ;
	mydoc->QueryInterface( IID_IPersistStreamInit ,(void **)&test_1);

	hHtmlText = GlobalAlloc(GMEM_FIXED, 5000);
	CreateStreamOnHGlobal(hHtmlText,TRUE, &pstream);

	test_1->Save(pstream, 1);
	//temp_str������������ݡ�
	memcpy(temp_str, hHtmlText, 5000);

	//���ԣ�д�뵽�ļ��Ķ�
	//CStdioFile tmpFile;
	//tmpFile.Open(_T("temp.txt"), CFile::modeCreate | CFile::modeReadWrite);
	//tmpFile.WriteString(temp_str);
	//tmpFile.Close();

	//�������سɹ�, URLΪ <a href="#" onclick = "copyToClipboard('\nhttp://byhh.net/f/Picture/1323415840/111.jpg \n');">
	//<font color=blue>http://byhh.net/f/Picture/1323415840/111.jpg </font></a>
	char *r1, *r2;
	r1 = strstr(temp_str, ">http");	
	if (r1 != NULL) {
		r1++;
		r2 = strstr(r1, " <");
		if (r2>r1) {
			_tcsncpy(url_str, r1, r2-r1);
			url_str[r2-r1]='\0';
			m_strUploadURLs = m_strUploadURLs+ url_str + "\r\n";
		}
	}
*/	