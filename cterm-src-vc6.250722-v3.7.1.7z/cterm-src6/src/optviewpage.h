#if !defined(AFX_OPTVIEWPAGE_H__5497012C_A871_4A0B_873B_878F0870970B__INCLUDED_)
#define AFX_OPTVIEWPAGE_H__5497012C_A871_4A0B_873B_878F0870970B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OptViewPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptViewPage dialog
#include "MyPropertyPage.h"

class COptViewPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(COptViewPage)

// Construction

public:
	COptViewPage();
	~COptViewPage();
	virtual UINT GetIDD();

// Dialog Data
	//{{AFX_DATA(COptViewPage)
	enum { IDD = IDD_OPT_VIEW };
	CComboBox	m_cbClick;
	BOOL	m_bTabUser;
	BOOL	m_bReadFlag;
	BOOL	m_bHilight;
	int		m_nTabWid;
	int		m_bTabFullName;
	int		m_nMouseMenu;
	int		m_nTermHeight;
	int		m_nTermWidth;
	BOOL	m_bShowCenter;
	BOOL	m_bMaxFullScreen;
	BOOL	m_bMenuFavTop;
	BOOL	m_bShowUserMenu;
	int		m_nCharHWRatio;
	BOOL	m_bTransparent;
	UINT	m_nAlpha;
	//}}AFX_DATA
#if ENABLE_CLEARTYPE
	int		m_nFontQuality;
#endif//ENABLE_CLEARTYPE


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(COptViewPage)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(COptViewPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnTransparent();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTVIEWPAGE_H__5497012C_A871_4A0B_873B_878F0870970B__INCLUDED_)
