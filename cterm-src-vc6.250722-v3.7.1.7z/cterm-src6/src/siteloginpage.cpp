// SiteLoginPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"       // main symbols

#include "SiteLoginPage.h"
#include "const.h"
#include "global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSiteLoginPage property page

IMPLEMENT_DYNCREATE(CSiteLoginPage, CMyPropertyPage)

CSiteLoginPage::CSiteLoginPage() : CMyPropertyPage(CSiteLoginPage::IDD)
{
	//{{AFX_DATA_INIT(CSiteLoginPage)
	m_bEnableSSH = FALSE;
	m_sitename = _T("");
	m_siteport = 0;
	m_siteaddr = _T("");
	m_sitetype = -1;
	m_nTermHeight = DEFAULT_TERM_HEIGHT;
	m_nTermWidth = DEFAULT_TERM_WIDTH;
	m_sTermType = _T("vt100");
	m_bIPV6 = FALSE;
	m_bHttpUpload = FALSE;
	//}}AFX_DATA_INIT
}

CSiteLoginPage::~CSiteLoginPage()
{
}

void CSiteLoginPage::DoDataExchange(CDataExchange* pDX)
{
	CMyPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSiteLoginPage)
	DDX_Check(pDX, IDC_CHK_SSH, m_bEnableSSH);
	DDX_Text(pDX, IDC_SITENAME, m_sitename);
	DDX_Text(pDX, IDC_SITEPORT, m_siteport);
	DDX_Text(pDX, IDC_SITEADDR, m_siteaddr);
	DDX_Radio(pDX, IDC_TYPE_A, m_sitetype);
	DDX_Text(pDX, IDC_EDIT_TERM_HEIGHT, m_nTermHeight);
	DDV_MinMaxInt(pDX, m_nTermHeight, 12, 80);
	DDX_Text(pDX, IDC_EDIT_TERM_WIDTH, m_nTermWidth);
	DDV_MinMaxInt(pDX, m_nTermWidth, 40, 254);
	DDX_Text(pDX, IDC_EDIT_TERMTYPE, m_sTermType);
	DDX_Check(pDX, IDC_CHECK_IPV6, m_bIPV6);
	DDX_Check(pDX, IDC_CHK_HTTP, m_bHttpUpload);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSiteLoginPage, CMyPropertyPage)
	//{{AFX_MSG_MAP(CSiteLoginPage)
	ON_BN_CLICKED(IDC_TYPE_A, OnTypeA)
	ON_BN_CLICKED(IDC_TYPE_B, OnTypeB)
	ON_BN_CLICKED(IDC_TYPE_C, OnTypeC)
	ON_BN_CLICKED(IDC_TYPE_D, OnTypeD)
	ON_BN_CLICKED(IDC_TYPE_E, OnTypeE)
	ON_BN_CLICKED(IDC_TYPE_F, OnTypeF)
	ON_BN_CLICKED(IDC_CHK_SSH, OnChkSSH)
	ON_EN_KILLFOCUS(IDC_SITEADDR, OnKillfocusSiteaddr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSiteLoginPage message handlers


void CSiteLoginPage::OnTypeA()
{
	m_sitetype = 0;
}

void CSiteLoginPage::OnTypeB()
{
	m_sitetype = 1;
}

void CSiteLoginPage::OnTypeC()
{
	m_sitetype = 2;
}

void CSiteLoginPage::OnTypeD()
{
	m_sitetype = 3;
}

void CSiteLoginPage::OnTypeE()
{
	m_sitetype = 4;
}

void CSiteLoginPage::OnTypeF()
{
	m_sitetype = 5;
}

void CSiteLoginPage::OnChkSSH()
{
	UpdateData(TRUE);

	if (m_bEnableSSH)
		m_siteport = SSH_PORT;
	else
		m_siteport = TELNET_PORT;

	UpdateData(FALSE);
}

BOOL CSiteLoginPage::OnInitDialog()
{
	CMyPropertyPage::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG



//	m_sitename	=m_pLogin->m_szProfileName;
//	m_siteaddr	=m_pLogin->m_szAddr;
//	m_siteport	=m_pLogin->m_nPort;
//	m_bEnableSSH=m_pLogin->m_bSSH;
//	m_sitetype	=m_pLogin->m_nSiteType;		//վ������

	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CSiteLoginPage::OnKillfocusSiteaddr()
{
	UpdateData();
	CString proto;
	int port = GetPort(m_siteaddr, proto);

	if (port != 0) {
		m_siteport =  port;
		m_siteaddr = m_siteaddr;
	}

	UpdateData(FALSE);
}

UINT CSiteLoginPage::GetIDD()
{
	return IDD;
}
