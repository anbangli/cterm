#if !defined(AFX_USERPASSDLG_H__D42B5E66_8BAB_4A93_BB26_A36C1E2FFF42__INCLUDED_)
#define AFX_USERPASSDLG_H__D42B5E66_8BAB_4A93_BB26_A36C1E2FFF42__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UserPassDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUserPassDlg dialog

class CTelnetSite;
class CUserPassDlg : public CDialog
{
// Construction

public:
	CUserPassDlg(CWnd* pParent = NULL, CTelnetSite * pSite = NULL);   // standard constructor
	CTelnetSite * m_pSite;

// Dialog Data
	//{{AFX_DATA(CUserPassDlg)
	enum { IDD = IDD_USERPASSDLG };
	CButton	m_okctrl;
	CEdit	m_passctrl;
	CEdit	m_userctrl;
	CString	m_user;
	CString	m_pass;
	BOOL	m_bSave;
	//}}AFX_DATA

	int m_nPassTry;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUserPassDlg)

public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	CToolTipCtrl m_tooltip;

	// Generated message map functions
	//{{AFX_MSG(CUserPassDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnNotask();
	afx_msg void OnChangeUser();
	afx_msg void OnChangePass();
	afx_msg void OnSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USERPASSDLG_H__D42B5E66_8BAB_4A93_BB26_A36C1E2FFF42__INCLUDED_)
