#if !defined(AFX_BATDLG_H__FE5A302B_61EA_4F68_AB79_1935005CFACF__INCLUDED_)
#define AFX_BATDLG_H__FE5A302B_61EA_4F68_AB79_1935005CFACF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BatDlg.h : header file
//
#include "autorun.h"
#include "telnetsite.h" // for CSimpleFilter

struct SBatVar {
	TCHAR nIndex;
	int  nMul;
	int  nAdd;
};

struct SBat {
	BOOL bReplyMode;
	//Reply Mode
	TCHAR szList[100];
	TCHAR szArticle[100];
	TCHAR szEnd[100];
	TCHAR szMenu[100];
#if ENABLE_FILTER
	CSimpleFilter Filter;
#endif//ENABLE_FILTER
	//Normal Mode
	int  nVar;
	SBatVar Var[26];
	int  nStart;
	int  nEnd;
	int  nMilliSecond;
	TCHAR szSend[100];
	//Dynamic
	int  nCount;
	int  nSendAt;

public:
	int GetCount(int n, TCHAR c);
	void DeleteVar(TCHAR c);
	void AddVar(TCHAR c, int m, int n);
	void Load(TCHAR *szFile);
	void Save(TCHAR *szFile);
	void Reset();
};

#define BS_SET 0
#define BS_ANY 1
/////////////////////////////////////////////////////////////////////////////
// CBatDlg dialog

class CBatDlg : public CDialog
{
// Construction
	SBat m_Bat;

public:
	CBatDlg(CWnd* pParent = NULL);   // standard constructor
	CAutoRun     m_Run;
// Dialog Data
	//{{AFX_DATA(CBatDlg)
	enum { IDD = IDD_BAT_DLG };
	CComboBox	m_cbFlag;
	CProgressCtrl	m_prog;
	CListCtrl	m_varlist;
	int		m_nAdd;
	UINT	m_nEnd;
	int		m_nFlag;
	int		m_nMul;
	CString	m_sSend;
	UINT	m_nStart;
	UINT	m_nTime;
	//}}AFX_DATA
	TCHAR    m_szSend[300];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBatDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CBatDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnReplaymode();
	afx_msg void OnSave();
	afx_msg void OnLoad();
	afx_msg void OnAddvar();
	afx_msg void OnDelvar();
	afx_msg void OnUpdatevar();
	afx_msg void OnClickVarList(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void PrepareString(int n);
	void PrepareString(int n, TCHAR *str, TCHAR *m_szSend);
	void ProcessNormal();
	void SendString(TCHAR *);
	void ProcessReply();
	void UpdateList();
	void UpdateMe(BOOL bLoad = TRUE);
	void SetMode();
	int m_WaitCount;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
extern CBatDlg *g_pBat;

#endif // !defined(AFX_BATDLG_H__FE5A302B_61EA_4F68_AB79_1935005CFACF__INCLUDED_)
