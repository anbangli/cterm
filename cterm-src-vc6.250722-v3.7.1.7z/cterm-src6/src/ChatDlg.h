#if !defined(AFX_CHATDLG_H__4BF47649_916D_41AE_8B6F_AFE33C596F2E__INCLUDED_)
#define AFX_CHATDLG_H__4BF47649_916D_41AE_8B6F_AFE33C596F2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ChatDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChatDlg dialog
#define CC_COMMON  0
#define CC_IDONLY  1
#define CC_MSGONLY 2
#define CC_BOTH    3


struct SChatCommand {
	TCHAR szOp[32];
	int  nType;
};

class CCTermView;
class CChatDlg : public CDialog
{
// Construction
	SChatCommand m_Command[200];

public:
	CCTermView *m_pView;
	void AddToList(BYTE *buf, int nLen);
	CChatDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChatDlg)
	enum { IDD = IDD_CHATDLG };
	CListBox	m_comlist;
	CListBox	m_list;
	CString	m_command;
	CString	m_user;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChatDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CChatDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnReload();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkCommandlist();
	afx_msg void OnChangecsf();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BOOL m_bRepload;
	void AddLine(TCHAR *);
};

#if ENABLE_CHATDLG
extern CChatDlg g_wndChat;
#endif//ENABLE_CHATDLG
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHATDLG_H__4BF47649_916D_41AE_8B6F_AFE33C596F2E__INCLUDED_)
