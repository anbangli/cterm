#if !defined(AFX_POSTTITLEDLG_H__998643E8_4E0F_4F7C_A33B_90490CEFE985__INCLUDED_)
#define AFX_POSTTITLEDLG_H__998643E8_4E0F_4F7C_A33B_90490CEFE985__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PostTitleDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPostTitleDlg dialog

class CPostTitleDlg : public CDialog
{
// Construction
public:
	CPostTitleDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPostTitleDlg)
	enum { IDD = IDD_EDIT_TITLE };
	CString	m_inputline;
	int		m_qmd;
	BOOL	m_reply;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPostTitleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPostTitleDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POSTTITLEDLG_H__998643E8_4E0F_4F7C_A33B_90490CEFE985__INCLUDED_)
