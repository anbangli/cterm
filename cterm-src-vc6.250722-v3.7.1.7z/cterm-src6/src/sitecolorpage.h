#if !defined(AFX_SITECOLORPAGE_H__55116D26_5CC9_482A_8A1F_C4179D73BA60__INCLUDED_)
#define AFX_SITECOLORPAGE_H__55116D26_5CC9_482A_8A1F_C4179D73BA60__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SiteColorPage.h : header file
//
#include "MyPropertyPage.h"
/////////////////////////////////////////////////////////////////////////////
// CSiteColorPage dialog

struct SDecodeSet;

class CSiteColorPage : public CMyPropertyPage
{
	DECLARE_DYNCREATE(CSiteColorPage)

// Construction

public:
	SDecodeSet *m_pDecode;
	CSiteColorPage();
	~CSiteColorPage();
	virtual UINT GetIDD();

	COLORREF m_CustColor[16];

// Dialog Data
	//{{AFX_DATA(CSiteColorPage)
	enum { IDD = IDD_SITE_COLOR };
	CString	m_colorfile;
	int		m_nColorSet;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CSiteColorPage)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:
	// Generated message map functions
	//{{AFX_MSG(CSiteColorPage)
	afx_msg void OnSetA();
	afx_msg void OnSetB();
	afx_msg void OnSetC();
	afx_msg void OnSetD();
	afx_msg void OnSetE();
	afx_msg void OnSetF();
	afx_msg void OnSetG();
	afx_msg void OnSetH();
	afx_msg void OnSetZz();
	afx_msg void OnSetI();
	afx_msg void OnC0();
	afx_msg void OnC1();
	afx_msg void OnC2();
	afx_msg void OnC3();
	afx_msg void OnC4();
	afx_msg void OnC5();
	afx_msg void OnC6();
	afx_msg void OnC7();
	afx_msg void OnC8();
	afx_msg void OnC9();
	afx_msg void OnC10();
	afx_msg void OnC11();
	afx_msg void OnC12();
	afx_msg void OnC13();
	afx_msg void OnC14();
	afx_msg void OnC15();
	afx_msg void OnColoropen();
	afx_msg void OnColorsave();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void SetCustColor(int index);
	void DrawColors();
	void GetColorFromFile(CString filename);
	bool m_bNeedRedrawColor;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SITECOLORPAGE_H__55116D26_5CC9_482A_8A1F_C4179D73BA60__INCLUDED_)
