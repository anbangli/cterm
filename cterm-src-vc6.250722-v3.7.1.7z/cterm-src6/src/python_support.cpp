///////////////////////////////////////////////////////////
////		python�ű�֧��
////
#include "stdafx.h"
#include "CTerm.h"
#include "MainFrm.h"
#include "ctermview.h"
#include "paramconfig.h"
#include "global.h"
#include "usermsg.h"

#if ENABLE_PICTURE
#include "PicShowDlg.h" 
#endif//ENABLE_PICTURE

inline void SetScriptInfo(CString sInfo);

bool g_bSysPythonScriptLoaded = false;
bool g_bPythonInited = false;

#if ENABLE_PYTHON

#ifdef _DEBUG
#undef _DEBUG
#include <Python.h>
#define _DEBUG
#else
#include <Python.h>
#endif

#ifdef UNICODE
#define PyString_FromString_T(s, len) PyString_FromString_T(s, len)
#else
#define PyString_FromString_T(s, len) PyString_FromString(s)
#endif

PyObject *PyMy_None = NULL;

/* Macro for returning Py_None from a function */
//#define Py_RETURN_NONE return Py_INCREF(Py_None), Py_None
#define PyMy_RETURN_NONE return Py_INCREF(PyMy_None), PyMy_None


/////////////////////////////////////////////////////////////////////
// ���´���ı�д�ο���qterm-0.3.7��python֧�ִ���
// http://qterm.sourceforge.net
/////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////
///////		begin exposed function to python

/*//��ʾһ����
static PyObject* CTerm_ShowString(PyObject *self, PyObject *args)
{
	char *s="";
	if(PyArg_ParseTuple(args, "|s:ShowString", &s));

	//CString str;
	//str.Format("%s", s);
	AfxMessageBox(s);

	PyMy_RETURN_NONE;
}
*/
//ȡ��i��view ��ID
//����Ϊ-1��δ������ȡ�����
static PyObject* CTerm_GetSessionID(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	int i = -1, nSessionID = -1;

	if (PyArg_ParseTuple(args, "|i:GetSessionID", &i)) {
		if (g_pMainWnd->ChildCount() > 0) {
			if (!(0 <= i && i < g_pMainWnd->ChildCount()))
				i = -1; // nActive
			nSessionID = g_pMainWnd->GetSessionID(i);
		}
	} else
		return NULL;

	if (nSessionID == -1) {
		PyMy_RETURN_NONE;
	} else {
		PyObject *py_ret = Py_BuildValue("i", nSessionID);
		Py_INCREF(py_ret);
		return py_ret;
	}
}

static PyObject* CTerm_GetFilePath(PyObject *self, PyObject *args)
{
	char *s = "";
	PyArg_ParseTuple(args, "|s:GetFilePath", &s);

	CString sExt(_T("�����ļ�(*.*)|*.*||"));

	if (!isempty(s)) {
		sExt = s;
	}

	CFileDialogEx fd(TRUE, _T(""), _T(""), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, sExt);

	if (fd.DoModal() == IDOK) {
		PyObject *py_ret = Py_BuildValue("s", fd.GetPathName());
		Py_INCREF(py_ret);
		return py_ret;
	}

	PyMy_RETURN_NONE;
}

static PyObject* CTerm_SetScriptInfo(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	char *s = NULL;

	if (PyArg_ParseTuple(args, "s:SetScriptInfo", &s)) {
		//SetScriptInfo(s);//ֱ��set�Ƿ�����
		int len = strlen(s);

		if (len <= 5000) {
			//char *str=malloc();
			//strcpy(str, s);
			g_pMainWnd->PostMessage(WM_SET_SCRIPT_INFO, (WPARAM) s, (LPARAM) 0);
		}

		PyMy_RETURN_NONE;
	} else
		return NULL;
}

static PyObject* CTerm_GetSessionNum(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);

	if (!PyArg_ParseTuple(args, ""))
		return NULL;

	PyObject *py_ret = Py_BuildValue("i", g_pMainWnd->ChildCount());

	Py_INCREF(py_ret);

	return py_ret;
}

//NULL ��ʾ����(��������)��Py_None��ʾ���ؿ�(None)����һ��python����

//���·��ǶԴ��ڲ����ģ�����1������δָ�����ں�
//Ĭ�϶Ի���ڽ��в���

//���ش��ڵ�վ������
static PyObject* CTerm_GetSiteType(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetSiteType", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->SiteType());
		Py_INCREF(py_ret);
		return py_ret;
	} else {
		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetSessionName(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetSessionName", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("s", pView->m_Site.m_Login.m_szProfileName);
		Py_INCREF(py_ret);
		return py_ret;
	} else {
		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetWorkDir(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);

	if (!PyArg_ParseTuple(args, ""))
		return NULL;

	PyObject *py_ret = Py_BuildValue("s", g_szWorkDir);

	Py_INCREF(py_ret);

	return py_ret;
}

static PyObject* CTerm_GetScriptDir(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);

	if (!PyArg_ParseTuple(args, ""))
		return NULL;

	PyObject *py_ret = Py_BuildValue("s", g_sScriptDir);

	Py_INCREF(py_ret);

	return py_ret;
}

static PyObject* CTerm_GetHostAddress(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetHostAddress", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("s", pView->m_Site.m_Login.m_szAddr);
		Py_INCREF(py_ret);
		return py_ret;
	} else {
		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetHostPort(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetHostPort", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->m_Site.m_Login.m_nPort);
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetTermWidth(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int i = -1 /*magic number*/, nSessionID = 0;

	if (PyArg_ParseTuple(args, "|i:GetTermWidth", &i)) {
		nSessionID = g_pMainWnd->ValidSessionID(i);
	}
	else {
		return NULL;
	}

	pView = g_pMainWnd->GetView(nSessionID);

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->TermW());
		Py_INCREF(py_ret);
		return py_ret;
	} else {
		PyObject *py_ret = Py_BuildValue("i", g_nTermWidth);    //ȫ��
		Py_INCREF(py_ret);
		return py_ret;
	}
}

static PyObject* CTerm_GetTermHeight(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int i = -1, nSessionID = 0;

	if (PyArg_ParseTuple(args, "|i:GetTermHeight", &i)) {
		nSessionID = g_pMainWnd->ValidSessionID(i);
	} else
		return NULL;

	pView = g_pMainWnd->GetView(nSessionID);

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->TermH());
		Py_INCREF(py_ret);
		return py_ret;
	} else {
		PyObject *py_ret = Py_BuildValue("i", g_nTermHeight);    //ȫ��
		Py_INCREF(py_ret);
		return py_ret;
	}
}

static PyObject* CTerm_GetLoginID(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetLoginID", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("s", pView->m_Site.m_Login.m_szLoginName);
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetLoginPW(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetLoginPW", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("s", pView->m_Site.m_Login.m_szLoginPSW);
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

//���ش��ڵ�״̬
static PyObject* CTerm_GetStatus(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:GetStatus", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", (int)pView->GetStatus());
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

//���ش��ڵ���״̬
static PyObject* CTerm_GetSubStatus(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:GetSubStatus", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->m_Status.SubStatus());
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject *CTerm_CaretX(PyObject *, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:CaretX", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->m_Core.cursorX());
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject *CTerm_CaretY(PyObject *, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:CaretX", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->m_Core.cursorY() - pView->m_Core.MaxStartLine());
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject *CTerm_IsConnected(PyObject *, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:IsConnected", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL) {
		PyObject *py_ret = Py_BuildValue("i", pView->IsStarted());
		Py_INCREF(py_ret);
		return py_ret;
	} else {

		PyMy_RETURN_NONE;
	}
}

static PyObject *CTerm_Disconnect(PyObject *, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:Disconnect", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL && pView->IsStarted()) {
		pView->m_Sock.DisConnect();
	}


	PyMy_RETURN_NONE;
}

static PyObject *CTerm_Reconnect(PyObject *, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0;

	if (PyArg_ParseTuple(args, "i:Reconnect", &n)) {
		pView = g_pMainWnd->GetView(n);
	} else
		return NULL;

	if (pView != NULL && !pView->IsStarted()) {
		pView->ReConnect();
	}

	PyMy_RETURN_NONE;
}

//����1��վ��
//���ֵ��÷�ʽ���൱���������غ���
//��Ӧ��ConnectSite�ĺ������汾
static PyObject *CTerm_ConnectSite(PyObject *, PyObject *args)
{
	CCTermApp *pApp = (CCTermApp *) AfxGetApp();
	char *s = NULL;
	int n = -38427;

	if (PyArg_ParseTuple(args, "s|i:ConnectSite", &s, &n)) {
		if (n == -38427) {
#if ENABLE_ADDRBOOK
			pApp->ConnectSite(CString(s));       //s Ϊվ����(��ַ���е�)
#else
			pApp->ConnectAddr(CString(s), TELNET_PORT);
#endif//ENABLE_ADDRBOOK
		} else
			pApp->ConnectAddr(CString(s), n);       // sΪ��ַ, nΪ�˿�
	} else
		return NULL;

	PyMy_RETURN_NONE;

}


static PyObject* CTerm_GetText(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0, nStart = 0, nEnd = -1, nScrn = 0; //nScrn�ĺ����GetScreenLine˵��

	if (PyArg_ParseTuple(args, "ii|ii:GetText", &n, &nStart, &nEnd, &nScrn)) {
		pView = g_pMainWnd->GetView(n);     //������������1��ָ�����ڣ���2��ָ���к�
	} else
		return NULL;

	if (nEnd == -1)
		nEnd = nStart;

//TRACE(_T("in CTerm_GetText\n"));
//TRACE(_T("\t start, end %d:%d\n"), nStart, nEnd);
	if (pView != NULL && pView->IsStarted() && nStart >= 0 && nEnd < pView->TermH() && nEnd >= nStart) {
		TCHAR* buf = (TCHAR*) malloc((pView->TermW() + 3) * (nEnd - nStart + 1));

		if (buf) {
			//int len=
			pView->m_Core.GetScreenLine(buf, nStart, nEnd, nScrn);    //���в�Ҫɾ����
//TRACE(_T("\t buf: %s\n"), buf);

			//char *str;
			//char *s=GetANSIStr(buf, str);
			PyObject *py_ret = PyString_FromString_T(buf, len);
			//safe_delete(s);

			free(buf);

			Py_INCREF(py_ret);
			return py_ret;
		}
	}

//else ....
	{
//TRACE(_T("\t here: start, end %d:%d\n"), nStart, nEnd);

		PyMy_RETURN_NONE;
	}
}

static PyObject* CTerm_GetAttrText(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = 0, nStart = 0, nEnd = -1;

	if (PyArg_ParseTuple(args, "ii|i:GetText", &n, &nStart, &nEnd)) {
		pView = g_pMainWnd->GetView(n);     //������������1��ָ�����ڣ���2��ָ���к�
	} else
		return NULL;

	if (nEnd == -1)
		nEnd = nStart;

	if (pView != NULL && pView->IsStarted() && nStart >= 0 && nEnd < pView->TermH() && nEnd >= nStart) {
		TCHAR* buf = (TCHAR*) malloc(643 * (nEnd - nStart + 1));

		if (buf) {
			//int len=
			pView->m_Core.ChangeToTxt(buf, CRect(0, nStart, pView->TermW(), nEnd));       //���в�Ҫɾ��

			PyObject *py_ret = PyString_FromString_T(buf, len);

			free(buf);

			Py_INCREF(py_ret);
			return py_ret;
		}
	}

	{

		PyMy_RETURN_NONE;
	}
}

//ע��: �ű���ִ�еĵ��ò��ܷ�������, ������Ļ�ı�
static PyObject* CTerm_GetSelectText(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;

	if (PyArg_ParseTuple(args, "i:GetSelectText", &n)) {
		pView = g_pMainWnd->GetView(n);
	} 
	else {
		return NULL;
	}

	if (pView != NULL) {
		TCHAR buf[8000] = _T("");
		pView->Copy(buf, true);
		PyObject *py_ret = Py_BuildValue("s", buf);
		Py_INCREF(py_ret);
		return py_ret;
	}
	else {
		PyMy_RETURN_NONE;
	}
}

//��������
static PyObject* CTerm_SendString(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;
	char *s = "";

	if (PyArg_ParseTuple(args, "is:SendString", &n, &s)) {
		pView = g_pMainWnd->GetView(n);	//������������1��ָ�����ڣ���2���Ǵ�
	} else
		return NULL;

	if (pView != NULL && pView->IsStarted()) {
		pView->Send(s, strlen(s));
	}


	PyMy_RETURN_NONE;
}

//��������������
static PyObject* CTerm_SendParsedString(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView = NULL;
	int n = -1;
	char *s = "";

	if (PyArg_ParseTuple(args, "is:SendParsedString", &n, &s)) {
		pView = g_pMainWnd->GetView(n);	//1����������//������������1��ָ�����ڣ���2���Ǵ�
	} else
		return NULL;

	if (pView != NULL && pView->IsStarted()) {
		CString str = TranslateString(CString(s));
		pView->Send(str.GetBuffer(0), str.GetLength());
		str.ReleaseBuffer();
	}


	PyMy_RETURN_NONE;
}

int AllowCmds[] = {ID_OPEN_URL, ID_FASTAWAY, ID_RIGHTCODE, ID_EDIT_DLG, ID_FILE_AGAIN, ID_EDIT_COPYANSI, ID_EDIT_PASTEANSI, ID_LEAVE, ID_DOWNLOAD_TOOL,
                   ID_FILE_CLOSE, ID_APP_EXIT, ID_EDIT_COPY, ID_EDIT_PASTE, ID_TEST, ID_CTRL_TAB, ID_BBS_POST, ID_BBS_SEARCH, ID_BBS_FULLTEXT, ID_TOOL_PICBOX,
                   ID_UPONEFILE
                  };
bool IsAllowCmd(int n)
{
	int len = sizeof(AllowCmds) / sizeof(int);

	if (ID_FAVORITESITE1 <= n && n < ID_FAVORITESITE1 + MAX_FAVORITE_NUM)
		return true;

	if (ID_SWITCH_VIEW_FIRST <= n && n <= ID_SWITCH_VIEW_FIRST + 9)
		return true;

	for (int i = 0; i < len; i++) {
		if (AllowCmds[i] == n)
			return true;
	}

	return false;
}

#if ENABLE_PICTURE
static PyObject* CTerm_GetPicture(PyObject *self, PyObject *args)
{
	char *url = NULL;//not ready for unicode?
	char *extinfo = NULL;

	if (PyArg_ParseTuple(args, "s|s:GetPicture", &url, &extinfo))
	{
		if (!isempty(url) && g_pPicShowDlg) {
			PICSTRUCT *pic = new PICSTRUCT;
			pic->strURL = url;

			TRACE("WM_PICTURE 14\n");

			if (extinfo) {
				pic->sExtInfo = extinfo;
			}

			g_pPicShowDlg->PostMessage(WM_PICTURE, (WPARAM)(pic), (LPARAM) FLAG_PIC_NEW);
		}
	} else
		return NULL;


	PyMy_RETURN_NONE;
}
#endif//ENABLE_PICTURE

// ִ��CTerm����(����������Ϣ)
static PyObject* CTerm_SendCommand(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	int n = -1;

	if (PyArg_ParseTuple(args, "i:SendCommand", &n)) {
		if (IsAllowCmd(n)) {
			g_pMainWnd->PostMessage(WM_COMMAND, (WPARAM)n, (LPARAM) 0);
		}
	} else
		return NULL;


	PyMy_RETURN_NONE;
}

static PyObject* CTerm_AntiIdleTime(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	int i = -1;

	if (!PyArg_ParseTuple(args, "|i:AntiIdleTime", &i))
		return NULL;

	extern int g_nIdleTime;

	if (i == -1) {   //get idletime
		PyObject *py_ret = Py_BuildValue("i", g_nIdleTime);
		Py_INCREF(py_ret);
		return py_ret;
	} else if (i > 0 && i < 3600) {   //set idlestring
		g_nIdleTime = i;
	}

	PyMy_RETURN_NONE;
}

static PyObject* CTerm_AntiIdleString(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	char *s = NULL;
	CCTermView *pView = NULL;
	int n = -1;

	if (!PyArg_ParseTuple(args, "i|s:AntiIdleString", &n, &s))
		return NULL;

	if (s == NULL) {
		//get idlestring
		CString s = g_pMainWnd->AntiIdleString(n);
		PyObject *py_ret = Py_BuildValue("s", s);
		Py_INCREF(py_ret);
		return py_ret;
	} else if (!isempty(s)) {
		//set idlestring
		g_pMainWnd->SetAntiIdleString(n, s);
	}

	PyMy_RETURN_NONE;
}

static PyObject* CTerm_SetAutoReply(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	char *s = NULL;

	if (!PyArg_ParseTuple(args, "|s:SetAutoReply", &s))
		return NULL;

	g_pMainWnd->SetAutoReply(s);

	PyMy_RETURN_NONE;
}

// ȡ���ñ���
// ������
static PyObject* CTerm_GetConfigInt(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	char *varname = NULL;

	if (!PyArg_ParseTuple(args, "s:GetConfigInt", &varname))
		return NULL;

	CCTermApp *pApp = (CCTermApp *) AfxGetApp();

	int val = pApp->GetProfileInt(_T("Setup"), varname, 1);

	PyObject *py_ret = Py_BuildValue("i", val);

	Py_INCREF(py_ret);

	return py_ret;
}

// �¿��߳�����һ��python����
/*static PyObject* CTerm_RunPythonCode(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView=NULL;
	int n=-1;
	char *s="";
	if(PyArg_ParseTuple(args, "is:RunPythonCode", &n, &s))
	{
		pView=g_pMainWnd->GetView(n);
	}
	else
        return NULL;

	if(pView!=NULL && s[0]!=0)
	{
		RunPythonCode(s, n);
	}

	PyMy_RETURN_NONE;
}
// �¿��߳�����һpython�ű�
static PyObject* CTerm_RunPythonFile(PyObject *self, PyObject *args)
{
	ASSERT(g_pMainWnd);
	CCTermView *pView=NULL;
	int n=-1;
	char *s="";
	if(PyArg_ParseTuple(args, "is:RunPythonFile", &n, &s))
	{
		pView=g_pMainWnd->GetView(n);
	}
	else
        return NULL;

	if(pView!=NULL && s[0]!=0)
	{
		g_pMainWnd->RunPythonScript(s, n);
	}

	PyMy_RETURN_NONE;
}*/
//////////////////////////////////////////////////////////////////
//				Pythons Embedding: build-in module CTerm
//////////////////////////////////////////////////////////////////
static PyMethodDef CTerm_Methods[] = {
//	{"showString"),			(PyCFunction)CTerm_ShowString,				METH_VARARGS,	"get text at line#"},

	{"GetSessionID",	(PyCFunction) CTerm_GetSessionID,			METH_VARARGS,	"get session ID"},
	{"GetSessionNum",	(PyCFunction) CTerm_GetSessionNum,			METH_VARARGS,	"get session number"},
	{"SetScriptInfo",	(PyCFunction) CTerm_SetScriptInfo,			METH_VARARGS,	"set statusbar info"},

	{"GetWorkDir",	(PyCFunction) CTerm_GetWorkDir,				METH_VARARGS,	"get cterm working dir"},
	{"GetScriptDir",	(PyCFunction) CTerm_GetScriptDir,			METH_VARARGS,	"get python script dir"},
	{"GetSiteType",	(PyCFunction) CTerm_GetSiteType,				METH_VARARGS,	"get site type"},
	{"GetSessionName",	(PyCFunction) CTerm_GetSessionName,			METH_VARARGS,	"get session name (site name in addressbook)"},
	{"GetHostAddress",	(PyCFunction) CTerm_GetHostAddress,			METH_VARARGS,	"getHostAddress"},
	{"GetHostPort",	(PyCFunction) CTerm_GetHostPort,				METH_VARARGS,	"getHostPort"},
	{"GetLoginID",	(PyCFunction) CTerm_GetLoginID,				METH_VARARGS,	"getLoginID"},
	{"GetLoginPW",	(PyCFunction) CTerm_GetLoginPW,				METH_VARARGS,	"getLoginPW"},
	{"GetTermWidth",	(PyCFunction) CTerm_GetTermWidth,			METH_VARARGS,	"GetTermWidth"},
	{"GetTermHeight",	(PyCFunction) CTerm_GetTermHeight,			METH_VARARGS,	"GetTermHeight"},
	{"GetConfigInt",	(PyCFunction) CTerm_GetConfigInt,			METH_VARARGS,	"GetConfigInt"},

	{"GetStatus",	(PyCFunction) CTerm_GetStatus,				METH_VARARGS,	"get status"},
	{"GetSubStatus",	(PyCFunction) CTerm_GetSubStatus,			METH_VARARGS,	"get substatus"},

	{"GetText",	(PyCFunction) CTerm_GetText,				METH_VARARGS,	"get text at line#"},
	{"GetSelectText",	(PyCFunction) CTerm_GetSelectText,		METH_VARARGS,	"getSelectText"},
	{"GetAttrText",	(PyCFunction) CTerm_GetAttrText,			METH_VARARGS,	"get attr text (with ANSI code) at line#"},

	{"SendString",	(PyCFunction) CTerm_SendString,			METH_VARARGS,	"send string to server"},
	{"SendParsedString", (PyCFunction) CTerm_SendParsedString,	METH_VARARGS,	" translate and send a string / send string with escape"},
	{"AntiIdleString",	(PyCFunction) CTerm_AntiIdleString,		METH_VARARGS,	" get / set the antiIdle string"},
	{"AntiIdleTime",	(PyCFunction) CTerm_AntiIdleTime,		METH_VARARGS,	" get / set the antiIdle tile"},

	{"CaretX",	(PyCFunction) CTerm_CaretX,				METH_VARARGS,	"caret x"},
	{"CaretY",	(PyCFunction) CTerm_CaretY,				METH_VARARGS,	"caret y"},

//	{"FormatError"),		(PyCFunction)CTerm_FormatError,			METH_VARARGS,	"get the traceback info"},
//	{"CopyArticle"),		(PyCFunction)CTerm_CopyArticle,			METH_VARARGS,	"copy current article"},
//	{"columns"),			(PyCFunction)CTerm_Columns,				METH_VARARGS,	"screen width"},
//	{"rows"),			(PyCFunction)CTerm_Rows,				METH_VARARGS,	"screen height"},
//	{"RunPythonCode",	(PyCFunction)CTerm_RunPythonCode,		METH_VARARGS,	"Run python code in a new thread"},
//	{"RunPythonFile",	(PyCFunction)CTerm_RunPythonFile,		METH_VARARGS,	"Run python file in a new thread"},

	{"IsConnected",	(PyCFunction) CTerm_IsConnected,			METH_VARARGS,	"connected to server or not"},
	{"Disconnect",	(PyCFunction) CTerm_Disconnect,			METH_VARARGS,	"disconnect from server"},
	{"Reconnect",	(PyCFunction) CTerm_Reconnect,			METH_VARARGS,	"reconnect"},
	{"ConnectSite",	(PyCFunction) CTerm_ConnectSite,			METH_VARARGS,	"ConnectSite"},

	{"SendCommand",	(PyCFunction) CTerm_SendCommand,			METH_VARARGS,	"Send a command to CTerm"},
#if ENABLE_PICTURE
	{"GetPicture",	(PyCFunction) CTerm_GetPicture,			METH_VARARGS,	"Get and show a picture"},
#endif//ENABLE_PICTURE
	{"SetAutoReply",	(PyCFunction) CTerm_SetAutoReply,			METH_VARARGS,	"Set auto reply string or disable it"},

	{"GetFilePath",	(PyCFunction) CTerm_GetFilePath,			METH_VARARGS,	"Show a open file dialog and return path selected"},

	{NULL,	(PyCFunction) NULL, 						0, 				NULL}
};

///////		end exposed function to python
/////////////////////////////////////////////////

PyThreadState *mainThreadState = NULL;
PyObject *g_pModule = NULL, *g_pDict = NULL;

// ����״̬���ű���Ϣ
inline void SetScriptInfo(CString sInfo)
{
	SetStatusBar(ID_INDICATOR_SCRIPT, sInfo);
}

inline void SetScriptInfo(UINT id)
{
	SetStatusBar(ID_INDICATOR_SCRIPT, g_LoadString(id));
}

//��ΪDELAYLOAD�Ĺ�ϵ��Ҫ��__try����dllδ�ҵ�������
//�����__try����һ�������ĺ������������Compiler Error C2712:
// cannot use __try in functions that require object unwinding
bool TryInitPython()
{
	// Wrap all calls to delay-load DLL functions inside an SEH
	// try-except block
	__try {
	//	Py_NoSiteFlag = 1;
		Py_Initialize();
	}
	__except(EXCEPTION_EXECUTE_HANDLER) {
		// Prepare to exit elegantly
////#ifdef _DEBUG
////		e->ReportError();
////#endif
////		e->Delete();
		return false;
	}

	return true;
}

// from qterm-0.3.7 main() and QTermWindow::QTermWindow()
void InitPython()
{
	if (g_bPythonInited)
		return;

	if (!g_bEnablePython) {
		//SetScriptInfo(IDS_PY_NOT_INIT);  //Pythonδ��ʼ��
		return;
	}

	//SetEnvironmentVariable( "PYTHONPATH"), "" );
//	HKEY hKey;
//
//	LONG Ret = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
//	                        _T("SOFTWARE\\Python\\PythonCore\\2.7\\PythonPath"),
//	                        0,
//	                        KEY_READ | KEY_WRITE,
//	                        &hKey);
//
//	if (Ret == ERROR_SUCCESS) {
//		char buf[256] = "";
//		DWORD type, len = 256;
//		RegQueryValueEx(hKey, NULL, 0, &type, (LPBYTE)(buf), &len);
//
//		if (strstr(buf, "DLLs;") != buf) {
//			// ������"DLLs;"��ͷ...���ܻ������
//			CString s("DLLs;");
//			s += buf;
//			RegSetValueEx(hKey, NULL, 0, REG_SZ, (LPBYTE) s.GetBuffer(1), s.GetLength());
//			s.ReleaseBuffer();
//		}
//
//		RegCloseKey(hKey);
//	}


	//Py_NoSiteFlag = 1; //int Py_NoSiteFlag; /* Suppress 'import site' */ 	//
	//if (!Py_NoSiteFlag)
	//	initsite(); /* Module site */

	if (!TryInitPython()) {
		SetScriptInfo(IDS_PY_FAIL_INIT);   //module not found, �ӳټ���û���ҵ�pythonxx.DLL
		return;
	}

	// initialize thread support
	PyEval_InitThreads();

	g_bPythonInited = true;

	mainThreadState = NULL;

	// save a pointer to the main PyThreadState object
	mainThreadState = PyThreadState_Get();

	// add path
	PyRun_SimpleString("import sys\n");
	PyRun_SimpleString("NoSiteFlag = 1\n");

	// pathLib/script

	// ����ض���(������import sys֮��)
	if (g_bPythonLog) {
		// �����ļ�
		PyRun_SimpleString("logfile=open('temp\\python.log','w')\nsys.stdout=logfile\nsys.stderr=logfile\n");
	}
	else {
		// �����ض��򵽿���̨�������ȴ򿪲�����ʾ��
		PyRun_SimpleString("sys.stdout=open('CONOUT$', 'w', 0)\nsys.stderr=sys.stdout\n");
	}


	//CString g_szWorkDir1 = g_szWorkDir.Left(g_szWorkDir.GetLength() - 1); // ȥ��ĩβ�ķ�б��
	//g_szWorkDirϵͳ�Ѿ�Ĭ�ϼӵ�·������
	CString pathCmd;
	pathCmd.Format(_T("sys.path.extend([r'.', r'%sLib', r'%sDLLs', r'%slib\\site-packages', r'%slib\\site-packages\\PIL', r'%s'])"),
	               g_szWorkDir, g_szWorkDir, g_szWorkDir, g_szWorkDir, g_sScriptDir);
	PyRun_SimpleString(pathCmd);
	PyRun_SimpleString("print 'sys.path:'\nprint sys.path");//temply

	// release the lock
	PyEval_ReleaseLock(); //��֣����ͷ�������

// python thread module
	// get the global python thread lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState
	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PyImport_AddModule("CTerm");

	Py_InitModule4("CTerm", CTerm_Methods,
	               NULL, (PyObject*) NULL, PYTHON_API_VERSION);

//	PyObject* pMainModule=PyImport_ImportModule("__main__");
//	PyObject* pMainDict=PyModule_GetDict(pMainModule);
//	Py_DECREF(pMainModule);
//	PyObject* pObjName = PyString_FromString("logfile");
//	PyObject* pLogFile = PyDict_GetItem(pMainDict, pObjName);
//	Py_DECREF(pObjName);

//	PyRun_String("print __name__\nprint 'after importing __main__'\nprint globals().keys()", Py_file_input, pMainDict, 0);

//	PyObject* pBuildInModule=PyImport_ImportModule("__builtin__");
//	PyObject* pBuildInDict=PyModule_GetDict(pBuildInModule);
//	PyRun_String("print __name__\nprint 'after importing __builtin__'\nprint globals().keys()", Py_file_input, pBuildInDict, 0);
//	PyRun_SimpleString("print __name__\nprint globals()");

	//load the system wide script
	PyObject *pName = PyString_FromString("globals");
	g_pModule = PyImport_Import(pName);
	Py_DECREF(pName);
	
	if ((g_pModule != NULL) && (g_pDict = PyModule_GetDict(g_pModule)) != NULL) {
		g_bSysPythonScriptLoaded = true;
	} else {
		PyErr_Print();
		
		if (g_pModule == NULL)
			TRACE("Failed to PyImport_Import\n");
		
		if (g_pDict == NULL)
			TRACE("Failed to PyModule_GetDict\n");
		
		g_bSysPythonScriptLoaded = false;
	}

	PyMy_None = Py_BuildValue("");   //None

	//create a global event
//	PyRun_SimpleString("import threading");
//	PyRun_SimpleString("greenlight=threading.Event()");

	//Clean up this thread's python interpreter reference
	PyThreadState_Swap(NULL);
	PyThreadState_Clear(myThreadState);
	PyThreadState_Delete(myThreadState);
	PyEval_ReleaseLock();

	SetScriptInfo((g_bPythonInited && g_bSysPythonScriptLoaded) ? IDS_PY_INITED : IDS_PY_FAIL_INIT);
}

// from qterm-0.3.7 main() and QTermWindow::QTermWindow()
void FinalizePython()
{
	if (!g_bPythonInited)
		return;

	// get the global python thread lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState
	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

//	PyRun_SimpleString("logfile.close()\n");

	//Displose of current python module so we can reload in constructor.
	if (g_pModule != NULL)
		Py_DECREF(g_pModule);

	//Clean up this thread's python interpreter reference
	PyThreadState_Swap(NULL);

	PyThreadState_Clear(myThreadState);

	PyThreadState_Delete(myThreadState);

	PyEval_ReleaseLock();

	// shut down the interpreter
	mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PyEval_AcquireLock();

	Py_Finalize();

	g_bPythonInited = false;

	mainThreadState = NULL;

	g_bSysPythonScriptLoaded = false;

	g_pModule = NULL;

	g_pDict = NULL;
}

// �����ص��������صĽ���������ڻص���������(������)
// ��������caller�ṩ�Ŀռ�
// ֻ����PythonCallback�ڲ�����
bool ProcessPythonCallbackResult(const char *func, PyObject *Py_Result, void *pResult)
{
	if (pResult == NULL)
		return false;

	if (strcmp(func, "OnParseURL") == 0) {
		SURLInfo *purlinfo = (SURLInfo *) pResult;
		PyObject* pItem = NULL;
		char *s = NULL;
		int n = PyTuple_Size(Py_Result);
		// (URL, x0, x1, nType, bIP, IP, bPicture)

		if (n > 0) {
			do {
				pItem = PyTuple_GetItem(Py_Result, 0);   //URL
				s = PyString_AsString(pItem);

				if (s == NULL || strlen(s) > 400)
					return false;
				else
					strcpy(purlinfo->szURL, s);

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 1);   //x0 �뿪x���󣬸�����:-239 ~ 0���

				purlinfo->x0 = PyInt_AsLong(pItem);

				if (0 < purlinfo->x0 || purlinfo->x0 < -239) /*magic number*/
					return false;

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 2);   //x1 �뿪x���ң�������:1 ~ 240 ���

				purlinfo->x1 = PyInt_AsLong(pItem);

//				if( 0>=( purlinfo->x1 - purlinfo->x0 )
//					|| ( purlinfo->x1 - purlinfo->x0 )>240) //���3��
//					return false;
				if (1 > purlinfo->x1
				        || purlinfo->x1 > 240)  //���3��
					return false;

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 3);   //type

				purlinfo->nType = PyInt_AsLong(pItem);

				if (0 > purlinfo->nType || purlinfo->nType > 3)   //0:url 1:email 2:proxy
					return false;

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 4);   //bIP

				purlinfo->bIP = PyInt_AsLong(pItem);

				if (--n <= 0) break;

				if (purlinfo->bIP) {
					pItem = PyTuple_GetItem(Py_Result, 5);   //ip
					s = PyString_AsString(pItem);

					if (s == NULL || strlen(s) > 15)
						return false;
					else
						strcpy(purlinfo->szIP, s);
				}

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 6);   //ext

				s = PyString_AsString(pItem);

				if (s == NULL || strlen(s) > MAX_EXT)      //'' .z .class
					return false;
				else
					strncpy(purlinfo->szExt, s, MAX_EXT);

				if (--n <= 0) break;

				pItem = PyTuple_GetItem(Py_Result, 7);   //bPicture

				purlinfo->bPicture = PyInt_AsLong(pItem);

				break; //�ٶ����
			} while (false);
		} else
			return false;

		return true;
	} else if (strcmp(func, "OnGetStatus") == 0) {
		int *pStatus = (int*) pResult, *pSub = ((int*) pResult) + 1;
		PyObject* pItem = NULL;
		int n = PyTuple_Size(Py_Result);
		// (status, substatus)

		if (n > 0) {
			pItem = PyTuple_GetItem(Py_Result, 0);
			*pStatus = PyInt_AsLong(pItem);

			if (n > 1) {
				pItem = PyTuple_GetItem(Py_Result, 1);
				*pSub = PyInt_AsLong(pItem);
			}
		} else
			return false;

		return true;
	} else if (strcmp(func, "OnGetMessage") == 0) {
#if ENABLE_MESSAGE
		CMessage* pMes = (CMessage*) pResult;
		PyObject* pItem = NULL;
		int n = PyTuple_Size(Py_Result);
		// (id, message)

		if (n > 1) {
			char *s = NULL;
			pItem = PyTuple_GetItem(Py_Result, 0);
			s = PyString_AsString(pItem);

			if (s == NULL || strlen(s) > 20)
				return false;
			else
				strcpy(pMes->szUserName, s);

			pItem = PyTuple_GetItem(Py_Result, 1);

			s = PyString_AsString(pItem);

			if (s == NULL || strlen(s) > 12*MAX_TERM_WIDTH)
				return false;
			else
				strcpy(pMes->szMes, s);

			return true;
		} else
			return false;

#else
		return false;

#endif//ENABLE_MESSAGE
	} else if (strcmp(func, "OnKeyDown") == 0) {
		PyObject* pItem = NULL;
		int n = PyTuple_Size(Py_Result);

		if (n > 0) {
			pItem = PyTuple_GetItem(Py_Result, 0);
			*((int*) pResult) = PyInt_AsLong(pItem);
		} else
			return false;

		return true;
	} else if (strcmp(func, "GetArticleTitle") == 0) {
		CString ** p = (CString **) pResult;

		if (!p) return false;

		CString *pStr = (CString *)(*p);

		if (!pStr) return false;

		CString &title = *pStr;

		p++;

		pStr = (CString *)(*p);

		if (!pStr) return false;

		CString &author = *pStr;

		PyObject* pItem = NULL;

		int n = PyTuple_Size(Py_Result);

		// (title, author)
		if (n > 1) {
			char *s = NULL;
			pItem = PyTuple_GetItem(Py_Result, 0);
			s = PyString_AsString(pItem);

			if (s == NULL)
				return false;
			else
				title = s;

			pItem = PyTuple_GetItem(Py_Result, 1);

			s = PyString_AsString(pItem);

			if (s == NULL)
				return false;
			else
				author = s;

			return true;
		} else
			return false;
	}

	return false; //�������˽�����ұ���ȷ����������true�����򷵻�false���˷���ֵ�󲿷�callback��������
}

// from qterm-0.3.7 QTermWindow::pythonCallback()
// �ص���������һ�����������Ͳ���������������pnArgs������
// pResult���ڽ���callback�������صĽ�����ɵ����߷���ռ�
bool CMainFrame::PythonCallback(const char* func, const long* pnArgs, BYTE nArgc, void* pResult)
{
	if (!g_bEnablePython || !g_bSysPythonScriptLoaded)
		return false;

	bool bRet = false;

	// get the global lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState

	//Python thread references
	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PyObject *pF = PyString_FromString(func);

	PyObject *pFunc = PyDict_GetItem(g_pDict, pF);

	Py_DECREF(pF);

	PyObject *pValue = NULL;

	if (pFunc && PyCallable_Check(pFunc)) {
		PyObject *pArgs = NULL;

		if (pnArgs != NULL && nArgc > 0) {
			pArgs = PyTuple_New(nArgc);

			for (int i = 0; i < nArgc; i++) {
				pValue = PyInt_FromLong(pnArgs[i]);
				PyTuple_SetItem(pArgs, i, pValue);
			}

			pValue = PyObject_CallObject(pFunc, pArgs);

			Py_DECREF(pArgs);
		} else {
			pValue = PyObject_CallObject(pFunc, NULL);
		}

		if (pValue != NULL) {
			if (pValue != PyMy_None) {
				bRet = true;
			}
		} else {
			PyErr_Print();
			TRACE("Python script error in callback function: %s\n", func);
		}

	} else {
		PyErr_Print();
	}

	// finish python executing
	// process result
	if (bRet && pResult) {
		bRet = ProcessPythonCallbackResult(func, pValue, pResult);
		Py_DECREF(pValue);    //��Py_DECREF����rfn=0, pItemҲ�͸���ʧЧ��
	}

	// swap my thread state out of the interpreter
	PyThreadState_Swap(NULL);

	// clear out any cruft from thread state object
	PyThreadState_Clear(myThreadState);

	// delete my thread state object
	PyThreadState_Delete(myThreadState);

	// release the lock
	PyEval_ReleaseLock();

	return bRet;
}

// from qterm-0.3.7 QTermWindow::runScriptFile()
void CMainFrame::RunPythonScript(const char *filename, int nSessionID)
{
	if (!g_bEnablePython || !g_bSysPythonScriptLoaded)
		return;

	SetScriptInfo(IDS_PY_RUN_SCRIPT);

	char str[32];

	_stprintf(str, "%ld", nSessionID);

	char *argv[2] = {str, NULL};

	// get the global python thread lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState
	extern PyThreadState *mainThreadState;

	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PySys_SetArgv(1, argv);

	// todo: д�ɺ�����toAbsolutePath
	CString file(filename);

	if (file.Find('\\') != -1) {
		if (file[1] != ':' && file[0] != '\\') {
			// ���·�� ���Ϲ���Ŀ¼
			file = g_szWorkDir + file;
		}
	} else {
		// ֻ���ļ�����Ĭ����script��
		file = g_sScriptDir + "\\" + file;
	}

	RunPythonFile(file.LockBuffer());

	file.UnlockBuffer();

	//Clean up this thread's python interpreter reference
	PyThreadState_Swap(NULL);
	PyThreadState_Clear(myThreadState);
	PyThreadState_Delete(myThreadState);
	PyEval_ReleaseLock();
}

// from qterm-0.3.7 QTermWindow::runPythonFile()
// ֻ��RunPythonScript����
int CMainFrame::RunPythonFile(const char *filename)
{
	/* Have to do it like this. PyRun_SimpleFile requires you to pass a
	  * stdio file pointer, but Vim and the Python DLL are compiled with
	  * different options under Windows, meaning that stdio pointers aren't
	  * compatible between the two. Yuk.
	  *
	  * Put the string "execfile('file')" into buffer. But, we need to
	  * escape any backslashes or single quotes in the file name, so that
	  * Python won't mangle the file name.
	  * ---- kafa
	  */
	char buffer[1024] = "";
	CString sInfo1, sInfo2;
	sInfo1.LoadString(IDS_PY_ERROR);
	sInfo2.LoadString(IDS_PY_FINISH);


	_stprintf(buffer,
	          "import thread,re,string,sys,traceback,CTerm\n\n"
//		"print 'starting thread to exec file'\n"
	          "def work_thread():\n"
//		"\tprint 'in work_thread()'\n"
//		"\tprint globals().keys()\n"
//		"\tprint greenlight\n"
	          "\ttry:\n"
	          "\t\texecfile(r'%s')\n"
	          "\texcept:\n"
	          "\t\texc, val, tb = sys.exc_info()\n"
	          "\t\tlines = traceback.format_exception(exc, val, tb)\n"
	          "\t\terr = string.join(lines)\n"
	          "\t\tprint err\n"
	          "\t\tSetScriptInfo('%s'+err)\n"
	          "\t\tsys.exit()\n\n"
	          "\tSetScriptInfo('%s')\n"
	          "thread0=thread.start_new_thread(work_thread, ())\n"
//		"print logfile\n"
//		"logfile.flush()\n"
	          "\n", filename, sInfo1, sInfo2);

//	int l=strlen(buffer);

	PyRun_String(buffer, Py_file_input, g_pDict, 0);   //g_pDict->0, ��������ִ��
//	PyRun_SimpleString(buffer);

	return 0;
}

void RunPythonScriptNoThread(const char *filename, int nSessionID)
{
	if (!g_bEnablePython || !g_bSysPythonScriptLoaded)
		return;

	SetScriptInfo(IDS_PY_RUN_SCRIPT);

	char str[32];

	_stprintf(str, "%ld", nSessionID);

	char *argv[2] = {str, NULL};

	// get the global python thread lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState
	extern PyThreadState *mainThreadState;

	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PySys_SetArgv(1, argv);

	char buffer[100] = "";

	CString sInfo1, sInfo2;

	sInfo1.LoadString(IDS_PY_ERROR);

	sInfo2.LoadString(IDS_PY_FINISH);


	_stprintf(buffer,
	          "import CTerm\n\n"
	          "try:\n"
	          "\texecfile(r'%s')\n"
	          "except:\n"
	          "\texc, val, tb = sys.exc_info()\n"
	          "\tlines = traceback.format_exception(exc, val, tb)\n"
	          "\terr = string.join(lines)\n"
	          "\tprint err\n"
	          "\tSetScriptInfo('%s'+err)\n"
	          "\tsys.exit()\n\n"
	          "SetScriptInfo('%s')\n"
	          "\n", filename, sInfo1, sInfo2);

	PyRun_String(buffer, Py_file_input, g_pDict, 0);

	//Clean up this thread's python interpreter reference
	PyThreadState_Swap(NULL);

	PyThreadState_Clear(myThreadState);

	PyThreadState_Delete(myThreadState);

	PyEval_ReleaseLock();

}

//int InvokePythonFunc ( int argc, char *argv[] )
//{
//	PyObject *pName, *pModule, *pDict, *pFunc;
//	PyObject *pArgs, *pValue;
//	int i;
//
//	if ( argc < 3 )
//	{
//		_ftprintf ( stderr, "Usage: call pythonfile funcname [args]\n" );
//		return 1;
//	}
//
////	Py_NoSiteFlag = 1; //int Py_NoSiteFlag; /* Suppress 'import site' */ 	//
//	//if (!Py_NoSiteFlag)
//	//	initsite(); /* Module site */
//
//	Py_Initialize();
//
//	//int numargs = argc;
//	Py_InitModule ( "CTerm", CTerm_Methods );
//
//	pName = PyString_FromString ( argv[1] );
//	// Error checking of pName left out
//
//	pModule = PyImport_Import ( pName );
//	Py_DECREF ( pName );
//
//	if ( pModule != NULL )
//	{
//		pDict = PyModule_GetDict ( pModule );
//		// pDict is a borrowed reference
//
//		pFunc = PyDict_GetItemString ( pDict, argv[2] );
//		// pFun: Borrowed reference
//
//		if ( pFunc && PyCallable_Check ( pFunc ) )
//		{
//			pArgs = PyTuple_New ( argc - 3 );
//			for ( i = 0; i < argc - 3; ++i )
//			{
//				pValue = PyInt_FromLong ( _ttoi ( argv[i + 3] ) );
//				if ( !pValue )
//				{
//					Py_DECREF ( pArgs );
//					Py_DECREF ( pModule );
//					_ftprintf ( stderr, "Cannot convert argument\n" );
//					return 1;
//				}
//				// pValue reference stolen here:
//				PyTuple_SetItem ( pArgs, i, pValue );
//			}
//			pValue = PyObject_CallObject ( pFunc, pArgs );
//			Py_DECREF ( pArgs );
//			if ( pValue != NULL )
//			{
//				_tprintf ( "Result of call: %ld\n", PyInt_AsLong ( pValue ) );
//				Py_DECREF ( pValue );
//			}
//			else
//			{
//				Py_DECREF ( pModule );
//				PyErr_Print();
//				_ftprintf ( stderr, "Call failed\n" );
//				return 1;
//			}
//			// pDict and pFunc are borrowed and must not be Py_DECREF-ed
//		}
//		else
//		{
//			if ( PyErr_Occurred() )
//				PyErr_Print();
//			_ftprintf ( stderr, _T ( "Cannot find function \"%s\"\n" ), argv[2] );
//		}
//		Py_DECREF ( pModule );
//	}
//	else
//	{
//		PyErr_Print();
//		_ftprintf ( stderr, _T ( "Failed to load \"%s\"\n" ), argv[1] );
//		return 1;
//	}
//	Py_Finalize();
//	return 0;
//}

#endif

// code�ﲻ�ܼӻ��У������������
// exec "import os
// os.startfile(...)"
void RunPythonCode(CString sCode, int nSessionID)
{
#if ENABLE_PYTHON

	if (!g_bEnablePython || !g_bSysPythonScriptLoaded)
		return;

	SetScriptInfo(IDS_PY_RUN_CODE);

	char str[32];

	_stprintf(str, "%ld", nSessionID);

	char *argv[2] = {str, NULL};

	// get the global python thread lock
	PyEval_AcquireLock();

	// get a reference to the PyInterpreterState
	extern PyThreadState *mainThreadState;

	PyInterpreterState *mainInterpreterState = mainThreadState->interp;

	// create a thread state object for this thread
	PyThreadState *myThreadState = PyThreadState_New(mainInterpreterState);

	PyThreadState_Swap(myThreadState);

	PySys_SetArgv(1, argv);

	CString sBuffer;

	CString sInfo1, sInfo2;

	sInfo1.LoadString(IDS_PY_ERROR);

	sInfo2.LoadString(IDS_PY_FINISH);

	//if ( ! sInfo1.LoadString ( IDS_PY_ERROR ) ); //do nothing
	//if ( ! sInfo2.LoadString ( IDS_PY_FINISH ) );
	sBuffer.Format(
	    "import thread,re,string,sys,traceback,CTerm\n\n"
	    "def work_thread():\n"
	    "\ttry:\n"
	    "\t\texec '%s'\n" //���ﲻҪ��r����Ϊcode�������\n
	    "\texcept:\n"
	    "\t\texc, val, tb = sys.exc_info()\n"
	    "\t\tlines = traceback.format_exception(exc, val, tb)\n"
	    "\t\terr = string.join(lines)\n"
	    "\t\tprint err\n"
	    "\t\tSetScriptInfo('%s'+err)\n"
	    "\t\tsys.exit()\n\n"
	    "\tSetScriptInfo('%s')\n"
	    "thread0=thread.start_new_thread(work_thread, ())\n"
	    "\n", sCode, sInfo1, sInfo2);

	PyRun_String(sBuffer, Py_file_input, g_pDict, 0);

	//Clean up this thread's python interpreter reference
	PyThreadState_Swap(NULL);

	PyThreadState_Clear(myThreadState);

	PyThreadState_Delete(myThreadState);

	PyEval_ReleaseLock();

#endif
}

// todo: ׷�ӷ�ʽ������ʱ���
void logerr(TCHAR *errinfo)
{
	FILE *fp = NULL;
	CString logfile = g_szWorkDir + _T("temp\\pyerr.log");

	if ((fp = _tfopen(logfile, _T("w"))) != NULL) {
		fwrite(errinfo, _tcslen(errinfo), 1, fp);
		fclose(fp);
	}
}

#if ENABLE_PYTHON
// ����״̬���Ľű���Ϣ
// ��Ϊ��python�����̵߳��ã�������Ҫ��postmessage
// wParamΪһ�ַ�����ַ
LRESULT CMainFrame::OnSetScriptInfo(WPARAM wParam, LPARAM lParam)
{
	if (wParam) {
		TCHAR *s = (TCHAR*) wParam;
		SetStatus(ID_INDICATOR_SCRIPT, s);

		if (g_bPythonLog) {
			logerr(s);
		}
	}

	return 1;
}

#endif//ENABLE_PYTHON
