// AddrBookDlg.cpp : implementation file
// �򿪵�ַ��

#include "stdafx.h"

#if ENABLE_ADDRBOOK

#include "AddrBookDlg.h"
#include "global.h"
#include "paramconfig.h"
#include "debugtool.h"
//#include "usermsg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern bool g_bAllowSameSiteName;
extern bool g_bAddrFullName;
/////////////////////////////////////////////////////////////////////////////
// CAddrBookDlg dialog

#define SetNewSel(i)	{m_list.SetSel(-1, FALSE); m_list.SetSel(i);}

#define OLD_ADDRBOOK_VER 0xabcd4321
#ifdef _UNICODE
#define ADDRBOOK_VER 2
#else
#define ADDRBOOK_VER OLD_ADDRBOOK_VER //��unicode��Ŀǰ��OLD_ADDRBOOK_VER���ݣ��������
#endif

const UINT manage_btn_ids[] = {IDC_ADDRTOP, IDC_ADDRUP, IDC_ADDRDOWN, IDC_ADDREND, IDC_ADDR_SORT, IDC_PASTE};
//, IDC_IMPORT, IDC_EXPORT
//, IDC_COPY, IDC_DELETE

CAddrBookDlg::CAddrBookDlg(CWnd* pParent /*=NULL*/, const TCHAR * file)
	: CDialog(CAddrBookDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddrBookDlg)
	m_addr = _T("");
	m_sitename = _T("");
	m_port = TELNET_PORT;
	m_sitetype = 1;
	m_bAutologin = FALSE;
	m_szStartSite = _T("");
	m_ssh = FALSE;
	//m_filename = _T("");
	m_nFavorite = 0;
	m_keyword = _T("");
	//}}AFX_DATA_INIT
	m_bInited = false;
	m_nSiteNum = 0;
	addrbookver = ADDRBOOK_VER;

	Init(file);
}


void CAddrBookDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddrBookDlg)
	DDX_Control(pDX, IDC_CHECK_AUTOLOGIN, m_chkAutoLogin);
	DDX_Control(pDX, IDC_LIST2, m_list2);
	DDX_Control(pDX, IDC_SITETYPE, m_sitetype_ctrl);
	DDX_Control(pDX, IDC_SITENAME, m_sitename_ctrl);
	DDX_Control(pDX, IDC_PORT, m_port_ctrl);
//	DDX_Control(pDX, IDC_IMPORT, m_import);
	DDX_Control(pDX, IDC_ADDR, m_addr_ctrl);
	DDX_Control(pDX, IDC_DELETE, m_delete);
	DDX_Control(pDX, IDC_ADD, m_add);
	DDX_Control(pDX, IDC_ADV, m_adv);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_ADDR, m_addr);
	DDV_MaxChars(pDX, m_addr, 200);
	DDX_Text(pDX, IDC_SITENAME, m_sitename);
	DDV_MaxChars(pDX, m_sitename, 39);
	DDX_Text(pDX, IDC_PORT, m_port);
	DDV_MinMaxInt(pDX, m_port, 0, 65535);
	DDX_CBIndex(pDX, IDC_SITETYPE, m_sitetype);
	DDX_Check(pDX, IDC_CHECK_AUTOLOGIN, m_bAutologin);
	DDX_Text(pDX, IDC_STARTSITE, m_szStartSite);
	DDX_Check(pDX, IDC_SSH, m_ssh);
	//DDX_Text(pDX, IDC_EDITFILENAME, m_filename);
	DDX_Text(pDX, IDC_KEYWORD, m_keyword);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddrBookDlg, CDialog)
//{{AFX_MSG_MAP(CAddrBookDlg)
ON_BN_CLICKED(IDC_ADV, OnAdv)
ON_BN_CLICKED(IDC_ADD, OnAdd)
ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
ON_BN_CLICKED(IDC_DELETE, OnDelete)
ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
ON_EN_CHANGE(IDC_ADDR, OnChangeCtvAddr)
ON_EN_CHANGE(IDC_PORT, OnChangeCtvPort)
ON_EN_CHANGE(IDC_SITENAME, OnChangeCtvSitename)
ON_CBN_SELCHANGE(IDC_SITETYPE, OnSelchangeSitetype)
ON_BN_CLICKED(IDC_ADDRUP, OnUp)
ON_BN_CLICKED(IDC_ADDRDOWN, OnDown)
ON_BN_CLICKED(IDC_ADDREND, OnEnd)
ON_BN_CLICKED(IDC_ADDRTOP, OnTop)
ON_BN_CLICKED(IDC_FAVOTITEADD, OnFavotiteAdd)
ON_BN_CLICKED(IDC_FAVOTITEDEL, OnFavotiteDel)
ON_LBN_SELCHANGE(IDC_LIST2, OnSelchangeList2)
ON_LBN_DBLCLK(IDC_LIST2, OnDblclkList2)
ON_BN_CLICKED(IDC_FAVOTITEUP, OnFavotiteUp)
ON_BN_CLICKED(IDC_FAVOTITEDOWN, OnFavotiteDown)
ON_BN_CLICKED(IDC_ADDR_SORT, OnSort)
ON_BN_CLICKED(IDC_CHECK_AUTOLOGIN, OnCheckAutologin)
ON_BN_CLICKED(IDC_STARTSITESET, OnStartsiteSet)
ON_EN_CHANGE(IDC_STARTSITE, OnChangeStartsite)
ON_BN_CLICKED(IDC_COPY, OnCopy)
ON_BN_CLICKED(IDC_PASTE, OnPaste)
ON_BN_CLICKED(IDC_SSH, OnSsh)
ON_BN_CLICKED(IDC_OPENBOK, OnOpenbok)
ON_EN_CHANGE(IDC_KEYWORD, OnChangeKeyword)
ON_BN_CLICKED(IDC_NEWSITE, OnNewsite)
	ON_EN_SETFOCUS(IDC_KEYWORD, OnSetfocusKeyword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddrBookDlg message handlers

UINT CF_CTADDR;
BOOL CAddrBookDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
#if ENABLE_MULTILANG
	g_SetDialogStrings(this, IDD);
#endif// ENABLE_MULTILANG
	
	if (m_pszFile.IsEmpty())
		CDialog::OnCancel();

	UpdateData(FALSE);
	
	if (CheckHeader(m_pszFile)) {
		m_Site.SetDefault(_T(""));
		if (!m_bInited) {
			// �б���ctor���Ѿ����¹��ˣ�������û��updateui
			// assert: initlistֻ��ctor����FALSE�������ù�
			m_bInited = InitList();
		}
		else {
			UpdateUI();
		}
		
		if (m_bInited) {
			OnSelchangeList1();
			UpdateList2();
		}
	}
	
	
#if ENABLE_BTNST
	m_add.SetFlat(0);
	
	//m_add.SetIcon(IDI_ADD);
	m_adv.SetFlat(0);
	
	//m_adv.SetIcon(IDI_PROPERITY);
	m_delete.SetFlat(0);
	
	//m_delete.SetIcon(IDI_DELETE);
//	m_import.SetFlat(0);
	
	//m_import.SetIcon(IDI_IMPORT);
#endif //ENABLE_BTNST
	
	SetIcon(AfxGetApp()->LoadIcon(IDI_ADDRLIST), FALSE);
	
	m_keyword = _T("�ؼ��ֻ���ĸ");
	UpdateData(FALSE);

	str2vec(m_StartSites, m_szStartSite);

	//	SetTimer(TIMER_ADDRBOOK, 100, NULL);
	
	CF_CTADDR = RegisterClipboardFormat(_T("Cterm_AddrBook"));
	
	//SetNewSel(0);
	
	//	AfxGetMainWnd()->SendMessage ( WM_SETSITE, 0, ( LPARAM ) &m_Site );
	
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);
		
		m_tooltip.AddTool(GetDlgItem(IDC_ADDR_SORT), IDS_ADDRDLG_SORT);
		m_tooltip.AddTool(GetDlgItem(IDC_OPENBOK), CString(m_pszFile));
		m_tooltip.AddTool(GetDlgItem(IDC_COPY), _T("����վ��"));
		m_tooltip.AddTool(GetDlgItem(IDC_PASTE), _T("ճ��վ��"));
		m_tooltip.AddTool(GetDlgItem(IDC_ADDRTOP), _T("�Ƶ�����"));
		m_tooltip.AddTool(GetDlgItem(IDC_ADDRUP), _T("վ������"));
		m_tooltip.AddTool(GetDlgItem(IDC_ADDRDOWN), _T("վ������"));
		m_tooltip.AddTool(GetDlgItem(IDC_ADDREND), _T("�Ƶ�����"));
	}

	{
		m_BalloonToolWnd.Create(this);
		//m_BalloonToolWnd.SetWidth(200);
		//m_BalloonToolWnd.SetBkColor(RGB(213,253,224)); //RGB(210,210,255) violet
		//m_BalloonToolWnd.SetFrameColor(RGB(0,106,53));
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	
	// EXCEPTION: OCX Property Pages should return FALSE
}

bool CAddrBookDlg::InitList(BOOL bInitCtrls)
{
	m_szProfileName.clear();
		
	m_nSiteNum = 0;
	
	if (m_pszFile.IsEmpty())
		return false;
	
	FILE *fp = _tfopen(m_pszFile, _T("rb"));
	
	if (fp == NULL) {
		DWORD err = GetLastError();
		// ���������ʾ������ʱ���������
		// һ������BOOL CCTermApp::InitInstance()
		// 		CTelnetSite *pSite=AddrBook.FindSite(g_szUser, g_sAddressBook, g_szLastSiteName);
		// �����ϴ�վ��
		// ����һ����
		// 	//����ʱ�Զ�����վ��
		//	if (g_szStartSite[0]!='\0')
		//		ConnectSite(g_szStartSite);
		// todo: Ӧ�÷��ش���ԭ�򣬱����������
		
		if (err == 2 || err == 3)
			MessageBox(_T("ָ���ĵ�ַ���ļ���·��δ�ҵ���"), _T("��ַ��"), MB_OK | MB_ICONINFORMATION);
		else
			MessageBox(_T("�򿪵�ַ���ļ�ʧ�ܡ�"), _T("��ַ��"), MB_OK | MB_ICONINFORMATION);
		
		return false;
	}
	
	//Wait for write
	fseek(fp, 0, SEEK_END);
	
	int filelen = ftell(fp);
	
	int sitenum = (filelen - 200) / sizeof(CTelnetSite);
	
	if (sitenum < 0) return false;  //wrong file
	
	// sitenum==0 //no site in file
	
	m_szProfileName.reserve(sitenum);
	
	fseek(fp, 200, SEEK_SET);
	
	bool bGot = false;
	
	int pos = 0;
	
	int  i = 0;
	
	do {
		bGot = GetSite(pos++);
		
		if (bGot) {
			CString sTitle(m_Site.m_Login.m_szProfileName);
			m_szProfileName.push_back(sTitle);
			//_tcscpy ( m_szProfileName[i], sTitle );
			
			i++;
		}
	} while (bGot);  //&& i < 256 );
	
	m_nSiteNum = i;
	
	fclose(fp);

	if (bInitCtrls) {
		UpdateUI();
	}
	
	return true;
}

void CAddrBookDlg::UpdateUI()
{
	//��FindSite��ʱ����Ҫ���½��棬�ò��������������
	
	int selpos = -1;
	selpos = m_list.GetCurSel();
	
	UpdateList();
	//int n=m_list.GetCount(); //==m_nSiteNum
	
	if (m_nSiteNum > 0) {
		if (selpos < 0 || selpos >= m_nSiteNum) selpos = 0;
		
		SetNewSel(selpos);
		
		OnSelchangeList1();
	}
}

void CAddrBookDlg::OnAdv()		//��_T("��ַ��"))�����е��_T("����")��ť,����һ��վ�������
{
	int pos = m_list.GetCurSel();
	int data = m_list.GetItemData(pos);
	if (data && !m_keyword.IsEmpty()) {
		// ������Ӧ�ǵȼ۵�
		// data��0, ��ʾ������ģʽ
		pos = data;
	}

	if (pos >= 0) {
		//if ( ! GetSite ( pos, _T( "" ), false ) ) return;
		GetSite(pos, _T(""), false);
		
		UpdateData();
		m_Site.m_Login.m_nPort = m_port;
		_tcscpy(m_Site.m_Login.m_szProfileName, (LPCTSTR) m_sitename);
		_tcscpy(m_Site.m_Login.m_szAddr, (LPCTSTR) m_addr);
		m_Site.SetSiteType(m_sitetype);
		m_Site.m_Login.m_bAutoLogin = m_bAutologin;
		m_Site.m_Login.m_bSSH = m_ssh;
		
		if (SetOneSite(&m_Site)) {
			// ����_T("վ������")����,��������
			if (pos < m_nSiteNum)
				SetSite(pos, m_Site);	// д�뵽��ַ����
			else
				InsertSite(0, m_Site);
			
			m_addr = m_Site.m_Login.m_szAddr;
			m_port = m_Site.m_Login.m_nPort;
			m_sitename = m_Site.m_Login.m_szProfileName;
			m_sitetype = m_Site.SiteType();
			m_bAutologin = bool (m_Site.m_Login.m_bAutoLogin);
			m_Site.m_Login.m_bSSH = m_ssh;
			
			//(m_Site.m_Login.m_szAddr[0]!=0 && m_Site.m_Login.m_szLoginName[0]!=0 && m_Site.m_Login.m_szLoginPSW[0]!=0);
			
			//pSite->m_Login.m_bSSH=LoginDlg.m_bSSH;
			
			UpdateData(FALSE);
			
			m_bInited = InitList();
			
			m_add.EnableWindow(FALSE);
		}
		else {
			GetSite(pos);
		}
	}
}

//bat 11:16  04-6-28	����վ��������λ
//����=>������£���ʾ���ǣ��������Կ��õ�ǰ���ԡ��������ǡ�
//����ַΪ�գ������µĿհ�վ�㣬����Ϊ��ǰѡ������
void CAddrBookDlg::OnAdd()	// ����/���� վ��
{
	UpdateData();
	
	if (m_sitename.IsEmpty()) {
		MessageBox(_T("��Ϊվ��ȡ����"), _T("��ַ��"), MB_OK | MB_ICONINFORMATION);
		return;
	}
	
	if (m_addr.IsEmpty()) {
		// �����µĿհ�վ��
		CTelnetSite site;
		site.SetDefault(_T(""), m_sitetype);
		_tcscpy(site.m_Login.m_szProfileName, (LPCTSTR) m_sitename);
		InsertSite(0, site);
	} else {
		// AfxGetMainWnd()->SendMessage ( WM_SETSITE, 0, ( LPARAM ) &m_Site );
		
		CString proto;
		int port = GetPort(m_addr, proto);
		
		if (port != 0) m_port = port;   //�˿�
		
		m_Site.m_Login.m_nPort = m_port;
		
		_tcscpy(m_Site.m_Login.m_szAddr, m_addr);	// ��ַ
		
		_tcscpy(m_Site.m_Login.m_szProfileName, (LPCTSTR) m_sitename);
		
		m_Site.SetSiteType(m_sitetype);
		
		m_Site.m_Login.m_bAutoLogin = m_bAutologin;
		
		m_Site.m_Login.m_bSSH = m_ssh;
		
		CTelnetSite site = m_Site;
		
		InsertSite(0, site);
	}
}

//��m_Site�����0��λ��
//��������-1
//���򷵻ز���վ�������
//�ú�������0����ʱ����������
//��������������ʱ�ͻ�����⣺m_Site�ᱻ����
int CAddrBookDlg::InsertSite(int index, CTelnetSite &site)
{
	if (index < 0) {
		//׷�ӵ�ĩβ
		AddSiteTail(site);
		index = m_nSiteNum - 1;
	} else {
		TCHAR ts[300] = _T("");
		
		//Check Name
		int i;
		
		for (i = 0;i < m_nSiteNum;i++) {
			CString sTitle(site.m_Login.m_szProfileName);
			
			int size = m_szProfileName.size();
			
			if (i < size) {
				if (sTitle.CompareNoCase(m_szProfileName[i]) == 0)
					break;
			}
		}
		
		bool bOverWrite = false;
		
		if (i < m_nSiteNum && !g_bAllowSameSiteName) {   //����������
			_stprintf(ts, _T("վ��\"%s\"�Ѿ����ڣ����Ƿ�?"), CString(site.m_Login.m_szProfileName));
			
			if (MessageBox(ts, _T("��ַ��"), MB_YESNO) == IDNO)
				return -1;
			else
				bOverWrite = true;
		}
		
		FILE *fptemp = NULL;
		
		if (bOverWrite) {
			ASSERT(i < m_nSiteNum);
			SetSite(i, site);    //����iû�б��޸ģ�����Ҫ����վ�������
			index = i;
			m_add.EnableWindow(FALSE);
		} else {
			// ��д����ʱ�ļ���
			_stprintf(ts, m_pszFile);
			_tcscat(ts, _T(".!!!"));
			fptemp = _tfopen(ts, _T("wb"));
			
			if (fptemp == NULL) {
				MessageBox(_T("����д�뵽վ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
				return -1;
			}
			
			AddrBookHeader(fptemp);
			
			for (i = 0; i < index ; i++) {   //�ȸ���ǰ���
				if (GetSite(i))
					WriteSite(fptemp);
			}
			
			// ���ӵ�վ��д�ڵ�index��
			WriteSite(fptemp, site);
			
			// ����ԭ��վ����Ϣ����ʱ�ļ�
			for (i = index;i < m_nSiteNum;i++) {
				if (GetSite(i))
					WriteSite(fptemp);
			}
			
			fclose(fptemp);
			
			m_nSiteNum++;
			
			CopyFile(ts, m_pszFile, FALSE);	// ������ʱ�ļ���ʵ�ʵ�ַ���ļ�
			DeleteFile(ts);
		}//else //no overWrite
	}
	
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(index);
		OnSelchangeList1();
	}
	
	return index;
}

inline void CAddrBookDlg::WriteSite(FILE *fp, CTelnetSite &site)
{
	ASSERT(fp != NULL);
	site.StrClear();
	EncodePsw(site.m_Login.m_szLoginPSW);
	EncodePsw(site.m_Login.m_szProxyPSW);
	fwrite(&site, sizeof(CTelnetSite), 1, fp);
	DecodePsw(site.m_Login.m_szLoginPSW);
	DecodePsw(site.m_Login.m_szProxyPSW);
}

inline void CAddrBookDlg::WriteSite(FILE *fp)
{
	ASSERT(fp != NULL);
	WriteSite(fp, m_Site);
}

bool CAddrBookDlg::AddrBookHeader(FILE *fp)
{
	fseek(fp, 0, SEEK_SET);
	
	//д�汾��
	fwrite((void *)&addrbookver, sizeof(addrbookver), 1, fp);
	//��ǰ�ĵ�ַ����ͷ��guest���ܺ�����ݣ�0x: 63 16 15 26 36 00 -> c . . & 6 .
	//���԰汾�Ų�������ظ�
	
	EncodePsw(m_szUserName);    //���û��ã�����δ�ã��û�������guest�������
	fwrite(m_szUserName, MAX_USER_NAME + sizeof(TCHAR), 1, fp);
#define PAD_LEN	  ( 200 - MAX_USER_NAME - sizeof(TCHAR) - sizeof( addrbookver ) )
	BYTE buf[ PAD_LEN ] = "";
#ifdef _DEBUG
	memset(buf, 0xDE, sizeof(buf));
#endif//_DEBUG
	fwrite(buf, PAD_LEN, 1, fp);
	DecodePsw(m_szUserName);
	return true;
}

bool CAddrBookDlg::CheckHeader(CString file)
{
	bool bRet = false;
	FILE *fp = _tfopen(file, _T("rb"));
	
	if (fp) {
		bRet = CheckHeader(fp);
		fclose(fp);
	} else {
		//MessageBox(_T("���ܴ򿪵�ַ���ļ�"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		bRet = false;
	}
	
	return bRet;
}

bool CAddrBookDlg::CheckHeader(FILE *fp)
{
	fseek(fp, 0, SEEK_SET);
	
	//���汾��
	int ver = 0;
	fread((void *)&ver, sizeof(ver), 1, fp);
	
	if (ver == 0x26151663) ver = OLD_ADDRBOOK_VER;
	
	// ��ǰ�ĵ�ַ����ͷ��guest���ܺ�����ݣ�0x: 63 16 15 26 36 00 -> c . . & 6 .
	// ���԰汾�Ų�������ظ�
	if (addrbookver != ver) {
		AfxMessageBox(_T("��ַ���汾������!"));
		return false;
	}
	
	return true;
}

// ׷�ӵ�ʱ���Щ������Ҫ��ʱ�ļ���ֱ��׷�Ӿ��У����Ե���д������
bool CAddrBookDlg::AddSiteTail(CTelnetSite &site)	// д�뵽��ַ���ļ���
{
	FILE *fp;
	int  nSize;
	
	if (m_pszFile.IsEmpty())
		return false;
	
	fp = _tfopen(m_pszFile, _T("rb"));
	
	if (fp == NULL) {
		fp = _tfopen(m_pszFile, _T("wb"));
		
		if (fp == NULL) {   //���userĿ¼�����ڣ����������󣩣�����ʱ��ѭ����ʾ�������
			DWORD err = GetLastError();
			
			if (err == ERROR_PATH_NOT_FOUND) {
				CString s, f(m_pszFile);
				int i = f.ReverseFind('\\');
				
				if (i != -1) {
					f = f.Left(i);
					s.Format(_T("Ŀ¼%s�����ڣ��Ƿ񴴽���"), f);
					
					if (MessageBox(s, _T("��ַ��"), MB_YESNO | MB_ICONQUESTION) == IDYES) {
						CreateDirectory(f, NULL);
						fp = _tfopen(m_pszFile, _T("wb"));
					} else
						return false;
				} else {
					ASSERT(false);
					MessageBox(_T("���ܴ򿪵�ַ���ļ�"), _T("��ַ��"), MB_OK | MB_ICONERROR);
					return false;
				}
			} else {
				MessageBox(_T("���ܴ򿪵�ַ���ļ�"), _T("��ַ��"), MB_OK | MB_ICONERROR);
				return false;
			}
		}
		
		AddrBookHeader(fp);
	} else {
		fclose(fp);
		fp = _tfopen(m_pszFile, _T("ab"));
	}
	
	m_szProfileName.push_back(CString(site.m_Login.m_szProfileName));
	
	//	_tcscpy ( m_szProfileName[m_nSiteNum], CString ( site.m_Login.m_szProfileName ) );
	m_nSiteNum++;
	
	fseek(fp, 0, SEEK_END);
	
	nSize = sizeof(CTelnetSite);
	
	WriteSite(fp, site);
	
	fclose(fp);
	
	//	UpdateList();
	return true;
}

void CAddrBookDlg::UpdateList()
{
	int i, at;
	m_list.ResetContent();
	
	for (i = 0;i < m_nSiteNum;i++) {
		CString sTitle(m_szProfileName[i]);
		// todo: �ò���Ӧ������һ������
		
		if (!g_bAddrFullName) {
			// ����ʾվ��������ʾ��λ����վ��
			//while(*sTitle && *(pTitle++)!='-');//������λ����
			//if(*pTitle==0) pTitle=m_Site.m_Login.m_szProfileName;
			int pos = sTitle.Find('-');
			
			if (pos != -1) {
				sTitle = sTitle.Right(sTitle.GetLength() - pos - 1);
			}
		}
		
		at = m_list.AddString(sTitle);
		
		m_list.SetItemData(at, 0);    //�����0
	}
	
	m_keyword.Empty();
	UpdateData(FALSE);
	// �ָ����й�����ť
	CWnd *pBtn = NULL;
	for (i = 0; i < sizeof(manage_btn_ids) / sizeof(UINT); ++i) {
//#pragma warning( disable : 4706 )
		//if (pBtn = GetDlgItem(manage_btn_ids[i])) {
		pBtn = GetDlgItem(manage_btn_ids[i]);
		if (pBtn) {
			pBtn->EnableWindow(TRUE);
		}
//#pragma warning( default : 4706 )
	}

	m_list.SetFocus();
}

// ����ֵ���ɹ��򷵻�true������false
// ��һ�ļ����������ɼ�ȡ�������ַ���ļ��ж�ȡ
bool CAddrBookDlg::GetSite(int nIndex, CString filename, bool bReportError)
{
	if (filename.IsEmpty()) {
		ASSERT(m_pszFile);
		filename = m_pszFile;
		//		if ( nIndex >= m_nSiteNum )
		//			return false;
	}
	
	FILE *fp = _tfopen(filename, _T("rb"));
	
	if (fp == NULL) {
		if (bReportError) MessageBox(_T("�򿪵�ַ���ļ�����"));
		
		return false;
	}
	
	//	if ( !CheckHeader( fp ) ) return false;
	bool bRet = false;
	
	fseek(fp, 0, SEEK_END);
	
	long filelen = ftell(fp);
	
	long pos = nIndex *sizeof(CTelnetSite) + 200;
	
	if (pos < filelen) {
		if (fseek(fp, pos, SEEK_SET) == 0) {
			if (fread(&m_Site, sizeof(CTelnetSite), 1, fp) == 1) {
				DecodePsw(m_Site.m_Login.m_szLoginPSW);
				DecodePsw(m_Site.m_Login.m_szProxyPSW);
				bRet = true;
				//��֤��Ч��
				m_Site.m_Login.Validate();//���ⳬ��, ͬʱ����pLoginSet
				//����ʱ����г������ݺ���ı����Ѿ���������Ҳ�����
				//Ҫд������ܳ���������֮ǰ�ͱ�֤
			}
		}
	}
	
	fclose(fp);
	
	return bRet;
}

void CAddrBookDlg::OnSelchangeList1()
{
	m_add.EnableWindow(FALSE);
	int pos = m_list.GetCurSel();
	int data = m_list.GetItemData(pos);
	if (data && !m_keyword.IsEmpty()) {
		// ������Ӧ�ǵȼ۵�
		// data��0, ��ʾ������ģʽ
		pos = data;
	}
	
	if (pos >= 0) {
		if (GetSite(pos)) {
			m_addr = m_Site.m_Login.m_szAddr;
			m_port = m_Site.m_Login.m_nPort;
			m_sitename = m_Site.m_Login.m_szProfileName;
			m_sitetype = m_Site.SiteType();
			m_bAutologin = bool (m_Site.m_Login.m_bAutoLogin);
			m_ssh = m_Site.m_Login.m_bSSH;
			//(m_Site.m_Login.m_szAddr[0]!=0 && m_Site.m_Login.m_szLoginName[0]!=0 && m_Site.m_Login.m_szLoginPSW[0]!=0);
			UpdateData(FALSE);
			
			if (m_keyword.IsEmpty()) {
				int i;
				for (i = 0; i < m_nFavorite; i++) {   // ��favorite����list����ͬ��
					//				if ( !_tcscmp ( m_szProfileName[pos], m_szFavorite[i] ) )
					if (m_szProfileName[pos].CompareNoCase(m_szFavorite[i]) == 0)
						break;
				}
				
				if (i > m_nFavorite) {   //not found
					return;
				}
				
				m_list2.SetCurSel(i);
			}
		}
	}
}

void CAddrBookDlg::OnSelchangeList2()		// ���ܵ�ַ������ͬ��
{
	if (!m_keyword.IsEmpty()) {
		// �˳�����ģʽ
		exitSearch();
	}

	m_add.EnableWindow(FALSE);
	int pos = m_list2.GetCurSel();
	int i = 0;
	
	if (pos >= 0) {
		for (i = 0; i < m_nSiteNum; i++) {
			//			if ( !_tcscmp ( m_szProfileName[i], m_szFavorite[pos] ) )
			if (m_szProfileName[i].CompareNoCase(m_szFavorite[pos]) == 0)
				break;
		}
		
		if (i >= m_nSiteNum) {   //not found
			return;
		}
	} else
		return;
	
	ASSERT(m_keyword.IsEmpty() || m_keyword == _T("�ؼ��ֻ���ĸ"));
	SetNewSel(i);
	
	if (i >= 0) {
		if (GetSite(i)) {
			m_addr = m_Site.m_Login.m_szAddr;
			m_port = m_Site.m_Login.m_nPort;
			m_sitename = m_Site.m_Login.m_szProfileName;
			m_sitetype = m_Site.SiteType();
			m_bAutologin = bool (m_Site.m_Login.m_bAutoLogin);
			m_ssh = m_Site.m_Login.m_bSSH;
			//(m_Site.m_Login.m_szAddr[0]!=0 && m_Site.m_Login.m_szLoginName[0]!=0 && m_Site.m_Login.m_szLoginPSW[0]!=0);
			UpdateData(FALSE);
		}
	}
}

void CAddrBookDlg::SetSite(int nIndex, CTelnetSite &Site)
{
	FILE *fp;
	
	if (nIndex >= m_nSiteNum) return;
	
	fp = _tfopen(m_pszFile, _T("r+b"));
	
	if (fp == NULL) return;
	
	if (fseek(fp, nIndex*sizeof(CTelnetSite) + 200, SEEK_SET))
		return;
	
	WriteSite(fp, Site);
	
	fclose(fp);
}

// ����վ�㵽ԭλ�ã�������ڵĻ�
BOOL CAddrBookDlg::SaveSite(CTelnetSite * pSite)
{
	int i;
	
	for (i = 0;i < m_nSiteNum;i++) {
		//		if ( !_tcsicmp ( CString ( pSite->m_Login.m_szProfileName ), m_szProfileName[i] ) )
		if (m_szProfileName[i].CompareNoCase(pSite->m_Login.m_szProfileName) == 0)
			break;
	}
	
	if (i >= m_nSiteNum)
		return FALSE;
	
	FILE *fp = _tfopen(m_pszFile, _T("r+b"));
	
	if (fp == NULL) return FALSE;
	
	if (fseek(fp, i*sizeof(CTelnetSite) + 200, SEEK_SET))
		return FALSE;
	
	WriteSite(fp, *pSite);
	
	fclose(fp);
	
	return TRUE;
}

//ɾ��վ��
void CAddrBookDlg::OnDelete()
{
	exitSearch();

	int count = m_list.GetSelCount();
	
	if (count > 0) {
		if (count > 1) {
			if (AfxMessageBox(_T("���Ҫɾ�����վ��(�޷��ָ�)?"), MB_YESNO) == IDNO)
				return;
		} else {
			if (AfxMessageBox(_T("���Ҫɾ��(�޷��ָ�)?"), MB_YESNO) == IDNO)
				return;
		}
		
		//init
		CString tmpfile(m_pszFile);
		
		tmpfile += _T(".!!!");
		
		FILE *fptemp = _tfopen(tmpfile, _T("wb"));
		
		if (fptemp == NULL) {
			MessageBox(_T("������ʱ�ļ�ʧ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
			return;
		}
		
		LPINT rgIndex = new int[count];
		
		count = m_list.GetSelItems(count,  rgIndex);
		
		AddrBookHeader(fptemp);
		
		int i;
		
		for (i = 0; i < count ; i++) {
			//��ɾ�����
			m_list.SetItemData(rgIndex[i], -1);
		}
		
		for (i = 0; i < m_nSiteNum; i++) {
			//��δ��ǵ���Ŀ������ʱ�ļ�
			if (m_list.GetItemData(i) != -1) {
				if (GetSite(i))
					WriteSite(fptemp);
			}
		}
		
		fclose(fptemp);
		
		CopyFile(tmpfile, m_pszFile, FALSE);
		DeleteFile(tmpfile);
		m_bInited = InitList(); //��ʼ��ʱ����ɾ�����
		
		if (m_bInited) {
			if (m_nSiteNum > rgIndex[0]) SetNewSel(rgIndex[0]);
			
			OnSelchangeList1();
		}
		
		delete [] rgIndex;
		
	}
}


void CAddrBookDlg::OnDblclkList1()
{
	OnOK();
}

void CAddrBookDlg::OnOK()
{
	UpdateData();
	
	int pos = m_list.GetCurSel();
	int data = m_list.GetItemData(pos);
	if (data && !m_keyword.IsEmpty()) {
		// ������Ӧ�ǵȼ۵�
		// data��0, ��ʾ������ģʽ
		pos = data;
	}
	
	if (pos >= 0) {
		GetSite(pos);
	}
	
	//�õ�ǰ�������ӣ���������
	m_Site.m_Login.m_nPort = m_port;
	
	_tcscpy(m_Site.m_Login.m_szProfileName, (LPCTSTR) m_sitename);
	
	_tcscpy(m_Site.m_Login.m_szAddr, (LPCTSTR) m_addr);
	
	//	TRACEF(_T("address book"));
	//	TRACEF(m_Site.m_Login.m_szProfileName);
	//	TRACEF(m_Site.m_Login.m_szAddr);
	
	m_Site.SetSiteType(m_sitetype);
	
	m_Site.m_Login.m_bAutoLogin = m_bAutologin;
	
	//if(!bAutologin)
	//	m_Site.m_Login.m_AutoLogin.nNum=0;
	m_Site.m_Login.m_bSSH = m_ssh;
	
	CDialog::OnOK();
}

CTelnetSite *CAddrBookDlg::FindSite(const TCHAR *szUserName, const TCHAR *szFile, const TCHAR *szName)
{
	if (m_bInited) {
		for (int i = 0; i < m_nSiteNum; i++) {
			// if ( _tcsicmp ( szName, m_szProfileName[i] ) == 0 )
			if (m_szProfileName[i].CompareNoCase(szName) == 0) {
				if (GetSite(i))
					return &m_Site;
				else
					return NULL;
			}
		}
	}
	
	return NULL;
}

// �������漸���������ơ�����/���¡���ť
void CAddrBookDlg::OnChangeCtvAddr()
{
	if (m_addr_ctrl.GetModify()) {
		m_add.EnableWindow();
		m_bAutologin = FALSE;
		//UpdateData(FALSE);//����;(
		//m_chkAutoLogin.SetCheck(0);
	}
}

void CAddrBookDlg::OnChangeCtvPort()
{
	if (m_port_ctrl.GetModify()) {
		m_add.EnableWindow();
		m_bAutologin = FALSE;
		//m_chkAutoLogin.SetCheck(0);
	}
}

void CAddrBookDlg::OnChangeCtvSitename()
{
	if (m_sitename_ctrl.GetModify()) {
		m_add.EnableWindow();
	}
}

void CAddrBookDlg::OnCheckAutologin()
{
	m_add.EnableWindow();
}

void CAddrBookDlg::OnSelchangeSitetype()
{
	m_add.EnableWindow();
	
}

// todo: ������Щ�����ظ��úܶ࣬�Ժ���Ҫ�Ż�
// վ������
void CAddrBookDlg::OnUp()
{
	//	m_bChanged = TRUE;
	
	int pos = m_list.GetCurSel();
	
	if (pos <= 0) return;
	
	TCHAR ts[300] = _T("");
	
	_stprintf(ts, m_pszFile);
	
	_stprintf(ts, _T(".!!!"));
	
	FILE *fptemp = _tfopen(ts, _T("wb"));
	
	if (fptemp == NULL) {
		MessageBox(_T("�����ƶ�վ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		return;
	}
	
	AddrBookHeader(fptemp);
	
	int i;
	
	if (pos >= 2) {
		for (i = 0;i <= pos - 2;i++) {
			if (GetSite(i))
				WriteSite(fptemp);
		}
	}
	
	if (GetSite(pos))
		WriteSite(fptemp);
	
	if (GetSite(pos - 1))
		WriteSite(fptemp);
	
	for (i = pos + 1;i < m_nSiteNum;i++) {
		if (GetSite(i))
			WriteSite(fptemp);
	}
	
	fclose(fptemp);
	
	CopyFile(ts, m_pszFile, FALSE);
	DeleteFile(ts);
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(pos - 1);
		OnSelchangeList1();
		//		UpdateData(FALSE); //��OnSelchangeList1��update��
	}
}

void CAddrBookDlg::OnDown()		// վ������
{
	int pos = m_list.GetCurSel();
	
	if (pos < 0 || pos == m_list.GetCount() - 1)
		return;
	
	TCHAR ts[300] = _T("");
	
	_stprintf(ts, m_pszFile);
	
	_tcscat(ts, _T(".!!!"));
	
	FILE *fptemp = _tfopen(ts, _T("wb"));
	
	if (fptemp == NULL) {
		MessageBox(_T("�����ƶ�վ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		return;
	}
	
	AddrBookHeader(fptemp);
	
	int i;
	
	if (pos > 0) {
		for (i = 0;i <= pos - 1;i++) {
			if (GetSite(i))
				WriteSite(fptemp);
		}
	}
	
	if (GetSite(pos + 1))
		WriteSite(fptemp);
	
	if (GetSite(pos))
		WriteSite(fptemp);
	
	for (i = pos + 2;i < m_nSiteNum;i++) {
		if (GetSite(i))
			WriteSite(fptemp);
	}
	
	fclose(fptemp);
	
	CopyFile(ts, m_pszFile, FALSE);
	DeleteFile(ts);
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(pos + 1);
		OnSelchangeList1();
	}
}

void CAddrBookDlg::OnTop()		// վ���Ƶ�����
{
	int pos = m_list.GetCurSel();
	
	if (pos <= 0) return;
	
	TCHAR ts[300] = _T("");
	
	_stprintf(ts, m_pszFile);
	
	_tcscat(ts, _T(".!!!"));
	
	FILE *fptemp = _tfopen(ts, _T("wb"));
	
	if (fptemp == NULL) {
		MessageBox(_T("�����ƶ�վ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		return;
	}
	
	AddrBookHeader(fptemp);
	
	if (GetSite(pos))
		WriteSite(fptemp);
	
	int i;
	
	if (pos > 0) {
		for (i = 0;i <= pos - 1;i++) {
			if (GetSite(i))
				WriteSite(fptemp);
		}
	}
	
	for (i = pos + 1;i < m_nSiteNum;i++) {
		if (GetSite(i))
			WriteSite(fptemp);
	}
	
	fclose(fptemp);
	
	CopyFile(ts, m_pszFile, FALSE);
	DeleteFile(ts);
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(0);
		OnSelchangeList1();
	}
}

void CAddrBookDlg::OnEnd()		// վ���Ƶ��ײ�
{
	int pos = m_list.GetCurSel();
	
	if (pos < 0 || pos >= m_nSiteNum - 1) return;
	
	TCHAR ts[300] = _T("");
	
	_stprintf(ts, m_pszFile);
	
	_tcscat(ts, _T(".!!!"));
	
	FILE *fptemp = _tfopen(ts, _T("wb"));
	
	if (fptemp == NULL) {
		MessageBox(_T("�����ƶ�վ��"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		return;
	}
	
	AddrBookHeader(fptemp);
	
	int i;
	
	if (pos > 0) {
		for (i = 0;i <= pos - 1;i++) {
			if (GetSite(i))
				WriteSite(fptemp);
		}
	}
	
	for (i = pos + 1;i < m_nSiteNum;i++) {
		if (GetSite(i))
			WriteSite(fptemp);
	}
	
	if (GetSite(pos))
		WriteSite(fptemp);
	
	fclose(fptemp);
	
	CopyFile(ts, m_pszFile, FALSE);
	
	DeleteFile(ts);
	
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(m_list.GetCount() - 1);
		OnSelchangeList1();
	}
}

void CAddrBookDlg::OnSort()		// վ������
{
	if (AfxMessageBox(__T("�Ƿ����ҪĨƽ���д���(�޷��ָ�)?"), MB_YESNO) == IDNO)
		return;
	
	//	m_bChanged = TRUE;
	
	TCHAR ts[300] = _T("");
	
	_stprintf(ts, m_pszFile);
	
	_tcscat(ts, _T(".!!!"));
	
	FILE *fptemp = _tfopen(ts, _T("wb"));
	
	if (fptemp == NULL) {
		MessageBox(_T("������ʱ�ļ�ʧ�ܣ�"), _T("��ַ��"), MB_OK | MB_ICONERROR);
		return;
	}
	
	AddrBookHeader(fptemp);
	
	CListBox tmpList; //for sort
	CRect rect(0, 0, 100, 100);
	tmpList.Create(LBS_STANDARD | LBS_SORT, rect, this, 0);
	
	int i = 0;
	
	for (i = 0;i < m_nSiteNum;i++) {
		CString sTitle(m_szProfileName[i]);
		
		if (!g_bAddrFullName) {
			// ����ʾվ��������ʾ��λ����վ��
			//while(*sTitle && *(pTitle++)!='-');//������λ����
			//if(*pTitle==0) pTitle=m_Site.m_Login.m_szProfileName;
			int pos = sTitle.Find('-');
			
			if (pos != -1) {
				sTitle = sTitle.Right(sTitle.GetLength() - pos - 1);
			}
		}
		
		int at = tmpList.AddString(sTitle);
		
		tmpList.SetItemData(at, i);   //����ָ������վ����������
	}
	
	for (i = 0;i < m_nSiteNum;i++) {
		//CString name;
		//tmpList.GetText(i, name);
		int idx = tmpList.GetItemData(i);    //ָ��ԭ��������վ��
		//AfxMessageBox(name); //sorted
		CString sProfile = m_szProfileName[idx]; //����ֱ����m_szProfileName[idx]����ΪFindSite�����m_szProfileName.clear(), ������ô�
		CTelnetSite *pSite = FindSite(g_szUser, g_sAddressBook, sProfile);
		
		if (pSite)
			WriteSite(fptemp, *pSite);
	}
	
	fclose(fptemp);
	
	CopyFile(ts, m_pszFile, FALSE);
	DeleteFile(ts);
	m_bInited = InitList();
	
	if (m_bInited && m_list.GetCount() > 0) {
		SetNewSel(m_nSiteNum);
		OnSelchangeList1();
	}
}

void CAddrBookDlg::UpdateList2()
{
	m_list2.ResetContent();
	
	int i, at;
	
	for (i = 0;i < m_nFavorite;i++) {
		at = m_list2.AddString(m_szFavorite[i]);
	}
}

void CAddrBookDlg::OnFavotiteAdd()
{
	if (!isempty(m_Site.m_Login.m_szProfileName) && m_nFavorite < MAX_FAVORITE_NUM) {
		// check existance first
		for (int i = 0; i < m_nFavorite; ++i) {
			if (stricmp(m_szFavorite[i], m_Site.m_Login.m_szProfileName) == 0)
			 return;
		}
		_tcscpy(m_szFavorite[m_nFavorite], CString(m_Site.m_Login.m_szProfileName));
		m_nFavorite++;
		UpdateList2();
	}
}

void CAddrBookDlg::OnFavotiteDel()
{
	int pos = m_list2.GetCurSel();
	
	if (pos < 0) return;
	
	//	m_szFavotite[pos][0]=0;
	if (pos < m_nFavorite - 1) {
		for (int i = pos; i < m_nFavorite; i++) {
			_tcscpy(m_szFavorite[i], m_szFavorite[i+1]);
		}
	}
	
	m_nFavorite--;
	
	UpdateList2();
}

void CAddrBookDlg::OnDblclkList2()
{
	OnOK();
}

void CAddrBookDlg::OnFavotiteUp()
{
	int pos = m_list2.GetCurSel();
	
	if (pos <= 0) return;
	
	TCHAR tmp[40] = _T("");
	
	_tcscpy(tmp, m_szFavorite[pos-1]);
	
	_tcscpy(m_szFavorite[pos-1], m_szFavorite[pos]);
	
	_tcscpy(m_szFavorite[pos], tmp);
	
	UpdateList2();
	
	if (m_list2.GetCount() > 0) {
		m_list2.SetCurSel(pos - 1);
		OnSelchangeList2();
	}
}

void CAddrBookDlg::OnFavotiteDown()
{
	int pos = m_list2.GetCurSel();
	
	if (pos < 0 || pos == m_nFavorite - 1) return;
	
	TCHAR tmp[40];
	
	_tcscpy(tmp, m_szFavorite[pos+1]);
	
	_tcscpy(m_szFavorite[pos+1], m_szFavorite[pos]);
	
	_tcscpy(m_szFavorite[pos], tmp);
	
	UpdateList2();
	
	if (m_list2.GetCount() > 0) {
		m_list2.SetCurSel(pos + 1);
		OnSelchangeList2();
	}
	
}

/*
void CAddrBookDlg::OnExport()
{
	SBasicAddress Item;
	
	CFileDialogEx fd(FALSE, _T("bok0"), _T("*.bok0"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("CTermIII ��ַ�������ļ� (*.bok0)|*.bok0|�����ļ� (*.*)|*.*||"));
	
	bool bAll = false;
	
	int selcount = m_list.GetSelCount();
	
	if (selcount <= 0)
		return;
	
	LPINT rgIndex = NULL;
	
	if (selcount > 1 && selcount < m_nSiteNum) {
		rgIndex = new int[selcount];
		
		if (!rgIndex)
			return;
		
		selcount = m_list.GetSelItems(selcount, rgIndex);
		
		if (selcount == LB_ERR)
			return;
		else if (selcount <= 0 || selcount >= m_nSiteNum)
			bAll = true;
	} else
		bAll = true;
	
	if (fd.DoModal() == IDOK) {
		FILE *fp = NULL;
		fp = _tfopen(fd.GetPathName(), _T("wb"));
		
		if (bAll)
			selcount = m_nSiteNum;
		
		int i;
		
		for (i = 0;i < selcount;i++) {
			int idx = bAll ? i : rgIndex[i];
			ASSERT(idx >= 0 && idx < m_nSiteNum);
			
			if (idx < 0 && idx >= m_nSiteNum)
				continue;
			
			if (GetSite(idx)) {
				_tcscpy(Item.m_szProfileName, m_Site.m_Login.m_szProfileName);	//վ��
				_tcscpy(Item.m_szAddr, m_Site.m_Login.m_szAddr);					// ��ַ
				Item.m_nPort = m_Site.m_Login.m_nPort;					// �˿�
				Item.m_nSiteType = m_Site.SiteType();			// ����
				Item.m_bSSH = m_Site.m_Login.m_bSSH;			// SSH
				//			_tcscpy(Item.m_szLoginName,m_Site.m_Login.m_szLoginName);	// �û���
				//			_tcscpy(Item.m_szLoginPSW, m_Site.m_Login.m_szLoginPSW);		// ����
				Item.m_nType = m_Site.m_Decode.m_nType;						// ����Э��
				Item.m_bEnterAsReturn = m_Site.m_Decode.m_bEnterAsReturn;		// �س�
				Item.m_bDoubleCode = m_Site.m_Decode.m_bDoubleCode;			// ˫�ֽ�
				fwrite(&Item, sizeof(SBasicAddress), 1, fp);
			}
		}
		
		fclose(fp);
		
		MessageBox(_T("��ַ���������(������վ�������Ϣ)."));
	}
	
	if (rgIndex)
		delete [] rgIndex;
}


void CAddrBookDlg::OnImport()	//����վ��
{
	FILE *fp;
	SBasicAddress Item;
	int n;
	CFileDialogEx fd(TRUE, _T("bok0"), _T("*.bok0"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("CTermIII ��ַ�������ļ�(*.bok0)|*.bok0|�����ļ�(*.*)|*.*||"));
	
	if (fd.DoModal() == IDOK) {
		fp = _tfopen(fd.GetPathName(), _T("rb"));
		
		if (fp == NULL) {
			MessageBox(_T("�ļ�������"));
			return;
		}
		
		do {
			n = fread(&Item, sizeof(SBasicAddress), 1, fp);

			int itemlen = _tcslen(Item.m_szAddr);
			if (itemlen > 40 || itemlen < 4	||
				Item.m_szAddr[0] < 0)
				//Item.m_nPort<=0||Item.m_nPort>65535||
			{
				MessageBox(_T("�ļ���ʽ�����޷�ת����"));
				fclose(fp);
				return;
			}
			
			if (n) {
				m_Site.SetDefault(Item.m_szAddr);
				//				AfxGetMainWnd()->SendMessage ( WM_SETSITE, 0, ( LPARAM ) &m_Site );
				m_Site.m_Login.m_nPort = Item.m_nPort;
				_tcscpy(m_Site.m_Login.m_szProfileName, Item.m_szProfileName);
				
				m_Site.SiteType() = Item.m_nSiteType;			// ����
				m_Site.m_Login.m_bSSH = Item.m_bSSH;			// SSH
				//			_tcscpy(Item.m_szLoginName,m_Site.m_Login.m_szLoginName);	// �û���
				//			_tcscpy(Item.m_szLoginPSW, m_Site.m_Login.m_szLoginPSW);		// ����
				m_Site.m_Decode.m_nType = Item.m_nType;						// ����Э��
				m_Site.m_Decode.m_bEnterAsReturn = Item.m_bEnterAsReturn;		// �س�
				m_Site.m_Decode.m_bDoubleCode = Item.m_bDoubleCode;			// ˫�ֽ�
				//				fwrite(&Item,sizeof(SBasicAddress),1,fp);
				
				//���ؼ���3�ֿ��ܣ�
				//1 m_pszFileΪ�գ���̫���ܷ�����
				//2 userĿ¼�����ڣ�����������
				//3 ����֧��256��վ��
				m_Site.StrClear();
				
				if (!AddSiteTail(m_Site))
					break;
			}
		} while (n);
		
		fclose(fp);
	}
	
	UpdateList();
}
*/

// ��������ʱ�Զ����ӵ�վ��
void CAddrBookDlg::OnStartsiteSet()
{
	bool bFound = false;
	for(vector<CString>::iterator it = m_StartSites.begin(); it != m_StartSites.end(); ++it) {
		if (*it == m_Site.m_Login.m_szProfileName) {
			bFound = true;
			break;
		}
	}

	if (!bFound) {
		m_StartSites.push_back(m_Site.m_Login.m_szProfileName);
	}

	vec2str(m_StartSites, m_szStartSite);
	UpdateData(FALSE);
}

void CAddrBookDlg::OnChangeStartsite()
{
	// If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	UpdateData();
}

void CAddrBookDlg::OnCopy()
{
	exitSearch();
	
	int selcount = m_list.GetSelCount();
	
	if (selcount > 0) {
		HGLOBAL hmem;
		BYTE *p = NULL;
		
		int size = sizeof(addrbookver) + sizeof(selcount) + sizeof(CTelnetSite) * selcount;
		hmem = GlobalAlloc(GMEM_FIXED, size);
		
		if (hmem == NULL) {
			CloseClipboard();
			AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
			return;
		}
		
		p = (BYTE*) GlobalLock(hmem);
		
		//		BYTE* pOri=p;
		
		if (p) {
			if (!OpenClipboard()) {
				AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
			}
			else {
				* ((int*) p) = addrbookver;    // ��ַ���汾��
				p += sizeof(addrbookver);
				* ((int*) p) = selcount;    // ���Ƶ�վ�����
				p += sizeof(selcount);
				
				LPINT rgIndex = new int[selcount];
				selcount = m_list.GetSelItems(selcount,  rgIndex);
				
				for (int i = 0; i < selcount ; i++) {
					if (rgIndex[i] >= 0) {
						if (GetSite(rgIndex[i])) {
							memcpy(p, (BYTE*)(&m_Site), sizeof(m_Site));
							p += sizeof(m_Site);
						}
					}
				}
				
				delete [] rgIndex;
				
				EmptyClipboard();
				
				SetClipboardData(CF_CTADDR, hmem);		// �� p ���Ƶ�������
				CloseClipboard();
				GlobalUnlock(hmem);

				//m_tooltip.Pop();
				//m_tooltip.AddTool(GetDlgItem(IDC_LIST1), _T("վ����Ϣ�ѿ���"));
				//m_tooltip.SetDelayTime(10);
				//m_tooltip.Activate(TRUE);

//				m_tooltip.Update();
				//POINT pt;
//				MSG msg = {GetSafeHwnd(), WM_MOUSEMOVE, 0, 0, 500, {0, 0}};
//				m_tooltip.RelayEvent(&msg);
				//PostMessage(WM_MOUSEMOVE);

				m_BalloonToolWnd.AddTool(GetDlgItem(IDC_LIST1), "վ����Ϣ�ѿ���");
				//PostMessage(WM_SHOWTIP);
			}
		}
	}
}

void CAddrBookDlg::OnPaste()
{
	HGLOBAL hmem;
	BYTE* p = NULL;
	
	if (!OpenClipboard()) {
		AfxMessageBox(_T("ERROR: Cannot open the Clipboard!"));
		return;
	}
	
	hmem = GetClipboardData(CF_CTADDR);
	
	if (hmem) {
		p = (BYTE *) GlobalLock(hmem);
		
		if (p) {
			int ver = *((int*)p);
			
			if (ver == addrbookver) {
				p += sizeof(int);
				int count = * ((int*) p);
				p += sizeof(int);
				int idx = 0;
				CTelnetSite site;
				
				for (int i = 0; i < count; i++) {
					site = * ((CTelnetSite*) p);
					p += sizeof(CTelnetSite);
					idx = InsertSite(idx, site);
					
					if (idx == -1) {
						AfxMessageBox(_T("����վ�����"));						
					}
					else {
						idx++;
					}
				}
			}
			
			//else wrong ver!
		}
	}
	
	GlobalUnlock(hmem);
	
	CloseClipboard();
}

BOOL CAddrBookDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);
	}
	
	m_BalloonToolWnd.RelayEvent(pMsg);

	if (pMsg->message == WM_KEYDOWN) {
		if (pMsg->wParam == VK_RETURN) {
			OnOK(); //�κ�ʱ�򰴻س�������
			//return TRUE;//never here
		} else if (GetFocus() == GetDlgItem(IDC_LIST1)) {
			bool bCtrl = isdown(VK_CONTROL);
			
			if (pMsg->wParam == VK_UP) {
				if (m_list.GetCurSel() == 0) {
					SetNewSel(m_list.GetCount() - 1);
					OnSelchangeList1();
					return TRUE;
				}
			} else if (pMsg->wParam == VK_DOWN) {
				if (m_list.GetCurSel() == m_list.GetCount() - 1) {
					SetNewSel(0);
					OnSelchangeList1();
					return TRUE;
				}
			} else if (pMsg->wParam == VK_DELETE) {
				OnDelete();
				return TRUE;
			} else if (pMsg->wParam == VK_BACK) {
				// �˸��������������˳�����ģʽ
				if (!m_keyword.IsEmpty()) {
					exitSearch();
				}
				return TRUE;
			} else if (bCtrl) {
				switch (pMsg->wParam) {
					
				case 'C':
					OnCopy();
					break;
					
				case 'V':
					OnPaste();
					break;
					
				case VK_UP:
					OnUp();
					break;
					
				case VK_DOWN:
					OnDown();
					break;
					
				case VK_HOME:
					OnTop();
					break;
					
				case VK_END:
					OnEnd();
					
				case VK_RIGHT:
					OnFavotiteAdd();
					break;
					
				case VK_LEFT:
					OnFavotiteDel();
					break;
					
				default:
					return CDialog::PreTranslateMessage(pMsg);
				}
				
				return TRUE;
			}
		}//if( GetFocus()==GetDlgItem(IDC_LIST1) )
	}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CAddrBookDlg::OnSsh()
{
	UpdateData(TRUE);
	
	if (m_ssh)
		m_port = SSH_PORT;
	else
		m_port = TELNET_PORT;
	
	UpdateData(FALSE);
	
	m_add.EnableWindow();
}

void CAddrBookDlg::OnOpenbok()
{
	CFileDialogEx fd(TRUE, _T("bok"), m_pszFile, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("CTerm��ַ��(*.bok)|*.bok|�����ļ�(*.*)|*.*||"));
	
	if (fd.DoModal() == IDOK) {
		//m_filename = ;
		m_pszFile = fd.GetPathName();
		
		if (CheckHeader(m_pszFile)) {
			m_Site.SetDefault(_T(""));
			m_bInited = InitList();
			
			if (m_bInited) {
				OnSelchangeList1();
				UpdateList2();
			}
		}
		
		m_tooltip.AddTool(GetDlgItem(IDC_OPENBOK), CString(m_pszFile));
	}
}

void CAddrBookDlg::exitSearch(bool bEmptyed)
{
	if (!bEmptyed) {
		if (m_keyword.IsEmpty() || m_keyword == _T("�ؼ��ֻ���ĸ")) return;
		
		m_keyword.Empty();
		UpdateData(FALSE);
	}
	
	int size = m_szProfileName.size();
	int at, i;
	int pos = m_list.GetCurSel(); //GetCurSel should not be called for a multiple-selection list box. ?
	DWORD oldpos;
	if ((oldpos = m_list.GetItemData(pos)) != LB_ERR) {
		pos = (int)oldpos;
	} else {
		pos = -1;
	}

	int count = m_list.GetSelCount();
	LPINT rgIndex = new int[count];
	m_list.GetSelItems(count, rgIndex);

	for (i = 0; i < count; ++i) {
		if ((oldpos = m_list.GetItemData(rgIndex[i])) != LB_ERR) {
			rgIndex[i] = (int)oldpos;
		} else {
			rgIndex[i] = -1;
		}
	}
	
	m_list.ResetContent();
	for (i = 0; i < size; ++i) {
		at = m_list.AddString(m_szProfileName[i]);
		m_list.SetItemData(at, 0);
	}
	
	// �ָ����й�����ť
	CWnd *pBtn = NULL;
	for (i = 0; i < sizeof(manage_btn_ids) / sizeof(UINT); ++i) {
//#pragma warning( disable : 4706 )
		//if (pBtn = GetDlgItem(manage_btn_ids[i])) {
		pBtn = GetDlgItem(manage_btn_ids[i]);
		if (pBtn) {
			pBtn->EnableWindow(TRUE);
		}
//#pragma warning( default : 4706 )
	}
	
	for (i = 0; i < count; ++i) {
		if (rgIndex[i] != -1) {
			m_list.SetSel(rgIndex[i]);
		}
	}

	if (pos != -1) {
		m_list.SetSel(pos);
	}

	delete [] rgIndex;
}

void CAddrBookDlg::OnChangeKeyword() 
{
	// If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	UpdateData();
	
	int at, i;
	
	if (m_keyword.IsEmpty()) {
		exitSearch(true);
	}
	else {
		int size = m_szProfileName.size();

		m_list.ResetContent();
		CString s, k(m_keyword);
		k.MakeUpper();
		for (i = 0; i < size; ++i) {
			s = m_szProfileName[i];			
			s.MakeUpper();
			bool bFound = (s.Find(k) != -1);
			if (!bFound) {
				CString spell = getSheng(s);//GetChineseSpell(s);
				//spell = getSheng("��");//;GetChineseSpell("��");
				bFound = (spell.Find(k) != -1); //spell[0] != '<' && 
			}

			if (bFound) {
				at = m_list.AddString(m_szProfileName[i]);
				m_list.SetItemData(at, i); // ������ԭ�б��е�λ��
			}
		}
		
		// �������й�����ť
		CWnd *pBtn = NULL;
		for (i = 0; i < sizeof(manage_btn_ids) / sizeof(UINT); ++i) {
//#pragma warning( disable : 4706 )
			pBtn = GetDlgItem(manage_btn_ids[i]);
			if (pBtn) {
				pBtn->EnableWindow(FALSE);
			}
//#pragma warning( default : 4706 )
		}
		
		// ���ð�ť֮��ᵼ�±༭��ʧȥ����
//#pragma warning( disable : 4706 )
		//if (pBtn = GetDlgItem(IDC_KEYWORD)) {
		pBtn = GetDlgItem(IDC_KEYWORD);
		if (pBtn) {
			pBtn->SetFocus();
		}
//#pragma warning( default : 4706 )
	}
}

void CAddrBookDlg::OnNewsite() 
{
	m_addr = _T("");
	m_port = TELNET_PORT;	
	m_sitetype = ST_SMTH;
	m_bAutologin = FALSE;
	m_ssh = FALSE;
	UpdateData(FALSE);
	
	m_sitename = _T("");
	
	m_Site.SetDefault(_T(""), ST_SMTH);
	m_sitename_ctrl.SetWindowText(_T("��дվ����Ϣ����ע�Ᵽ��"));
	m_sitename_ctrl.SetFocus();
	m_sitename_ctrl.SetSel(0, -1, TRUE);
}

void CAddrBookDlg::Init(const TCHAR * file)
{
	m_pszFile = file ? file : g_sAddressBook;   // ��ַ���ļ�
	_tcsncpy(m_szUserName, g_szUser, MAX_USER_NAME); // ���û������������е��û�������
	m_szUserName[strlen(g_szUser)] = '\0';
	m_nFavorite = g_nFavoriteSite;		// �ҵ��վ�㣭����
	
	for (int i = 0; i < m_nFavorite; i++) {
		_tcscpy(m_szFavorite[i], g_szFavoriteSite[i]);	// �ҵ��վ��
	}
	
	m_szStartSite = g_szStartSite;	// ����ʱ�Զ����ӵ�վ��
	
	if (CheckHeader(m_pszFile)) {
		m_Site.SetDefault(_T(""));
		if (!m_bInited) {
			m_bInited = InitList(FALSE);
		}
	}
}

void CAddrBookDlg::UnInit() const
{
	g_szStartSite = m_szStartSite;
	
	g_nFavoriteSite = m_nFavorite;
	
	for (int i = 0; i < m_nFavorite; i++) {
		g_szFavoriteSite[i] = m_szFavorite[i];
	}
}

void CAddrBookDlg::OnSetfocusKeyword() 
{
	if (m_keyword == _T("�ؼ��ֻ���ĸ")) {
		m_keyword.Empty();
		UpdateData(FALSE);
	}
}
#endif//ENABLE_ADDRBOOK
