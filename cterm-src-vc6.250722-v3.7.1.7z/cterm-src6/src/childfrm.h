// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__2AC2BA98_FE64_11D3_B1BC_000080013F30__INCLUDED_)
#define AFX_CHILDFRM_H__2AC2BA98_FE64_11D3_B1BC_000080013F30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#if ENABLE_CLOSEDLG
#include "closedlg.h"
#endif//ENABLE_CLOSEDLG

class CCTermView;
class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)

public:
	CChildFrame();

// Attributes

public:

// Operations
	void SetTitle();
	// ȡ��tab��ʾ��title
	CString GetTabTitle() const;
	void SetTitle(const CString &t)
	{
		m_szTitle = t;
	}

//	const CString &GetTitle() const
//	{
//		return m_szTitle;
//	}

public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation

public:
	// view for the client area of the frame.
	CCTermView *m_pView;
	virtual ~CChildFrame();
//	int GetMyIndex();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions

protected:
#if ENABLE_CLOSEDLG
	CCloseDlg* m_pCloseDlg;
#endif//ENABLE_CLOSEDLG

	//{{AFX_MSG(CChildFrame)
	afx_msg void OnFileClose();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnChildActivate();
	afx_msg void OnFastaway();
	afx_msg void OnUpdateFastaway(CCmdUI* pCmdUI);
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg LRESULT OnConnectOK(WPARAM wParam, LPARAM lParam);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnWindowPosChanged(WINDOWPOS FAR* lpwndpos);
	afx_msg void OnMDIActivate(BOOL bActivate, CWnd* pActivateWnd, CWnd* pDeactivateWnd);
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
#if ENABLE_FULLSCRN
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
#endif//ENABLE_FULLSCRN
	DECLARE_MESSAGE_MAP()

private:
	CString m_szTitle;

private:
	void ChangeSize(WINDOWPOS FAR* lpwndpos); // before OnWindowPosChanging()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFRM_H__2AC2BA98_FE64_11D3_B1BC_000080013F30__INCLUDED_)
