#if !defined(AFX_SIMPLEFILTERDLG_H__68849BF9_F698_4922_AECA_90F0A632CF44__INCLUDED_)
#define AFX_SIMPLEFILTERDLG_H__68849BF9_F698_4922_AECA_90F0A632CF44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SimpleFilterDlg.h : header file
//

#if ENABLE_BTNST
#include "btnst.h"
#else
typedef CButton CButtonST;
#endif //ENABLE_BTNST

/////////////////////////////////////////////////////////////////////////////
// CSimpleFilterDlg dialog

#if ENABLE_FILTER

class CSimpleFilter;
class AFX_CLASS_EXPORT CSimpleFilterDlg : public CDialog
{
// Construction

public:
	CSimpleFilterDlg(CWnd* pParent = NULL);   // standard constructor
	CSimpleFilter *m_pFilter;

	int m_nType;
// Dialog Data
	//{{AFX_DATA(CSimpleFilterDlg)
	enum { IDD = IDD_SIMFILTER };
	CButtonST	m_delete;
	CListCtrl	m_list;
	BOOL	m_bBreak;
	CString	m_index;
	CString	m_reply;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSimpleFilterDlg)

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

protected:

	// Generated message map functions
	//{{AFX_MSG(CSimpleFilterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnClickFilterList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDelete();
	virtual void OnOK();
	afx_msg void OnUp();
	afx_msg void OnDown();
	afx_msg void OnSetdefault();
	afx_msg void OnModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void UpdateList();
	void UpdateItemDisplay();
	CImageList m_Image;
};

#endif//ENABLE_FILTER

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SIMPLEFILTERDLG_H__68849BF9_F698_4922_AECA_90F0A632CF44__INCLUDED_)
